REM SPDX-License-Identifier: AGPL-3.0-only
REM Copyright (C) 2026 Dimitris Galatsanos
@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Portivo.ps1"
endlocal
