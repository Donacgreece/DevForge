# Portivo Control Center Installation Guide

This document covers the supported deployment workflow for the Portivo Control Center release package on Windows and Linux.

## Windows

### Requirements

- 64-bit Windows 10, Windows 11 or Windows Server
- Administrator privileges during installation
- Internet access during the first installation and when an update needs a newer private runtime or dependency set
- TCP port `8766` available on the host

### Install

1. Extract the complete release ZIP to a local folder.
2. Double-click `Install Windows.cmd`.
3. Accept the Windows UAC prompt.
4. On a new installation, define the local Portivo administrator password.
5. Leave LAN access enabled when other computers must reach the Portivo server.
6. Select `Install Portivo`.
7. Wait for the installer health check to complete.

Portivo is installed to:

```text
C:\portivo-control-center
```

The installer configures the `Portivo Control Center` Windows Service with Automatic Delayed Start and automatic service recovery.

### v2.1.0-r5 polished uninstall experience

The r4 Windows installer runs its private-runtime import probe from the application root, avoiding a fresh-install failure before the service directory exists. The uninstaller docks its action buttons independently from scrollable content so **Uninstall Portivo** remains visible at high DPI.

Windows installs register **Portivo Control Center** in Windows Installed Apps and deploy a supported uninstaller. Linux installs deploy an equivalent root-owned uninstaller.

Standard uninstall removes the Portivo application, service/runtime, logs and installer-created firewall exposure while preserving `.env`, `data/` and `backups/` so a later reinstall can reuse the existing configuration and database.

Full Removal / Purge permanently deletes those preserved items only after an explicit warning. The uninstallers can optionally create a final backup before purge.

### v2.1.0-r6 lightweight health architecture

The bundled Linux installer ensures the platform `ping` utility is present (`iputils-ping` on Debian/Ubuntu or `iputils` on RHEL-family systems). Normal Auto health polling uses one ICMP echo. A failed ICMP is retried twice, five seconds apart by default. Only after all three ICMP attempts fail may Portivo issue one configured SNMPv3 `sysUpTime.0` confirmation.

TCP/22 and SSH are not part of switch availability monitoring in r6. If no SNMPv3 monitoring profile is configured, Auto stops after the confirmed ICMP failure. SNMP telemetry status remains independent from ping reachability, existing incident confirmation remains in effect, confirmed offline devices back off automatically, and deterministic per-switch jitter prevents large fleets from polling in lockstep.

### v2.0.0-r9 runtime and supply-chain checks

The Windows installer uses the official 64-bit CPython 3.13.15 installer for the Portivo-managed runtime directory. Before it is executed, the downloaded file must match the SHA-256 value pinned in `installer-manifest.json` and must have a valid Windows Authenticode signature. The WinSW service wrapper is also accepted only when its SHA-256 matches the pinned release digest. A mismatch aborts installation.

During a runtime upgrade, the previously working Portivo-managed Python directory is preserved transactionally until the new runtime, dependencies, database migration, service start and Portivo health check have all succeeded. If the upgrade fails, the installer restores the previous runtime together with the normal application/database safety backup.

Production dependency installation uses the exact `requirements.lock` set without opportunistically upgrading pip or asking pip to re-resolve transitive dependencies. On Windows, source distributions are rejected so dependency installation uses binary wheels only, followed by `pip check`.

When LAN access is enabled, the TCP `8766` firewall rule is configured for Domain, Private and Public Windows network profiles, matching the v1.6.1 installer behavior.

Local access:

```text
http://127.0.0.1:8766
```

LAN access:

```text
http://SERVER-IP:8766
```

### Update or Repair

Extract the newer release package and run `Install Windows.cmd` again. The installer detects the existing installation, stops the service, creates a safety backup, updates the application, refreshes dependencies, applies database migrations, repairs the service configuration when required and performs a health check before completing.

The database, `.env`, logs and backups are preserved during a normal update.

### Windows Troubleshooting

Service status:

```powershell
Get-Service PortivoControlCenter
```

Listening port:

```powershell
netstat -ano | findstr :8766
```

Firewall rule:

```powershell
Get-NetFirewallRule -DisplayName "Portivo Control Center TCP 8766" | Format-Table DisplayName,Enabled,Profile,Direction,Action
```

Network profile:

```powershell
Get-NetConnectionProfile
```

Expected listener for LAN access:

```text
0.0.0.0:8766  LISTENING
```

## Linux

### Recommended baseline

- Debian 12 or newer
- Ubuntu Server 24.04 LTS or newer
- 64-bit Linux with systemd
- Python 3.11 or newer
- root or sudo access
- Internet access during the first installation

### Install

```bash
chmod +x "Install Linux.sh"
./"Install Linux.sh"
```

Portivo is installed to:

```text
/opt/portivo-control-center
```

The installer creates a dedicated `portivo` service account and configures:

```text
portivo-control-center.service
```

The r9 service unit keeps the application/runtime tree root-owned and read-only to the service account. Only `data/`, `logs/` and `backups/` remain service-writable. The systemd sandbox also enables `NoNewPrivileges`, strict system protection, home/device isolation, private temporary storage, kernel/control-group protection and SUID/SGID restrictions.

Useful commands:

```bash
systemctl status portivo-control-center
systemctl restart portivo-control-center
journalctl -u portivo-control-center -f
```

### Update

Run the newer `Install Linux.sh` package again. The installer creates a safety backup, updates the application, refreshes the Python environment, applies database migrations and restarts the systemd service.

## Uninstall

### Windows

Use either **Settings → Apps → Installed apps → Portivo Control Center → Uninstall** or run:

```text
Uninstall Windows.cmd
```

The default **Standard uninstall** preserves `C:\portivo-control-center\.env`, `data\` and `backups\`. **Full removal / purge** deletes all Portivo local state only after confirmation.

### Linux

From the installer package:

```bash
sudo ./"Uninstall Linux.sh"
```

Or from an installed system:

```bash
sudo /opt/portivo-control-center/uninstall/"Uninstall Linux.sh"
```

The default mode preserves `.env`, `data/` and `backups/`. Use `--purge` for permanent removal or `--keep-data` for a non-interactive standard uninstall.

## Persistent Data

Protect the Portivo database and application environment as part of normal server backup policy. Deleting the installation directory manually can also delete local users, inventory, Jobs, Audit history and secrets when no separate backup exists.

## Network and Security

Portivo is intended for internal management networks. Do not expose TCP `8766` directly to the public Internet. Restrict access at the host firewall or upstream network firewall to the management subnets that require the application.

### HTTP on a trusted management LAN

The default deployment uses HTTP and `PUBLIC_URL_SCHEME=http`. Session cookies remain `HttpOnly` and `SameSite=Strict`, but they are not marked `Secure` because browsers do not return Secure cookies over plain HTTP. This mode should remain inside a trusted management network.

### HTTPS through a trusted reverse proxy

Portivo supports HTTPS deployments where TLS terminates at a trusted reverse proxy such as IIS, nginx or Apache and the proxy forwards requests to Portivo over the protected server-side path. Set the following in `.env` and restart the service:

```text
PUBLIC_URL_SCHEME=https
```

With this setting Portivo marks the session cookie `Secure` and emits HSTS. The application listener itself remains HTTP, so the reverse proxy is responsible for the certificate and TLS connection presented to users.

By default Portivo does not trust `X-Forwarded-For`. If login-rate limiting should use the original client address behind the proxy, enable proxy headers only for explicitly trusted direct proxy addresses:

```text
TRUST_PROXY_HEADERS=true
TRUSTED_PROXY_IPS=127.0.0.1,::1
```

Do not enable `TRUST_PROXY_HEADERS` when untrusted clients can connect directly to the Portivo listener, because forwarded source headers can otherwise be spoofed.

### Login protection and local password policy

Login throttling is enabled by default. It tracks failures by source IP plus username and also by source IP, applying progressive delays before authentication is allowed to reach local verification or SSH/AAA sources. It does not hard-lock an account.

New or changed local administrator passwords require 12 to 128 characters. Existing passwords from older releases remain valid after an upgrade until they are changed.

### Database backups

Admin database backup downloads use a temporary SQLite snapshot streamed directly from disk. The complete backup is not loaded into Portivo process memory. The temporary snapshot is removed automatically after the response finishes or if the backup request fails.

## Webhook notifications

After installation, sign in as a platform administrator and open **Notifications** from the main navigation. Add one or more destinations, choose Microsoft Teams / Power Automate, Slack, Discord or Generic JSON, paste the HTTPS webhook endpoint and use **Test** before enabling production alerts.

Configure the global incident policy in the same workspace, including All vs Selected scope, Site/Group filters, consecutive-failure threshold, recovery notifications and optional still-offline reminders.

Webhook URLs are treated as secrets and encrypted with `APP_SECRET_KEY`. Keep the same application secret when restoring the database to another installation, otherwise encrypted integration endpoints cannot be decrypted. Generic webhook endpoints must resolve to public HTTPS addresses.
