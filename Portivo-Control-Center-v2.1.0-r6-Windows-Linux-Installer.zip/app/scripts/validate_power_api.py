# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-power-api-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "power-api.db")
os.environ["APP_SECRET_KEY"] = "power-api-validation-secret-key-000000000000000000"
os.environ["APP_ADMIN_PASSWORD"] = "Portivo-Power-Validation-Admin-2026!"
os.environ["LOGIN_RATE_LIMIT_ENABLED"] = "false"

from fastapi.testclient import TestClient  # noqa: E402
from app.crypto import encrypt_secret  # noqa: E402
from app.db import db, init_db, utc_now  # noqa: E402
from app import main as main_module  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def add_device(name: str, host: str, site: str, group: str) -> int:
    now = utc_now()
    with db() as conn:
        cursor = conn.execute(
            """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at,last_status)
            VALUES(?,?,?,?,?,'OS6560-P24X4','8.10.105.R02','AOS8',1,'','','',?,?,'online')""",
            (name, host, 22, site, group, now, now),
        )
        return int(cursor.lastrowid)


def add_snmp_profile() -> int:
    now = utc_now()
    with db() as conn:
        cursor = conn.execute(
            """INSERT INTO monitoring_credential_profiles(
                name,method,username,snmp_port,snmp_auth_protocol,snmp_auth_password_enc,
                snmp_priv_protocol,snmp_priv_password_enc,last_status,created_at,updated_at,updated_by
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                "UPS Read Only", "snmpv3", "upsmonitor", 161, "SHA256", encrypt_secret("auth-pass-123456"),
                "AES128", encrypt_secret("priv-pass-123456"), "verified", now, now, "validator",
            ),
        )
        return int(cursor.lastrowid)


def main() -> int:
    init_db()
    from app.schemas import MonitoringCredentialProfileRequest
    des_profile = MonitoringCredentialProfileRequest(
        name="Legacy DES", method="snmpv3", username="snmpuser",
        snmp_auth_protocol="SHA", snmp_auth_password="auth-pass-123456",
        snmp_priv_protocol="DES", snmp_priv_password="priv-pass-123456",
    )
    require(des_profile.snmp_priv_protocol == "DES", "Monitoring credential schema rejected DES privacy")
    profile_id = add_snmp_profile()
    same_site_id = add_device("A-Access-01", "198.51.100.11", "Site A", "Access")
    other_site_id = add_device("B-Access-01", "203.0.113.11", "Site B", "Access")

    original_verify = main_module.verify_ups
    main_module.verify_ups = lambda host, monitoring_profile_id, driver_mode="auto", **kwargs: {
        "manufacturer": "APC by Schneider Electric",
        "model": "Smart-UPS SRT 3000",
        "driver_mode": driver_mode,
        "driver_key": "apc",
        "driver_name": "APC PowerNet",
        "sys_object_id": "1.3.6.1.4.1.318.1.3.27",
        "power_state": "normal",
        "output_source": "normal",
        "battery_status": "normal",
        "battery_charge_percent": 97,
        "runtime_minutes": 40,
        "load_percent": 35,
        "alarm_count": 0,
        "alarms": [],
        "telemetry": {
            "battery": [
                {"key":"battery_voltage","label":"Battery voltage","value":81.6,"unit":"V","source":"RFC 1628 UPS-MIB"},
                {"key":"battery_temperature","label":"Battery temperature","value":37,"unit":"°C","source":"APC PowerNet"},
            ],
            "input": [{"key":"input_voltage_1","label":"Input voltage L1","value":231,"unit":"V","source":"RFC 1628 UPS-MIB"}],
        } if kwargs.get("detailed") else {},
    }
    try:
        with TestClient(main_module.app) as client:
            login = client.post("/api/auth/login", json={"username": "admin", "password": os.environ["APP_ADMIN_PASSWORD"], "mode": "admin"})
            require(login.status_code == 200, f"Admin login failed: {login.text}")

            verified = client.post("/api/power/verify", json={"host": "198.51.100.60", "monitoring_profile_id": profile_id, "driver_mode": "auto"})
            require(verified.status_code == 200, f"UPS verify API failed: {verified.text}")
            require(verified.json().get("driver_key") == "apc", "UPS verify did not return detected APC driver")

            timeout_detail = "No SNMPv3 response from 198.51.100.61:161; OS-managed source using authPriv SHA256/AES128; fallback also timed out"
            main_module.verify_ups = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError(timeout_detail))
            timeout_result = client.post("/api/power/verify", json={"host": "198.51.100.61", "monitoring_profile_id": profile_id, "driver_mode": "apc"})
            require(timeout_result.status_code == 400, f"UPS timeout must be an actionable 400 response: {timeout_result.text}")
            require(timeout_result.json().get("detail") == timeout_detail, "UPS timeout diagnostic was hidden by the API")
            main_module.verify_ups = lambda host, monitoring_profile_id, driver_mode="auto", **kwargs: {
                "manufacturer": "APC by Schneider Electric",
                "model": "Smart-UPS SRT 3000",
                "driver_mode": driver_mode,
                "driver_key": "apc",
                "driver_name": "APC PowerNet",
                "sys_object_id": "1.3.6.1.4.1.318.1.3.27",
                "power_state": "normal",
                "output_source": "normal",
                "battery_status": "normal",
                "battery_charge_percent": 97,
                "runtime_minutes": 40,
                "load_percent": 35,
                "alarm_count": 0,
                "alarms": [],
                "telemetry": {
                    "battery": [
                        {"key":"battery_voltage","label":"Battery voltage","value":81.6,"unit":"V","source":"RFC 1628 UPS-MIB"},
                        {"key":"battery_temperature","label":"Battery temperature","value":37,"unit":"°C","source":"APC PowerNet"},
                    ],
                    "input": [{"key":"input_voltage_1","label":"Input voltage L1","value":231,"unit":"V","source":"RFC 1628 UPS-MIB"}],
                } if kwargs.get("detailed") else {},
            }

            created = client.post("/api/power/ups", json={
                "name": "Site-A-UPS-01", "host": "198.51.100.60", "site": "Site A", "group_name": "Power",
                "location": "Main rack", "monitoring_profile_id": profile_id, "driver_mode": "auto", "enabled": False,
            })
            require(created.status_code == 201, f"UPS create failed: {created.text}")
            ups_id = int(created.json()["id"])
            require(created.json().get("driver_mode") == "auto", "UPS driver mode was not persisted")

            assignment = client.put(f"/api/power/ups/{ups_id}/assignments", json={"device_ids": [same_site_id]})
            require(assignment.status_code == 200, f"Same-site protected-switch assignment failed: {assignment.text}")
            require(assignment.json().get("protected_switches") == 1, "Protected switch count is incorrect")

            rejected = client.put(f"/api/power/ups/{ups_id}/assignments", json={"device_ids": [same_site_id, other_site_id]})
            require(rejected.status_code == 400, "Cross-site UPS assignment must be rejected")

            inventory = client.get("/api/power")
            require(inventory.status_code == 200, inventory.text)
            body = inventory.json()
            require({item["key"] for item in body.get("drivers", [])} == {"auto", "generic", "xppc", "apc", "eaton", "vertiv", "socomec", "acculine", "cyberpower", "riello"}, "Power API driver catalog is incomplete")
            asset = next(item for item in body.get("ups", []) if int(item["id"]) == ups_id)
            require(asset.get("protected_switch_count") == 1, "Power inventory did not preserve protected-switch assignment")
            require(body.get("incidents") == [], "Power inventory must not preload incident history")

            stored_details = client.get(f"/api/power/ups/{ups_id}/details")
            require(stored_details.status_code == 200, f"UPS details API failed: {stored_details.text}")
            require(stored_details.json().get("protected_switches", [])[0].get("name") == "A-Access-01", "UPS details did not include protected switches")
            refreshed_details = client.post(f"/api/power/ups/{ups_id}/details/refresh")
            require(refreshed_details.status_code == 200, f"UPS detail refresh failed: {refreshed_details.text}")
            detail_body = refreshed_details.json()
            require(detail_body.get("telemetry", {}).get("battery"), "Detailed UPS telemetry was not returned")
            require(detail_body.get("telemetry_updated_at"), "Detailed UPS telemetry timestamp was not stored")
            with db() as conn:
                detail_row = conn.execute("SELECT telemetry_json, telemetry_updated_at FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
                require(bool(detail_row["telemetry_json"] and detail_row["telemetry_json"] != "{}"), "Detailed UPS telemetry was not persisted")
                require(bool(detail_row["telemetry_updated_at"]), "Detailed UPS telemetry update time was not persisted")

            # Power history is server-paginated at a hard maximum of 25 rows.
            now = utc_now()
            with db() as conn:
                for index in range(31):
                    kind = "ups_low_battery" if index % 3 == 0 else "ups_on_battery"
                    status = "open" if index in {29, 30} else "closed"
                    conn.execute(
                        """INSERT INTO power_incidents(ups_id,ups_name,incident_type,status,opened_at,recovered_at,details_json,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                        (ups_id, "Site-A-UPS-01", kind, status, now, now if status == "closed" else None, f'{{"reason":"validation event {index}"}}', now, now),
                    )
                # UPS communication loss is retained as informational Power
                # history, while notification routing remains disabled.
                conn.execute(
                    """INSERT INTO power_incidents(ups_id,ups_name,incident_type,status,opened_at,recovered_at,details_json,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""",
                    (ups_id, "Site-A-UPS-01", "ups_unreachable", "closed", now, now, '{"reason":"legacy reachability noise"}', now, now),
                )
            page_one = client.get("/api/power/incidents?page=1")
            require(page_one.status_code == 200, page_one.text)
            require(len(page_one.json().get("items", [])) == 25, "Power incident API must return at most 25 rows per page")
            require(page_one.json().get("pagination", {}).get("total") == 32, "Power incident total count is incorrect")
            require(page_one.json().get("pagination", {}).get("pages") == 2, "Power incident page count is incorrect")
            page_two = client.get("/api/power/incidents?page=2")
            require(len(page_two.json().get("items", [])) == 7, "Power incident second page is incorrect")
            open_only = client.get("/api/power/incidents?status=open")
            require(all(item.get("status") == "open" for item in open_only.json().get("items", [])), "Power incident status filter failed")
            unreachable_only = client.get("/api/power/incidents?incident_type=ups_unreachable")
            require(unreachable_only.json().get("pagination", {}).get("total") == 1, "UPS communication history must be visible in Power incidents")
            searched = client.get("/api/power/incidents?search=validation%20event%2030")
            require(searched.json().get("pagination", {}).get("total") == 1, "Power incident search failed")

            duplicate = client.post("/api/power/ups", json={
                "name": "Site-A-UPS-02", "host": "198.51.100.60", "site": "Site A", "group_name": "Power",
                "location": "Second rack", "monitoring_profile_id": profile_id, "driver_mode": "eaton", "enabled": False,
            })
            require(duplicate.status_code == 409, "Duplicate UPS management address must be rejected")

        print("PORTIVO POWER API VALIDATION: PASS")
        return 0
    finally:
        main_module.verify_ups = original_verify


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
