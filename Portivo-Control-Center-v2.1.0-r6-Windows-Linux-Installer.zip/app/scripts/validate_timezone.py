# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_SECRET_KEY", "timezone-validation-secret-key-00000000000000")
DB_PATH = Path(tempfile.gettempdir()) / "portivo-timezone-validation.db"
os.environ["DATABASE_PATH"] = str(DB_PATH)

from app.db import init_db, update_app_settings, utc_now
from app.notification_engine import _provider_payload
from app.time_service import format_platform_datetime, local_date_boundary_utc, platform_timezone_name

def cleanup() -> None:
    DB_PATH.unlink(missing_ok=True)
    Path(str(DB_PATH) + "-wal").unlink(missing_ok=True)
    Path(str(DB_PATH) + "-shm").unlink(missing_ok=True)

def main() -> int:
    cleanup()
    try:
        init_db()
        sample = "2026-08-13T18:10:00+00:00"
        assert "+00:00" in utc_now()
        update_app_settings({"platform_timezone": "Europe/Athens"}, "validator")
        assert platform_timezone_name() == "Europe/Athens"
        assert format_platform_datetime(sample) == "13/08/2026 21:10:00"
        assert local_date_boundary_utc("2026-08-13").isoformat().startswith("2026-08-12T21:00:00")
        assert local_date_boundary_utc("2026-08-13", end_of_day=True).isoformat().startswith("2026-08-13T21:00:00")
        payload = {"title":"Switch Offline","summary":"Validation","severity":"critical","occurred_at":sample,"event_id":"timezone-validation","event_type":"switch_offline","device":{"name":"SW1","ip":"192.0.2.1","site":"Site","group":"Group"},"health":{"failed_checks":3},"incident":{"last_reachable":"2026-08-13T18:09:00+00:00"}}
        teams = _provider_payload("microsoft", payload)
        assert "13/08/2026 21:10:00 (Europe/Athens)" in teams["text"]
        generic = _provider_payload("generic", payload)
        assert generic["occurred_at"] == sample
        assert generic["occurred_at_local"] == "13/08/2026 21:10:00 (Europe/Athens)"
        update_app_settings({"platform_timezone": "Europe/London"}, "validator")
        assert platform_timezone_name() == "Europe/London"
        assert format_platform_datetime(sample) == "13/08/2026 19:10:00"
        assert _provider_payload("generic", payload)["occurred_at"] == sample
        assert _provider_payload("generic", payload)["occurred_at_local"] == "13/08/2026 19:10:00 (Europe/London)"
    except Exception as exc:
        print(f"TIMEZONE VALIDATION: FAIL ({exc})")
        return 1
    finally:
        cleanup()
    print("TIMEZONE VALIDATION: PASS")
    return 0

if __name__ == "__main__": raise SystemExit(main())
