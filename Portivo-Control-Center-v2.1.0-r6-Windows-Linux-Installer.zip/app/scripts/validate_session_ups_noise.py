# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-session-ups-noise-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "validation.db")
os.environ.setdefault("APP_SECRET_KEY", "session-ups-noise-validation-secret-0000000000")

from app.db import db, init_db, utc_now  # noqa: E402
from app.notification_engine import purge_ups_reachability_noise  # noqa: E402
from app.power_monitor import _apply_result  # noqa: E402
from app.session_credentials import SessionCredentialStore  # noqa: E402


def main() -> int:
    # One personal access credential per username. A new login revokes the old
    # browser token while another username remains independent.
    store = SessionCredentialStore(ttl_seconds=3600)
    old_token = store.create("testoperator", "first-password")
    other_token = store.create("operator", "other-password")
    new_token = store.create("testoperator", "second-password")
    assert old_token != new_token
    assert store.get_device_credentials(old_token) is None
    assert store.get_device_credentials(new_token)["username"] == "testoperator"
    assert store.get_device_credentials(other_token)["username"] == "operator"
    assert store.count() == 2
    sessions = store.list_sessions()
    assert sum(1 for item in sessions if item["username"] == "testoperator") == 1

    init_db()
    now = utc_now()
    with db() as conn:
        profile = conn.execute(
            """INSERT INTO monitoring_credential_profiles(name,method,username,created_at,updated_at,updated_by)
               VALUES('UPS validation','snmpv3','upsuser',?,?, 'validation')""",
            (now, now),
        )
        profile_id = int(profile.lastrowid)
        conn.execute(
            """INSERT INTO ups_devices(id,name,host,monitoring_profile_id,enabled,last_status,last_seen,power_state,
                   consecutive_failures,created_at,updated_at,updated_by)
               VALUES(1,'UPS-TEST','192.0.2.50',?,1,'online',?,'normal',0,?,?, 'validation')""",
            (profile_id, now, now, now),
        )

    # Failed SNMP reads remain transient until the shared notification-policy
    # confirmation threshold is reached. The default policy is three checks.
    _apply_result(1, None, "SNMP request timed out", utc_now())
    with db() as conn:
        row = conn.execute("SELECT last_status,power_state,consecutive_failures FROM ups_devices WHERE id=1").fetchone()
        assert row["last_status"] == "online"
        assert row["power_state"] == "normal"
        assert int(row["consecutive_failures"]) == 1
        assert conn.execute("SELECT COUNT(*) FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()[0] == 0

    _apply_result(1, None, "SNMP request timed out again", utc_now())
    with db() as conn:
        row = conn.execute("SELECT last_status,power_state,consecutive_failures FROM ups_devices WHERE id=1").fetchone()
        assert row["last_status"] == "online"
        assert row["power_state"] == "normal"
        assert int(row["consecutive_failures"]) == 2
        assert conn.execute("SELECT COUNT(*) FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()[0] == 0

    _apply_result(1, None, "SNMP request timed out third time", utc_now())
    with db() as conn:
        row = conn.execute("SELECT last_status,power_state,consecutive_failures FROM ups_devices WHERE id=1").fetchone()
        assert row["last_status"] == "unreachable"
        assert row["power_state"] == "normal"
        assert int(row["consecutive_failures"]) == 3
        incident = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()
        assert incident is not None and incident["status"] == "open"
        assert conn.execute("SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')").fetchone()[0] == 0

        # Even an old reachability webhook row must be purged and the retired
        # destination switch must stay disabled, while Power history is kept.
        dest = conn.execute(
            """INSERT INTO notification_destinations(name,provider,enabled,webhook_url_enc,scope_mode,sites_json,groups_json,
               notify_offline,notify_recovery,notify_reminder,notify_stack_degraded,notify_stack_recovery,
               notify_ups_on_battery,notify_ups_power_restored,notify_ups_low_battery,notify_ups_unreachable,created_at,updated_at,updated_by)
               VALUES('Legacy','generic',0,'','all','[]','[]',1,1,1,1,1,1,1,1,1,?,?, 'validation')""",
            (now, now),
        )
        destination_id = int(dest.lastrowid)
        conn.execute(
            """INSERT INTO notification_outbox(event_id,destination_id,event_type,device_name,severity,status,attempts,next_attempt_at,created_at,power_incident_id,payload_json)
               VALUES('legacy-ups-unreachable',?, 'ups_unreachable','UPS-TEST','critical','failed',1,?,?,?,'{}')""",
            (destination_id, now, now, int(incident["id"])),
        )

    result = purge_ups_reachability_noise()
    assert result["incidents"] == 0
    assert result["deliveries"] >= 1
    with db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')").fetchone()[0] == 0
        assert conn.execute("SELECT notify_ups_unreachable FROM notification_destinations WHERE id=?", (destination_id,)).fetchone()[0] == 0
        assert conn.execute("SELECT last_status FROM ups_devices WHERE id=1").fetchone()[0] == "unreachable"

    # A successful poll closes only the informational communication incident.
    snapshot = {
        "manufacturer": "Validation", "model": "UPS", "software_version": "", "reported_name": "UPS",
        "driver_key": "generic", "sys_object_id": "1.3.6.1.2.1.33", "power_state": "normal",
        "output_source": "normal", "battery_status": "normal", "battery_charge_percent": 100,
        "runtime_minutes": 30, "seconds_on_battery": 0, "load_percent": 20, "alarm_count": 0, "alarms": [],
    }
    _apply_result(1, snapshot, "", utc_now())
    with db() as conn:
        row = conn.execute("SELECT last_status,consecutive_failures FROM ups_devices WHERE id=1").fetchone()
        assert row["last_status"] == "online" and int(row["consecutive_failures"]) == 0
        incident = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()
        assert incident is not None and incident["status"] == "closed" and incident["recovered_at"]
        assert conn.execute("SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')").fetchone()[0] == 0

    print("PORTIVO SESSION + UPS NOISE VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
