# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
legal = (ROOT / "LEGAL.md").read_text(encoding="utf-8")
third = (ROOT / "THIRD_PARTY_NOTICES.md").read_text(encoding="utf-8")
trademarks = (ROOT / "TRADEMARKS.md").read_text(encoding="utf-8")
index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
main = (ROOT / "app/main.py").read_text(encoding="utf-8")
version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()

assert version == "2.1.0", version
assert license_text.startswith("                    GNU AFFERO GENERAL PUBLIC LICENSE")
assert "Version 3, 19 November 2007" in license_text
assert "13. Remote Network Interaction; Use with the GNU General Public License." in license_text
assert "AGPL-3.0-only" in readme
assert "AGPL-3.0-only" in legal
assert "License separation" in third
assert (ROOT / "requirements.in").is_file()
assert (ROOT / "requirements.lock").is_file()
assert (ROOT / "SBOM.spdx.json").is_file()
assert (ROOT / "CONTRIBUTING.md").is_file()
assert (ROOT / "THIRD_PARTY_LICENSES").is_dir()
assert "You may copy, modify and redistribute Portivo" in index
assert "login-legal-footer" in index
assert "GNU AGPL v3.0 license applies" in trademarks
assert 'href="/legal/notice"' in index
assert 'href="/legal/license"' in index
assert 'href="/legal/source"' in index
assert '@app.get("/legal/notice"' in main
assert '@app.get("/legal/license"' in main
assert '@app.get("/legal/source"' in main
assert 'window.PORTIVO_UI_REVISION="2.1.0-r6"' in index
assert "MIT License. See [LICENSE]" not in readme
print("PORTIVO AGPL LICENSING VALIDATION: PASS")
