# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    temp_dir = tempfile.TemporaryDirectory(prefix="portivo-ups-vendor-validation-")
    os.environ["DATABASE_PATH"] = str(Path(temp_dir.name) / "ups-vendor.db")
    os.environ.setdefault("APP_SECRET_KEY", "ups-vendor-validation-secret-key-000000000000")

    from app.db import init_db
    from app import power_monitor
    from app.power_drivers import (
        SYS_DESCR,
        SYS_OBJECT_ID,
        UPS_IDENT_MANUFACTURER,
        UPS_IDENT_MODEL,
        VERTIV_BATTERY_CAPACITY,
        VERTIV_BATTERY_RUNTIME,
        VERTIV_OUTPUT_LOAD,
        VERTIV_OUTPUT_SOURCE,
        VERTIV_SYSTEM_STATUS,
        XPPC_MODEL, XPPC_FIRMWARE, XPPC_BATTERY_STATUS, XPPC_BATTERY_CAPACITY, XPPC_RUNTIME_SECONDS,
        XPPC_OUTPUT_STATUS, XPPC_OUTPUT_LOAD, XPPC_BATTERY_VOLTAGE, XPPC_BATTERY_TEMPERATURE,
        XPPC_INPUT_VOLTAGE, XPPC_INPUT_FREQUENCY, XPPC_OUTPUT_VOLTAGE, XPPC_OUTPUT_FREQUENCY,
        power_driver_catalog,
    )

    init_db()
    catalog = {item["key"] for item in power_driver_catalog()}
    required = {"auto", "generic", "xppc", "vertiv", "socomec", "acculine", "apc", "eaton", "cyberpower", "riello"}
    if not required.issubset(catalog):
        raise AssertionError(f"UPS vendor drivers missing from catalog: {required - catalog}")
    catalog_rows = {item["key"]: item for item in power_driver_catalog()}
    if "OFYS-RT" not in catalog_rows["socomec"].get("name", "") or "OFYS-RT" not in catalog_rows["socomec"].get("models", ""):
        raise AssertionError("Socomec OFYS-RT coverage is missing from the runtime driver registry")
    if not catalog_rows["xppc"].get("models") or not catalog_rows["vertiv"].get("models"):
        raise AssertionError("Power driver family metadata is incomplete")

    standard = {
        SYS_DESCR: "Vertiv Liebert GXT5 with RDU101",
        SYS_OBJECT_ID: "1.3.6.1.4.1.476.1.42.3.9",
        UPS_IDENT_MANUFACTURER: "Vertiv",
        UPS_IDENT_MODEL: "Liebert GXT5-3000IRT2UXLE",
    }
    vendor = {
        VERTIV_SYSTEM_STATUS: "On Battery",
        VERTIV_OUTPUT_SOURCE: "3",
        VERTIV_BATTERY_CAPACITY: "94.0",
        VERTIV_BATTERY_RUNTIME: "26.5",
        VERTIV_OUTPUT_LOAD: "35.2",
    }

    original_get_many = power_monitor.snmpv3_get_many
    original_walk = power_monitor.snmpv3_walk
    try:
        def fake_get_many(host, profile, oids):
            result = {}
            for oid in oids:
                if oid in standard:
                    result[oid] = standard[oid]
                elif oid in vendor:
                    result[oid] = vendor[oid]
                else:
                    result[oid] = ""
            return result

        power_monitor.snmpv3_get_many = fake_get_many
        power_monitor.snmpv3_walk = lambda *args, **kwargs: []
        snapshot = power_monitor.probe_ups(
            "192.0.2.20",
            {"method": "snmpv3"},
            driver_mode="auto",
            detailed=True,
        )
    finally:
        power_monitor.snmpv3_get_many = original_get_many
        power_monitor.snmpv3_walk = original_walk

    if snapshot.get("driver_key") != "vertiv":
        raise AssertionError(f"Vertiv probe did not select vendor driver: {snapshot}")
    if snapshot.get("power_state") != "on_battery" or snapshot.get("battery_charge_percent") != 94:
        raise AssertionError(f"Vertiv vendor-only core telemetry was not normalized: {snapshot}")
    if snapshot.get("runtime_minutes") != 26 or snapshot.get("load_percent") != 35:
        raise AssertionError(f"Vertiv runtime/load enrichment failed: {snapshot}")
    if not (snapshot.get("telemetry") or {}).get("monitoring"):
        raise AssertionError("Detailed Vertiv telemetry did not include monitoring metadata")

    xppc_standard = {
        SYS_DESCR: "SNMP Web Manager",
        SYS_OBJECT_ID: "SNMPv2-SMI::enterprises.935.1",
        UPS_IDENT_MANUFACTURER: "",
        UPS_IDENT_MODEL: "UPS",
    }
    xppc_vendor = {
        XPPC_MODEL: "Intelligent 3000VA",
        XPPC_FIRMWARE: "V092B000D0",
        XPPC_BATTERY_STATUS: "2",
        XPPC_BATTERY_CAPACITY: "100",
        XPPC_RUNTIME_SECONDS: "4560",
        XPPC_OUTPUT_STATUS: "2",
        XPPC_OUTPUT_LOAD: "17",
        XPPC_BATTERY_VOLTAGE: "136",
        XPPC_BATTERY_TEMPERATURE: "380",
        XPPC_INPUT_VOLTAGE: "2330",
        XPPC_INPUT_FREQUENCY: "500",
        XPPC_OUTPUT_VOLTAGE: "2300",
        XPPC_OUTPUT_FREQUENCY: "500",
    }
    try:
        def fake_xppc_get_many(host, profile, oids):
            # Simulate an older NMC that accepts the standard RFC request but
            # rejects large private-enterprise GET PDUs. Portivo must retry the
            # native XPPC metrics in smaller/individual reads instead of falling
            # back to Generic UPS-MIB.
            if any(str(oid).startswith("1.3.6.1.4.1.935") for oid in oids) and len(oids) > 2:
                raise TimeoutError("vendor PDU too large")
            result = {}
            for oid in oids:
                if oid in xppc_standard:
                    result[oid] = xppc_standard[oid]
                elif oid in xppc_vendor:
                    result[oid] = xppc_vendor[oid]
                else:
                    # Reproduce the partial RFC facade seen in the field: many
                    # standard objects exist but return placeholder zeroes.
                    result[oid] = "0" if oid.startswith("1.3.6.1.2.1.33") else ""
            return result

        power_monitor.snmpv3_get_many = fake_xppc_get_many
        power_monitor.snmpv3_walk = lambda *args, **kwargs: []
        xppc_snapshot = power_monitor.probe_ups(
            "192.0.2.93", {"method": "snmpv3"}, driver_mode="generic", detailed=True
        )
    finally:
        power_monitor.snmpv3_get_many = original_get_many
        power_monitor.snmpv3_walk = original_walk

    if xppc_snapshot.get("driver_key") != "xppc":
        raise AssertionError(f"XPPC enterprise identity did not select XPPC driver: {xppc_snapshot}")
    if xppc_snapshot.get("sys_object_id") != "1.3.6.1.4.1.935.1":
        raise AssertionError(f"Symbolic XPPC sysObjectID was not normalized: {xppc_snapshot}")
    if xppc_snapshot.get("model") != "Intelligent 3000VA":
        raise AssertionError(f"XPPC native model did not replace generic UPS identity: {xppc_snapshot}")
    if xppc_snapshot.get("runtime_minutes") != 76 or xppc_snapshot.get("load_percent") != 17:
        raise AssertionError(f"XPPC runtime/load normalization failed: {xppc_snapshot}")
    if xppc_snapshot.get("power_state") != "normal" or xppc_snapshot.get("battery_charge_percent") != 100:
        raise AssertionError(f"XPPC state/charge normalization failed: {xppc_snapshot}")
    telem = xppc_snapshot.get("telemetry") or {}
    output = {item.get("key"): item for item in telem.get("output", [])}
    if (output.get("output_frequency") or {}).get("value") != 50.0:
        raise AssertionError(f"XPPC vendor details did not override placeholder RFC output frequency: {output}")
    monitoring = {item.get("key"): item.get("value") for item in telem.get("monitoring", [])}
    if monitoring.get("driver") != "Phoenixtec / XPPC":
        raise AssertionError(f"XPPC driver metadata missing from Details: {monitoring}")

    index_html = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
    app_js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    schemas = (ROOT / "app/schemas.py").read_text(encoding="utf-8")
    for marker in (
        'value="xppc">Phoenixtec / XPPC',
        'value="vertiv">Vertiv / Liebert',
        'value="socomec">Socomec / NET VISION / OFYS-RT',
        'value="acculine">AccuLine TNmax',
        'value="cyberpower">CyberPower / RMCARD',
        'value="riello">Riello UPS / NetMan',
    ):
        if marker not in index_html:
            raise AssertionError(f"UPS form is missing driver option: {marker}")
    for marker in ('normalized === "xppc"', 'normalized === "vertiv"', 'normalized === "socomec"', 'normalized === "acculine"', 'normalized === "cyberpower"', 'normalized === "riello"'):
        if marker not in app_js:
            raise AssertionError(f"Frontend power driver label support missing: {marker}")
    if '"xppc"' not in schemas or '"vertiv", "socomec", "acculine", "xppc", "cyberpower", "riello"' not in schemas:
        raise AssertionError("UPS API schema does not accept vendor driver modes")


    if 'BUILTIN_POWER_DRIVER_CATALOG' not in app_js or 'mergePowerDriverCatalog' not in app_js:
        raise AssertionError("Drivers UI does not have the runtime/fallback merged power driver registry")
    if 'window.PORTIVO_UI_REVISION="2.1.0-r6"' not in index_html:
        raise AssertionError("Static UI revision handshake is missing")
    print("Portivo UPS vendor compatibility validation: PASS")
    temp_dir.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
