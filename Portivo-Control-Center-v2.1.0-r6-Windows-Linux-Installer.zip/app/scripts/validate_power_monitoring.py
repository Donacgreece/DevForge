# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    temp_dir = tempfile.TemporaryDirectory(prefix="portivo-power-validation-")
    os.environ["DATABASE_PATH"] = str(Path(temp_dir.name) / "power.db")
    os.environ.setdefault("APP_SECRET_KEY", "power-validation-only-secret-key-00000000000000")

    from app.db import db, init_db
    from app.power_monitor import (
        UPS_ALARMS_PRESENT,
        UPS_BATTERY_STATUS,
        UPS_CHARGE_PERCENT,
        UPS_IDENT_MANUFACTURER,
        UPS_IDENT_MODEL,
        UPS_OUTPUT_SOURCE,
        UPS_RUNTIME_MINUTES,
        parse_ups_snapshot,
    )

    init_db()
    with db() as conn:
        device_columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(devices)").fetchall()}
        ups_columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(ups_devices)").fetchall()}
        destination_columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(notification_destinations)").fetchall()}
        outbox_columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(notification_outbox)").fetchall()}
        tables = {str(row["name"]) for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "power_source_ups_id" not in device_columns:
            raise AssertionError("devices.power_source_ups_id is missing")
        if not {"ups_devices", "power_incidents"}.issubset(tables):
            raise AssertionError("Power Infrastructure tables are missing")
        if not {"driver_mode", "driver_key", "sys_object_id"}.issubset(ups_columns):
            raise AssertionError("UPS driver persistence columns are missing")
        required_destination = {
            "notify_ups_on_battery", "notify_ups_power_restored", "notify_ups_low_battery", "notify_ups_unreachable"
        }
        if not required_destination.issubset(destination_columns):
            raise AssertionError("UPS destination routing columns are missing")
        if "power_incident_id" not in outbox_columns:
            raise AssertionError("notification_outbox.power_incident_id is missing")

    normal = parse_ups_snapshot({
        UPS_IDENT_MANUFACTURER: "Example Power",
        UPS_IDENT_MODEL: "UPS 3000",
        UPS_BATTERY_STATUS: "2",
        UPS_CHARGE_PERCENT: "98",
        UPS_RUNTIME_MINUTES: "42",
        UPS_OUTPUT_SOURCE: "3",
        UPS_ALARMS_PRESENT: "0",
    }, [("1.3.6.1.2.1.33.1.4.4.1.5.1", "37")], [])
    if normal["power_state"] != "normal" or normal["battery_charge_percent"] != 98 or normal["load_percent"] != 37:
        raise AssertionError(f"Normal UPS-MIB snapshot parsed incorrectly: {normal}")

    low = parse_ups_snapshot({
        UPS_BATTERY_STATUS: "3",
        UPS_CHARGE_PERCENT: "12",
        UPS_RUNTIME_MINUTES: "4",
        UPS_OUTPUT_SOURCE: "5",
        UPS_ALARMS_PRESENT: "1",
    }, [], [("1.3.6.1.2.1.33.1.6.2.1.2.1", "1.3.6.1.2.1.33.1.6.3.3")])
    if low["power_state"] != "low_battery" or "Low battery" not in low["alarms"]:
        raise AssertionError(f"Low-battery UPS-MIB snapshot parsed incorrectly: {low}")

    depleted = parse_ups_snapshot({
        UPS_BATTERY_STATUS: "4",
        UPS_CHARGE_PERCENT: "0",
        UPS_RUNTIME_MINUTES: "0",
        UPS_OUTPUT_SOURCE: "5",
        UPS_ALARMS_PRESENT: "0",
    }, [], [])
    if depleted["power_state"] != "depleted":
        raise AssertionError(f"Depleted UPS-MIB snapshot parsed incorrectly: {depleted}")

    # Power history must remain authoritative even before webhook routing is
    # configured. A utility-loss event should therefore open a power incident
    # with the default disabled notification policy and zero destinations.
    from app.notification_engine import observe_ups_result

    checked = datetime.now(timezone.utc)
    now = checked.isoformat()
    power_started = (checked - timedelta(seconds=25)).isoformat()
    with db() as conn:
        profile_id = int(conn.execute(
            "INSERT INTO monitoring_credential_profiles(name,method,username,created_at,updated_at,updated_by) VALUES(?,?,?,?,?,?)",
            ("Power Validation SNMPv3", "snmpv3", "validator", now, now, "validator"),
        ).lastrowid)
        ups_id = int(conn.execute(
            "INSERT INTO ups_devices(name,host,site,monitoring_profile_id,last_status,power_state,created_at,updated_at,updated_by) VALUES(?,?,?,?,?,?,?,?,?)",
            ("Validation UPS", "192.0.2.50", "Validation Site", profile_id, "online", "on_battery", now, now, "validator"),
        ).lastrowid)
    observe_ups_result(
        {"id": ups_id, "name": "Validation UPS", "host": "192.0.2.50", "site": "Validation Site", "group_name": "", "last_status": "online", "power_state": "on_battery", "power_event_started_at": power_started, "output_source": "battery", "battery_status": "normal", "battery_charge_percent": 90, "runtime_minutes": 30, "alarms": []},
        previous={"last_status": "online", "power_state": "normal"},
        checked_at=now,
    )
    with db() as conn:
        incident = conn.execute("SELECT incident_type,status FROM power_incidents WHERE ups_id=? ORDER BY id DESC LIMIT 1", (ups_id,)).fetchone()
        outbox_count = int(conn.execute("SELECT COUNT(*) AS c FROM notification_outbox WHERE power_incident_id IS NOT NULL").fetchone()["c"])
    if not incident or str(incident["incident_type"]) != "ups_on_battery" or str(incident["status"]) != "open":
        raise AssertionError("UPS on-battery incident was not recorded with webhook routing disabled")
    if outbox_count != 0:
        raise AssertionError("Webhook outbox should stay empty while notification delivery is disabled")

    print("Portivo Power Infrastructure validation: PASS")
    temp_dir.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
