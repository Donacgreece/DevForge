# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("APP_SECRET_KEY", "validation-only-secret-key-0123456789abcdef")
DB_PATH = ROOT / "data" / "validation-health-r6.db"
os.environ.setdefault("DATABASE_PATH", str(DB_PATH))
os.environ.setdefault("HEALTH_PING_ATTEMPTS", "3")
os.environ.setdefault("HEALTH_PING_RETRY_DELAY_SECONDS", "5")
os.environ.setdefault("HEALTH_POLL_JITTER_SECONDS", "10")

from app import health_monitor as hm  # noqa: E402
from app.db import db, init_db  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def run_case(*, mode: str, profile: bool, ping_results: list[bool], snmp: bool, snmp_due: bool = False):
    device = {
        "id": 11,
        "host": "192.0.2.10",
        "ssh_port": 22,
        "health_probe_mode": mode,
        "health_monitor_profile_id": 7 if profile else None,
        "stack_monitor_method": "ssh",
        "stack_monitor_profile_id": None,
        "health_snmp_checked_at": None,
    }
    profiles = {7: {"id": 7, "method": "snmpv3", "username": "validator"}} if profile else {}
    calls: list[str] = []
    results = iter(ping_results)
    old_ping, old_snmp, old_due, old_wait = hm._probe_ping, hm._probe_snmp, hm._snmp_due, hm._wait_ping_retry
    try:
        def fake_ping(host: str):
            calls.append("ping")
            ok = next(results, False)
            return ok, 1, "" if ok else "ping failed"
        hm._probe_ping = fake_ping
        hm._probe_snmp = lambda device, profile: (calls.append("snmp") or snmp, 2, "" if snmp else "snmp failed")
        hm._snmp_due = lambda device: snmp_due
        hm._wait_ping_retry = lambda: calls.append("wait")
        return hm._probe_device(device, profiles), calls
    finally:
        hm._probe_ping, hm._probe_snmp, hm._snmp_due, hm._wait_ping_retry = old_ping, old_snmp, old_due, old_wait


def main() -> None:
    DB_PATH.unlink(missing_ok=True)
    try:
        init_db()

        (_, result, _, method, telemetry), calls = run_case(mode="auto", profile=True, ping_results=[True], snmp=True, snmp_due=False)
        require(result.ok and method == "ping", "Auto must use ICMP as the normal reachability probe")
        require(calls == ["ping"], "Healthy Auto polling must perform only one ICMP request when telemetry is not due")
        require(not telemetry, "Telemetry must remain independent when it is not due")

        (_, result, _, method, telemetry), calls = run_case(mode="auto", profile=True, ping_results=[True], snmp=True, snmp_due=True)
        require(result.ok and method == "ping", "Due telemetry must not replace successful ICMP reachability")
        require(calls == ["ping", "snmp"], "Due SNMP telemetry may run only after successful ICMP")
        require(telemetry.get("ok") is True, "Due SNMP telemetry must be recorded separately")

        (_, result, _, method, _), calls = run_case(mode="auto", profile=True, ping_results=[False, False, True], snmp=True)
        require(result.ok and method == "ping", "ICMP recovery on retry must remain Online")
        require(calls == ["ping", "wait", "ping", "wait", "ping"], "Auto must perform exactly two bounded ICMP retries before fallback")

        (_, result, _, method, telemetry), calls = run_case(mode="auto", profile=True, ping_results=[False, False, False], snmp=True)
        require(result.ok and method == "snmpv3", "One SNMPv3 request must confirm reachability after all ICMP attempts fail")
        require(calls == ["ping", "wait", "ping", "wait", "ping", "snmp"], "Auto order must be Ping x3 then one SNMP confirmation")
        require(telemetry.get("ok") is True, "SNMP confirmation must also update telemetry state")

        (_, result, _, method, _), calls = run_case(mode="auto", profile=True, ping_results=[False, False, False], snmp=False)
        require(not result.ok and method == "snmpv3", "Auto must fail when both ICMP confirmation and SNMP confirmation fail")
        require(calls == ["ping", "wait", "ping", "wait", "ping", "snmp"], "No TCP/22 fallback may run after SNMP failure")

        (_, result, _, method, _), calls = run_case(mode="auto", profile=False, ping_results=[False, False, False], snmp=False)
        require(not result.ok and method == "ping", "Auto without SNMP must rely only on confirmed ICMP failure")
        require(calls == ["ping", "wait", "ping", "wait", "ping"], "Auto without SNMP must stop after ICMP retries")

        (_, result, _, method, _), calls = run_case(mode="ping", profile=True, ping_results=[False, False, False], snmp=True)
        require(not result.ok and method == "ping", "Ping-only mode must remain ICMP-only")
        require(calls == ["ping", "wait", "ping", "wait", "ping"], "Ping-only mode must use the same bounded retry confirmation")

        (_, result, _, method, _), calls = run_case(mode="snmp", profile=True, ping_results=[True], snmp=True)
        require(result.ok and method == "snmpv3" and calls == ["snmp"], "SNMP-only mode must perform exactly one SNMP probe")

        status = hm.health_monitor_status()
        require(status.get("architecture") == "icmp-confirmed-snmpv3-fallback-no-tcp", "Health status must advertise the no-TCP architecture")
        require(status.get("ssh_login_used") is False, "Periodic switch health must never use SSH login")
        require(status.get("ping_attempts") == 3, "Default ICMP confirmation must be three attempts")
        require(status.get("ping_retry_delay_seconds") == 5.0, "Default ICMP retry delay must be five seconds")
        require(status.get("poll_jitter_seconds") == 10.0, "Fleet polling must expose deterministic jitter")

        health_source = (ROOT / "app/health_monitor.py").read_text(encoding="utf-8")
        schemas = (ROOT / "app/schemas.py").read_text(encoding="utf-8")
        index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
        require("socket.create_connection" not in health_source and "_probe_tcp22" not in health_source, "Health engine must contain no TCP connect probe")
        require('"tcp22"' not in schemas, "Device health API must not expose TCP/22 mode")
        require('value="tcp22"' not in index, "Device health UI must not expose TCP/22 mode")

        # Upgrade safety: an r5 device stored in TCP-only mode must be normalized to Auto.
        with db() as conn:
            now = "2026-08-30T10:00:00+00:00"
            conn.execute(
                "INSERT INTO devices(name,host,profile,health_probe_mode,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                ("Legacy TCP health", "192.0.2.44", "AOS8", "tcp22", now, now),
            )
        init_db()
        with db() as conn:
            row = conn.execute("SELECT health_probe_mode FROM devices WHERE host='192.0.2.44'").fetchone()
        require(row and row["health_probe_mode"] == "auto", "Upgrade migration must normalize legacy TCP/22 health mode to Auto")

        # Jitter is stable and bounded for a given device.
        j1 = hm._device_jitter_seconds({"id": 11})
        j2 = hm._device_jitter_seconds({"id": 11})
        require(j1 == j2 and 0.0 <= j1 <= 10.0, "Per-device health jitter must be deterministic and bounded")

        print("LIGHTWEIGHT HEALTH PROBE ARCHITECTURE v2.1.0-r6: PASS")
    finally:
        DB_PATH.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
