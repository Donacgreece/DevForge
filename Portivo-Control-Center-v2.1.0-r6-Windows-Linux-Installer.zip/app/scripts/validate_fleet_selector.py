# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INDEX = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
APP = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
CSS = (ROOT / "app/static/styles.css").read_text(encoding="utf-8")

checks = {
    "shared Operations grid": 'class="fleet-switch-grid" id="bulkDeviceList"' in INDEX,
    "shared Audit grid": 'class="audit-scope-list fleet-switch-grid" id="auditScopeList"' in INDEX,
    "shared filter styling in Operations": 'class="fleet-selector-filter-bar"' in INDEX,
    "shared filter styling in Audit": 'class="audit-filter-bar fleet-selector-filter-bar"' in INDEX,
    "shared card renderer": "function fleetSwitchCardMarkup" in APP,
    "Operations uses shared renderer": "return fleetSwitchCardMarkup(device, { selected, mode: \"operations\"" in APP,
    "Audit uses shared renderer": "fleetSwitchCardMarkup(device, {\n    selected: state.fleetAuditSelected" in APP,
    "contextual Operations overrides": 'data-bulk-override="port"' in APP and 'data-bulk-override="slot"' in APP,
    "legacy Operations table removed": 'class="target-table-wrap"' not in INDEX,
    "shared selector responsive styles": ".fleet-switch-grid" in CSS and ".fleet-selector-filter-bar" in CSS,
}

failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("FLEET SELECTOR VALIDATION: FAIL")
    for name in failed:
        print(f"  FAIL: {name}")
    raise SystemExit(1)

print("FLEET SELECTOR VALIDATION: PASS")
for name in checks:
    print(f"  PASS: {name}")
