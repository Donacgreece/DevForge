# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_SECRET_KEY", "runbook-execution-validation-secret-000000000")

from app import job_runner


class FakeResult:
    def __init__(self, output: str = "OK", ok: bool = True, error: str = ""):
        self.output = output
        self.ok = ok
        self.error = error


class FakeSession:
    def __init__(self, fail_on: str = ""):
        self.commands: list[str] = []
        self.fail_on = fail_on

    def execute(self, command: str):
        self.commands.append(command)
        if command == self.fail_on:
            return FakeResult(output="", ok=False, error="Rejected")
        return FakeResult(output=f"OUTPUT:{command}")


class FakeConnection:
    def execute(self, *_args, **_kwargs):
        return SimpleNamespace()


@contextmanager
def fake_db():
    yield FakeConnection()


def run_case(*, fail_on: str = "") -> tuple[str, list[str], list[dict]]:
    updates: list[dict] = []
    session = FakeSession(fail_on=fail_on)

    @contextmanager
    def fake_command_session(*_args, **_kwargs):
        yield session

    old_update = job_runner._update_item
    old_command_session = job_runner.command_session
    old_db = job_runner.db
    old_sleep = job_runner.time.sleep
    try:
        job_runner._update_item = lambda item_id, **values: updates.append({"item_id": item_id, **values})
        job_runner.command_session = fake_command_session
        job_runner.db = fake_db
        job_runner.time.sleep = lambda _seconds: None
        snapshot = {
            "id": 7,
            "name": "Execution Validator",
            "risk": "change",
            "steps": [
                {"type": "command", "command": "show system"},
                {"type": "wait", "seconds": 1},
                {"type": "verify", "command": "show interfaces status"},
            ],
        }
        status = job_runner._execute_runbook_item(
            99,
            {"id": 1, "name": "SW1", "username": "svc", "password_enc": "secret"},
            dry_run=False,
            snapshot=snapshot,
        )
        return status, session.commands, updates
    finally:
        job_runner._update_item = old_update
        job_runner.command_session = old_command_session
        job_runner.db = old_db
        job_runner.time.sleep = old_sleep


def main() -> int:
    try:
        status, commands, updates = run_case()
        assert status == "success"
        assert commands == ["show system", "show interfaces status"]
        assert any(item.get("status") == "success" for item in updates)
        assert any("show interfaces status" in str(item.get("verification_output") or "") for item in updates)

        status, commands, updates = run_case(fail_on="show interfaces status")
        assert status == "failed"
        assert commands == ["show system", "show interfaces status"]
        assert any(item.get("status") == "failed" and "step 3 failed" in str(item.get("error") or "").lower() for item in updates)

        # UI and scheduler integration must remain wired to the same action.
        html = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
        scheduler = (ROOT / "app" / "unp_scheduler.py").read_text(encoding="utf-8")
        assert 'id="runbookLibraryDialog"' in html
        assert 'id="automationRunbookLibraryButton"' in html
        assert 'custom_runbook' in js
        assert '"custom_runbook"' in scheduler
        assert "runbook_snapshot" in scheduler
    except Exception as exc:
        print(f"RUNBOOK EXECUTION VALIDATION: FAIL ({exc})")
        return 1
    print("RUNBOOK EXECUTION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
