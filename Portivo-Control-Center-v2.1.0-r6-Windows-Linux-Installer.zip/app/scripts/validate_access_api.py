# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-access-api-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "access-api.db")
os.environ["APP_SECRET_KEY"] = "access-api-validation-secret-key-000000000000000000"
os.environ["APP_ADMIN_PASSWORD"] = "Portivo-Validation-Admin-2026!"
os.environ["LOGIN_RATE_LIMIT_ENABLED"] = "false"

from fastapi.testclient import TestClient  # noqa: E402
from app.crypto import encrypt_secret  # noqa: E402
from app.db import db, init_db, utc_now  # noqa: E402
from app import main as main_module  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def add_device(name: str, host: str, site: str, group: str) -> int:
    now = utc_now()
    with db() as conn:
        cursor = conn.execute(
            """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at,last_status)
            VALUES(?,?,?,?,?,'OS6560-P24X4','8.10.105.R02','AOS8',1,'','','',?,?,'online')""",
            (name, host, 22, site, group, now, now),
        )
        return int(cursor.lastrowid)


def main() -> int:
    init_db()
    access_id = add_device("A-Access", "198.51.100.11", "Site A", "Access Layer")
    core_id = add_device("A-Core", "198.51.100.12", "Site A", "Core")
    other_id = add_device("B-Access", "203.0.113.11", "Site B", "Access Layer")

    # Authentication is transport-tested elsewhere. For authorization validation
    # replace only the SSH credential probe and preserve the real login/session flow.
    auth_device = {"id": access_id, "name": "A-Access", "host": "198.51.100.11", "ssh_port": 22, "profile": "AOS8"}
    main_module._authenticate_ssh_login = lambda username, password: (auth_device, encrypt_secret(password))

    with TestClient(main_module.app) as admin_client, TestClient(main_module.app) as ssh_client:
        admin_login = admin_client.post("/api/auth/login", json={"username": "admin", "password": os.environ["APP_ADMIN_PASSWORD"], "mode": "admin"})
        require(admin_login.status_code == 200, f"Admin login failed: {admin_login.text}")

        ssh_login = ssh_client.post("/api/auth/login", json={"username": "help.user", "password": "irrelevant", "mode": "ssh"})
        require(ssh_login.status_code == 200, f"SSH login failed: {ssh_login.text}")
        login_data = ssh_login.json()
        require(login_data["role"] == "read_only", "New SSH identity must start as Read Only")
        require(login_data["permissions"]["scope"]["mode"] == "none", "New SSH identity must start with no scope")
        require(ssh_client.get("/api/devices").json() == [], "No-scope user must see no devices")
        require(ssh_client.get("/api/catalog").status_code == 403, "Read Only must not receive executable catalog")

        access = admin_client.get("/api/admin/access-control").json()
        roles = {item["key"]: item for item in access["roles"]}
        users = admin_client.get("/api/admin/ssh-users").json()
        user = next(item for item in users if item["username"] == "help.user")

        assignment = admin_client.put(
            f"/api/admin/ssh-users/{user['id']}/access",
            json={
                "role_id": roles["helpdesk"]["id"], "enabled": True, "scope_mode": "selected",
                "sites": ["Site A"], "groups": [{"site": "Site A", "group": "Access Layer"}],
            },
        )
        require(assignment.status_code == 200, f"Helpdesk assignment failed: {assignment.text}")

        # Role/scope is re-read on every request. The already-active SSH session
        # must immediately inherit the new assignment without a new login.
        me = ssh_client.get("/api/auth/me").json()
        require(me["role"] == "helpdesk", "Active session did not adopt Helpdesk role immediately")
        require(me["permissions"]["scope"]["mode"] == "selected", "Active session did not adopt scope immediately")
        visible = ssh_client.get("/api/devices")
        require(visible.status_code == 200, visible.text)
        require([item["id"] for item in visible.json()] == [access_id], "Site/Group scope leaked devices")

        catalog = ssh_client.get("/api/catalog")
        require(catalog.status_code == 200, catalog.text)
        action_ids = set(catalog.json().keys())
        require({"interface_alias", "interface_cycle", "poe_cycle"}.issubset(action_ids), "Helpdesk basic actions are incomplete")
        require("save_config" not in action_ids and "custom_command" not in action_ids, "Helpdesk received privileged actions")
        require(not me["permissions"]["use_terminal"] and not me["permissions"]["custom_cli"], "Helpdesk received raw console capability")
        require("drivers.view" in me["permissions"]["capabilities"] and "power.view" in me["permissions"]["capabilities"], "Helpdesk missing Power/Drivers visibility")
        require(ssh_client.get("/api/platform/drivers").status_code == 200, "Helpdesk should see switch driver reference")
        require(ssh_client.get("/api/platform/drivers/power").status_code == 200, "Helpdesk should see UPS driver reference")
        require(ssh_client.get("/api/power/monitoring-profiles").status_code == 403, "Helpdesk received UPS configuration credentials")

        allowed = ssh_client.post("/api/preview", json={"action": "interface_cycle", "targets": [{"device_id": access_id, "port": "1/1/1"}], "cycle_delay_seconds": 5})
        require(allowed.status_code == 200, f"Helpdesk interface restart preview denied: {allowed.text}")
        denied_change = ssh_client.post("/api/preview", json={"action": "save_config", "targets": [{"device_id": access_id}]})
        require(denied_change.status_code == 403, "Helpdesk must not execute Save Configuration")
        denied_scope = ssh_client.post("/api/preview", json={"action": "interface_cycle", "targets": [{"device_id": other_id, "port": "1/1/1"}], "cycle_delay_seconds": 5})
        require(denied_scope.status_code == 403, "Scoped Helpdesk action crossed Site boundary")
        require(ssh_client.get("/api/admin/access-control").status_code == 403, "Helpdesk must not access Access Control administration")

        # Read Only keeps scoped viewing but loses every command/console surface.
        assignment = admin_client.put(
            f"/api/admin/ssh-users/{user['id']}/access",
            json={"role_id": roles["read_only"]["id"], "enabled": True, "scope_mode": "selected", "sites": ["Site A"], "groups": []},
        )
        require(assignment.status_code == 200, assignment.text)
        me = ssh_client.get("/api/auth/me").json()
        require(me["role"] == "read_only", "Read Only assignment did not take effect immediately")
        require(not me["permissions"]["execute_commands"] and not me["permissions"]["use_terminal"] and not me["permissions"]["custom_cli"], "Read Only retained execution capability")
        require(ssh_client.get("/api/catalog").status_code == 403, "Read Only received action catalog")
        require(ssh_client.get("/api/profiles").status_code == 403, "Read Only received Command Library data")
        require(ssh_client.post("/api/preview", json={"action": "interface_status_all", "targets": [{"device_id": access_id}]}).status_code == 403, "Read Only executed read CLI")
        require(ssh_client.get("/api/fleet-audits/catalog").status_code == 200, "Read Only should retain report visibility")

        # Custom Roles are always scoped and may grant an exact command action.
        custom_resp = admin_client.post(
            "/api/admin/access-roles",
            json={"name": "Alias Support", "description": "Alias only validation", "capabilities": ["devices.view"], "allowed_actions": ["interface_alias"]},
        )
        require(custom_resp.status_code == 201, custom_resp.text)
        custom = custom_resp.json()
        require("operations.view" in custom["capabilities"], "Custom Role command dependency was not normalized")
        assignment = admin_client.put(
            f"/api/admin/ssh-users/{user['id']}/access",
            json={"role_id": custom["id"], "enabled": True, "scope_mode": "selected", "sites": ["Site A"], "groups": [{"site": "Site A", "group": "Access Layer"}]},
        )
        require(assignment.status_code == 200, assignment.text)
        custom_catalog = ssh_client.get("/api/catalog")
        require(custom_catalog.status_code == 200, custom_catalog.text)
        custom_ids = set(custom_catalog.json().keys())
        require("interface_alias" in custom_ids and "interface_cycle" not in custom_ids, "Custom Role exact action policy leaked commands")
        require(ssh_client.post("/api/preview", json={"action": "interface_cycle", "targets": [{"device_id": access_id, "port": "1/1/1"}]}).status_code == 403, "Custom Role bypassed exact command policy")
        require(ssh_client.post("/api/preview", json={"action": "interface_alias", "targets": [{"device_id": access_id, "port": "1/1/1"}], "port_alias": "Desk"}).status_code == 200, "Custom Role exact command grant failed")

        # Scoped roles can explicitly be granted All Sites. This is an explicit
        # assignment, not an implicit default.
        assignment = admin_client.put(
            f"/api/admin/ssh-users/{user['id']}/access",
            json={"role_id": roles["operator"]["id"], "enabled": True, "scope_mode": "all", "sites": [], "groups": []},
        )
        require(assignment.status_code == 200, assignment.text)
        all_visible = ssh_client.get("/api/devices").json()
        require({item["id"] for item in all_visible} == {access_id, core_id, other_id}, "Explicit All Sites assignment failed")

    print("PORTIVO ACCESS API VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
