﻿# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
param(
    [string]$AppPath = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
    [int]$Port = 0
)

$envPath = Join-Path $AppPath ".env"
if ($Port -le 0) {
    $Port = 8766
    if (Test-Path $envPath) {
        $line = Get-Content -LiteralPath $envPath | Where-Object { $_ -match '^\s*APP_PORT\s*=' } | Select-Object -First 1
        if ($line) { $Port = [int]((($line -split '=', 2)[1]).Trim('"', "'", ' ')) }
    }
}

$addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object {
        $_.IPAddress -notmatch '^127\.' -and
        $_.IPAddress -notmatch '^169\.254\.' -and
        $_.PrefixOrigin -ne 'WellKnown'
    } |
    Select-Object -ExpandProperty IPAddress -Unique

if (-not $addresses) {
    Write-Host "No usable LAN IPv4 address was detected." -ForegroundColor Yellow
    exit 0
}

foreach ($address in $addresses) {
    Write-Host "  http://$address`:$Port"
}
