# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-power-correlation-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "power-correlation.db")
os.environ.setdefault("APP_SECRET_KEY", "power-correlation-validation-only-secret-000000")

from app.db import init_db  # noqa: E402
from app.notification_engine import _build_payload, _provider_payload  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    init_db()
    device = {
        "id": 7, "name": "SW-ACCESS-07", "host": "198.51.100.7",
        "site": "Site A", "group_name": "Access Layer", "model": "OS6560", "aos_version": "8.10", "profile": "AOS8",
    }
    power = {
        "correlated": True,
        "confidence": "high",
        "reason": "assigned UPS battery is depleted",
        "ups_id": 3,
        "ups_name": "UPS-RACK-01",
        "ups_host": "198.51.100.50",
        "power_state": "depleted",
        "reachability": "unreachable",
        "battery_charge_percent": 2,
        "runtime_minutes": 0,
        "load_percent": 27,
    }
    offline = _build_payload(
        event_type="switch_offline", device=device, incident_id=42, failed_checks=3,
        opened_at="2026-08-15T09:00:00Z", last_reachable="2026-08-15T08:59:30Z", power=power,
    )
    microsoft = _provider_payload("microsoft", offline)
    text = str(microsoft.get("text") or "")
    require(offline["title"] == "Switch Offline · Power-related", "Power-correlated switch alert title is not explicit")
    require("Probable root cause: assigned UPS battery is depleted" in text, "Teams text is missing probable root cause")
    require("Confidence: High" in text, "Teams text is missing correlation confidence")
    require("Assigned UPS: UPS-RACK-01" in text, "Teams text is missing assigned UPS")
    card = microsoft["attachments"][0]["content"]
    facts = {item["title"]: item["value"] for item in card["body"][2]["facts"]}
    require(facts.get("Probable root cause") == "assigned UPS battery is depleted", "Adaptive Card root-cause fact missing")
    require(facts.get("Confidence") == "High", "Adaptive Card confidence fact missing")

    recovered_power = dict(power)
    recovered_power.update({"current_power_state": "normal", "current_reachability": "online", "utility_restored": True})
    recovery = _build_payload(
        event_type="switch_recovered", device=device, incident_id=42, failed_checks=3,
        opened_at="2026-08-15T09:00:00Z", recovered_at="2026-08-15T09:25:00Z",
        last_reachable="2026-08-15T08:59:30Z", power=recovered_power,
    )
    recovery_ms = _provider_payload("microsoft", recovery)
    recovery_text = str(recovery_ms.get("text") or "")
    require(recovery["title"] == "Switch Recovered · Power-related outage", "Power-correlated recovery title is not explicit")
    require("Recovery evidence: assigned UPS returned to normal utility power" in recovery_text, "Teams recovery text is missing utility-restoration evidence")

    print("PORTIVO POWER CORRELATION NOTIFICATION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
