# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.reload_actions import ReloadActionError, reload_stack_member_command, reload_switch_command


def fail(message: str) -> None:
    raise SystemExit(f"STACK RELOAD: FAIL: {message}")


def main() -> None:
    if reload_switch_command({"profile": "AOS8"}) != "reload from working no rollback-timeout":
        fail("AOS8 standalone reload plan changed")
    if reload_switch_command({"profile": "AOS6"}) != "reload working no rollback-timeout":
        fail("AOS6 standalone reload plan changed")
    if reload_stack_member_command({"profile": "AOS8"}, "3") != "reload chassis-id 3 from working no rollback-timeout":
        fail("AOS8 targeted chassis reload plan changed")

    legacy = {
        "profile": "AOS6",
        "stack_members": [
            {"id": "1", "role": "Primary"},
            {"id": "2", "role": "Secondary"},
            {"id": "3", "role": "Idle"},
        ],
    }
    expected = {"1": "reload primary", "2": "reload secondary", "3": "reload ni 3"}
    for chassis, command in expected.items():
        if reload_stack_member_command(legacy, chassis) != command:
            fail(f"AOS6 chassis {chassis} role-aware reload plan changed")
    try:
        reload_stack_member_command({"profile": "AOS6", "stack_members": [{"id": "4", "role": ""}]}, "4")
    except ReloadActionError:
        pass
    else:
        fail("AOS6 unknown-role member must fail closed")

    catalog = json.loads((ROOT / "data" / "action_catalog.json").read_text(encoding="utf-8"))
    for action in ("reload_switch", "reload_stack_member"):
        if action not in catalog:
            fail(f"missing catalog action {action}")
        if catalog[action].get("risk") != "change" or not catalog[action].get("contextualOnly"):
            fail(f"{action} must remain a contextual change action")

    app_js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
    index_html = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")
    for token in (
        "workspaceKnownChassisIds",
        "logical-chassis-card",
        "openWorkspaceReload",
        'typed !== "RELOAD"',
    ):
        if token not in app_js:
            fail(f"front-panel safety token missing: {token}")
    if 'id="workspaceReloadDialog"' not in index_html or 'id="workspaceReloadConfirmation"' not in index_html:
        fail("dedicated reload confirmation dialog is missing")

    print("STACK RELOAD: PASS")
    print("AOS8 targeted chassis reload: guarded")
    print("AOS6 role-aware member reload: guarded and fail-closed")
    print("Logical front panel: chassis-aware")


if __name__ == "__main__":
    main()
