# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path
import os
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
tmp=tempfile.TemporaryDirectory(prefix="portivo-driver-registry-")
os.environ["DATABASE_PATH"]=str(Path(tmp.name)/"registry.db")
os.environ.setdefault("APP_SECRET_KEY","driver-registry-validation-secret-key-000000000000")
from app.power_drivers import power_driver_catalog, detect_driver, SYS_OBJECT_ID, UPS_IDENT_MANUFACTURER, UPS_IDENT_MODEL

rows=power_driver_catalog()
keys=[r["key"] for r in rows]
expected=["auto","generic","xppc","vertiv","socomec","acculine","apc","eaton","cyberpower","riello"]
if keys != expected:
    raise AssertionError(f"Unexpected power driver registry order/content: {keys}")
if detect_driver({SYS_OBJECT_ID:"1.3.6.1.4.1.935.1"}).key != "xppc":
    raise AssertionError("XPPC enterprise identity did not resolve")
if detect_driver({SYS_OBJECT_ID:"1.3.6.1.4.1.476.1.42", UPS_IDENT_MANUFACTURER:"Vertiv", UPS_IDENT_MODEL:"GXT5LI-5000GVRT3UXLN"}).key != "vertiv":
    raise AssertionError("Vertiv enterprise identity did not resolve")
if detect_driver({UPS_IDENT_MANUFACTURER:"SOCOMEC", UPS_IDENT_MODEL:"OFYS-RT-U3000"}).key != "socomec":
    raise AssertionError("Socomec OFYS-RT identity did not resolve")
if detect_driver({SYS_OBJECT_ID:"1.3.6.1.4.1.3808.1", UPS_IDENT_MANUFACTURER:"CyberPower"}).key != "cyberpower":
    raise AssertionError("CyberPower enterprise identity did not resolve")
if detect_driver({SYS_OBJECT_ID:"1.3.6.1.4.1.7783.1", UPS_IDENT_MANUFACTURER:"Riello UPS"}).key != "riello":
    raise AssertionError("Riello enterprise identity did not resolve")
if not all(str(r.get("models") or "").strip() for r in rows):
    raise AssertionError("Driver registry is missing family metadata")
print("Power driver registry: PASS")
tmp.cleanup()
