# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sqlite3
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    temp_dir = tempfile.TemporaryDirectory(prefix="portivo-job-lifecycle-")
    db_path = Path(temp_dir.name) / "lifecycle.db"
    os.environ["DATABASE_PATH"] = str(db_path)
    os.environ.setdefault("APP_SECRET_KEY", "job-lifecycle-validation-secret-key-000000000000")

    from app.db import db, init_db, utc_now
    from app.job_lifecycle import reconcile_orphaned_jobs

    init_db()
    with db() as conn:
        columns = {str(row["name"]) for row in conn.execute("PRAGMA table_info(jobs)").fetchall()}
        required = {
            "heartbeat_at", "interrupted_reason", "retry_of_job_id", "cancel_requested",
            "cancel_requested_at", "cancel_requested_by", "interrupted_count", "cancelled_count",
            "removed_at", "removed_by",
        }
        missing = sorted(required - columns)
        if missing:
            raise AssertionError(f"Missing Job lifecycle columns: {missing}")

        now = utc_now()
        cursor = conn.execute(
            """INSERT INTO jobs(action,status,dry_run,target_count,requested_by,payload_json,created_at,started_at)
               VALUES('save_config','running',0,3,'validator','{}',?,?)""",
            (now, now),
        )
        job_id = int(cursor.lastrowid)
        conn.execute(
            "INSERT INTO job_items(job_id,device_id,device_name,host,status,started_at) VALUES(?,1,'A','192.0.2.10','success',?)",
            (job_id, now),
        )
        conn.execute(
            "INSERT INTO job_items(job_id,device_id,device_name,host,status,started_at) VALUES(?,2,'B','192.0.2.11','running',?)",
            (job_id, now),
        )
        conn.execute(
            "INSERT INTO job_items(job_id,device_id,device_name,host,status) VALUES(?,3,'C','192.0.2.12','queued')",
            (job_id,),
        )

    reconciled = reconcile_orphaned_jobs()
    if job_id not in reconciled:
        raise AssertionError("Running Job was not reconciled on startup")

    with db() as conn:
        job = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        items = conn.execute("SELECT status FROM job_items WHERE job_id=? ORDER BY id", (job_id,)).fetchall()
        if not job or str(job["status"]) != "interrupted":
            raise AssertionError("Orphaned Job did not become Interrupted")
        if int(job["success_count"] or 0) != 1 or int(job["interrupted_count"] or 0) != 2:
            raise AssertionError("Lifecycle counts were not preserved during reconciliation")
        if [str(row["status"]) for row in items] != ["success", "interrupted", "interrupted"]:
            raise AssertionError("Successful evidence was not preserved or unfinished targets were not interrupted")
        audit_count = int(conn.execute(
            "SELECT COUNT(*) FROM audit_log WHERE event='job_interrupted_on_startup' AND object_id=?",
            (str(job_id),),
        ).fetchone()[0])
        if audit_count != 1:
            raise AssertionError("Startup reconciliation was not audited")

    main_source = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
    for route in (
        '@app.post("/api/jobs/{job_id}/cancel")',
        '@app.post("/api/jobs/{job_id}/retry")',
        '@app.delete("/api/jobs/{job_id}")',
    ):
        if route not in main_source:
            raise AssertionError(f"Missing lifecycle endpoint: {route}")
    if "AND status <> 'success'" not in main_source:
        raise AssertionError("Retry must exclude already successful targets")

    print("Portivo Job lifecycle validation: PASS")
    temp_dir.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
