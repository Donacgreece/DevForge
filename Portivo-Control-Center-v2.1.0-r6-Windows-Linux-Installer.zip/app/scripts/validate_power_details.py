# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-power-details-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "power-details.db")
os.environ["APP_SECRET_KEY"] = "power-details-validation-secret-key-000000000000000"

from app.db import db, init_db  # noqa: E402
from app.power_monitor import (  # noqa: E402
    _build_standard_detail_metrics,
    _merge_detail_sections,
    _resolved_detail_sections,
    UPS_IDENT_MANUFACTURER,
    UPS_IDENT_MODEL,
    UPS_IDENT_AGENT_SOFTWARE,
    UPS_BATTERY_STATUS,
    UPS_CHARGE_PERCENT,
    UPS_RUNTIME_MINUTES,
    UPS_SECONDS_ON_BATTERY,
    UPS_BATTERY_VOLTAGE,
    UPS_BATTERY_CURRENT,
    UPS_BATTERY_TEMPERATURE,
    UPS_INPUT_LINE_BADS,
    UPS_INPUT_NUM_LINES,
    UPS_INPUT_TABLE,
    UPS_OUTPUT_FREQUENCY,
    UPS_OUTPUT_NUM_LINES,
    UPS_OUTPUT_TABLE,
    UPS_CONFIG_OUTPUT_VA,
    UPS_CONFIG_OUTPUT_POWER,
    UPS_TEST_RESULTS_SUMMARY,
)
from app.power_drivers import (  # noqa: E402
    DRIVERS,
    build_vendor_detail_metrics,
    APC_MANUFACTURE_DATE,
    APC_SERIAL_NUMBER,
    APC_BATTERY_LAST_REPLACE,
    APC_HIGH_PREC_BATTERY_VOLTAGE,
    APC_HIGH_PREC_BATTERY_CURRENT,
    APC_HIGH_PREC_BATTERY_TEMPERATURE,
    APC_BATTERY_CABINET_AH,
    APC_INPUT_FREQUENCY,
    APC_OUTPUT_ACTIVE_POWER,
    APC_BATTERY_TEST_LAST_DATE,
    APC_BATTERY_TEST_PROCESS,
    APC_BATTERY_TEST_CONDITION,
    APC_COMM_STATUS,
    EATON_BATTERY_VOLTAGE,
    EATON_BATTERY_CURRENT,
    EATON_INPUT_FREQUENCY,
    EATON_INPUT_NUM_PHASES,
    EATON_INPUT_TABLE,
    EATON_OUTPUT_FREQUENCY,
    EATON_OUTPUT_NUM_PHASES,
    EATON_OUTPUT_TABLE,
    EATON_CONFIG_OUTPUT_WATTS,
    EATON_AMBIENT_TEMPERATURE,
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def metric_map(sections: dict[str, list[dict]], section: str) -> dict[str, dict]:
    return {str(item.get("key")): item for item in sections.get(section, [])}


def main() -> int:
    init_db()
    with db() as conn:
        columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(ups_devices)").fetchall()}
    require("telemetry_json" in columns, "ups_devices.telemetry_json migration is missing")
    require("telemetry_updated_at" in columns, "ups_devices.telemetry_updated_at migration is missing")

    standard_values = {
        UPS_IDENT_MANUFACTURER: "APC by Schneider Electric",
        UPS_IDENT_MODEL: "Easy UPS 1P",
        UPS_IDENT_AGENT_SOFTWARE: "NMC3 3.2.1",
        UPS_BATTERY_STATUS: "2",
        UPS_CHARGE_PERCENT: "100",
        UPS_RUNTIME_MINUTES: "43",
        UPS_SECONDS_ON_BATTERY: "0",
        UPS_BATTERY_VOLTAGE: "816",       # RFC1628 is 0.1 V
        UPS_BATTERY_CURRENT: "18",        # RFC1628 is 0.1 A
        UPS_BATTERY_TEMPERATURE: "37",
        UPS_INPUT_LINE_BADS: "1",
        UPS_INPUT_NUM_LINES: "1",
        UPS_OUTPUT_FREQUENCY: "500",      # RFC1628 is 0.1 Hz
        UPS_OUTPUT_NUM_LINES: "1",
        UPS_CONFIG_OUTPUT_VA: "2000",
        UPS_CONFIG_OUTPUT_POWER: "1800",
        UPS_TEST_RESULTS_SUMMARY: "2",
    }
    standard_walks = {
        "rfc_input": [
            (f"{UPS_INPUT_TABLE}.1.1", "1"),
            (f"{UPS_INPUT_TABLE}.2.1", "500"),
            (f"{UPS_INPUT_TABLE}.3.1", "231"),
            (f"{UPS_INPUT_TABLE}.4.1", "18"),
            (f"{UPS_INPUT_TABLE}.5.1", "420"),
        ],
        "rfc_output": [
            (f"{UPS_OUTPUT_TABLE}.1.1", "1"),
            (f"{UPS_OUTPUT_TABLE}.2.1", "230"),
            (f"{UPS_OUTPUT_TABLE}.3.1", "18"),
            (f"{UPS_OUTPUT_TABLE}.4.1", "390"),
            (f"{UPS_OUTPUT_TABLE}.5.1", "17"),
        ],
        "rfc_bypass": [],
    }
    standard = _build_standard_detail_metrics(standard_values, standard_walks)
    battery = metric_map(standard, "battery")
    require(battery["battery_voltage"]["value"] == 81.6, "RFC1628 battery voltage scaling is incorrect")
    require(battery["battery_current"]["value"] == 1.8, "RFC1628 battery current scaling is incorrect")
    require(battery["battery_charge"]["value"] == 100, "RFC1628 battery capacity was not retained")
    require(battery["battery_runtime"]["value"] == 43, "RFC1628 runtime was not retained")
    require(battery["battery_temperature"]["value"] == 37.0, "RFC1628 battery temperature was not retained")
    input_metrics = metric_map(standard, "input")
    require(input_metrics["input_frequency_1"]["value"] == 50.0, "RFC1628 input frequency scaling is incorrect")
    require(input_metrics["input_voltage_1"]["value"] == 231.0, "RFC1628 input voltage was not retained")
    output_metrics = metric_map(standard, "output")
    require(output_metrics["output_load_1"]["value"] == 17.0, "RFC1628 output load was not retained")
    require(output_metrics["rated_output_va"]["value"] == 2000.0, "RFC1628 output VA capacity was not retained")

    apc_values = {
        APC_MANUFACTURE_DATE: "07/15/2025",
        APC_SERIAL_NUMBER: "AS2515000123",
        APC_BATTERY_LAST_REPLACE: "07/15/2025",
        APC_HIGH_PREC_BATTERY_VOLTAGE: "816",
        APC_HIGH_PREC_BATTERY_CURRENT: "18",
        APC_HIGH_PREC_BATTERY_TEMPERATURE: "370",
        APC_BATTERY_CABINET_AH: "7",
        APC_INPUT_FREQUENCY: "50.0",
        APC_OUTPUT_ACTIVE_POWER: "340",
        APC_BATTERY_TEST_LAST_DATE: "08/01/2026",
        APC_BATTERY_TEST_PROCESS: "1",
        APC_BATTERY_TEST_CONDITION: "2",
        APC_COMM_STATUS: "2",
    }
    apc = build_vendor_detail_metrics(DRIVERS["apc"], apc_values, {})
    apc_identity = metric_map(apc, "identity")
    apc_battery = metric_map(apc, "battery")
    apc_diag = metric_map(apc, "diagnostics")
    require(apc_identity["serial_number"]["value"] == "AS2515000123", "APC serial number telemetry is missing")
    require(apc_battery["battery_voltage"]["value"] == 81.6, "APC high precision battery voltage scaling is incorrect")
    require(apc_battery["battery_current"]["value"] == 1.8, "APC high precision battery current scaling is incorrect")
    require(apc_battery["battery_temperature"]["value"] == 37.0, "APC high precision battery temperature scaling is incorrect")
    require(apc_diag["battery_test_process"]["value"] == "Successful", "APC battery-test status mapping is incorrect")
    require(apc_diag["ups_communication"]["value"] == "Communication OK", "APC communication status mapping is incorrect")

    # Detailed cards must use the already resolved vendor-backed snapshot rather
    # than leaving the weaker RFC1628 unknown status visible. Vendor-only charge
    # and runtime should also be surfaced when the generic objects are absent.
    weak_standard = _build_standard_detail_metrics({UPS_BATTERY_STATUS: "1"}, {})
    resolved = _resolved_detail_sections(
        _merge_detail_sections(weak_standard, {}),
        {
            "battery_status": "normal",
            "battery_charge_percent": 100,
            "runtime_minutes": 54,
            "load_percent": 17,
        },
        DRIVERS["apc"],
    )
    resolved_battery = metric_map(resolved, "battery")
    resolved_output = metric_map(resolved, "output")
    require(resolved_battery["battery_status"]["value"] == "Normal", "Resolved APC battery status did not replace RFC unknown")
    require(resolved_battery["battery_status"]["source"] == "APC PowerNet", "Resolved battery status source is not transparent")
    require(resolved_battery["battery_charge"]["value"] == 100, "Vendor-backed battery charge was not added to details")
    require(resolved_battery["battery_runtime"]["value"] == 54, "Vendor-backed runtime was not added to details")
    require(resolved_output["output_load"]["value"] == 17, "Vendor-backed output load was not added to details")

    truly_unknown = _resolved_detail_sections(weak_standard, {"battery_status": "unknown"}, DRIVERS["apc"])
    unknown_battery = metric_map(truly_unknown, "battery")
    require("battery_status" not in unknown_battery, "Unresolved Unknown battery status should be omitted rather than shown as useful telemetry")

    eaton_values = {
        EATON_BATTERY_VOLTAGE: "81.6",
        EATON_BATTERY_CURRENT: "1.8",
        EATON_INPUT_FREQUENCY: "500",
        EATON_INPUT_NUM_PHASES: "1",
        EATON_OUTPUT_FREQUENCY: "500",
        EATON_OUTPUT_NUM_PHASES: "1",
        EATON_CONFIG_OUTPUT_WATTS: "2000",
        EATON_AMBIENT_TEMPERATURE: "37",
    }
    eaton_walks = {
        "input": [
            (f"{EATON_INPUT_TABLE}.1.1", "1"),
            (f"{EATON_INPUT_TABLE}.2.1", "232"),
            (f"{EATON_INPUT_TABLE}.3.1", "18"),
            (f"{EATON_INPUT_TABLE}.4.1", "420"),
        ],
        "output": [
            (f"{EATON_OUTPUT_TABLE}.1.1", "1"),
            (f"{EATON_OUTPUT_TABLE}.2.1", "230"),
            (f"{EATON_OUTPUT_TABLE}.3.1", "18"),
            (f"{EATON_OUTPUT_TABLE}.4.1", "390"),
            (f"{EATON_OUTPUT_TABLE}.5.1", "17"),
        ],
        "bypass": [],
    }
    eaton = build_vendor_detail_metrics(DRIVERS["eaton"], eaton_values, eaton_walks)
    eaton_input = metric_map(eaton, "input")
    eaton_output = metric_map(eaton, "output")
    eaton_environment = metric_map(eaton, "environment")
    require(eaton_input["input_frequency"]["value"] == 50.0, "Eaton input frequency scaling is incorrect")
    require(any(item.get("value") == 232.0 for item in eaton.get("input", [])), "Eaton per-phase input voltage is missing")
    require(any(item.get("value") == 390.0 for item in eaton.get("output", [])), "Eaton per-phase output power is missing")
    require(eaton_environment["ambient_temperature"]["value"] == 37.0, "Eaton environmental telemetry is missing")

    unsupported = build_vendor_detail_metrics(DRIVERS["apc"], {APC_SERIAL_NUMBER: "No Such Object available on this agent"}, {})
    require("identity" not in unsupported or not unsupported["identity"], "Unsupported vendor OIDs must be omitted instead of shown as values")

    print("PORTIVO POWER DETAILS VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
