#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

echo "Portivo Control Center v2.1.0 setup"

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python 3.11 or newer is required." >&2
  exit 1
fi

if ! command -v ping >/dev/null 2>&1; then
  echo "Warning: ping is not installed. Auto health monitoring will use SNMPv3/TCP fallback until iputils-ping (or equivalent) is installed." >&2
fi

"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11 or newer is required")
PY

if [[ ! -x .venv/bin/python ]]; then
  echo "Creating virtual environment..."
  "$PYTHON_BIN" -m venv .venv
else
  echo "Existing .venv detected. It will be reused."
fi

.venv/bin/python -m pip install --disable-pip-version-check --no-deps -r requirements.lock
.venv/bin/python -m pip check

if [[ ! -f .env ]]; then
  secret="$(.venv/bin/python scripts/generate_secret.py)"
  cat > .env <<EOF
APP_NAME=Portivo Control Center
APP_VERSION=2.1.0
APP_HOST=0.0.0.0
APP_PORT=8766
APP_SECRET_KEY=$secret
APP_ADMIN_USERNAME=admin
PUBLIC_URL_SCHEME=http
TRUST_PROXY_HEADERS=false
TRUSTED_PROXY_IPS=127.0.0.1,::1
LOGIN_RATE_LIMIT_ENABLED=true
LOGIN_RATE_LIMIT_WINDOW_SECONDS=300
LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS=30
SSH_CONNECT_TIMEOUT=12
AUTH_CONNECT_TIMEOUT=2.5
AUTH_GLOBAL_TIMEOUT_SECONDS=5
AUTH_MAX_SOURCES=5
SSH_COMMAND_TIMEOUT=30
SSH_CONNECT_RETRIES=3
SSH_RETRY_BACKOFF_SECONDS=0.75
SSH_OPERATION_LOCK_TIMEOUT=180
SSH_POST_SAVE_PROMPT_TIMEOUT=20
SSH_POST_SAVE_COOLDOWN_SECONDS=2
SSH_POST_SAVE_FALLBACK_COOLDOWN_SECONDS=5
SSH_RECENT_AUTH_SUCCESS_WINDOW_SECONDS=60
SSH_RECENT_AUTH_RETRY_DELAY_SECONDS=2
SSH_TERMINAL_IDLE_MINUTES=15
MAX_PARALLEL_SWITCHES=6
FINDER_MAX_PARALLEL_SWITCHES=12
HEALTH_MONITOR_ENABLED=true
HEALTH_PING_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_POLL_INTERVAL_SECONDS=120
HEALTH_POLL_INTERVAL_SECONDS=30
HEALTH_MAX_PARALLEL_SWITCHES=32
HEALTH_PING_ATTEMPTS=3
HEALTH_PING_RETRY_DELAY_SECONDS=5
HEALTH_POLL_JITTER_SECONDS=10
HEALTH_OFFLINE_POLL_INTERVAL_SECONDS=60
HEALTH_LONG_OFFLINE_AFTER_SECONDS=900
HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS=120
DATABASE_PATH=./data/portivo.db
COMMAND_PROFILES_PATH=./data/command_profiles.json
ACTION_CATALOG_PATH=./data/action_catalog.json
EOF
  chmod 600 .env
  echo ".env created."
else
  echo "Existing .env detected. It will not be overwritten."
fi

printf '\nChoose the local bootstrap administrator password. Minimum length: 12 characters.\n'
read -r -s -p "Administrator password: " password1
echo
read -r -s -p "Confirm administrator password: " password2
echo
if [[ "$password1" != "$password2" ]]; then
  echo "The administrator passwords do not match." >&2
  exit 1
fi
if (( ${#password1} < 12 )); then
  echo "The administrator password must contain at least 12 characters." >&2
  exit 1
fi
OSC_ADMIN_PASSWORD="$password1" .venv/bin/python scripts/set_admin_password.py --username admin
unset password1 password2

.venv/bin/python scripts/validate_installation.py
chmod +x start_linux.sh scripts/setup_linux.sh

echo
echo "Installation complete."
echo "Start the application with: ./start_linux.sh"
echo "Local URL: http://127.0.0.1:8766"
echo "LAN URL: http://SERVER-IP:8766"
