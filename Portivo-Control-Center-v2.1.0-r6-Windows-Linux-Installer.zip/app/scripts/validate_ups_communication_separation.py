# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-ups-communication-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "ups-communication.db")
os.environ.setdefault("APP_SECRET_KEY", "ups-communication-validation-secret-000000000000")

from app.db import db, init_db, utc_now  # noqa: E402
from app.main import _public_ups  # noqa: E402
from app.notification_engine import get_notification_state  # noqa: E402
from app.power_monitor import _apply_result, _communication_failure_threshold  # noqa: E402


def row_for(ups_id: int):
    with db() as conn:
        return conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()


def main() -> int:
    init_db()
    now = utc_now()
    with db() as conn:
        conn.execute("UPDATE notification_policy SET failure_threshold=3 WHERE id=1")
        profile_id = int(conn.execute(
            "INSERT INTO monitoring_credential_profiles(name,method,username,created_at,updated_at,updated_by) VALUES(?,?,?,?,?,?)",
            ("UPS communication validation", "snmpv3", "validator", now, now, "validation"),
        ).lastrowid)
        ups_id = int(conn.execute(
            """INSERT INTO ups_devices(name,host,site,monitoring_profile_id,enabled,last_status,last_seen,last_checked,
               power_state,output_source,battery_status,battery_charge_percent,runtime_minutes,load_percent,
               consecutive_failures,created_at,updated_at,updated_by)
               VALUES(?,?,?,?,1,'online',?,?,'normal','normal','normal',100,45,20,0,?,?,?)""",
            ("UPS-OFFLINE", "192.0.2.80", "Validation", profile_id, now, now, now, now, "validation"),
        ).lastrowid)

    # The UPS must remain visually online until the same configured outage
    # confirmation count used by Notifications has actually been reached.
    _apply_result(ups_id, None, "timeout-1", utc_now())
    first = _public_ups(row_for(ups_id))
    assert first["last_status"] == "online", first
    assert int(first["consecutive_failures"]) == 1

    _apply_result(ups_id, None, "timeout-2", utc_now())
    second = _public_ups(row_for(ups_id))
    assert second["last_status"] == "online", second
    assert int(second["consecutive_failures"]) == 2

    _apply_result(ups_id, None, "timeout-3", utc_now())
    third = _public_ups(row_for(ups_id))
    assert third["last_status"] == "unreachable", third
    assert third["communication_status"] == "unreachable"
    assert third["power_state"] == "normal"
    assert third["severity"] == "healthy", third

    with db() as conn:
        incident = conn.execute(
            "SELECT * FROM power_incidents WHERE ups_id=? AND incident_type='ups_unreachable' AND status='open'",
            (ups_id,),
        ).fetchone()
    assert incident is not None, "confirmed communication loss must be retained as informational Power history"

    # A successful live probe must reset the failed-check counter and close the
    # informational communication incident without creating dashboard/notif noise.
    snapshot = {
        "manufacturer": "Validation",
        "model": "UPS",
        "driver_key": "generic",
        "sys_object_id": "1.3.6.1.2.1.33",
        "power_state": "normal",
        "output_source": "normal",
        "battery_status": "normal",
        "battery_charge_percent": 100,
        "runtime_minutes": 45,
        "seconds_on_battery": 0,
        "load_percent": 20,
        "alarm_count": 0,
        "alarms": [],
    }
    _apply_result(ups_id, snapshot, "", utc_now())
    recovered = _public_ups(row_for(ups_id))
    assert recovered["last_status"] == "online", recovered
    assert int(recovered["consecutive_failures"]) == 0

    with db() as conn:
        open_incident = conn.execute(
            "SELECT * FROM power_incidents WHERE ups_id=? AND incident_type='ups_unreachable' AND status='open'",
            (ups_id,),
        ).fetchone()
        closed_incident = conn.execute(
            "SELECT * FROM power_incidents WHERE ups_id=? AND incident_type='ups_unreachable' AND status='closed' ORDER BY id DESC LIMIT 1",
            (ups_id,),
        ).fetchone()
    assert open_incident is None
    assert closed_incident is not None

    notification_state = get_notification_state(include_inventory=False, history_limit=50)
    assert int(notification_state["summary"]["open_power_incidents"]) == 0
    assert not any(str(item.get("incident_type")) == "ups_unreachable" for item in notification_state.get("incidents", []))
    assert not any(str(item.get("event_type")) in {"ups_unreachable", "ups_reachable"} for item in notification_state.get("deliveries", []))

    assert int(_communication_failure_threshold()) == 3

    main_source = (ROOT / "app/main.py").read_text(encoding="utf-8")
    power_history = main_source[main_source.index('def power_incident_history('):main_source.index('@app.get("/api/power/monitoring-profiles")')]
    assert "incident_type<>'ups_unreachable'" not in power_history
    assert 'get("severity") in {"warning", "critical"}' in main_source
    assert "record_ups_probe_failure" in main_source
    assert "record_ups_probe_success" in main_source

    app_js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    assert 'communicationOffline ? "unreachable"' in app_js
    assert 'Communication check ${Math.min(failedChecks, threshold)}/${threshold} failed.' in app_js
    assert 'ups_unreachable: t("power.upsOfflineIncident"' in app_js

    print("UPS COMMUNICATION SEPARATION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
