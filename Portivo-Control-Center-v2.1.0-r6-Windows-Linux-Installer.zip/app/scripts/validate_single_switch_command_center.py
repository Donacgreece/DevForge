# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
PROFILES = json.loads((ROOT / "data/command_profiles.json").read_text(encoding="utf-8"))

profile_actions = set()
for profile in PROFILES.values():
    profile_actions.update((profile.get("commands") or {}).keys())
    profile_actions.update(profile.get("orchestrated_actions") or [])

checks = {
    "single-switch workspace lazy-loads the command library": 'if (viewId === "deviceWorkspaceView" && hasCapability("command_library.view") && !Object.keys(state.profiles || {}).length) loadProfiles()' in JS,
    "workspace refresh can restore a missing command library": 'current === "deviceWorkspaceView"' in JS and '[loadProfiles()]' in JS,
    "profile requests are de-duplicated": 'profilesRequest: null' in JS and 'if (state.profilesRequest) return state.profilesRequest;' in JS,
    "workspace loading does not render the hidden library page": 'if (document.querySelector(".view.active")?.id === "profilesView") renderProfiles();' in JS,
    "verified profile catalog is substantially larger than fallback actions": len(profile_actions) >= 50,
    "workspace still uses the shared role-filtered action source": 'for (const [key, meta] of availableActionEntries())' in JS,
}

failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("SINGLE SWITCH COMMAND CENTER VALIDATION: FAIL")
    for name in failed:
        print(f"  FAIL: {name}")
    raise SystemExit(1)

print(f"SINGLE SWITCH COMMAND CENTER VALIDATION: PASS ({len(profile_actions)} verified profile actions available before role filtering)")
