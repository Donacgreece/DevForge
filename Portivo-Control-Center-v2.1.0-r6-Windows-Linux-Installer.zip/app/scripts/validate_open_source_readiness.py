# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def first_non_shebang(text):
    lines=text.splitlines()
    return "\n".join(lines[:8])

# File-level licensing for Portivo-owned code.
for pattern in ("*.py","*.js","*.css","*.html","*.ps1","*.sh","*.cmd"):
    for p in list((ROOT/"app").rglob(pattern))+list((ROOT/"scripts").rglob(pattern))+list((ROOT/"deployment").rglob(pattern)):
        head=first_non_shebang(p.read_text(encoding="utf-8-sig",errors="replace"))
        assert "SPDX-License-Identifier: AGPL-3.0-only" in head, f"Missing SPDX header: {p.relative_to(ROOT)}"
        assert "Copyright (C) 2026 Dimitris Galatsanos" in head, f"Missing copyright header: {p.relative_to(ROOT)}"
for p in (ROOT/"run.py",):
    head=first_non_shebang(p.read_text(encoding="utf-8-sig"))
    assert "SPDX-License-Identifier: AGPL-3.0-only" in head

lock=(ROOT/"requirements.lock").read_text(encoding="utf-8")
for raw in lock.splitlines():
    line=raw.strip()
    if not line or line.startswith("#"): continue
    requirement=line.split(";",1)[0].strip()
    assert "==" in requirement, f"Unpinned dependency: {line}"
    assert not any(op in requirement.replace("==","") for op in (">=","<=","~=","!=","<",">")), f"Range in lock: {line}"
assert "netmiko==4.7.0" in lock
assert "pysnmp==7.1.28" in lock

sbom=json.loads((ROOT/"SBOM.spdx.json").read_text(encoding="utf-8"))
assert sbom["spdxVersion"]=="SPDX-2.3"
assert any(p["name"]=="Portivo Control Center" and p["licenseDeclared"]=="AGPL-3.0-only" for p in sbom["packages"])
assert len(sbom["packages"]) >= 40
licenses=ROOT/"THIRD_PARTY_LICENSES"
assert licenses.is_dir() and len(list(licenses.glob("*.txt"))) >= 40
third=(ROOT/"THIRD_PARTY_NOTICES.md").read_text(encoding="utf-8")
for name in ("FastAPI","Uvicorn","Netmiko","Paramiko","cryptography","PySNMP","ReportLab","HTTPX","openpyxl"):
    assert name in third, name
idx=(ROOT/"app/static/index.html").read_text(encoding="utf-8")
assert "login-legal-footer" in idx and 'href="/legal/source"' in idx and 'href="/legal/license"' in idx
contrib=(ROOT/"CONTRIBUTING.md").read_text(encoding="utf-8")
assert "does **not** accept external code contributions or pull requests" in contrib
main=(ROOT/"app/main.py").read_text(encoding="utf-8")
for token in ("requirements.lock", "SBOM.spdx.json", "CONTRIBUTING.md", "THIRD_PARTY_LICENSES"):
    assert token in main, token
print("PORTIVO OPEN SOURCE RELEASE READINESS VALIDATION: PASS")
