# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_SECRET_KEY", "compact-port-layout-validation-secret-key-000000000000")

from app.device_layout import (
    infer_device_port_layout, is_compact_os6360_model, is_os6360_family_model,
    infer_compact_os6360_from_live_ports, compact_os6360_port_allowed,
)
from app.device_identity import parse_show_system
from app.port_inventory import parse_lanpower


def main() -> None:
    for model in ("OS6360-10", "OS6360-P10", "OS6360P10", "OS6360-P10-US", "OS6360-P10 Rev.A", "OS6360-P10 AOS 8.9.195.R02", "OS6360-P10 8.10.151.R03", "OS6360 P10 8.10.151.R03"):
        assert is_compact_os6360_model(model), model
        layout = infer_device_port_layout(model, "AOS8")
        assert layout["known"] is True, model
        assert layout["access_ports"] == 8, (model, layout)
        assert layout["uplink_ports"] == 4, (model, layout)
        assert layout["total_ports"] == 12, (model, layout)
        assert layout["modules"][0]["ports"] == [f"1/1/{n}" for n in range(1, 9)]
        assert layout["modules"][1]["ports"] == [f"1/1/{n}" for n in range(9, 13)]


    assert compact_os6360_port_allowed("1/1/1", "AOS8")
    assert compact_os6360_port_allowed("1/1/12", "AOS8")
    assert compact_os6360_port_allowed("1/12", "AOS8")
    assert not compact_os6360_port_allowed("1/1/13", "AOS8")
    assert not compact_os6360_port_allowed("1/1/108", "AOS8")
    assert not compact_os6360_port_allowed("1/1/111", "AOS8")
    assert not compact_os6360_port_allowed("1/1/120", "AOS8")

    # Real OS6360 compact units may report only the generic family string.
    # The live interface evidence from the field is 1..12 plus pseudo rows
    # such as 108/120. That exact shape must resolve to the compact layout.
    live_ports = [f"1/1/{n}" for n in range(1, 13)] + ["1/1/108", "1/1/120"]
    assert is_os6360_family_model("Alcatel-Lucent Enterprise OmniSwitch OS6360")
    assert infer_compact_os6360_from_live_ports("OS6360", live_ports, "AOS8")
    assert infer_compact_os6360_from_live_ports("OS6360", [f"1/{n}" for n in range(1, 13)] + ["1/108", "1/120"], "AOS8")
    assert not infer_compact_os6360_from_live_ports("OS6360", [f"1/1/{n}" for n in range(1, 13)], "AOS8")
    assert not infer_compact_os6360_from_live_ports("OS6360", live_ports + ["1/1/24"], "AOS8")
    assert not infer_compact_os6360_from_live_ports("OS6560", live_ports, "AOS8")

    # Real identity output can mention the generic family before the exact SKU.
    # The driver must retain the most specific model so the front panel layout
    # resolves to the compact 8+4 physical-port chassis.
    identity = parse_show_system(
        "Description: Alcatel-Lucent Enterprise OmniSwitch OS6360, 8.9.195.R02\n"
        "Hardware model: OS6360-P10\n",
        profile_hint="AOS8",
    )
    assert identity.model == "OS6360-P10", identity
    assert infer_device_port_layout(identity.model, "AOS8")["total_ports"] == 12

    regular = infer_device_port_layout("OS6560-P48X4", "AOS8")
    assert regular["access_ports"] == 48
    assert regular["uplink_ports"] == 4

    known = {f"1/1/{n}" for n in range(1, 13)}
    sample = """
Port Maximum Actual Used Status Priority On/Off Class Type
1 30000 1200 Powered On Low On 4 802.3at
11 30000 0 Powered Off Low Off 0 802.3af
111 120 0 Powered On Low On 0 PoE
120 Total Available Power
"""
    poe = parse_lanpower(sample, "1/1", known)
    assert set(poe) == {"1/1/1", "1/1/11"}, poe
    assert "1/1/111" not in poe
    assert "1/1/120" not in poe

    app_js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
    assert "const liveDevice = result.device || device;" in app_js
    assert "hydrateWorkspacePorts(liveDevice, result.ports || [])" in app_js
    assert "function workspaceEffectivePortLayout(device, livePorts = [])" in app_js
    assert "function workspaceSanitizeLivePorts(device, livePorts = [])" in app_js
    assert "workspaceCompactOs6360FromPorts(device, livePorts)" in app_js
    print("Compact OS6360 layout, live identity hydration and phantom-port validation passed")


if __name__ == "__main__":
    main()
