﻿# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
param(
    [string]$AppPath = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
    [int]$Port = 0
)

$ErrorActionPreference = "Stop"
$envPath = Join-Path $AppPath ".env"
if (-not (Test-Path $envPath)) {
    throw "The .env file was not found at $envPath"
}

$lines = [System.Collections.Generic.List[string]]::new()
foreach ($line in (Get-Content -LiteralPath $envPath)) {
    [void]$lines.Add([string]$line)
}
if ($Port -le 0) {
    $portLine = $lines | Where-Object { $_ -match '^\s*APP_PORT\s*=' } | Select-Object -First 1
    $Port = if ($portLine) { [int]((($portLine -split '=', 2)[1]).Trim('"', "'", ' ')) } else { 8766 }
}

$hostFound = $false
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*APP_HOST\s*=') {
        $lines[$i] = 'APP_HOST=0.0.0.0'
        $hostFound = $true
        break
    }
}
if (-not $hostFound) { $lines.Add('APP_HOST=0.0.0.0') }
[System.IO.File]::WriteAllLines($envPath, $lines, (New-Object System.Text.UTF8Encoding($false)))

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run this script from PowerShell opened as Administrator."
}

$ruleName = "Portivo Control Center TCP $Port"
$existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
if (-not $existing) {
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Domain,Private,Public | Out-Null
} else {
    Set-NetFirewallRule -DisplayName $ruleName -Enabled True -Direction Inbound -Action Allow -Profile Domain,Private,Public | Out-Null
}

Write-Host "LAN access enabled on Domain, Private and Public Windows network profiles for TCP port $Port." -ForegroundColor Green
& (Join-Path $AppPath "scripts\show_lan_addresses.ps1") -Port $Port -AppPath $AppPath
