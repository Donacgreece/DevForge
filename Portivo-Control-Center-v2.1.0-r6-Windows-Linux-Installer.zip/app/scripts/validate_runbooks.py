# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_SECRET_KEY", "runbook-validation-secret-key-000000000000000")
DB_PATH = Path(tempfile.gettempdir()) / "portivo-runbook-validation.db"
os.environ["DATABASE_PATH"] = str(DB_PATH)

from app.db import init_db
from app.runbooks import (
    approve_runbook,
    classify_command,
    delete_runbook,
    get_runbook,
    normalize_runbook_payload,
    render_runbook,
    save_runbook,
)


def main() -> int:
    try:
        DB_PATH.unlink(missing_ok=True)
        Path(str(DB_PATH) + "-wal").unlink(missing_ok=True)
        Path(str(DB_PATH) + "-shm").unlink(missing_ok=True)
        init_db()
        source = {
            "name": "Validation Runbook",
            "description": "validator",
            "allow_scheduled": True,
            "max_targets": 25,
            "concurrency": 4,
            "failure_policy": "continue",
            "variables": [{"name": "vlan", "label": "VLAN", "default": "200", "required": True}],
            "steps": [
                {"type": "command", "command": "show vlan {{vlan}}"},
                {"type": "wait", "seconds": 2},
                {"type": "verify", "command": "show vlan {{vlan}}"},
            ],
        }
        payload = normalize_runbook_payload(source)
        assert payload["risk"] == "read"

        saved = save_runbook(source, "validator")
        assert saved["status"] == "draft"
        approved = approve_runbook(saved["id"], "validator")
        assert approved["status"] == "approved"
        assert approved["approved_by"] == "validator"

        rendered = render_runbook(approved, {"vlan": "100"})
        assert rendered["steps"][0]["command"] == "show vlan 100"
        assert rendered["steps"][1]["seconds"] == 2
        assert rendered["risk"] == "read"

        # Execution snapshots must stay immutable after a library edit.
        snapshot_command = rendered["steps"][0]["command"]
        edited_source = {**source, "steps": [{"type": "command", "command": "show system"}]}
        edited = save_runbook(edited_source, "validator", runbook_id=saved["id"])
        assert edited["status"] == "draft"
        assert edited["approved_by"] is None
        assert rendered["steps"][0]["command"] == snapshot_command
        assert get_runbook(saved["id"])["steps"][0]["command"] == "show system"

        assert classify_command("interfaces 1/1/1 admin-state disable") == "change"
        assert classify_command("reload") == "high"
        assert classify_command("show system") == "read"

        # Variables cannot become command separators, and VERIFY stays read-only.
        try:
            render_runbook(approved, {"vlan": "200; reload"})
            raise AssertionError("command-separator variable was accepted")
        except ValueError:
            pass
        try:
            normalize_runbook_payload({
                "name": "Invalid verify",
                "steps": [{"type": "verify", "command": "interfaces 1/1/1 admin-state disable"}],
            })
            raise AssertionError("state-changing VERIFY step was accepted")
        except ValueError:
            pass

        delete_runbook(saved["id"])
        assert get_runbook(saved["id"]) is None
    except Exception as exc:
        print(f"RUNBOOK VALIDATION: FAIL ({exc})")
        return 1
    finally:
        DB_PATH.unlink(missing_ok=True)
        Path(str(DB_PATH) + "-wal").unlink(missing_ok=True)
        Path(str(DB_PATH) + "-shm").unlink(missing_ok=True)
    print("RUNBOOK VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
