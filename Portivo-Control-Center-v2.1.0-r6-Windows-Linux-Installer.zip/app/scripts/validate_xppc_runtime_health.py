# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations
import os, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
os.environ.setdefault("APP_SECRET_KEY","xppc-runtime-health-validator-secret-000000000")
from app.power_drivers import DRIVERS,enrich_snapshot,build_vendor_detail_metrics,XPPC_BATTERY_STATUS,XPPC_BATTERY_CAPACITY,XPPC_RUNTIME_SECONDS,XPPC_OUTPUT_LOAD,XPPC_OUTPUT_STATUS,XPPC_3P_RUNTIME_MINUTES,XPPC_3P_OUTPUT_LOAD_R,XPPC_3P_OUTPUT_FREQUENCY
import app.power_monitor as power_monitor
power_monitor.get_app_setting_int = lambda name, default, minimum, maximum: default
from app.power_monitor import _derive_power_state
base={"battery_status":"normal","battery_charge_percent":100,"runtime_minutes":0,"seconds_on_battery":0,"output_source":"normal","load_percent":0,"alarms":[],"alarm_count":0}
values={XPPC_BATTERY_STATUS:"2",XPPC_BATTERY_CAPACITY:"100",XPPC_RUNTIME_SECONDS:"0",XPPC_OUTPUT_LOAD:"0",XPPC_OUTPUT_STATUS:"2",XPPC_3P_RUNTIME_MINUTES:"76",XPPC_3P_OUTPUT_LOAD_R:"17",XPPC_3P_OUTPUT_FREQUENCY:"500"}
r=enrich_snapshot(DRIVERS["xppc"],base,values)
assert r["runtime_minutes"]==76,r
assert r["load_percent"]==17,r
flat={m["key"]:m for rows in build_vendor_detail_metrics(DRIVERS["xppc"],values).values() for m in rows}
assert flat["battery_runtime"]["value"]==76,flat.get("battery_runtime")
assert flat["output_load_1"]["value"]==17,flat.get("output_load_1")
assert flat["output_frequency"]["value"]==50,flat.get("output_frequency")
assert _derive_power_state({"output_source":"unknown","battery_status":"normal","battery_charge_percent":100,"seconds_on_battery":0})=="normal"
print("XPPC runtime/load fallback and UPS health normalization: PASS")
