# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    temp_dir = tempfile.TemporaryDirectory(prefix="portivo-power-driver-validation-")
    os.environ["DATABASE_PATH"] = str(Path(temp_dir.name) / "drivers.db")
    os.environ.setdefault("APP_SECRET_KEY", "power-driver-validation-secret-key-000000000000")

    from app.db import init_db
    from app.power_drivers import (
        APC_BATTERY_CAPACITY,
        APC_BATTERY_STATUS,
        APC_HIGH_PREC_BATTERY_CAPACITY,
        APC_MODEL,
        APC_OUTPUT_LOAD,
        APC_OUTPUT_STATUS,
        EATON_ALARMS,
        EATON_ALARM_DESCR_TABLE,
        EATON_BATTERY_CAPACITY,
        EATON_MANUFACTURER,
        EATON_MODEL,
        EATON_OUTPUT_LOAD,
        EATON_OUTPUT_SOURCE,
        EATON_RUNTIME_SECONDS,
        XPPC_ENTERPRISE, XPPC_MODEL, XPPC_BATTERY_STATUS, XPPC_BATTERY_CAPACITY, XPPC_RUNTIME_SECONDS, XPPC_OUTPUT_STATUS, XPPC_OUTPUT_LOAD,
        VERTIV_ENTERPRISE,
        VERTIV_SYSTEM_STATUS,
        VERTIV_OUTPUT_SOURCE,
        VERTIV_BATTERY_CAPACITY,
        VERTIV_BATTERY_RUNTIME,
        VERTIV_OUTPUT_LOAD,
        VERTIV_ALARM_BATTERY_LOW,
        CYBERPOWER_ENTERPRISE, RIELLO_ENTERPRISE,
        SYS_DESCR,
        SYS_OBJECT_ID,
        UPS_IDENT_MANUFACTURER,
        UPS_IDENT_MODEL,
        detect_driver,
        enrich_snapshot,
        power_driver_catalog,
        vendor_alarm_label,
    )

    init_db()
    catalog = {item["key"] for item in power_driver_catalog()}
    if catalog != {"auto", "generic", "xppc", "apc", "eaton", "vertiv", "socomec", "acculine", "cyberpower", "riello"}:
        raise AssertionError(f"Unexpected UPS driver catalog: {catalog}")

    cyberpower = detect_driver({SYS_OBJECT_ID: CYBERPOWER_ENTERPRISE + ".1", UPS_IDENT_MANUFACTURER: "CyberPower Systems"})
    if cyberpower.key != "cyberpower":
        raise AssertionError(f"CyberPower auto detection failed: {cyberpower.key}")
    cyber_snapshot = enrich_snapshot(cyberpower, {"manufacturer":"", "alarms":[]}, {SYS_OBJECT_ID: CYBERPOWER_ENTERPRISE + ".1"})
    if cyber_snapshot.get("manufacturer") != "CyberPower":
        raise AssertionError(f"CyberPower identity enrichment failed: {cyber_snapshot}")

    riello = detect_driver({SYS_OBJECT_ID: RIELLO_ENTERPRISE + ".1", UPS_IDENT_MANUFACTURER: "Riello UPS"})
    if riello.key != "riello":
        raise AssertionError(f"Riello auto detection failed: {riello.key}")
    riello_snapshot = enrich_snapshot(riello, {"manufacturer":"", "alarms":[]}, {SYS_OBJECT_ID: RIELLO_ENTERPRISE + ".1"})
    if riello_snapshot.get("manufacturer") != "Riello UPS":
        raise AssertionError(f"Riello identity enrichment failed: {riello_snapshot}")

    xppc_values = {
        SYS_OBJECT_ID: XPPC_ENTERPRISE,
        SYS_DESCR: "SNMP Web Manager",
        XPPC_MODEL: "Intelligent 3000VA",
        XPPC_BATTERY_STATUS: "2",
        XPPC_BATTERY_CAPACITY: "100",
        XPPC_RUNTIME_SECONDS: "4560",
        XPPC_OUTPUT_STATUS: "2",
        XPPC_OUTPUT_LOAD: "17",
    }
    xppc = detect_driver(xppc_values)
    if xppc.key != "xppc":
        raise AssertionError(f"XPPC auto detection failed: {xppc.key}")
    xppc_snapshot = enrich_snapshot(xppc, {
        "manufacturer": "", "model": "UPS", "software_version": "", "battery_status": "unknown",
        "battery_charge_percent": 100, "runtime_minutes": 0, "output_source": "normal",
        "load_percent": 0, "alarms": [],
    }, xppc_values)
    if xppc_snapshot["model"] != "Intelligent 3000VA" or xppc_snapshot["runtime_minutes"] != 76 or xppc_snapshot["load_percent"] != 17 or xppc_snapshot["output_source"] != "normal":
        raise AssertionError(f"XPPC enrichment failed: {xppc_snapshot}")

    apc_values = {
        SYS_OBJECT_ID: "1.3.6.1.4.1.318.1.3.27",
        SYS_DESCR: "APC Web/SNMP Management Card",
        APC_MODEL: "Smart-UPS SRT 3000",
        APC_BATTERY_STATUS: "2",
        APC_BATTERY_CAPACITY: "96",
        APC_OUTPUT_STATUS: "3",
        APC_OUTPUT_LOAD: "41",
    }
    apc = detect_driver(apc_values)
    if apc.key != "apc":
        raise AssertionError(f"APC auto detection failed: {apc.key}")
    apc_snapshot = enrich_snapshot(apc, {
        "manufacturer": "", "model": "", "software_version": "", "battery_status": "unknown",
        "battery_charge_percent": None, "runtime_minutes": None, "output_source": "other",
        "load_percent": None, "alarms": [],
    }, apc_values)
    if apc_snapshot["model"] != "Smart-UPS SRT 3000" or apc_snapshot["battery_charge_percent"] != 96 or apc_snapshot["output_source"] != "battery" or apc_snapshot["load_percent"] != 41:
        raise AssertionError(f"APC enrichment failed: {apc_snapshot}")

    # Easy UPS/NMC3 regression: some platforms expose the PowerNet high-precision
    # battery capacity while the classic advanced capacity scalar is unavailable.
    easy_ups_values = {
        SYS_OBJECT_ID: "1.3.6.1.4.1.318.1.3.27",
        SYS_DESCR: "APC Network Management Card 3",
        APC_MODEL: "EASY UPS 1P SRVPM1KRIL-E",
        APC_BATTERY_STATUS: "2",
        APC_BATTERY_CAPACITY: "No Such Instance currently exists at this OID",
        APC_HIGH_PREC_BATTERY_CAPACITY: "987",
        APC_OUTPUT_STATUS: "2",
        APC_OUTPUT_LOAD: "23",
    }
    easy_ups_snapshot = enrich_snapshot(apc, {
        "manufacturer": "", "model": "", "software_version": "", "battery_status": "unknown",
        "battery_charge_percent": None, "runtime_minutes": 38, "output_source": "other",
        "load_percent": None, "alarms": [],
    }, easy_ups_values)
    if easy_ups_snapshot["battery_charge_percent"] != 99 or easy_ups_snapshot["output_source"] != "normal":
        raise AssertionError(f"APC high-precision battery fallback failed: {easy_ups_snapshot}")

    if EATON_MANUFACTURER != "1.3.6.1.4.1.534.1.1.1.0" or EATON_RUNTIME_SECONDS != "1.3.6.1.4.1.534.1.2.1.0" or EATON_OUTPUT_SOURCE != "1.3.6.1.4.1.534.1.4.5.0" or EATON_ALARMS != "1.3.6.1.4.1.534.1.7.1.0" or EATON_ALARM_DESCR_TABLE != "1.3.6.1.4.1.534.1.7.2.1.2":
        raise AssertionError("Eaton xUPS OID hierarchy does not match the official PowerMIB enterprise tree")

    eaton_values = {
        SYS_OBJECT_ID: "1.3.6.1.4.1.534.1",
        SYS_DESCR: "Eaton Network-M3",
        EATON_MANUFACTURER: "Eaton",
        EATON_MODEL: "9PX 3000",
        EATON_RUNTIME_SECONDS: "1800",
        EATON_BATTERY_CAPACITY: "88",
        EATON_OUTPUT_LOAD: "34",
        EATON_OUTPUT_SOURCE: "3",
    }
    eaton = detect_driver(eaton_values)
    if eaton.key != "eaton":
        raise AssertionError(f"Eaton auto detection failed: {eaton.key}")
    eaton_snapshot = enrich_snapshot(eaton, {
        "manufacturer": "", "model": "", "software_version": "", "battery_status": "unknown",
        "battery_charge_percent": None, "runtime_minutes": None, "output_source": "other",
        "load_percent": None, "alarms": [],
    }, eaton_values)
    if eaton_snapshot["model"] != "9PX 3000" or eaton_snapshot["runtime_minutes"] != 30 or eaton_snapshot["battery_charge_percent"] != 88 or eaton_snapshot["output_source"] != "normal":
        raise AssertionError(f"Eaton enrichment failed: {eaton_snapshot}")

    if vendor_alarm_label(eaton, "1.3.6.1.4.1.534.1.7.4") != "Low battery":
        raise AssertionError("Eaton xUPS well-known alarm mapping failed")


    vertiv_values = {
        SYS_OBJECT_ID: f"{VERTIV_ENTERPRISE}.1.42.3",
        SYS_DESCR: "Vertiv Liebert GXT5 RDU101",
        UPS_IDENT_MANUFACTURER: "Vertiv",
        UPS_IDENT_MODEL: "Liebert GXT5-3000IRT2UXLE",
        VERTIV_SYSTEM_STATUS: "On Battery",
        VERTIV_OUTPUT_SOURCE: "3",
        VERTIV_BATTERY_CAPACITY: "93.0",
        VERTIV_BATTERY_RUNTIME: "28.4",
        VERTIV_OUTPUT_LOAD: "31.7",
        VERTIV_ALARM_BATTERY_LOW: "0",
    }
    vertiv = detect_driver(vertiv_values)
    if vertiv.key != "vertiv":
        raise AssertionError(f"Vertiv auto detection failed: {vertiv.key}")
    vertiv_snapshot = enrich_snapshot(vertiv, {
        "manufacturer": "", "model": "Liebert GXT5-3000IRT2UXLE", "software_version": "", "battery_status": "unknown",
        "battery_charge_percent": None, "runtime_minutes": None, "output_source": "other",
        "load_percent": None, "alarms": [],
    }, vertiv_values)
    if vertiv_snapshot["manufacturer"] not in {"Vertiv", "Vertiv / Liebert"} or vertiv_snapshot["battery_charge_percent"] != 93 or vertiv_snapshot["runtime_minutes"] != 28 or vertiv_snapshot["load_percent"] != 32 or vertiv_snapshot["output_source"] != "battery" or vertiv_snapshot["battery_status"] != "discharging":
        raise AssertionError(f"Vertiv enrichment failed: {vertiv_snapshot}")

    socomec = detect_driver({SYS_DESCR: "SOCOMEC NET VISION 7", UPS_IDENT_MANUFACTURER: "SOCOMEC", UPS_IDENT_MODEL: "MASTERYS BC+"})
    if socomec.key != "socomec":
        raise AssertionError(f"Socomec auto detection failed: {socomec.key}")
    socomec_snapshot = enrich_snapshot(socomec, {"manufacturer":"", "alarms":[]}, {})
    if socomec_snapshot.get("manufacturer") != "Socomec":
        raise AssertionError(f"Socomec manufacturer normalization failed: {socomec_snapshot}")

    acculine = detect_driver({SYS_DESCR: "AccuLine TNmax UPS SNMP card", UPS_IDENT_MODEL: "TNmax 3000"})
    if acculine.key != "acculine":
        raise AssertionError(f"AccuLine auto detection failed: {acculine.key}")
    acculine_snapshot = enrich_snapshot(acculine, {"manufacturer":"", "alarms":[]}, {})
    if acculine_snapshot.get("manufacturer") != "AccuLine":
        raise AssertionError(f"AccuLine manufacturer normalization failed: {acculine_snapshot}")

    forced_socomec = detect_driver({}, requested="socomec")
    if forced_socomec.key != "socomec":
        raise AssertionError("Explicit Socomec driver mode was not respected")

    generic = detect_driver({SYS_DESCR: "RFC1628 UPS"})
    if generic.key != "generic":
        raise AssertionError(f"Generic fallback failed: {generic.key}")

    apc_by_rfc_identity = detect_driver({UPS_IDENT_MANUFACTURER: "Schneider Electric", UPS_IDENT_MODEL: "APC Smart-UPS"})
    if apc_by_rfc_identity.key != "apc":
        raise AssertionError(f"APC RFC1628 identity auto detection failed: {apc_by_rfc_identity.key}")

    eaton_by_rfc_identity = detect_driver({UPS_IDENT_MANUFACTURER: "Eaton", UPS_IDENT_MODEL: "9PX"})
    if eaton_by_rfc_identity.key != "eaton":
        raise AssertionError(f"Eaton RFC1628 identity auto detection failed: {eaton_by_rfc_identity.key}")

    forced = detect_driver({}, requested="apc")
    if forced.key != "apc":
        raise AssertionError("Explicit APC driver mode was not respected")

    print("Portivo UPS driver validation: PASS")
    temp_dir.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
