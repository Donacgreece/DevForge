# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
import secrets

print(secrets.token_urlsafe(48))
