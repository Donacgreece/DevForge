# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app_js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
index = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")

# Roadmap is a standalone sidebar destination, not a child of More.
assert 'class="nav-item sidebar-roadmap-link" data-view="roadmapView"' in index
assert 'class="nav-item" data-view="moreView"' in index
assert 'const moreChild = ["moreView", "profilesView", "driversView"].includes(viewId);' in app_js
assert '["moreView", "profilesView", "driversView", "roadmapView"].includes(viewId)' not in app_js

# Active state must be exact for Roadmap, while More may represent only its true child views.
needle = 'item.classList.toggle("active", item.dataset.view === viewId || (item.dataset.view === "moreView" && moreChild))'
assert needle in app_js

print("SIDEBAR NAVIGATION ACTIVE-STATE VALIDATION: PASS")
