# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'app/static/index.html').read_text(encoding='utf-8')
plan = re.search(r'<section class="roadmap-tab-panel active" data-roadmap-panel="plan">(.*?)</section>', html, re.S)
if not plan:
    raise AssertionError('Roadmap plan panel not found')
stages = re.findall(r'<article class="roadmap-stage[^>]*>(.*?)</article>', plan.group(1), re.S)
if not stages:
    raise AssertionError('No roadmap stages found')
for stage in stages:
    items = re.findall(r'<li\b', stage)
    if len(items) != 4:
        title = re.search(r'<strong(?: [^>]*)?>(.*?)</strong>', stage, re.S)
        label = re.sub('<[^>]+>', '', title.group(1)).strip() if title else 'unknown stage'
        raise AssertionError(f'Roadmap stage {label!r} has {len(items)} bullets instead of 4')
if 'Lightweight Adaptive Health Monitoring' not in plan.group(1):
    raise AssertionError('Released roadmap theme is not Lightweight Adaptive Health Monitoring')
if re.search(r'verinso', plan.group(1), re.I):
    raise AssertionError('Reseller branding leaked into Roadmap')
print('ROADMAP FOUR-BULLET VALIDATION: PASS')
