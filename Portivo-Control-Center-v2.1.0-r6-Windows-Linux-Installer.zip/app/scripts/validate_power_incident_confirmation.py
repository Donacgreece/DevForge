# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-power-confirm-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "power-confirm.db")
os.environ.setdefault("APP_SECRET_KEY", "power-confirmation-validation-only-secret-000000")

from app.db import db, init_db  # noqa: E402
from app.notification_engine import observe_ups_result  # noqa: E402


def ups_state(power: str, started: str, *, status: str = "online", status_changed_at: str | None = None) -> dict[str, object]:
    return {
        "id": 1,
        "name": "UPS-TEST",
        "host": "192.0.2.50",
        "site": "Test",
        "group_name": "Lab",
        "model": "Test UPS",
        "last_status": status,
        "status_changed_at": status_changed_at or started,
        "power_state": power,
        "power_event_started_at": started,
        "output_source": "normal" if power == "normal" else "battery",
        "battery_status": "normal",
        "battery_charge_percent": 100,
        "runtime_minutes": 60,
        "seconds_on_battery": 0,
        "load_percent": 10,
        "alarm_count": 0,
        "alarms": [],
        "last_error": "",
    }


def main() -> int:
    init_db()
    with db() as conn:
        now = "2026-08-17T07:00:00+00:00"
        cursor = conn.execute(
            """
            INSERT INTO monitoring_credential_profiles(
                name, method, username, created_at, updated_at, updated_by
            ) VALUES('UPS test', 'snmpv3', 'test', ?, ?, 'validation')
            """,
            (now, now),
        )
        profile_id = int(cursor.lastrowid)
        conn.execute(
            """
            INSERT INTO ups_devices(
                id, name, host, monitoring_profile_id, enabled, last_status,
                power_state, created_at, updated_at, updated_by
            ) VALUES(1, 'UPS-TEST', '192.0.2.50', ?, 1, 'online', 'normal', ?, ?, 'validation')
            """,
            (profile_id, now, now),
        )
        conn.execute("UPDATE app_settings SET value='30' WHERE name='ups_unreachable_confirm_seconds'")
        conn.execute("UPDATE app_settings SET value='20' WHERE name='ups_power_confirm_seconds'")
        conn.execute("UPDATE app_settings SET value='20' WHERE name='ups_power_recovery_seconds'")

    normal0 = ups_state("normal", "2026-08-17T07:00:00+00:00")
    abnormal0 = ups_state("on_battery", "2026-08-17T07:01:00+00:00")
    observe_ups_result(abnormal0, previous=normal0, checked_at="2026-08-17T07:01:00+00:00")
    with db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM power_incidents").fetchone()[0] == 0

    # A short false state must disappear without ever entering incident history.
    recovered_fast = ups_state("normal", "2026-08-17T07:01:10+00:00")
    observe_ups_result(recovered_fast, previous=abnormal0, checked_at="2026-08-17T07:01:10+00:00")
    with db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM power_incidents").fetchone()[0] == 0

    abnormal1 = ups_state("on_battery", "2026-08-17T07:02:00+00:00")
    observe_ups_result(abnormal1, previous=recovered_fast, checked_at="2026-08-17T07:02:00+00:00")
    abnormal_confirmed = ups_state("on_battery", "2026-08-17T07:02:00+00:00")
    observe_ups_result(abnormal_confirmed, previous=abnormal1, checked_at="2026-08-17T07:02:25+00:00")
    with db() as conn:
        row = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_on_battery'").fetchone()
        assert row is not None and row["status"] == "open"
        assert row["opened_at"] == "2026-08-17T07:02:00+00:00"

    normal1 = ups_state("normal", "2026-08-17T07:03:00+00:00")
    observe_ups_result(normal1, previous=abnormal_confirmed, checked_at="2026-08-17T07:03:00+00:00")
    with db() as conn:
        assert conn.execute("SELECT status FROM power_incidents WHERE incident_type='ups_on_battery'").fetchone()[0] == "open"

    normal_confirmed = ups_state("normal", "2026-08-17T07:03:00+00:00")
    observe_ups_result(normal_confirmed, previous=normal1, checked_at="2026-08-17T07:03:25+00:00")
    with db() as conn:
        row = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_on_battery'").fetchone()
        assert row["status"] == "closed"
        assert row["recovered_at"] == "2026-08-17T07:03:00+00:00"

    # Confirmed communication loss is informational Power history only. It is
    # visible in Power, but never creates webhook delivery noise.
    unreachable0 = ups_state(
        "normal", "2026-08-17T07:04:00+00:00", status="unreachable",
        status_changed_at="2026-08-17T07:04:00+00:00",
    )
    observe_ups_result(unreachable0, previous=normal_confirmed, checked_at="2026-08-17T07:04:00+00:00")
    with db() as conn:
        row = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()
        assert row is not None and row["status"] == "open"
        assert conn.execute("SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')").fetchone()[0] == 0

    reachable = ups_state(
        "normal", "2026-08-17T07:05:00+00:00", status="online",
        status_changed_at="2026-08-17T07:05:00+00:00",
    )
    observe_ups_result(reachable, previous=unreachable0, checked_at="2026-08-17T07:05:00+00:00")
    with db() as conn:
        row = conn.execute("SELECT * FROM power_incidents WHERE incident_type='ups_unreachable'").fetchone()
        assert row is not None and row["status"] == "closed" and row["recovered_at"]
        assert conn.execute("SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')").fetchone()[0] == 0

    print("PORTIVO UPS INCIDENT CONFIRMATION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
