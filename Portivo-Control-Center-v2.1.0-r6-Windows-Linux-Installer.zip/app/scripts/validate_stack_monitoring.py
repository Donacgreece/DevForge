# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import tempfile
import sys
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_SECRET_KEY", "stack-validation-only-secret-key-000000000000000")
_tmp = tempfile.TemporaryDirectory(prefix="portivo-stack-validation-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "portivo.db")

from app.db import db, init_db  # noqa: E402
from app.profiles import render_command  # noqa: E402
from app.snmp_monitor import parse_entity_mib  # noqa: E402
import app.snmp_monitor as snmp_monitor  # noqa: E402
from app.stack_monitor import parse_stack_members, _record_result  # noqa: E402


def fail(message: str) -> int:
    print(f"STACK MONITORING VALIDATION: FAIL: {message}")
    return 1


def device_dict(device_id: int):
    with db() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
    return {key: row[key] for key in row.keys()}


def main() -> int:
    topology_command, _ = render_command("AOS8", "vc_topology")
    if topology_command.strip().lower() != "show virtual-chassis topology":
        return fail(f"unexpected AOS8 topology command: {topology_command}")

    topology_fixture = """
Oper Chas Role       Status     Config Chas ID  Oper Pri  Group  MAC-Address
---------+----------+----------+---------------+---------+------+------------------
1         Master     Running    1               100       0      02:10:00:00:00:01
2         Slave      Running    2               100       0      02:10:00:00:00:02
3         Slave      Running    3               100       0      02:10:00:00:00:03
4         Slave      Running    4               100       0      02:10:00:00:00:04
"""
    parsed = parse_stack_members(topology_fixture)
    if parsed["count"] != 4 or parsed["member_ids"] != ["1", "2", "3", "4"]:
        return fail(f"AOS8 topology fixture parsed incorrectly: {parsed}")
    if parsed["members"][0].get("role") != "Master" or not parsed["members"][0].get("mac"):
        return fail("topology role/MAC evidence was not preserved")

    not_joined_fixture = """
Local Chassis: 1
Oper Chas Role        Status      Config Chas ID  Oper Pri  Group  MAC-Address
---------+-----------+-----------+---------------+---------+------+------------------
1         Master      Running     1               100       10     02:10:00:00:00:11
-         Unassigned  Not-Joined  2               -         -      -
"""
    not_joined = parse_stack_members(not_joined_fixture)
    if not not_joined["ok"] or not_joined["count"] != 1 or not_joined["detected_count"] != 2:
        return fail(f"AOS8 Not-Joined topology parsed incorrectly: {not_joined}")
    if not_joined["member_ids"] != ["1"]:
        return fail(f"AOS8 Not-Joined active member set is wrong: {not_joined}")
    member2 = next((item for item in not_joined["members"] if item.get("id") == "2"), None)
    if not member2 or str(member2.get("status") or "").lower() != "not-joined":
        return fail(f"configured Not-Joined member was not preserved: {not_joined}")

    entity_fixture = [
        ("1.3.6.1.2.1.47.1.1.1.1.5.101", "3"),
        ("1.3.6.1.2.1.47.1.1.1.1.6.101", "1"),
        ("1.3.6.1.2.1.47.1.1.1.1.7.101", "Chassis 1"),
        ("1.3.6.1.2.1.47.1.1.1.1.11.101", "SER001"),
        ("1.3.6.1.2.1.47.1.1.1.1.13.101", "OS6560-P48X4"),
        ("1.3.6.1.2.1.47.1.1.1.1.5.102", "chassis(3)"),
        ("1.3.6.1.2.1.47.1.1.1.1.6.102", "2"),
        ("1.3.6.1.2.1.47.1.1.1.1.7.102", "Chassis 2"),
        ("1.3.6.1.2.1.47.1.1.1.1.11.102", "SER002"),
    ]
    snmp = parse_entity_mib(entity_fixture)
    if not snmp["ok"] or snmp["member_ids"] != ["1", "2"]:
        return fail(f"SNMPv3 ENTITY-MIB fixture parsed incorrectly: {snmp}")

    # Regression: verification must mirror normal desktop SNMP tools by letting
    # the OS select the source address first. Explicit source binding is only a
    # timeout fallback. USM passphrase key types are left at PySNMP defaults.
    import asyncio
    class FakeValue:
        def __init__(self, value): self.value = value
        def prettyPrint(self): return self.value
    class FakeTarget:
        def __init__(self): self.bound = False
        def set_local_address(self, _iface): self.bound = True; return self
    class FakeUdpTarget:
        targets = []
        @classmethod
        async def create(cls, *_args, **_kwargs):
            target = FakeTarget(); cls.targets.append(target); return target
    class FakeEngine:
        transport_dispatcher = None
    class FakeUsm:
        calls = []
        def __init__(self, *args, **kwargs): self.__class__.calls.append((args, kwargs))
    fake_calls = {"count": 0}
    async def fake_get_cmd(*_args, **_kwargs):
        fake_calls["count"] += 1
        return (None, None, 0, [(FakeValue("1.3.6.1.2.1.1.1.0"), FakeValue("ALE OS6560"))])
    original_imports = snmp_monitor._pysnmp_imports
    original_route = snmp_monitor._route_source_ip
    try:
        snmp_monitor._route_source_ip = lambda *_args: "192.0.2.55"
        snmp_monitor._pysnmp_imports = lambda: {
            "ContextData": lambda: object(), "ObjectIdentity": lambda value: value, "ObjectType": lambda value: value,
            "SnmpEngine": FakeEngine, "UdpTransportTarget": FakeUdpTarget, "UsmUserData": FakeUsm,
            "bulk_walk_cmd": None, "get_cmd": fake_get_cmd,
            "USM_AUTH_HMAC96_SHA": "sha", "USM_AUTH_HMAC192_SHA256": "sha256", "USM_PRIV_CFB128_AES": "aes", "USM_PRIV_CBC56_DES": "des",
        }
        value = asyncio.run(snmp_monitor._get_sysdescr_async("192.0.2.10", {
            "username":"snmpuserv3", "snmp_port":161, "snmp_auth_protocol":"SHA256",
            "snmp_auth_password":"authpass1", "snmp_priv_protocol":"AES", "snmp_priv_password":"privpass1",
        }))
        if value != "ALE OS6560" or not FakeUdpTarget.targets or FakeUdpTarget.targets[0].bound:
            return fail("SNMPv3 verification did not use OS-managed source addressing first")
        if not FakeUsm.calls or "authKeyType" in FakeUsm.calls[0][1] or "privKeyType" in FakeUsm.calls[0][1]:
            return fail("SNMPv3 USM verification should use PySNMP passphrase defaults")
        des_auth = snmp_monitor._auth_data(snmp_monitor._pysnmp_imports(), {
            "username":"snmpuserv3", "snmp_auth_protocol":"SHA", "snmp_auth_password":"authpass1",
            "snmp_priv_protocol":"DES", "snmp_priv_password":"privpass1",
        })
        if not FakeUsm.calls or FakeUsm.calls[-1][1].get("privProtocol") != "des":
            return fail("SNMPv3 DES privacy did not map to PySNMP CBC56-DES")
    finally:
        snmp_monitor._pysnmp_imports = original_imports
        snmp_monitor._route_source_ip = original_route

    init_db()
    with db() as conn:
        device_cols = {row["name"] for row in conn.execute("PRAGMA table_info(devices)").fetchall()}
        required = {
            "stack_monitor_method", "stack_monitor_profile_id", "stack_baseline_member_ids_json",
            "stack_baseline_members_json", "stack_baseline_candidate_json", "stack_baseline_stable_checks",
            "stack_baseline_learned_at", "stack_last_status", "stack_last_error",
        }
        if not required.issubset(device_cols):
            return fail(f"missing stack device columns: {sorted(required-device_cols)}")
        profile_cols = {row["name"] for row in conn.execute("PRAGMA table_info(monitoring_credential_profiles)").fetchall()}
        if not {"method", "ssh_password_enc", "snmp_auth_password_enc", "snmp_priv_password_enc"}.issubset(profile_cols):
            return fail("monitoring credential profile schema is incomplete")
        now = "2026-08-14T08:00:00+00:00"
        cursor = conn.execute(
            """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at,last_status,stack_monitor_enabled,stack_monitor_method)
            VALUES('Stack-Test','192.0.2.10',22,'Lab','Core','OS6560-P48X4','8.10','AOS8',1,'','','',?,?, 'online',1,'ssh')""",
            (now, now),
        )
        device_id = int(cursor.lastrowid)

    healthy4 = {"count": 4, "member_ids": ["1","2","3","4"], "members": [{"id":str(i)} for i in range(1,5)], "ok": True}
    for step in range(1, 4):
        _record_result(device_dict(device_id), healthy4, checked_at=f"2026-08-14T08:00:0{step}+00:00")
        row = device_dict(device_id)
        if step < 3 and row["stack_last_status"] != "learning":
            return fail(f"baseline should still be learning after check {step}")
    row = device_dict(device_id)
    if row["stack_last_status"] != "healthy" or row["stack_expected_members"] != 4:
        return fail("automatic baseline was not learned after three stable checks")

    degraded = {"count": 3, "member_ids": ["1","2","4"], "members": [{"id":"1"},{"id":"2"},{"id":"4"}], "ok": True}
    _record_result(device_dict(device_id), degraded, checked_at="2026-08-14T08:00:04+00:00")
    if device_dict(device_id)["stack_last_status"] == "degraded":
        return fail("stack degraded after only one changed-membership check")
    _record_result(device_dict(device_id), degraded, checked_at="2026-08-14T08:00:05+00:00")
    if device_dict(device_id)["stack_last_status"] != "degraded":
        return fail("stack did not confirm degraded after two checks")
    _record_result(device_dict(device_id), healthy4, checked_at="2026-08-14T08:00:06+00:00")
    if device_dict(device_id)["stack_last_status"] != "degraded":
        return fail("stack recovery was accepted after one healthy check")
    _record_result(device_dict(device_id), healthy4, checked_at="2026-08-14T08:00:07+00:00")
    if device_dict(device_id)["stack_last_status"] != "healthy":
        return fail("stack did not recover after two healthy checks")

    with db() as conn:
        cursor = conn.execute(
            """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at,last_status,stack_monitor_enabled,stack_monitor_method)
            VALUES('Stack-Two','192.0.2.11',22,'Lab','Core','OS6560-P48X4','8.10','AOS8',1,'','','',?,?, 'online',1,'ssh')""",
            (now, now),
        )
        two_id = int(cursor.lastrowid)
    healthy2 = {"count": 2, "member_ids": ["1","2"], "members": [{"id":"1","status":"Running"},{"id":"2","status":"Running"}], "ok": True}
    for step in range(1, 4):
        _record_result(device_dict(two_id), healthy2, checked_at=f"2026-08-14T08:10:0{step}+00:00")
    if device_dict(two_id)["stack_last_status"] != "healthy":
        return fail("2-member stack baseline was not learned")
    _record_result(device_dict(two_id), not_joined, checked_at="2026-08-14T08:10:04+00:00")
    if device_dict(two_id)["stack_last_status"] == "degraded":
        return fail("2-member stack degraded after only one Not-Joined check")
    _record_result(device_dict(two_id), not_joined, checked_at="2026-08-14T08:10:05+00:00")
    if device_dict(two_id)["stack_last_status"] != "degraded":
        return fail("2-member stack did not degrade after confirmed Not-Joined member")
    if int(device_dict(two_id)["stack_current_members"] or 0) != 1:
        return fail("2-member degraded stack did not retain the single running member count")

    # Integration regression: the incident and webhook payload must identify
    # the exact configured chassis that became Not-Joined and preserve its
    # last-known healthy role/MAC from the learned baseline.
    with db() as conn:
        conn.execute("UPDATE notification_policy SET enabled=1 WHERE id=1")
        conn.execute(
            """INSERT INTO notification_destinations(
                name,provider,enabled,webhook_url_enc,scope_mode,sites_json,groups_json,
                notify_offline,notify_recovery,notify_reminder,notify_stack_degraded,notify_stack_recovery,
                created_at,updated_at,updated_by
            ) VALUES('Stack Test','generic',1,'validation-secret','all','[]','[]',0,0,0,1,1,?,?, 'validator')""",
            (now, now),
        )
        cursor = conn.execute(
            """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at,last_status,stack_monitor_enabled,stack_monitor_method)
            VALUES('Stack-Incident','192.0.2.12',22,'Lab','Core','OS6560-P48X4','8.10','AOS8',1,'','','',?,?, 'online',1,'ssh')""",
            (now, now),
        )
        incident_device_id = int(cursor.lastrowid)
    healthy2_evidence = {
        "count": 2, "member_ids": ["1", "2"], "ok": True,
        "members": [
            {"id":"1","config_id":"1","role":"Master","status":"Running","mac":"02:10:00:00:00:11"},
            {"id":"2","config_id":"2","role":"Slave","status":"Running","mac":"02:10:00:00:00:12"},
        ],
    }
    for step in range(1, 4):
        _record_result(device_dict(incident_device_id), healthy2_evidence, checked_at=f"2026-08-14T08:20:0{step}+00:00")
    _record_result(device_dict(incident_device_id), not_joined, checked_at="2026-08-14T08:20:04+00:00")
    _record_result(device_dict(incident_device_id), not_joined, checked_at="2026-08-14T08:20:05+00:00")
    with db() as conn:
        incident = conn.execute(
            "SELECT * FROM notification_incidents WHERE device_id=? AND incident_type='stack_degraded' ORDER BY id DESC LIMIT 1",
            (incident_device_id,),
        ).fetchone()
        if not incident or incident["status"] != "open":
            return fail("confirmed Not-Joined member did not open a stack incident")
        details = json.loads(str(incident["details_json"] or "{}"))
        if details.get("missing_member_ids") != ["2"]:
            return fail(f"stack incident did not identify missing chassis 2: {details}")
        missing = (details.get("missing_members") or [{}])[0]
        if str(missing.get("state") or "").lower() != "not-joined":
            return fail(f"stack incident did not preserve Not-Joined state: {details}")
        if missing.get("last_known_role") != "Slave" or missing.get("last_known_mac") != "02:10:00:00:00:12":
            return fail(f"stack incident did not enrich chassis identity from baseline: {details}")
        degraded_outbox = conn.execute(
            "SELECT * FROM notification_outbox WHERE incident_id=? AND event_type='stack_degraded' ORDER BY id DESC LIMIT 1",
            (incident["id"],),
        ).fetchone()
        if not degraded_outbox:
            return fail("stack degraded incident did not enqueue a webhook payload")
        degraded_payload = json.loads(str(degraded_outbox["payload_json"] or "{}"))
        if "Missing chassis: 2" not in str(degraded_payload.get("summary") or ""):
            return fail(f"stack degraded webhook summary omitted chassis identity: {degraded_payload}")
        conn.execute(
            "UPDATE notification_outbox SET status='delivered', delivered_at=? WHERE id=?",
            ("2026-08-14T08:20:06+00:00", degraded_outbox["id"]),
        )
    _record_result(device_dict(incident_device_id), healthy2_evidence, checked_at="2026-08-14T08:20:07+00:00")
    _record_result(device_dict(incident_device_id), healthy2_evidence, checked_at="2026-08-14T08:20:08+00:00")
    with db() as conn:
        closed = conn.execute("SELECT * FROM notification_incidents WHERE device_id=? AND incident_type='stack_degraded' ORDER BY id DESC LIMIT 1", (incident_device_id,)).fetchone()
        closed_details = json.loads(str(closed["details_json"] or "{}")) if closed else {}
        if not closed or closed["status"] != "closed" or closed_details.get("recovered_member_ids") != ["2"]:
            return fail(f"stack recovery did not preserve affected chassis identity: {closed_details}")
        recovery_outbox = conn.execute(
            "SELECT * FROM notification_outbox WHERE incident_id=? AND event_type='stack_recovered' ORDER BY id DESC LIMIT 1",
            (closed["id"],),
        ).fetchone()
        if not recovery_outbox:
            return fail("stack recovery did not enqueue a recovery webhook")
        recovery_payload = json.loads(str(recovery_outbox["payload_json"] or "{}"))
        if "Chassis 2 rejoined" not in str(recovery_payload.get("summary") or ""):
            return fail(f"stack recovery webhook omitted recovered chassis identity: {recovery_payload}")

    print("AOS8 show virtual-chassis topology parser: PASS")
    print("AOS8 Unassigned/Not-Joined member handling: PASS")
    print("SNMPv3 ENTITY-MIB chassis parser: PASS")
    print("SNMPv3 OS-managed source and USM passphrase compatibility: PASS")
    print("Monitoring credential database schema: PASS")
    print("Automatic three-pass baseline learning: PASS")
    print("Two-pass degradation/recovery confirmation: PASS")
    print("Stack incident chassis identity and webhook evidence: PASS")
    print("STACK MONITORING VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
