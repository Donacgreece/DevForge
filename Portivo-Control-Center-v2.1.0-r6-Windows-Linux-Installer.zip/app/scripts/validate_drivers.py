# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.device_identity import parse_show_system
from app.profiles import load_profiles, render_command
from app.vendor_drivers import netmiko_device_type, registered_driver_metadata, registry


def main() -> None:
    profiles = load_profiles()
    metadata = registered_driver_metadata(profiles)
    assert set(registry.profiles()) == {"AOS6", "AOS8"}, registry.profiles()
    assert {item["profile"] for item in metadata} == {"AOS6", "AOS8"}
    assert all(item["vendor"] == "Alcatel-Lucent Enterprise" for item in metadata)
    assert all(item["netmiko_device_type"] == "alcatel_aos" for item in metadata)
    assert all(item["capabilities"] for item in metadata)

    aos8 = """Name: ACCESS-01\nDescription: Alcatel-Lucent Enterprise OmniSwitch OS6860E, 8.10.107.R03\n"""
    aos6 = """Name: LEGACY-01\nDescription: OmniSwitch 6450, 6.7.2.122.R01\n"""
    identity8 = parse_show_system(aos8)
    identity6 = parse_show_system(aos6)
    assert identity8.model == "OS6860E" and identity8.detected_profile == "AOS8", identity8
    assert identity6.model == "OS6450" and identity6.detected_profile == "AOS6", identity6
    assert identity8.driver_key == "ale-aos8"
    assert identity6.driver_key == "ale-aos6"

    assert netmiko_device_type("AOS8") == "alcatel_aos"
    assert netmiko_device_type("AOS6") == "alcatel_aos"
    command, _ = render_command("AOS8", "interface_status", port="1 / 1 / 2")
    assert "1/1/2" in command, command
    try:
        render_command("AOS8", "interface_status", port="1/1/2; show system")
    except Exception:
        pass
    else:
        raise AssertionError("Driver-specific port validation accepted command injection text")

    print(json.dumps({"drivers": metadata, "identity_tests": "pass"}, indent=2))
    print("VENDOR DRIVERS: PASS")


if __name__ == "__main__":
    main()
