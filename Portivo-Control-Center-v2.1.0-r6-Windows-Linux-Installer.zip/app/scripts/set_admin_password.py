# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.auth import hash_password
from app.password_policy import validate_password
from app.db import db, init_db, utc_now


def _password_from_environment_or_prompt() -> str:
    supplied = os.getenv("OSC_ADMIN_PASSWORD", "")
    if supplied:
        return supplied
    first = getpass.getpass("New bootstrap administrator password: ")
    second = getpass.getpass("Confirm password: ")
    if first != second:
        raise ValueError("The passwords do not match")
    return first


def main() -> int:
    parser = argparse.ArgumentParser(description="Create or reset the local bootstrap administrator.")
    parser.add_argument("--username", default=os.getenv("APP_ADMIN_USERNAME", "admin"))
    parser.add_argument("--display-name", default="Administrator")
    args = parser.parse_args()

    username = args.username.strip()
    if not username:
        raise ValueError("Administrator username cannot be empty")
    password = _password_from_environment_or_prompt()
    validate_password(password)

    init_db()
    now = utc_now()
    with db() as conn:
        row = conn.execute("SELECT id FROM app_users WHERE username = ?", (username,)).fetchone()
        if row:
            conn.execute(
                """
                UPDATE app_users
                SET display_name = ?, password_hash = ?, role = 'admin', enabled = 1,
                    must_change_password = 0, updated_at = ?
                WHERE id = ?
                """,
                (args.display_name, hash_password(password), now, row["id"]),
            )
        else:
            conn.execute(
                """
                INSERT INTO app_users(
                    username, display_name, password_hash, role, enabled,
                    must_change_password, created_at, updated_at
                ) VALUES(?, ?, ?, 'admin', 1, 0, ?, ?)
                """,
                (username, args.display_name, hash_password(password), now, now),
            )
    print(f"Bootstrap administrator '{username}' is ready.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(2)
