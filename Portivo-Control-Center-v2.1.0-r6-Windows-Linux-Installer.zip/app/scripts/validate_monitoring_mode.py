# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-monitoring-mode-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "monitoring-mode.db")
os.environ["APP_SECRET_KEY"] = "monitoring-mode-validation-secret-key-0000000000"
os.environ["APP_ADMIN_PASSWORD"] = "Portivo-Monitoring-Validation-Admin-2026!"
os.environ["LOGIN_RATE_LIMIT_ENABLED"] = "false"

from fastapi.testclient import TestClient  # noqa: E402
from app.db import init_db, update_app_settings  # noqa: E402
from app.monitoring_policy import monitoring_policy  # noqa: E402
from app import main as main_module  # noqa: E402
from app.health_monitor import health_monitor_status  # noqa: E402
from app.stack_monitor import stack_monitor_status  # noqa: E402
from app.power_monitor import power_monitor_status  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    init_db()
    defaults = monitoring_policy()
    require(defaults["mode"] == "full", "Default monitoring mode must be Full monitoring")
    require(all(defaults["services"].values()), "All monitoring services must default to enabled")

    # Start the application in Management only to validate the real startup path.
    update_app_settings({"monitoring_mode": "management_only"}, "validator")
    with TestClient(main_module.app) as client:
        login = client.post(
            "/api/auth/login",
            json={"username": "admin", "password": os.environ["APP_ADMIN_PASSWORD"], "mode": "admin"},
        )
        require(login.status_code == 200, f"Admin login failed: {login.text}")

        settings = client.get("/api/admin/settings")
        require(settings.status_code == 200, settings.text)
        payload = settings.json()
        require(payload.get("monitoring_mode") == "management_only", "Management-only mode was not persisted")
        require(payload.get("monitoring_switch_availability") is True, "Service choices must remain stored while paused")
        require(not health_monitor_status().get("running"), "Switch health worker must not run in Management only")
        require(not stack_monitor_status().get("running"), "Stack worker must not run in Management only")
        require(not power_monitor_status().get("running"), "Power worker must not run in Management only")

        dashboard = client.get("/api/dashboard")
        require(dashboard.status_code == 200, dashboard.text)
        require(dashboard.json().get("monitoring_policy", {}).get("mode") == "management_only", "Dashboard must expose the active monitoring mode")

        # Full monitoring may retain granular services as disabled. This validates
        # that the mode switch does not destroy the saved service selection.
        saved = client.put("/api/admin/settings", json={
            "default_language": "en",
            "ssh_users_manage_inventory": True,
            "health_poll_interval_seconds": 30,
            "platform_timezone": "UTC",
            "monitoring_mode": "full",
            "monitoring_switch_availability": False,
            "monitoring_stack_health": False,
            "monitoring_power_ups": False,
            "monitoring_incident_detection": False,
            "authentication_source_device_ids": [],
        })
        require(saved.status_code == 200, saved.text)
        policy = saved.json().get("monitoring_policy", {})
        require(policy.get("mode") == "full", "Full monitoring mode was not applied")
        require(not any(policy.get("effective", {}).values()), "Disabled granular services must stay disabled")
        require(not health_monitor_status().get("running"), "Disabled switch monitoring must not have a running worker")
        require(not stack_monitor_status().get("running"), "Disabled stack monitoring must not have a running worker")
        require(not power_monitor_status().get("running"), "Disabled power monitoring must not have a running worker")

        # Old/partial clients that omit the new fields must not silently reset them.
        legacy_save = client.put("/api/admin/settings", json={
            "default_language": "en",
            "ssh_users_manage_inventory": True,
            "health_poll_interval_seconds": 45,
            "platform_timezone": "UTC",
            "authentication_source_device_ids": [],
        })
        require(legacy_save.status_code == 200, legacy_save.text)
        after_legacy = client.get("/api/admin/settings").json()
        require(after_legacy.get("monitoring_mode") == "full", "Legacy settings save unexpectedly changed monitoring mode")
        require(after_legacy.get("monitoring_power_ups") is False, "Legacy settings save unexpectedly reset granular monitoring choices")

    html = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
    for marker in ["adminMonitoringSettings", "adminMonitorSwitchAvailability", "adminMonitorPowerUps", "dashboardMonitoringModeBanner"]:
        require(marker in html, f"Monitoring mode UI marker is missing: {marker}")
    require("syncAdminMonitoringModeUi" in js, "Monitoring mode UI synchronization is missing")

    print("PORTIVO MONITORING MODE VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
