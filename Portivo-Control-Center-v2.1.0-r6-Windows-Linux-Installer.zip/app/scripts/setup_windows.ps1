﻿# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

function Convert-SecureToPlain([Security.SecureString]$SecureValue) {
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

$hasPyLauncher = [bool](Get-Command py -ErrorAction SilentlyContinue)
$hasPython = [bool](Get-Command python -ErrorAction SilentlyContinue)
if (-not $hasPyLauncher -and -not $hasPython) {
    throw "Python 3.11 or newer was not found. Install 64-bit Python and enable Add Python to PATH."
}

Write-Host "Portivo Control Center v2.1.0 setup" -ForegroundColor Cyan
Write-Host "Creating the Python virtual environment..."
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    if ($hasPyLauncher) { & py -3 -m venv .venv }
    else { & python -m venv .venv }
    if ($LASTEXITCODE -ne 0) { throw "Virtual environment creation failed." }
} else {
    Write-Host "Existing .venv detected. It will be reused."
}

$venvPython = Join-Path $PWD ".venv\Scripts\python.exe"
& $venvPython -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)"
if ($LASTEXITCODE -ne 0) { throw "Python 3.11 or newer is required." }
Write-Host "Installing required Python packages..."
& $venvPython -m pip install --disable-pip-version-check --only-binary=:all: --no-deps -r requirements.lock
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
& $venvPython -m pip check
if ($LASTEXITCODE -ne 0) { throw "Dependency consistency check failed." }

if (-not (Test-Path ".env")) {
    $secret = & $venvPython scripts\generate_secret.py
    @"
APP_NAME=Portivo Control Center
APP_VERSION=2.1.0
APP_HOST=0.0.0.0
APP_PORT=8766
APP_SECRET_KEY=$secret
APP_ADMIN_USERNAME=admin
PUBLIC_URL_SCHEME=http
TRUST_PROXY_HEADERS=false
TRUSTED_PROXY_IPS=127.0.0.1,::1
LOGIN_RATE_LIMIT_ENABLED=true
LOGIN_RATE_LIMIT_WINDOW_SECONDS=300
LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS=30
SSH_CONNECT_TIMEOUT=12
AUTH_CONNECT_TIMEOUT=2.5
AUTH_GLOBAL_TIMEOUT_SECONDS=5
AUTH_MAX_SOURCES=5
SSH_COMMAND_TIMEOUT=30
SSH_CONNECT_RETRIES=3
SSH_RETRY_BACKOFF_SECONDS=0.75
SSH_OPERATION_LOCK_TIMEOUT=180
SSH_POST_SAVE_PROMPT_TIMEOUT=20
SSH_POST_SAVE_COOLDOWN_SECONDS=2
SSH_POST_SAVE_FALLBACK_COOLDOWN_SECONDS=5
SSH_RECENT_AUTH_SUCCESS_WINDOW_SECONDS=60
SSH_RECENT_AUTH_RETRY_DELAY_SECONDS=2
SSH_TERMINAL_IDLE_MINUTES=15
MAX_PARALLEL_SWITCHES=6
FINDER_MAX_PARALLEL_SWITCHES=12
HEALTH_MONITOR_ENABLED=true
HEALTH_PING_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_POLL_INTERVAL_SECONDS=120
HEALTH_POLL_INTERVAL_SECONDS=30
HEALTH_MAX_PARALLEL_SWITCHES=32
HEALTH_PING_ATTEMPTS=3
HEALTH_PING_RETRY_DELAY_SECONDS=5
HEALTH_POLL_JITTER_SECONDS=10
HEALTH_OFFLINE_POLL_INTERVAL_SECONDS=60
HEALTH_LONG_OFFLINE_AFTER_SECONDS=900
HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS=120
DATABASE_PATH=./data/portivo.db
COMMAND_PROFILES_PATH=./data/command_profiles.json
ACTION_CATALOG_PATH=./data/action_catalog.json
"@ | Set-Content -Path ".env" -Encoding UTF8
    Write-Host ".env created."
} else {
    Write-Host "Existing .env detected. It will not be overwritten."
}

Write-Host "`nChoose the local bootstrap administrator password." -ForegroundColor Yellow
Write-Host "It is used only for initial inventory setup and the Admin Panel. Minimum length: 12 characters."
$password1 = Convert-SecureToPlain (Read-Host "Administrator password" -AsSecureString)
$password2 = Convert-SecureToPlain (Read-Host "Confirm administrator password" -AsSecureString)
if ($password1 -ne $password2) { throw "The administrator passwords do not match." }
if ($password1.Length -lt 12) { throw "The administrator password must contain at least 12 characters." }

try {
    $env:OSC_ADMIN_PASSWORD = $password1
    & $venvPython scripts\set_admin_password.py --username admin
    if ($LASTEXITCODE -ne 0) { throw "Administrator initialization failed." }
} finally {
    Remove-Item Env:OSC_ADMIN_PASSWORD -ErrorAction SilentlyContinue
    $password1 = $null
    $password2 = $null
}

Write-Host "Validating the AOS command catalog..."
& $venvPython scripts\validate_installation.py
if ($LASTEXITCODE -ne 0) { throw "Command profile validation failed." }

Write-Host "`nInstallation complete." -ForegroundColor Green
Write-Host "Start the application with: .\start_windows.bat"
Write-Host "Local URL: http://127.0.0.1:8766"
Write-Host "For LAN access, allow TCP 8766 in Windows Firewall or run scripts\enable_lan_access.ps1 as Administrator."
