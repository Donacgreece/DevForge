# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    app_js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
    monitor = (ROOT / "app/power_monitor.py").read_text(encoding="utf-8")
    checks = {
        "bounded API timeout helper": "async function apiWithTimeout" in app_js and "UPS telemetry request timed out" in app_js,
        "details refresh uses timeout": "apiWithTimeout(`/api/power/ups/${upsId}/details/refresh`" in app_js,
        "loading cleanup finally": "button.classList.remove(\"is-loading\")" in app_js and "finally" in app_js,
        "fast SNMP reachability gate": "values = snmpv3_get_many(host, profile, [SYS_DESCR])" in monitor,
        "incidents shortcut button": 'id="powerIncidentsJump"' in index,
        "incidents scroll target": 'id="powerIncidentsPanel"' in index,
        "incidents shortcut handler": 'powerIncidentsPanel")?.scrollIntoView' in app_js,
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        print("POWER DETAILS LOADING VALIDATION: FAIL")
        for name in failed:
            print(f"  FAIL: {name}")
        return 1
    print("POWER DETAILS LOADING VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
