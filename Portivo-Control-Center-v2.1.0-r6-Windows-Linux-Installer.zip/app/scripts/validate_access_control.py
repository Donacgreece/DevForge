# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-access-validation-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "access.db")
os.environ.setdefault("APP_SECRET_KEY", "access-validation-only-secret-key-000000000000")

from app.access_control import (  # noqa: E402
    access_context_for_profile,
    device_in_scope,
    list_roles,
    save_custom_role,
)
from app.db import db, init_db, utc_now, _migrate_ssh_user_access  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    init_db()
    roles = {item["key"]: item for item in list_roles()}
    expected = {"admin", "power_user", "site_admin", "operator", "helpdesk", "read_only"}
    require(expected.issubset(roles), "Missing one or more built-in access roles")
    require(roles["admin"]["global_role"] and roles["power_user"]["global_role"], "Admin and Power User must be global")
    for key in {"site_admin", "operator", "helpdesk", "read_only"}:
        require(roles[key]["scope_required"] and not roles[key]["global_role"], f"{key} must require scope")

    now = utc_now()
    with db() as conn:
        for name, host, site, group in [
            ("A-Access", "192.0.2.10", "Site A", "Access Layer"),
            ("A-Core", "192.0.2.11", "Site A", "Core"),
            ("B-Core", "192.0.2.12", "Site B", "Core"),
        ]:
            conn.execute(
                """INSERT INTO devices(name,host,ssh_port,site,group_name,model,aos_version,profile,enabled,notes,username,password_enc,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (name, host, 22, site, group, "", "", "AOS8", 1, "", "", "", now, now),
            )
        device_rows = conn.execute("SELECT id,site,group_name FROM devices ORDER BY id").fetchall()

    helpdesk = access_context_for_profile({
        "role": "user", "access_role_id": roles["helpdesk"]["id"],
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site A"], "groups": [{"site": "Site A", "group": "Access Layer"}]}),
    })
    require(helpdesk.can_action("interface_alias"), "Helpdesk must allow alias changes")
    require(helpdesk.can_action("interface_cycle"), "Helpdesk must allow interface restart")
    require(helpdesk.can_action("poe_cycle"), "Helpdesk must allow PoE restart")
    require(not helpdesk.can_action("save_config"), "Helpdesk must not receive broader change access")
    require(not helpdesk.has("terminal.use") and not helpdesk.has("custom_cli.use"), "Helpdesk must not receive raw CLI access")
    require(helpdesk.has("power.view") and helpdesk.has("drivers.view"), "Helpdesk must retain power visibility and driver reference access")
    require(not any(helpdesk.has(cap) for cap in {"power.create", "power.edit", "power.delete", "power.verify", "power.assign"}), "Helpdesk received UPS administration rights")
    require([device_in_scope(helpdesk, row) for row in device_rows] == [True, False, False], "Helpdesk Site/Group scope failed")

    mixed_scope = access_context_for_profile({
        "role": "user", "access_role_id": roles["helpdesk"]["id"],
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site A", "Site B"], "groups": [{"site": "Site A", "group": "Access Layer"}]}),
    })
    require([device_in_scope(mixed_scope, row) for row in device_rows] == [True, False, True], "Per-Site group restriction semantics failed")

    readonly = access_context_for_profile({
        "role": "user", "access_role_id": roles["read_only"]["id"],
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site A"], "groups": []}),
    })
    require(not readonly.has("operations.view"), "Read Only must not see Operations")
    require(not readonly.has("devices.live_ports"), "Read Only must not execute live port queries")
    require(not readonly.has("terminal.use") and not readonly.has("custom_cli.use"), "Read Only must not receive a console")
    require(not readonly.can_action("interface_status_all"), "Read Only must not execute read CLI commands")

    operator = access_context_for_profile({
        "role": "user", "access_role_id": roles["operator"]["id"],
        "scope_json": json.dumps({"mode": "all", "sites": [], "groups": []}),
    })
    require(operator.has("operations.runbook"), "Operator must support approved Runbooks")
    require(operator.can_action("vlan_port_maintenance"), "Operator must allow governed operational maintenance")
    require(not operator.has("terminal.use") and not operator.has("custom_cli.use"), "Operator must not receive unrestricted CLI")

    site_admin = access_context_for_profile({
        "role": "user", "access_role_id": roles["site_admin"]["id"],
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site A"], "groups": []}),
    })
    require(site_admin.has("inventory.manage") and site_admin.has("terminal.use") and site_admin.has("custom_cli.use"), "Site Administrator must have full scoped operational access")
    require(all(site_admin.has(cap) for cap in {"power.create", "power.edit", "power.delete", "power.verify", "power.assign", "drivers.view"}), "Site Administrator power/driver capabilities are incomplete")
    require(site_admin.can_action("save_config") and site_admin.can_action("custom_command"), "Site Administrator action policy is incomplete")

    custom = save_custom_role(
        role_id=None, name="Validation Custom", description="Scoped validation role",
        capabilities=["dashboard.view", "devices.view"],
        allowed_actions=["interface_cycle"], actor="validator",
    )
    require("operations.view" in custom["capabilities"], "Custom Role action grants must pull in the Operations workspace dependency")
    custom_ctx = access_context_for_profile({
        "role": "user", "access_role_id": custom["id"],
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site B"], "groups": []}),
    })
    require(custom_ctx.can_action("interface_cycle"), "Custom Role action grant failed")
    require(not custom_ctx.can_action("poe_cycle"), "Custom Role leaked an unassigned action")
    require([device_in_scope(custom_ctx, row) for row in device_rows] == [False, False, True], "Custom Role scope failed")

    power_custom = save_custom_role(
        role_id=None, name="UPS Verifier", description="Granular power validation",
        capabilities=["power.verify", "drivers.view"], allowed_actions=[], actor="validator",
    )
    require("power.view" in power_custom["capabilities"], "Granular UPS administration must pull in Power visibility")
    require("power.verify" in power_custom["capabilities"] and "power.edit" not in power_custom["capabilities"], "Granular UPS permissions leaked edit rights")

    # v1.9.0-r7 legacy compatibility: an early Custom Role saved with the old
    # coarse power.manage right must expand without losing access after update.
    with db() as conn:
        legacy_cursor = conn.execute(
            "INSERT INTO access_roles(role_key,name,description,built_in,capabilities_json,allowed_actions_json,created_at,updated_at,updated_by) VALUES(?,?,?,?,?,?,?,?,?)",
            ("custom-legacy-power", "Legacy Power", "", 0, '["power.manage"]', '[]', now, now, "validator"),
        )
        legacy_role_id = int(legacy_cursor.lastrowid)
    legacy_power_ctx = access_context_for_profile({
        "role": "user", "access_role_id": legacy_role_id,
        "scope_json": json.dumps({"mode": "selected", "sites": ["Site A"], "groups": []}),
    })
    require(all(legacy_power_ctx.has(cap) for cap in {"power.create", "power.edit", "power.delete", "power.verify", "power.assign"}), "Legacy power.manage Custom Role did not expand safely")

    # Upgrade migration is intentionally fail-closed for legacy standard users.
    with db() as conn:
        conn.execute(
            "INSERT INTO ssh_user_profiles(username,display_name,role,access_role_id,scope_json,enabled,first_seen,last_login,login_count,updated_at,updated_by) VALUES(?,?,?,?,?,1,?,?,0,?,?)",
            ("legacy-viewer", "Legacy Viewer", "user", None, '{"mode":"none","sites":[],"groups":[]}', now, now, now, "validator"),
        )
        conn.execute(
            "INSERT INTO ssh_user_profiles(username,display_name,role,access_role_id,scope_json,enabled,first_seen,last_login,login_count,updated_at,updated_by) VALUES(?,?,?,?,?,1,?,?,0,?,?)",
            ("legacy-power", "Legacy Power", "power_user", None, '{"mode":"none","sites":[],"groups":[]}', now, now, now, "validator"),
        )
        _migrate_ssh_user_access(conn)
        viewer = conn.execute("SELECT access_role_id,scope_json FROM ssh_user_profiles WHERE username='legacy-viewer'").fetchone()
        power = conn.execute("SELECT access_role_id,scope_json FROM ssh_user_profiles WHERE username='legacy-power'").fetchone()
    require(json.loads(viewer["scope_json"])["mode"] == "none", "Legacy standard users must migrate with no scope")
    require(json.loads(power["scope_json"])["mode"] == "all", "Legacy Power Users must remain global")

    index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    require('id="userAccessDialog"' in index and 'id="accessRoleDialog"' in index, "Access Control UI dialogs are missing")
    require('data-requires-terminal id="workspaceTerminalCard"' in index, "Terminal visibility guard is missing")
    require('allowedActionIds()' in js and 'VIEW_CAPABILITIES' in js, "Frontend capability/action enforcement is missing")
    require('driversView: "drivers.view"' in js and 'power.assign' in js and 'power.verify' in js, "Frontend v1.9 capability gates are incomplete")
    require('actionAllowedForCurrentUser("interface_alias")' in js, "Helpdesk-safe alias UI gate is missing")

    print("PORTIVO ACCESS CONTROL VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
