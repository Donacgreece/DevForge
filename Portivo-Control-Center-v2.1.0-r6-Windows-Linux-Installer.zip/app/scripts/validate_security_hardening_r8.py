# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
main = (ROOT / "app/main.py").read_text(encoding="utf-8")
notify = (ROOT / "app/notification_engine.py").read_text(encoding="utf-8")
index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
appjs = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
schemas = (ROOT / "app/schemas.py").read_text(encoding="utf-8")

checks = {
    "docs disabled": 'docs_url=None, redoc_url=None, openapi_url=None' in main,
    "public health minimized": 'return {"status": "ok"}' in main and '@app.get("/api/health/build")' in main,
    "loopback build metadata": '_require_loopback(request)' in main and '"revision": PORTIVO_BUILD_REVISION' in main,
    "revision header removed": 'response.headers["X-Portivo-Revision"]' not in main,
    "expanded CSP": all(token in main for token in ["default-src 'self'", "object-src 'none'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'", "connect-src 'self' ws: wss:"]),
    "websocket origin validation": '_websocket_origin_allowed(websocket)' in main and main.index('_websocket_origin_allowed(websocket)') < main.index('await websocket.accept()', main.index('@app.websocket("/ws/devices/{device_id}/terminal")')),
    "terminal errors sanitized": 'Terminal output was interrupted unexpectedly.' in main and 'The terminal session failed unexpectedly.' in main,
    "inventory byte cap": 'INVENTORY_IMPORT_MAX_BYTES = 20 * 1024 * 1024' in main and 'Inventory upload exceeds the 20 MiB limit' in main,
    "inventory shape caps": all(token in main for token in ['INVENTORY_IMPORT_MAX_ROWS = 25_000', 'INVENTORY_IMPORT_MAX_COLUMNS = 64', 'INVENTORY_IMPORT_MAX_CELL_CHARS = 32_768']),
    "xlsx bomb safeguards": all(token in main for token in ['INVENTORY_XLSX_MAX_UNCOMPRESSED_BYTES', 'INVENTORY_XLSX_MAX_COMPRESSION_RATIO', '_validate_xlsx_archive(content)']),
    "webhook redirects disabled": '_NoWebhookRedirects' in notify and '_WEBHOOK_OPENER.open' in notify and 'Webhook redirects are not allowed' in notify,
    "webhook destination revalidated": 'webhook_url = validate_webhook_url(webhook_url, provider)' in notify,
    "SHA256 default": 'snmp_auth_protocol: Literal["SHA", "SHA256"] = "SHA256"' in schemas and 'profile?.snmp_auth_protocol || "SHA256"' in appjs,
    "legacy labels": 'SHA (Legacy)' in index and 'DES (Legacy)' in index,
    "r8 UI handshake": 'window.PORTIVO_UI_REVISION="2.1.0-r6"' in index,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("PORTIVO SAFE SECURITY HARDENING VALIDATION: FAIL")
    for name in failed:
        print(f"  FAIL: {name}")
    raise SystemExit(1)
print("PORTIVO SAFE SECURITY HARDENING VALIDATION: PASS")
