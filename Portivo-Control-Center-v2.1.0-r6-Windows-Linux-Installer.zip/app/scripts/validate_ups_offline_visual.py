#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
css = (ROOT / "app" / "static" / "styles.css").read_text(encoding="utf-8")
assert 'communicationOffline ? "communication-offline" : escapeHtml(severity)' in js
assert '.power-ups-card.communication-offline::before' in css
assert 'background: var(--muted)' in css
print("UPS OFFLINE VISUAL VALIDATION: PASS")
