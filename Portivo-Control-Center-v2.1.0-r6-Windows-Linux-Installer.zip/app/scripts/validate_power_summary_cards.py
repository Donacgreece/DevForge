# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
app = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
styles = (ROOT / "app/static/styles.css").read_text(encoding="utf-8")

card_ids = [
    "powerMetricTotalCard", "powerMetricNormalCard", "powerMetricBatteryCard",
    "powerMetricCriticalCard", "powerMetricOfflineCard", "powerMetricProtectedCard",
]
for card_id in card_ids:
    assert f'id="{card_id}"' in index, card_id
    assert f'bindPowerMetricCard("{card_id}"' in app, card_id

assert index.count('class="glass-card power-metric-filter"') >= 2
assert index.count('power-metric-filter') >= 6
assert index.count('role="button" tabindex="0"') >= 6
assert 'value="critical" data-i18n="power.critical"' in index
assert 'health === "on_battery"' in app and '["on_battery", "low_battery", "depleted"]' in app
assert 'health === "critical"' in app and 'severity === "critical"' in app
assert 'metricFilter === "protected"' in app and 'protected_switch_count' in app
assert 'filterPowerUpsByMetric("protected")' in app
assert 'showAllPowerUps()' in app
assert '.power-metric-grid article.power-metric-filter:hover' in styles
assert '.power-metric-grid { display:grid; grid-template-columns:repeat(6,minmax(0,1fr));' in styles
print("POWER SUMMARY CARD ACTIONS VALIDATION: PASS")
