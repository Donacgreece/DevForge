# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# This validator is intended to run from the package root, before app imports.
_tmp = tempfile.TemporaryDirectory(prefix="portivo-monitoring-verify-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "portivo.db")
os.environ.setdefault("APP_SECRET_KEY", "validation-secret-key-0123456789-abcdefghijklmnopqrstuvwxyz")

from app.db import db, init_db  # noqa: E402
from app.schemas import MonitoringCredentialProfileRequest  # noqa: E402
from app import main as main_module  # noqa: E402


def main() -> int:
    init_db()
    admin = {"username": "validator"}

    profile = main_module._save_monitoring_profile_impl(
        None,
        MonitoringCredentialProfileRequest(
            name="UPS validation",
            method="snmpv3",
            username="snmpvalidator",
            snmp_auth_password="authpass1",
            snmp_priv_password="privpass1",
        ),
        admin,
    )
    profile_id = int(profile["id"])

    with db() as conn:
        switch_id = int(conn.execute(
            """INSERT INTO devices(name,host,ssh_port,profile,site,group_name,model,enabled,created_at,updated_at)
               VALUES('SW-VALIDATE','192.0.2.11',22,'AOS8','LAB','','',1,'2026-08-17T00:00:00Z','2026-08-17T00:00:00Z')"""
        ).lastrowid)
        ups_id = int(conn.execute(
            """INSERT INTO ups_devices(name,host,site,group_name,location,monitoring_profile_id,driver_mode,enabled,created_at,updated_at,updated_by)
               VALUES('UPS-VALIDATE','192.0.2.12','LAB','','',?,'generic',1,'2026-08-17T00:00:00Z','2026-08-17T00:00:00Z','validator')""",
            (profile_id,),
        ).lastrowid)

    targets = main_module.monitoring_verification_targets(admin)
    assert any(item["type"] == "switch" and int(item["id"]) == switch_id for item in targets)
    assert any(item["type"] == "ups" and int(item["id"]) == ups_id for item in targets)

    calls: list[tuple[str, str]] = []
    original_verify = main_module.snmpv3_verify
    main_module.snmpv3_verify = lambda host, candidate: calls.append((host, str(candidate["username"]))) or "ok"
    try:
        saved = main_module._save_monitoring_profile_impl(
            profile_id,
            MonitoringCredentialProfileRequest(
                name="UPS validation",
                method="snmpv3",
                username="snmpvalidator",
                verify_target_type="ups",
                verify_target_id=ups_id,
            ),
            admin,
        )
    finally:
        main_module.snmpv3_verify = original_verify

    assert saved["last_status"] == "verified"
    assert saved["verified_target_type"] == "ups"
    assert int(saved["verified_target_id"]) == ups_id
    assert saved["verified_device_id"] is None
    assert saved["verified_device_name"] == "UPS-VALIDATE"
    assert calls == [("192.0.2.12", "snmpvalidator")]

    print("Monitoring credential managed-device verification: PASS")
    _tmp.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
