# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
css = (ROOT / "app/static/styles.css").read_text(encoding="utf-8")

assert 'id="previewPanel"' in html, "Review commands panel missing"
assert 'preview-command-shell' in js, "Structured command shell markup missing"
assert 'preview-device-copy' in js, "Per-device preview identity markup missing"
assert 'preview-command-shell-head' in css, "Command shell visual treatment missing"
assert 'background: var(--surface-raised)' in css, "Preview surface does not use Portivo surface tokens"
assert 'grid-template-columns: minmax(420px,.86fr) minmax(500px,1.14fr)' in css, "Operations column layout changed unexpectedly"
assert 'v1.9.4: Portivo-native Review commands refinement' in css, "v1.9.4 review refinement marker missing"
print("REVIEW COMMANDS UI VALIDATION: PASS")
