# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.ale_cli import ORCHESTRATED_ACTIONS, action_support, poe_status_command, poe_status_commands, slot_from_port
from app.profiles import load_profiles, public_profiles, render_command, supported_actions
from app.device_finder import parse_mac_table
from app.reload_actions import reload_stack_member_command, reload_switch_command, ReloadActionError


def fail(message: str) -> None:
    raise SystemExit(f"CLI RELIABILITY: FAIL: {message}")


def main() -> None:
    profiles = load_profiles()
    public = public_profiles()
    if set(profiles) != {"AOS6", "AOS8"}:
        fail(f"unexpected ALE profiles: {sorted(profiles)}")

    for profile_name, profile in profiles.items():
        commands = profile.get("commands", {})
        orchestrated = set(profile.get("orchestrated_actions", []))
        if orchestrated != set(ORCHESTRATED_ACTIONS):
            fail(f"{profile_name}: orchestrated ALE workflows are not complete")
        for action in ORCHESTRATED_ACTIONS:
            if action in commands:
                fail(f"{profile_name}/{action}: orchestrated action must not contain a raw command")
        for action, command in commands.items():
            normalized = " ".join(str(command).lower().split())
            if normalized == "show lanpower":
                fail(f"{profile_name}/{action}: bare show lanpower is incomplete on supported ALE families")
            if profile_name == "AOS8" and normalized.startswith("show lanpower port "):
                fail(f"{profile_name}/{action}: AOS8 PoE status is slot-qualified, not 'show lanpower port'")
        for action, command in profile.get("verification", {}).items():
            normalized = " ".join(str(command).lower().split())
            if normalized == "show lanpower" or normalized.startswith("show lanpower port "):
                fail(f"{profile_name}/{action}: invalid PoE verification command {command!r}")

    aos6 = profiles["AOS6"]["commands"]
    aos8 = profiles["AOS8"]["commands"]
    if any(action.startswith("unp_") for action in aos6):
        fail("AOS6 profile exposes AOS8 UNP command family")
    if aos6.get("hardware_info") != "show hardware info":
        fail("AOS6 hardware-info syntax regressed")
    if aos6.get("power_supply") != "show power":
        fail("AOS6 power-supply syntax regressed")
    if aos8.get("power_supply") != "show powersupply":
        fail("AOS8 power-supply syntax regressed")

    # OmniSwitch source learning uses the ALE `show mac-learning` family.
    # Do not regress to Cisco-style `show mac-address-table` forms.
    for profile_name, commands in (("AOS6", aos6), ("AOS8", aos8)):
        for action in ("mac_table", "mac_count", "mac_learned"):
            if commands.get(action) != "show mac-learning":
                fail(f"{profile_name}/{action}: ALE MAC-learning syntax regressed")

    sample_mac_learning = """
Legend: Mac Address: * = address not valid,
   Domain    Vlan/SrvcId[:ID]           Mac Address           Type          Operation          Interface
------------+----------------------+-------------------+------------------+-------------+-------------------------
        VLAN                   100   02:00:00:00:00:01            dynamic     bridging                     1/1/1
        VLAN                   200   02:00:00:00:00:02            dynamic     bridging                     1/1/2
        VLAN                   300   02:00:00:00:00:03            dynamic     bridging                    1/1/48
 Total number of Valid MAC addresses above = 3
"""
    parsed_mac_learning = parse_mac_table(sample_mac_learning)
    if [(item.get("vlan"), item.get("port"), item.get("mac")) for item in parsed_mac_learning] != [
        ("100", "1/1/1", "020000000001"),
        ("200", "1/1/2", "020000000002"),
        ("300", "1/1/48", "020000000003"),
    ]:
        fail("ALE show mac-learning parser regression")

    # Rendering tests for family-specific writes. PoE verification is intentionally
    # orchestrated by the runner so it can use the documented slot-scoped variants
    # and never fall back to an invalid raw port/global query.
    command, verify = render_command("AOS8", "poe_enable", port="1/1/2")
    if command != "lanpower port 1/1/2 admin-state enable" or verify:
        fail(f"AOS8 PoE enable plan is wrong: {command!r} / {verify!r}")
    command, verify = render_command("AOS6", "poe_enable", port="1/2")
    if command != "lanpower start 1/2" or verify:
        fail(f"AOS6 PoE enable plan is wrong: {command!r} / {verify!r}")
    command, _ = render_command("AOS8", "interface_enable", port="1/1/2")
    if command != "interfaces 1/1/2 admin-state enable":
        fail("AOS8 interface admin syntax regressed")
    command, _ = render_command("AOS6", "interface_enable", port="1/2")
    if command != "interfaces 1/2 admin up":
        fail("AOS6 interface admin syntax regressed")

    if slot_from_port("AOS8", "1/1/48") != "1/1" or slot_from_port("AOS6", "1/48") != "1":
        fail("ALE port-to-slot normalization failed")
    if poe_status_command("AOS8", "1/1") != "show lanpower slot 1/1":
        fail("AOS8 preferred PoE query generation failed")
    if poe_status_commands("AOS8", "1/1") != ("show lanpower slot 1/1", "show lanpower 1/1"):
        fail("AOS8 PoE documented fallback chain regressed")
    if poe_status_command("AOS6", "1") != "show lanpower 1":
        fail("AOS6 PoE query generation failed")
    if poe_status_commands("AOS6", "1") != ("show lanpower 1",):
        fail("AOS6 PoE query chain regressed")

    for profile_name, profile in public.items():
        for action in set(profile.get("commands", {})) | set(profile.get("orchestrated_actions", [])):
            state = profile.get("compatibility", {}).get(action, {}).get("state")
            if state not in {"documented", "orchestrated", "model_dependent", "unsupported"}:
                fail(f"{profile_name}/{action}: missing compatibility state")

    if not ORCHESTRATED_ACTIONS.issubset(supported_actions()):
        fail("orchestrated actions missing from supported action registry")

    # Portivo workflows must report family-aware compatibility rather than being
    # mislabeled as unsupported merely because they are not one raw CLI string.
    configured8 = set(aos8) | set(ORCHESTRATED_ACTIONS)
    configured6 = set(aos6) | set(ORCHESTRATED_ACTIONS)
    for profile_name, configured in (("AOS8", configured8), ("AOS6", configured6)):
        for action in ("interface_cycle", "poe_cycle"):
            if action_support(profile_name, action, configured).state != "orchestrated":
                fail(f"{profile_name}/{action}: workflow compatibility state regressed")
    if action_support("AOS8", "check_unp", configured8).state != "orchestrated":
        fail("AOS8/check_unp: UNP workflow compatibility state regressed")
    if action_support("AOS6", "check_unp", configured6).state != "unsupported":
        fail("AOS6/check_unp: AOS8-only UNP workflow must remain unsupported")

    # Controlled reload plans. AOS8 targets the explicit chassis ID. Legacy AOS6
    # member reload is role-aware and fails closed if Portivo has not learned the
    # physical member role from stack health.
    if reload_switch_command({"profile": "AOS8"}) != "reload from working no rollback-timeout":
        fail("AOS8 standalone reload command regressed")
    if reload_switch_command({"profile": "AOS6"}) != "reload working no rollback-timeout":
        fail("AOS6 standalone reload command regressed")
    if reload_stack_member_command({"profile": "AOS8"}, "3") != "reload chassis-id 3 from working no rollback-timeout":
        fail("AOS8 chassis reload command regressed")
    aos6_primary = {"profile": "AOS6", "stack_members": [{"id": "1", "role": "Primary"}, {"id": "2", "role": "Secondary"}]}
    if reload_stack_member_command(aos6_primary, "1") != "reload primary":
        fail("AOS6 primary-member reload mapping regressed")
    if reload_stack_member_command(aos6_primary, "2") != "reload secondary":
        fail("AOS6 secondary-member reload mapping regressed")
    aos6_idle = {"profile": "AOS6", "stack_members": [{"id": "3", "role": "Idle"}]}
    if reload_stack_member_command(aos6_idle, "3") != "reload ni 3":
        fail("AOS6 idle-member reload mapping regressed")
    try:
        reload_stack_member_command({"profile": "AOS6", "stack_members": [{"id": "4", "role": ""}]}, "4")
    except ReloadActionError:
        pass
    else:
        fail("AOS6 member reload must fail closed when the member role is unknown")

    # Legacy R6 training material directly demonstrates slot-level lanpower start/stop.
    # Keep per-port AOS6 PoE control conservative until the exact device accepts
    # the profile mapping, rather than advertising it as universal ALE syntax.
    if action_support("AOS6", "poe_enable", configured6).state != "model_dependent":
        fail("AOS6/poe_enable: per-port legacy PoE control must remain model/release dependent")
    if action_support("AOS6", "poe_disable", configured6).state != "model_dependent":
        fail("AOS6/poe_disable: per-port legacy PoE control must remain model/release dependent")

    # Static guard against reintroducing the two command forms that triggered
    # real OS6560 failures. Metadata/comments are intentionally not scanned;
    # executable profile strings are checked above and runtime PoE helpers are
    # validated through exact generation tests.
    main_text = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
    runner_text = (ROOT / "app" / "job_runner.py").read_text(encoding="utf-8")
    if 'show lanpower port {port}' in main_text or 'show lanpower port {port}' in runner_text:
        fail("invalid AOS8 PoE port-status syntax reappeared in executable paths")
    executable_text = "\n".join([
        main_text,
        (ROOT / "app" / "vlan_maintenance.py").read_text(encoding="utf-8"),
        (ROOT / "app" / "port_troubleshooter.py").read_text(encoding="utf-8"),
    ])
    if "show mac-address-table" in executable_text:
        fail("Cisco-style MAC table syntax reappeared in ALE executable paths")

    manifest = json.loads((ROOT / "data" / "ale_cli_validation.json").read_text(encoding="utf-8"))
    if manifest.get("vendor") != "Alcatel-Lucent Enterprise":
        fail("validation manifest missing ALE vendor identity")

    print("CLI RELIABILITY: PASS")
    print(f"AOS8: {len(aos8)} raw + {len(ORCHESTRATED_ACTIONS)} orchestrated actions")
    print(f"AOS6: {len(aos6)} raw + {len(ORCHESTRATED_ACTIONS)} orchestrated actions")


if __name__ == "__main__":
    main()
