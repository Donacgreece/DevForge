# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
html = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")
js = (ROOT / "app" / "static" / "app.js").read_text(encoding="utf-8")
css = (ROOT / "app" / "static" / "styles.css").read_text(encoding="utf-8")

assert '"ups_offline": offline' in main
assert 'id="powerMetricOffline"' in html
assert 'value="offline"' in html
assert 'return "offline"' in js
assert 'summary.ups_offline' in js
assert 'filterPowerUpsByHealth("offline")' in js
assert 'communication-offline' in css
print("POWER OFFLINE SUMMARY VALIDATION: PASS")
