# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.vendor_drivers import registry

PROFILE_PATH = ROOT / "data" / "command_profiles.json"
CATALOG_PATH = ROOT / "data" / "action_catalog.json"

# Core capabilities Portivo relies on in both ALE families. PoE global/port
# views are intentionally workflows rather than raw CLI strings.
REQUIRED_RAW_READ_ACTIONS = {
    "system_info",
    "interface_status_all",
    "interface_status",
    "interface_details",
    "vlan_members",
    "mac_table",
    "arp_table",
    "lldp_neighbors",
}
REQUIRED_RAW_WRITE_ACTIONS = {
    "interface_enable",
    "interface_disable",
    "interface_alias",
    "poe_enable",
    "poe_disable",
    "save_config",
}
REQUIRED_PROFILE_WORKFLOWS = {"poe_global_status", "poe_port_status", "poe_status", "reload_stack_member"}
PORTIVO_WORKFLOWS = {"interface_cycle", "poe_cycle", "custom_command", "check_unp", "fix_unp"}


def _load_object(path: Path, description: str) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not data:
        raise SystemExit(f"No {description} were found in {path}.")
    return data


def main() -> None:
    profiles = _load_object(PROFILE_PATH, "command profiles")
    catalog = _load_object(CATALOG_PATH, "catalog actions")

    registered_profiles = set(registry.profiles())
    configured_profiles = {str(name).strip().upper() for name in profiles}
    missing_drivers = sorted(configured_profiles - registered_profiles)
    if missing_drivers:
        raise SystemExit(f"No vendor driver is registered for: {', '.join(missing_drivers)}")
    orphan_drivers = sorted(registered_profiles - configured_profiles)
    if orphan_drivers:
        raise SystemExit(f"Registered drivers have no command profile: {', '.join(orphan_drivers)}")

    profile_action_union: set[str] = set()
    for name, profile in profiles.items():
        commands = profile.get("commands")
        if not isinstance(commands, dict):
            raise SystemExit(f"{name}: commands must be an object")
        workflows = profile.get("orchestrated_actions", [])
        if not isinstance(workflows, list) or any(not isinstance(item, str) or not item.strip() for item in workflows):
            raise SystemExit(f"{name}: orchestrated_actions must be a list of action names")
        workflow_set = set(workflows)
        if workflow_set != REQUIRED_PROFILE_WORKFLOWS:
            raise SystemExit(
                f"{name}: expected ALE-aware workflows {sorted(REQUIRED_PROFILE_WORKFLOWS)}, got {sorted(workflow_set)}"
            )
        overlap = sorted(set(commands) & workflow_set)
        if overlap:
            raise SystemExit(f"{name}: workflow actions must not also contain raw CLI strings: {', '.join(overlap)}")

        missing = sorted((REQUIRED_RAW_READ_ACTIONS | REQUIRED_RAW_WRITE_ACTIONS) - set(commands))
        if missing:
            raise SystemExit(f"{name}: missing core raw actions: {', '.join(missing)}")
        profile_action_union.update(commands)
        profile_action_union.update(workflow_set)

        for action, command in commands.items():
            if not isinstance(command, str) or not command.strip():
                raise SystemExit(f"{name}/{action}: command must be a non-empty string")
            if "\n" in command or "\r" in command:
                raise SystemExit(f"{name}/{action}: multiline commands are not allowed")

        verification = profile.get("verification", {})
        if not isinstance(verification, dict):
            raise SystemExit(f"{name}: verification must be an object")
        for action, command in verification.items():
            if action not in commands:
                raise SystemExit(f"{name}/{action}: verification exists for an unsupported raw action")
            if not isinstance(command, str) or not command.strip():
                raise SystemExit(f"{name}/{action}: verification command must be a non-empty string")
            if "\n" in command or "\r" in command:
                raise SystemExit(f"{name}/{action}: multiline verification commands are not allowed")

    catalog_actions = set(catalog)
    missing_catalog = sorted((profile_action_union | PORTIVO_WORKFLOWS) - catalog_actions)
    if missing_catalog:
        raise SystemExit(f"The action catalog is missing: {', '.join(missing_catalog)}")

    for action, metadata in catalog.items():
        if not isinstance(metadata, dict):
            raise SystemExit(f"catalog/{action}: metadata must be an object")
        for key in ("label", "description", "category"):
            if not isinstance(metadata.get(key), str) or not metadata[key].strip():
                raise SystemExit(f"catalog/{action}: {key} must be a non-empty string")
        if metadata.get("risk") not in {"read", "change"}:
            raise SystemExit(f"catalog/{action}: risk must be read or change")

    counts = ", ".join(
        f"{name}={len(profile.get('commands', {}))}+{len(profile.get('orchestrated_actions', []))} workflows"
        for name, profile in sorted(profiles.items())
    )
    print(f"Validated {len(profiles)} driver-backed profiles ({counts}) and {len(catalog)} catalog actions.")


if __name__ == "__main__":
    main()
