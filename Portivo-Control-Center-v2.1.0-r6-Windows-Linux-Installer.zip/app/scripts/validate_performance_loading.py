# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
MAIN = (ROOT / "app/main.py").read_text(encoding="utf-8")

checks = {
    "login does not block on refreshAll": "await refreshAll();" not in JS,
    "dashboard refresh avoids full device inventory": 'if (current === "dashboardView" && hasCapability("dashboard.view")) await loadDashboard();' in JS,
    "device inventory has short TTL cache": "cacheAge < 15000" in JS,
    "device render is active-view only": "function renderDeviceDataForActiveView()" in JS and 'activeView === "devicesView"' in JS,
    "admin uses progressive loading": "Promise.allSettled(deferredRequests)" in JS and "applyAdminCore(overview, settingsData);" in JS,
    "dashboard provides switch attention without full browser inventory": '"switch_attention": [' in MAIN and '_public_device(row)' in MAIN and 'for row in switch_attention_rows' in MAIN,
    "dashboard attention result is bounded": "LIMIT 8" in MAIN,
    "new login resets user-scoped device cache": "state.devicesLoadedAt = 0;" in JS and "state.devices = [];" in JS,
}

failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("PERFORMANCE LOADING VALIDATION: FAIL")
    for name in failed:
        print(f"  FAIL: {name}")
    raise SystemExit(1)

print("PERFORMANCE LOADING VALIDATION: PASS")
