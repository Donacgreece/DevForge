# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
lock = (ROOT / "requirements.lock").read_text(encoding="utf-8")
req_in = (ROOT / "requirements.in").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
win_setup = (ROOT / "scripts/setup_windows.ps1").read_text(encoding="utf-8")
linux_setup = (ROOT / "scripts/setup_linux.sh").read_text(encoding="utf-8")
sbom = json.loads((ROOT / "SBOM.spdx.json").read_text(encoding="utf-8"))
notices = (ROOT / "THIRD_PARTY_NOTICES.md").read_text(encoding="utf-8")
index = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
main = (ROOT / "app/main.py").read_text(encoding="utf-8")
licenses = ROOT / "THIRD_PARTY_LICENSES"

package_versions = {
    str(pkg.get("name")): str(pkg.get("versionInfo"))
    for pkg in sbom.get("packages", [])
    if isinstance(pkg, dict)
}

checks = {
    "current backend revision": 'PORTIVO_BUILD_REVISION = "2.1.0-r6"' in main,
    "current frontend revision": 'window.PORTIVO_UI_REVISION="2.1.0-r6"' in index,
    "cryptography exact pin": "cryptography==49.0.0" in lock,
    "multipart exact pin": "python-multipart==0.0.32" in lock,
    "reportlab exact pin": "reportlab==4.4.10" in lock,
    "python runtime baseline": "CPython 3.13.15" in lock,
    "cryptography bounded input": "cryptography>=49,<50" in req_in,
    "multipart bounded input": "python-multipart>=0.0.32,<1.0" in req_in,
    "reportlab bounded input": "reportlab>=4.4.10,<5.0" in req_in,
    "windows no pip self-upgrade": "pip install --upgrade pip" not in win_setup and "pip','install','--upgrade','pip" not in win_setup,
    "linux no pip self-upgrade": "pip install --upgrade pip" not in linux_setup,
    "windows exact no-deps install": "--only-binary=:all:" in win_setup and "--no-deps" in win_setup and "requirements.lock" in win_setup and "pip check" in win_setup,
    "linux exact no-deps install": "--no-deps" in linux_setup and "requirements.lock" in linux_setup and "pip check" in linux_setup,
    "SBOM cryptography": package_versions.get("cryptography") == "49.0.0",
    "SBOM multipart": package_versions.get("python-multipart") == "0.0.32",
    "SBOM reportlab": package_versions.get("ReportLab") == "4.4.10",
    "SBOM python": package_versions.get("Python") == "3.13.15",
    "notices cryptography": "| cryptography | 49.0.0 |" in notices,
    "notices multipart": "| python-multipart | 0.0.32 |" in notices,
    "notices reportlab": "| ReportLab | 4.4.10 |" in notices,
    "python license artifact": (licenses / "Python-3.13.15.txt").is_file(),
    "cryptography license artifact": (licenses / "cryptography-49.0.0.txt").is_file(),
    "multipart license artifact": (licenses / "python-multipart-0.0.32.txt").is_file(),
    "reportlab license artifact": (licenses / "ReportLab-4.4.10.txt").is_file(),
    "old dependency license artifacts removed": not any(
        (licenses / name).exists()
        for name in (
            "Python-3.12.10.txt",
            "cryptography-46.0.4.txt",
            "python-multipart-0.0.29.txt",
            "ReportLab-4.4.9.txt",
        )
    ),
    "README supply-chain controls": "Security and supply-chain controls" in readme,
    "CHANGELOG current release": "### Static revision 2.1.0-r6" in changelog,
}

failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("PORTIVO DEPENDENCY & SUPPLY-CHAIN HARDENING VALIDATION: FAIL")
    for name in failed:
        print(f"  FAIL: {name}")
    raise SystemExit(1)

print("PORTIVO DEPENDENCY & SUPPLY-CHAIN HARDENING VALIDATION: PASS")
