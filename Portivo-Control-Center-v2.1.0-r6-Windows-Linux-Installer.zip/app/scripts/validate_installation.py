# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
REQUIRED_PATHS = [
    "VERSION",
    "run.py",
    "requirements.txt",
    "requirements.in",
    "requirements.lock",
    "SBOM.spdx.json",
    "CONTRIBUTING.md",
    "LICENSE",
    "LEGAL.md",
    "THIRD_PARTY_NOTICES.md",
    "TRADEMARKS.md",
    "README.md",
    "INSTALLATION.md",
    "deployment/windows/Uninstall-Portivo.ps1",
    "deployment/windows/Uninstall Windows.cmd",
    "deployment/linux/Uninstall Linux.sh",
    "app/main.py",
    "app/db.py",
    "app/job_lifecycle.py",
    "app/power_monitor.py",
    "app/power_drivers.py",
    "app/monitoring_policy.py",
    "app/snmp_monitor.py",
    "app/unp_scheduler.py",
    "app/static/index.html",
    "app/static/app.js",
    "app/login_throttle.py",
    "app/password_policy.py",
    "app/time_service.py",
    "app/stack_monitor.py",
    "app/vendor_drivers.py",
    "data/command_profiles.json",
    "data/action_catalog.json",
    "data/ale_cli_validation.json",
    "scripts/validate_profiles.py",
    "scripts/validate_drivers.py",
    "scripts/validate_cli_reliability.py",
    "scripts/validate_vlan_stability.py",
    "scripts/validate_fleet_selector.py",
    "scripts/validate_runbooks.py",
    "scripts/validate_runbook_execution.py",
    "scripts/validate_timezone.py",
    "scripts/validate_access_control.py",
    "scripts/validate_access_api.py",
    "scripts/validate_stack_monitoring.py",
    "scripts/validate_stack_reload.py",
    "scripts/validate_job_lifecycle.py",
    "scripts/validate_upgrade_migrations.py",
    "scripts/validate_power_monitoring.py",
    "scripts/validate_power_drivers.py",
    "scripts/validate_power_driver_registry.py",
    "scripts/validate_xppc_runtime_health.py",
    "scripts/validate_ups_vendor_support.py",
    "scripts/validate_power_api.py",
    "scripts/validate_power_details.py",
    "scripts/validate_power_correlation_notifications.py",
    "scripts/validate_power_incident_confirmation.py",
    "scripts/validate_monitoring_mode.py",
    "scripts/validate_compact_port_layout.py",
    "scripts/validate_session_ups_noise.py",
    "scripts/validate_performance_loading.py",
    "scripts/validate_single_switch_command_center.py",
    "scripts/validate_roadmap_shape.py",
    "scripts/validate_dashboard_outage_confirmation.py",
    "scripts/validate_ups_communication_separation.py",
    "scripts/validate_power_details_loading.py",
    "scripts/validate_power_offline_summary.py",
    "scripts/validate_ups_offline_visual.py",
    "scripts/validate_review_commands_ui.py",
    "scripts/validate_login_navigation_refinement.py",
    "scripts/validate_sidebar_navigation_state.py",
    "scripts/validate_power_summary_cards.py",
    "scripts/validate_licensing.py",
    "scripts/validate_open_source_readiness.py",
    "scripts/validate_security_hardening_r8.py",
    "scripts/validate_supply_chain_hardening_r9.py",
    "scripts/validate_health_probe_architecture_v210_r6.py",
    "scripts/validate_uninstall_support_v210_r6.py",
]
VALIDATORS = [
    "scripts/validate_profiles.py",
    "scripts/validate_drivers.py",
    "scripts/validate_cli_reliability.py",
    "scripts/validate_vlan_stability.py",
    "scripts/validate_fleet_selector.py",
    "scripts/validate_runbooks.py",
    "scripts/validate_runbook_execution.py",
    "scripts/validate_timezone.py",
    "scripts/validate_access_control.py",
    "scripts/validate_access_api.py",
    "scripts/validate_stack_monitoring.py",
    "scripts/validate_stack_reload.py",
    "scripts/validate_job_lifecycle.py",
    "scripts/validate_upgrade_migrations.py",
    "scripts/validate_power_monitoring.py",
    "scripts/validate_power_drivers.py",
    "scripts/validate_power_driver_registry.py",
    "scripts/validate_xppc_runtime_health.py",
    "scripts/validate_ups_vendor_support.py",
    "scripts/validate_power_api.py",
    "scripts/validate_power_details.py",
    "scripts/validate_power_correlation_notifications.py",
    "scripts/validate_power_incident_confirmation.py",
    "scripts/validate_monitoring_mode.py",
    "scripts/validate_compact_port_layout.py",
    "scripts/validate_session_ups_noise.py",
    "scripts/validate_performance_loading.py",
    "scripts/validate_single_switch_command_center.py",
    "scripts/validate_roadmap_shape.py",
    "scripts/validate_dashboard_outage_confirmation.py",
    "scripts/validate_ups_communication_separation.py",
    "scripts/validate_power_details_loading.py",
    "scripts/validate_power_offline_summary.py",
    "scripts/validate_ups_offline_visual.py",
    "scripts/validate_review_commands_ui.py",
    "scripts/validate_login_navigation_refinement.py",
    "scripts/validate_sidebar_navigation_state.py",
    "scripts/validate_power_summary_cards.py",
    "scripts/validate_licensing.py",
    "scripts/validate_open_source_readiness.py",
    "scripts/validate_security_hardening_r8.py",
    "scripts/validate_supply_chain_hardening_r9.py",
    "scripts/validate_health_probe_architecture_v210_r6.py",
    "scripts/validate_uninstall_support_v210_r6.py",
]


def main() -> int:
    missing = [path for path in REQUIRED_PATHS if not (ROOT / path).is_file()]
    if missing:
        print("PORTIVO INSTALLATION VALIDATION: FAIL")
        for path in missing:
            print(f"  MISSING: {path}")
        return 1

    print("Portivo required runtime files: PASS")
    child_env = os.environ.copy()
    if len(str(child_env.get("APP_SECRET_KEY") or "")) < 32:
        child_env["APP_SECRET_KEY"] = "installation-validation-only-secret-key-000000000000"
    for validator in VALIDATORS:
        print(f"Running {validator}...")
        completed = subprocess.run(
            [sys.executable, str(ROOT / validator)],
            cwd=ROOT,
            env=child_env,
            check=False,
        )
        if completed.returncode != 0:
            print(f"PORTIVO INSTALLATION VALIDATION: FAIL ({validator})")
            return completed.returncode or 1

    print("PORTIVO INSTALLATION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
