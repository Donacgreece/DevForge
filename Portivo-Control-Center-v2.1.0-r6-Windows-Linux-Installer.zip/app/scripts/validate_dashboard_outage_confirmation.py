# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.TemporaryDirectory(prefix="portivo-dashboard-confirm-")
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "dashboard-confirm.db")
os.environ.setdefault("APP_SECRET_KEY", "dashboard-confirmation-validation-only-secret-000000")

from app.health_monitor import confirmed_connectivity_status  # noqa: E402


def main() -> int:
    threshold = 3
    healthy = {"last_status": "online", "last_seen": "2026-08-18T06:00:00+00:00", "consecutive_failures": 0}
    first_loss = {"last_status": "offline", "last_seen": "2026-08-18T06:00:00+00:00", "consecutive_failures": 1}
    second_loss = {"last_status": "offline", "last_seen": "2026-08-18T06:00:00+00:00", "consecutive_failures": 2}
    confirmed_loss = {"last_status": "offline", "last_seen": "2026-08-18T06:00:00+00:00", "consecutive_failures": 3}
    never_seen = {"last_status": "offline", "last_seen": "", "consecutive_failures": 1}

    assert confirmed_connectivity_status(healthy, threshold) == "online"
    assert confirmed_connectivity_status(first_loss, threshold) == "online"
    assert confirmed_connectivity_status(second_loss, threshold) == "online"
    assert confirmed_connectivity_status(confirmed_loss, threshold) == "offline"
    assert confirmed_connectivity_status(never_seen, threshold) == "unknown"
    assert confirmed_connectivity_status({**confirmed_loss, "consecutive_failures": 4}, 5) == "online"
    assert confirmed_connectivity_status({**confirmed_loss, "consecutive_failures": 5}, 5) == "offline"

    main_py = (ROOT / "app/main.py").read_text(encoding="utf-8")
    if "SELECT failure_threshold FROM notification_policy WHERE id=1" not in main_py:
        raise AssertionError("Dashboard does not read the notification outage confirmation threshold")
    if '"outage_confirmation_checks": outage_confirmation_checks' not in main_py:
        raise AssertionError("Dashboard payload does not expose its outage confirmation threshold")
    if "confirmed_connectivity_status" not in main_py:
        raise AssertionError("Dashboard does not use confirmed connectivity state")

    print("DASHBOARD OUTAGE CONFIRMATION VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        _tmp.cleanup()
