# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.vlan_maintenance import stable_signature


def assessment(eligible, protected):
    return {
        "eligible_ports": list(eligible),
        "protected_ports": [
            {"port": port, "reasons": list(reasons)}
            for port, reasons in protected
        ],
    }


def main() -> int:
    first = assessment(
        ["1/1/1", "1/1/2", "1/1/3"],
        [("1/1/48", ["Target VLAN is tagged on this port", "High learned-MAC count: 161"])],
    )
    counter_only_change = assessment(
        ["1/1/1", "1/1/2", "1/1/3"],
        [("1/1/48", ["Target VLAN is tagged on this port", "High learned-MAC count: 162"])],
    )
    if stable_signature(first) != stable_signature(counter_only_change):
        print("VLAN STABILITY VALIDATION: FAIL (volatile MAC count changed signature)")
        return 1

    eligible_became_protected = assessment(
        ["1/1/1", "1/1/2"],
        [
            ("1/1/3", ["LAG member"]),
            ("1/1/48", ["Target VLAN is tagged on this port", "High learned-MAC count: 162"]),
        ],
    )
    if stable_signature(first) == stable_signature(eligible_became_protected):
        print("VLAN STABILITY VALIDATION: FAIL (eligibility transition not detected)")
        return 1

    new_matching_protected = assessment(
        ["1/1/1", "1/1/2", "1/1/3"],
        [
            ("1/1/17", ["Trunk-like membership: 2 VLANs"]),
            ("1/1/48", ["Target VLAN is tagged on this port", "High learned-MAC count: 162"]),
        ],
    )
    if stable_signature(first) == stable_signature(new_matching_protected):
        print("VLAN STABILITY VALIDATION: FAIL (new matching protected port not detected)")
        return 1

    reason_only_change = assessment(
        ["1/1/1", "1/1/2", "1/1/3"],
        [("1/1/48", ["Explicitly protected by policy", "High learned-MAC count: 250"])],
    )
    if stable_signature(first) != stable_signature(reason_only_change):
        print("VLAN STABILITY VALIDATION: FAIL (protected classification should remain stable)")
        return 1

    print("VLAN STABILITY VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
