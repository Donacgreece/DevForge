# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
win = (ROOT / "deployment/windows/Uninstall-Portivo.ps1").read_text(encoding="utf-8")
cmd = (ROOT / "deployment/windows/Uninstall Windows.cmd").read_text(encoding="utf-8")
linux = (ROOT / "deployment/linux/Uninstall Linux.sh").read_text(encoding="utf-8")
main = (ROOT / "app/main.py").read_text(encoding="utf-8")
changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")

checks = {
    "Windows default is keep-data": "[ValidateSet('Prompt','KeepData','Purge')]" in win and "$Mode = 'Prompt'" in win,
    "Windows preserves explicit state only": "@('.env','data','backups')" in win,
    "Windows purge has destructive confirmation": "Full Removal permanently deletes Portivo credentials, configuration, database and backups" in win,
    "Windows removes service": "sc.exe delete $ServiceName" in win,
    "Windows removes firewall rule": "Remove-NetFirewallRule" in win,
    "Windows removes Installed Apps registration": "Uninstall\\PortivoControlCenter" in win,
    "Windows launcher present": "Uninstall-Portivo.ps1" in cmd,
    "Windows uninstall matches installer dimensions": 'Height="680" Width="980"' in win,
    "Windows uninstall branded two-panel layout": 'REMOVE CLEANLY' in win and 'STAY IN CONTROL' in win and 'PORTIVO WINDOWS UNINSTALL' in win,
    "Windows uninstall uses installer visual palette": '#5C388D' in win and '#302244' in win and '#6F3FD4' in win,
    "Windows uninstall has live progress": 'Set-UninstallStatus' in win and 'ProgressBar x:Name="Progress"' in win,
    "Windows action row is docked and always visible": 'DockPanel.Dock="Bottom"' in win and 'x:Name="UninstallButton"' in win and 'ScrollViewer VerticalScrollBarVisibility="Auto"' in win,
    "Windows uninstall has in-window success state": 'Portivo was removed successfully.' in win and "uninstallButton.Visibility = 'Collapsed'" in win,
    "Windows uninstaller branding assets": 'portivo-logo-white.png' in win and 'portivo.ico' in win,
    "Linux branded terminal workflow": "PORTIVO CONTROL CENTER" in linux and "Clean removal. Your choice of what stays." in linux and "step()" in linux,
    "Linux default prompt / keep-data": 'MODE="prompt"' in linux and '--keep-data' in linux,
    "Linux preserves explicit state only": 'for name in .env data backups' in linux,
    "Linux purge requires PURGE confirmation": 'Type PURGE to continue' in linux,
    "Linux removes systemd service": 'systemctl disable "$SERVICE_NAME"' in linux and 'rm -f "$SERVICE_FILE"' in linux,
    "Linux removes service identity": 'userdel "$SERVICE_USER"' in linux,
    "Exact source endpoint includes deployment scripts": '"deployment"' in main,
    "r6 changelog": "### Static revision 2.1.0-r6" in changelog,
    "Windows keep-data label uses ASCII-safe punctuation": "Standard uninstall - keep data" in win and "Standard uninstall — keep data" not in win,
    "Windows uninstaller is ASCII-only": all(ord(ch) < 128 for ch in win),
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    print("UNINSTALL SUPPORT v2.1.0-r6: FAIL")
    for name in failed:
        print(f" - {name}")
    raise SystemExit(1)
print("UNINSTALL SUPPORT v2.1.0-r6: PASS")
