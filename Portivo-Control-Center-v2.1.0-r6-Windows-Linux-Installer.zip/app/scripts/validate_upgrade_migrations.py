# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    temp_dir = tempfile.TemporaryDirectory(prefix="portivo-upgrade-validation-")
    db_path = Path(temp_dir.name) / "legacy.db"

    # Recreate the v1.8.3-era Job table shape before v1.8.4 lifecycle columns.
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                dry_run INTEGER NOT NULL DEFAULT 0,
                target_count INTEGER NOT NULL DEFAULT 0,
                success_count INTEGER NOT NULL DEFAULT 0,
                failure_count INTEGER NOT NULL DEFAULT 0,
                requested_by TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT
            );
            INSERT INTO jobs(action,status,dry_run,target_count,requested_by,payload_json,created_at,started_at)
            VALUES('save_config','running',0,1,'upgrade-validator','{}','2026-08-15T00:00:00+00:00','2026-08-15T00:00:01+00:00');
            """
        )
        conn.commit()
    finally:
        conn.close()

    os.environ["DATABASE_PATH"] = str(db_path)
    os.environ.setdefault("APP_SECRET_KEY", "upgrade-validation-only-secret-key-000000000000")

    from app.db import db, init_db

    # This is the same migration entry point used by the Windows updater.
    init_db()

    with db() as conn2:
        columns = {str(row["name"]) for row in conn2.execute("PRAGMA table_info(jobs)").fetchall()}
        required = {
            "heartbeat_at", "interrupted_reason", "retry_of_job_id", "cancel_requested",
            "cancel_requested_at", "cancel_requested_by", "interrupted_count", "cancelled_count",
            "removed_at", "removed_by",
        }
        missing = sorted(required - columns)
        if missing:
            raise AssertionError(f"Upgrade migration missed Job lifecycle columns: {missing}")
        indexes = {str(row["name"]) for row in conn2.execute("PRAGMA index_list(jobs)").fetchall()}
        if "idx_jobs_retry_of" not in indexes:
            raise AssertionError("Upgrade migration did not create idx_jobs_retry_of after adding retry_of_job_id")
        if "idx_jobs_removed_at" not in indexes:
            raise AssertionError("Upgrade migration did not create idx_jobs_removed_at after adding removed_at")
        row = conn2.execute("SELECT status FROM jobs WHERE id=1").fetchone()
        if not row or str(row["status"]) != "running":
            raise AssertionError("Upgrade migration unexpectedly changed legacy Job state before startup reconciliation")

        # Rewind the newly introduced Power Infrastructure pieces to a pre-v1.9
        # shape and run init_db again. This catches migration ordering bugs where
        # an index is created before ALTER TABLE has added its target column.
        conn2.execute("DROP INDEX IF EXISTS idx_devices_power_source")
        conn2.execute("DROP INDEX IF EXISTS idx_notification_outbox_power_incident")
        conn2.execute("DROP TABLE IF EXISTS power_incidents")
        conn2.execute("DROP TABLE IF EXISTS ups_devices")
        conn2.execute("ALTER TABLE devices DROP COLUMN power_source_ups_id")
        conn2.execute("ALTER TABLE notification_outbox DROP COLUMN power_incident_id")
        for column in ("notify_ups_on_battery", "notify_ups_power_restored", "notify_ups_low_battery", "notify_ups_unreachable"):
            conn2.execute(f"ALTER TABLE notification_destinations DROP COLUMN {column}")

    init_db()

    with db() as conn3:
        device_columns = {str(row["name"]) for row in conn3.execute("PRAGMA table_info(devices)").fetchall()}
        destination_columns = {str(row["name"]) for row in conn3.execute("PRAGMA table_info(notification_destinations)").fetchall()}
        outbox_columns = {str(row["name"]) for row in conn3.execute("PRAGMA table_info(notification_outbox)").fetchall()}
        tables = {str(row["name"]) for row in conn3.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "power_source_ups_id" not in device_columns:
            raise AssertionError("Upgrade migration missed devices.power_source_ups_id")
        if not {"ups_devices", "power_incidents"}.issubset(tables):
            raise AssertionError("Upgrade migration missed Power Infrastructure tables")
        ups_columns = {str(row["name"]) for row in conn3.execute("PRAGMA table_info(ups_devices)").fetchall()}
        required_ups_driver_columns = {"driver_mode", "driver_key", "sys_object_id"}
        if not required_ups_driver_columns.issubset(ups_columns):
            raise AssertionError("Upgrade migration missed UPS driver persistence columns")
        required_destination = {"notify_ups_on_battery", "notify_ups_power_restored", "notify_ups_low_battery", "notify_ups_unreachable"}
        if not required_destination.issubset(destination_columns):
            raise AssertionError("Upgrade migration missed UPS notification routing columns")
        if "power_incident_id" not in outbox_columns:
            raise AssertionError("Upgrade migration missed notification_outbox.power_incident_id")
        indexes = {str(row["name"]) for row in conn3.execute("PRAGMA index_list(devices)").fetchall()}
        if "idx_devices_power_source" not in indexes:
            raise AssertionError("Upgrade migration did not create idx_devices_power_source after adding power_source_ups_id")

    print("Portivo upgrade migration validation: PASS")
    temp_dir.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
