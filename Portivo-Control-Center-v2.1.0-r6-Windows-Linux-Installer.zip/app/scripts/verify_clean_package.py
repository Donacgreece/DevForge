# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
import sys
from pathlib import Path
from zipfile import BadZipFile, ZipFile

ROOT = Path(__file__).resolve().parent.parent
SELF = Path(__file__).resolve()

RUNTIME_PATTERNS = (
    ".env",
    "*.db",
    "*.sqlite",
    "*.sqlite3",
    "*.db-wal",
    "*.db-shm",
    "*.log",
    "*.bak",
    "*.backup",
    "*.pem",
    "*.key",
    "*.pfx",
    "*.p12",
)

FORBIDDEN_DIR_NAMES = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "node_modules",
    "backups",
    "logs",
}

ENVIRONMENT_MARKERS = (
    "example-company-production-marker",
    "example-site-production-marker",
)

RFC1918_IPV4_RE = re.compile(
    r"(?<![\d.])(?:10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2})(?![\d.])"
)

PRIVATE_KEY_RE = re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")
MAC_RE = re.compile(r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}(?![0-9a-f])")
TEXT_SUFFIXES = {
    ".py", ".js", ".html", ".css", ".json", ".md", ".txt", ".csv", ".yml", ".yaml",
    ".toml", ".ini", ".cfg", ".conf", ".example", ".sh", ".ps1", ".bat", ".cmd", ".service",
}


def is_text_candidate(path: Path) -> bool:
    return path.suffix.lower() in TEXT_SUFFIXES or path.name in {"Dockerfile", "VERSION", "LICENSE", ".gitignore"}


def _globally_administered_mac(value: str) -> bool:
    normalized = value.replace("-", ":")
    try:
        first_octet = int(normalized.split(":", 1)[0], 16)
    except (ValueError, IndexError):
        return False
    return not bool(first_octet & 0x02)


def scan_text(path: Path, errors: list[str]) -> None:
    if path.resolve() == SELF:
        return
    try:
        text = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return
    for marker in ENVIRONMENT_MARKERS:
        if marker.casefold() in text.casefold():
            errors.append(f"environment-specific marker in {path.relative_to(ROOT)}: {marker}")
    if RFC1918_IPV4_RE.search(text):
        errors.append(f"RFC1918/private IPv4 literal in {path.relative_to(ROOT)}")
    if PRIVATE_KEY_RE.search(text):
        errors.append(f"private key material in {path.relative_to(ROOT)}")
    for mac in MAC_RE.findall(text):
        if _globally_administered_mac(mac):
            errors.append(f"production-looking globally administered MAC in {path.relative_to(ROOT)}: {mac}")


def scan_xlsx(path: Path, errors: list[str]) -> None:
    try:
        with ZipFile(path) as archive:
            for name in archive.namelist():
                if not name.endswith((".xml", ".rels")):
                    continue
                text = archive.read(name).decode("utf-8", "ignore")
                for marker in ENVIRONMENT_MARKERS:
                    if marker.casefold() in text.casefold():
                        errors.append(f"environment-specific marker in {path.relative_to(ROOT)}::{name}: {marker}")
                if RFC1918_IPV4_RE.search(text):
                    errors.append(f"RFC1918/private IPv4 literal in {path.relative_to(ROOT)}::{name}")
                for mac in MAC_RE.findall(text):
                    if _globally_administered_mac(mac):
                        errors.append(f"production-looking globally administered MAC in {path.relative_to(ROOT)}::{name}: {mac}")
    except BadZipFile:
        errors.append(f"invalid XLSX archive: {path.relative_to(ROOT)}")


def main() -> int:
    errors: list[str] = []

    for directory in ROOT.rglob("*"):
        if directory.is_dir() and directory.name in FORBIDDEN_DIR_NAMES:
            errors.append(f"runtime or development directory included: {directory.relative_to(ROOT)}")

    seen: set[Path] = set()
    for pattern in RUNTIME_PATTERNS:
        for path in ROOT.rglob(pattern):
            if path.is_file() and path not in seen:
                seen.add(path)
                errors.append(f"runtime or secret file included: {path.relative_to(ROOT)}")

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() == ".xlsx":
            scan_xlsx(path, errors)
        elif is_text_candidate(path):
            scan_text(path, errors)

    data_dir = ROOT / "data"
    allowed_data_files = {"action_catalog.json", "command_profiles.json", "ale_cli_validation.json"}
    if data_dir.exists():
        unexpected = sorted(
            str(path.relative_to(ROOT))
            for path in data_dir.rglob("*")
            if path.is_file() and path.name not in allowed_data_files
        )
        for item in unexpected:
            errors.append(f"unexpected runtime data file: {item}")

    if errors:
        print("CLEAN PACKAGE: FAIL")
        for error in sorted(set(errors)):
            print(f" - {error}")
        return 1

    print("CLEAN PACKAGE: PASS")
    print("No database, active .env, runtime records, secrets or installation-specific references were found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
