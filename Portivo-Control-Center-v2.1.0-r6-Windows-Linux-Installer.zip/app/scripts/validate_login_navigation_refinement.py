# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
index = (ROOT / "app" / "static" / "index.html").read_text(encoding="utf-8")
styles = (ROOT / "app" / "static" / "styles.css").read_text(encoding="utf-8")

login = index.split('<section class="login-screen"', 1)[1].split('</section>', 1)[0]
assert 'login-language-menu' not in login
assert 'data-language-menu' not in login
assert 'id="loginThemeToggle"' in login

sidebar = index.split('<nav aria-label="Primary navigation"', 1)[1].split('</aside>', 1)[0]
assert 'sidebar-roadmap-link' in sidebar
assert 'data-view="roadmapView"' in sidebar

more = index.split('<section class="view" id="moreView">', 1)[1].split('<section class="view" id="driversView">', 1)[0]
hero_pos = more.index('class="panel glass-card more-hero"')
legal_pos = more.index('class="panel glass-card more-legal-notice"')
grid_pos = more.index('class="more-hub-grid"')
assert hero_pos < legal_pos < grid_pos
assert 'data-more-target="roadmapView"' not in more
assert 'data-more-target="driversView"' in more
assert '.login-form > .login-language-menu' not in styles

print("LOGIN/NAVIGATION REFINEMENT VALIDATION: PASS")
