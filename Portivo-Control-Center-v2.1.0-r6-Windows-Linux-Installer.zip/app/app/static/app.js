// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Dimitris Galatsanos
const state = {
  user: null,
  devices: [],
  selected: new Map(),
  jobs: [],
  jobFilterOptions: null,
  auditFilterOptions: null,
  jobFilterTimer: null,
  auditFilterTimer: null,
  jobsRequestSequence: 0,
  auditRequestSequence: 0,
  activityHistoryUi: {
    jobsPage: 1, jobsPageSize: 25, jobsPages: 1, jobsTotal: 0,
    auditPage: 1, auditPageSize: 25, auditPages: 1, auditTotal: 0,
  },
  profiles: {},
  catalog: {},
  profilesRequest: null,
  activeProfile: "AOS8",
  lastPreview: null,
  refreshTimer: null,
  healthRefreshTimer: null,
  adminOverview: null,
  adminSettings: null,
  adminSessions: [],
  adminUsers: [],
  adminAccessControl: { roles: [], capabilities: [], actions: [], sites: [], groups: [] },
  adminSelectedRoleId: null,
  adminRoleEditorDraft: false,
  monitoringProfiles: [],
  monitoringVerificationTargets: [],
  monitoringSecretDirty: { ssh: false, auth: false, priv: false },
  automation: { credential: { configured: false }, actions: [], schedules: [], safeguards: { fix_unp: {} } },
  runbooks: [],
  notifications: null,
  power: { summary: {}, ups: [], incidents: [], monitor: {}, profiles: [], incidentHistory: [], incidentFilterOptions: { types: [], ups: [] }, inventoryMetricFilter: "" },
  powerHistoryUi: { page: 1, pages: 1, total: 0, pageSize: 25 },
  powerFilterTimer: null,
  drivers: { switches: [], power: [] },
  powerAssignmentUpsId: null,
  powerDetailsUpsId: null,
  powerDetailsPayload: null,
  powerDetailsRefreshSequence: 0,
  powerAssignmentSelected: new Set(),
  dashboardPowerAttention: [],
  dashboardSwitchAttention: [],
  devicesLoadedAt: 0,
  devicesRequest: null,
  adminLoadGeneration: 0,
  notificationHistoryUi: {
    deliveriesPage: 1, deliveriesPageSize: 25,
    incidentsPage: 1, incidentsPageSize: 25,
  },
  currentWorkspaceDeviceId: null,
  currentJobId: null,
  workspacePorts: [],
  workspacePortResult: null,
  workspacePortView: "map",
  workspacePortsLoading: false,
  activeWorkspacePort: null,
  workspacePortDialogSession: 0,
  workspaceAliasOperationSequence: 0,
  workspaceAliasOperations: new Map(),
  workspaceAliasRefreshTimer: null,
  workspaceDiagnosisSequence: 0,
  workspacePendingReload: null,
  terminalSocket: null,
  terminalConnected: false,
  terminalConnecting: false,
  terminalBusy: false,
  terminalPrompt: "$",
  terminalHistory: [],
  terminalHistoryIndex: 0,
  terminalDeviceId: null,
  terminalManualClose: false,
  terminalLines: [""],
  terminalRow: 0,
  terminalColumn: 0,
  terminalEscape: "",
  terminalAutoConnectTimer: null,
  deviceVerification: null,
  deviceDetectionTimer: null,
  deviceSort: { key: "name", direction: "asc" },
  finderSearchId: null,
  finderPollTimer: null,
  finderResult: null,
  pendingConfig: { device_count: 0, change_count: 0, devices: [] },
  pendingSaveAllRunning: false,
  fleetAuditCatalog: [],
  fleetAuditHistory: [],
  fleetAuditSelected: new Set(),
  currentFleetAudit: null,
  fleetAuditPollTimer: null,
  commandPaletteResults: [],
  commandPaletteIndex: 0,
  activityTab: "jobs",
  passwordPolicy: { min_length: 12, max_length: 128 },
  platformTimezone: "UTC",
};

const pageMeta = {
  dashboardView: ["page.dashboard.title", "page.dashboard.subtitle"],
  devicesView: ["page.devices.title", "page.devices.subtitle"],
  powerView: ["page.power.title", "page.power.subtitle"],
  finderView: ["page.finder.title", "page.finder.subtitle"],
  deviceWorkspaceView: ["workspace.pageTitle", "workspace.pageSubtitle"],
  bulkView: ["page.operations.title", "page.operations.subtitle"],
  auditsView: ["page.fleetAudits.title", "page.fleetAudits.subtitle"],
  notificationsView: ["page.notifications.title", "page.notifications.subtitle"],
  activityView: ["page.activity.title", "page.activity.subtitle"],
  jobsView: ["page.jobs.title", "page.jobs.subtitle"],
  moreView: ["page.more.title", "page.more.subtitle"],
  driversView: ["page.drivers.title", "page.drivers.subtitle"],
  profilesView: ["page.library.title", "page.library.subtitle"],
  auditView: ["page.audit.title", "page.audit.subtitle"],
  automationView: ["page.automation.title", "page.automation.subtitle"],
  adminView: ["page.admin.title", "page.admin.subtitle"],
  roadmapView: ["page.roadmap.title", "page.roadmap.subtitle"],
};

const FALLBACK_ACTIONS = {
  interface_cycle: { label: "Restart interface", category: "Interfaces", description: "Temporarily disable an interface, wait, then enable it again.", risk: "change", needsPort: true, needsDelay: true },
  poe_cycle: { label: "Restart PoE port", category: "Power over Ethernet", description: "Temporarily disable lanpower, wait, then enable it again.", risk: "change", needsPort: true, needsDelay: true },
  check_unp: { label: "Check UNP", category: "UNP", description: "Scan selected switches for GUEST with VOIP or IPTV on the same non-protected port without changing any interface.", risk: "read", liveReadOnly: true },
  fix_unp: { label: "Fix UNP", category: "UNP", description: "Detect GUEST with VOIP or IPTV on the same port and restart only affected interfaces.", risk: "change", needsDelay: true },
  vlan_port_maintenance: { label: "VLAN Port Maintenance", category: "Layer 2", description: "Discover access ports for a target VLAN, protect uplinks, then restart PoE or the interface.", risk: "change", needsDelay: true, needsVlanMaintenance: true },
  custom_command: { label: "Custom CLI console", category: "Advanced", description: "Run one or more manually entered AOS commands with preview and audit logging.", risk: "change", custom: true },
  custom_runbook: { label: "Custom Runbook", category: "Advanced", description: "Run a reusable CLI workflow with variables, approval, target limits and audit logging.", risk: "change", customRunbook: true },
  reload_switch: { label: "Reload switch", category: "System", description: "Safely restart a standalone switch from its working software directory.", risk: "change", contextualOnly: true },
  reload_stack_member: { label: "Reload stack member", category: "System", description: "Restart only the selected physical stack member.", risk: "change", needsSlot: true, contextualOnly: true },
};

function t(key, variables = {}, fallback = "") {
  return window.I18n?.t(key, variables, fallback) ?? fallback ?? key;
}

function actionMeta(action) {
  const base = state.catalog[action] || FALLBACK_ACTIONS[action] || {
    label: String(action || "").replaceAll("_", " "),
    category: "Other",
    description: "AOS command template. Availability depends on model, software release and enabled features.",
    risk: "read",
  };
  return {
    ...base,
    label: t(`actions.${action}.label`, {}, base.label),
    originalCategory: base.category,
    category: t(`actions.${action}.category`, {}, t(`categories.${base.category}`, {}, base.category)),
    description: t(`actions.${action}.description`, {}, base.description),
  };
}

const categoryOrder = ["System", "Diagnostics", "Interfaces", "Power over Ethernet", "UNP", "Layer 2", "Layer 3", "QoS and Policy", "Security", "Fabric and VC", "Configuration", "Advanced", "Other"];

function $(id) { return document.getElementById(id); }
function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
function setPlatformTimezone(value) {
  const requested = String(value || "UTC").trim() || "UTC";
  try {
    new Intl.DateTimeFormat("en-GB", { timeZone: requested }).format(new Date());
    state.platformTimezone = requested;
  } catch (_) {
    state.platformTimezone = "UTC";
  }
  document.documentElement.dataset.platformTimezone = state.platformTimezone;
}
function formatDate(value) {
  if (!value) return t("common.never", {}, "Never");
  const date = new Date(value);
  const locale = window.I18n?.locale || "en-GB";
  if (Number.isNaN(date.getTime())) return String(value);
  try { return date.toLocaleString(locale, { timeZone: state.platformTimezone || "UTC" }); }
  catch (_) { return date.toLocaleString(locale, { timeZone: "UTC" }); }
}
function platformDateKey(value) {
  const date = value ? new Date(value) : null;
  if (!date || Number.isNaN(date.getTime())) return "";
  try {
    const parts = new Intl.DateTimeFormat("en-GB", { timeZone: state.platformTimezone || "UTC", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
    const lookup = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${lookup.year}-${lookup.month}-${lookup.day}`;
  } catch (_) {
    return date.toISOString().slice(0, 10);
  }
}
function actionLabel(action) { return actionMeta(action).label; }
function statusBadge(status) {
  const normalized = String(status || "unknown").toLowerCase();
  const statusKey = normalized === "success" ? "successful" : normalized;
  const label = t(`status.${statusKey}`, {}, statusKey);
  return `<span class="status ${escapeHtml(normalized)}">${escapeHtml(label)}</span>`;
}
function connectionDetail(device) {
  const status = String(device.last_status || "unknown").toLowerCase();
  if (status === "online" && Number.isFinite(Number(device.response_ms))) {
    return `<span class="connection-detail">${Number(device.response_ms)} ms</span>`;
  }
  if (status === "offline" && device.last_error) {
    return `<span class="connection-detail error" title="${escapeHtml(device.last_error)}">${escapeHtml(device.last_error)}</span>`;
  }
  return `<span class="connection-detail">${escapeHtml(t("devices.awaitingCheck", {}, "Awaiting automatic check"))}</span>`;
}
function toast(message, type = "") {
  const el = document.createElement("div");
  el.className = `toast ${type}`.trim();
  el.textContent = message;
  $("toastContainer").appendChild(el);
  setTimeout(() => el.remove(), 4300);
}

async function api(path, options = {}) {
  const config = { credentials: "same-origin", cache: "no-store", ...options };
  if (config.body && !(config.body instanceof FormData) && typeof config.body !== "string") {
    config.headers = { "Content-Type": "application/json", ...(config.headers || {}) };
    config.body = JSON.stringify(config.body);
  }
  const response = await fetch(path, config);
  const serverRevision = response.headers.get("x-portivo-revision") || "";
  const uiRevision = String(window.PORTIVO_UI_REVISION || "");
  if (serverRevision && uiRevision && serverRevision !== uiRevision && sessionStorage.getItem("portivo-revision-reload") !== serverRevision) {
    sessionStorage.setItem("portivo-revision-reload", serverRevision);
    window.location.reload();
    throw new Error(`Portivo updated to ${serverRevision}; reloading interface`);
  }
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();
  if (!response.ok) {
    const detail = typeof data === "object" ? data.detail : data;
    const message = Array.isArray(detail) ? detail.map(item => item.msg).join(", ") : detail;
    if (response.status === 401 && path !== "/api/auth/login") showLogin();
    const error = new Error(message || `Request failed: ${response.status}`);
    error.status = response.status;
    error.payload = data;
    throw error;
  }
  return data;
}

async function apiWithTimeout(path, options = {}, timeoutMs = 60000) {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), Math.max(1000, Number(timeoutMs || 60000)));
  try {
    return await api(path, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === "AbortError") {
      const seconds = Math.max(1, Math.round(Number(timeoutMs || 60000) / 1000));
      throw new Error(`UPS telemetry request timed out after ${seconds} seconds.`);
    }
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
}

function initializeTheme() {
  const saved = localStorage.getItem("osc-theme");
  if (saved === "dark" || saved === "light") document.documentElement.dataset.theme = saved;
  else document.documentElement.dataset.theme = window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  updateThemeControls();
}
function updateThemeControls() {
  const isDark = document.documentElement.dataset.theme === "dark";
  const icon = isDark ? "#i-sun" : "#i-moon";
  const titleKey = isDark ? "theme.lightTitle" : "theme.darkTitle";
  for (const id of ["themeToggle", "loginThemeToggle"]) {
    const button = $(id);
    if (!button) continue;
    const use = button.querySelector("use");
    if (use) use.setAttribute("href", icon);
    button.title = t(titleKey, {}, isDark ? "Switch to light mode" : "Switch to dark mode");
    button.setAttribute("aria-label", button.title);
  }
}
function toggleTheme() {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("osc-theme", next);
  updateThemeControls();
}
function isBootstrapAdmin() { return state.user?.auth_type === "admin"; }
function isSshUser() { return state.user?.auth_type === "ssh"; }
function isPlatformAdmin() { return Boolean(state.user?.permissions?.admin_panel); }
function canManageInventory() { return Boolean(state.user?.permissions?.manage_inventory); }
function canExecuteChanges() { return Boolean(state.user?.permissions?.execute_changes); }
function canUseTerminal() { return Boolean(state.user?.permissions?.use_terminal); }
function isReadOnlyUser() { return Boolean(state.user?.permissions?.read_only); }
function hasCapability(capability) {
  const caps = state.user?.permissions?.capabilities || [];
  return caps.includes("*") || caps.includes(capability);
}
function allowedActionIds() { return new Set(state.user?.permissions?.allowed_actions || []); }
function actionAllowedForCurrentUser(action) { return allowedActionIds().has(String(action || "")); }
function scopeSummary(scope = state.user?.permissions?.scope || {}) {
  if (scope.global || scope.mode === "all") return t("access.allSites", {}, "All Sites");
  if (scope.mode !== "selected") return t("access.noScope", {}, "No access scope");
  const sites = Array.isArray(scope.sites) ? scope.sites : [];
  const groups = Array.isArray(scope.groups) ? scope.groups : [];
  if (!groups.length) return sites.length === 1 ? sites[0] : t("access.siteCount", { count: sites.length }, `${sites.length} Sites`);
  return `${sites.length} ${sites.length === 1 ? "Site" : "Sites"} · ${groups.length} ${groups.length === 1 ? "Group" : "Groups"}`;
}
const VIEW_CAPABILITIES = {
  dashboardView: "dashboard.view", devicesView: "devices.view", powerView: "power.view", finderView: "finder.use",
  deviceWorkspaceView: "devices.live_ports", bulkView: "operations.view", auditsView: "audits.view",
  notificationsView: "notifications.view", activityView: "activity.jobs", profilesView: "command_library.view",
  moreView: null, driversView: "drivers.view",
  automationView: "__admin__", adminView: "__admin__", roadmapView: null,
};
function viewAllowed(viewId) {
  if (viewId === "moreView") return true;
  const capability = VIEW_CAPABILITIES[viewId];
  if (!capability) return true;
  if (capability === "__admin__") return isPlatformAdmin();
  if (viewId === "activityView") return hasCapability("activity.jobs") || hasCapability("activity.audit");
  return hasCapability(capability);
}
function applyAccessVisibility() {
  document.querySelectorAll(".nav-item[data-view]").forEach(button => button.classList.toggle("hidden", !viewAllowed(button.dataset.view)));
  document.querySelectorAll(".admin-only").forEach(element => element.classList.toggle("hidden", !isPlatformAdmin()));
  document.querySelectorAll(".power-capability-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.view")));
  document.querySelectorAll(".power-create-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.create")));
  document.querySelectorAll(".power-edit-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.edit")));
  document.querySelectorAll(".power-delete-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.delete")));
  document.querySelectorAll(".power-verify-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.verify")));
  document.querySelectorAll(".power-assign-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.assign")));
  document.querySelectorAll(".command-library-capability").forEach(element => element.classList.toggle("hidden", !hasCapability("command_library.view")));
  document.querySelectorAll(".drivers-capability").forEach(element => element.classList.toggle("hidden", !hasCapability("drivers.view")));
  document.querySelectorAll(".bootstrap-admin-only").forEach(element => element.classList.toggle("hidden", !isBootstrapAdmin()));
  const auditTab = document.querySelector('[data-activity-tab="audit"]');
  const jobsTab = document.querySelector('[data-activity-tab="jobs"]');
  if (auditTab) auditTab.classList.toggle("hidden", !hasCapability("activity.audit"));
  if (jobsTab) jobsTab.classList.toggle("hidden", !hasCapability("activity.jobs"));
  if (state.activityTab === "audit" && !hasCapability("activity.audit")) state.activityTab = "jobs";
  if (state.activityTab === "jobs" && !hasCapability("activity.jobs") && hasCapability("activity.audit")) state.activityTab = "audit";
  document.querySelectorAll("[data-requires-terminal]").forEach(element => element.classList.toggle("hidden", !canUseTerminal()));
  const scopeWarning = $("accessScopeWarning");
  const scope = state.user?.permissions?.scope || {};
  if (scopeWarning) scopeWarning.classList.toggle("hidden", !state.user || !scope.required || scope.mode !== "none");
}
function applyPasswordPolicy(policy = {}) {
  const minLength = Math.max(1, Number(policy.min_length || 12));
  const maxLength = Math.max(minLength, Number(policy.max_length || 128));
  state.passwordPolicy = { min_length: minLength, max_length: maxLength };
  const input = $("newPassword");
  if (input) {
    input.minLength = minLength;
    input.maxLength = maxLength;
  }
  const description = $("passwordPolicyDescription");
  if (description) description.textContent = t("password.description", { min: minLength }, `Use at least ${minLength} characters.`);
}

async function initializeLanguage() {
  let preferred = localStorage.getItem("osc-language");
  if (!preferred) {
    try {
      const status = await api("/api/auth/bootstrap-status");
      applyPasswordPolicy(status.password_policy || {});
      setPlatformTimezone(status.platform_timezone || "UTC");
      preferred = status.default_language || navigator.language || "en";
    } catch (_) {
      preferred = navigator.language || "en";
    }
  }
  await window.I18n.setLanguage(preferred);
  updateLanguageControls();
}
function languageOptionsMarkup() {
  const languages = Array.isArray(window.I18n?.languages) ? window.I18n.languages : [];
  return languages.map(item => `<option value="${escapeHtml(item.code)}">${escapeHtml(item.label)}</option>`).join("");
}
function languageMenuMarkup() {
  const languages = Array.isArray(window.I18n?.languages) ? window.I18n.languages : [];
  const active = window.I18n?.language || "en";
  return languages.map(item => {
    const selected = item.code === active;
    const code = String(item.code || "").toUpperCase();
    return `<button class="language-option${selected ? " selected" : ""}" data-language-option="${escapeHtml(item.code)}" role="option" aria-selected="${selected ? "true" : "false"}" type="button"><span class="language-option-code">${escapeHtml(code)}</span><span class="language-option-label">${escapeHtml(item.label)}</span><span class="language-option-check" aria-hidden="true">${selected ? "✓" : ""}</span></button>`;
  }).join("");
}
function closeLanguageMenus(except = null) {
  document.querySelectorAll("[data-language-menu]").forEach(menu => {
    if (menu === except) return;
    menu.classList.remove("open");
    menu.querySelector("[data-language-trigger]")?.setAttribute("aria-expanded", "false");
    const popover = menu.querySelector("[data-language-options]");
    if (popover) popover.hidden = true;
  });
}
function toggleLanguageMenu(menu) {
  if (!menu) return;
  const opening = !menu.classList.contains("open");
  closeLanguageMenus(opening ? menu : null);
  const trigger = menu.querySelector("[data-language-trigger]");
  const popover = menu.querySelector("[data-language-options]");
  menu.classList.toggle("open", opening);
  trigger?.setAttribute("aria-expanded", opening ? "true" : "false");
  if (popover) popover.hidden = !opening;
}
function updateLanguageControls() {
  const languages = Array.isArray(window.I18n?.languages) ? window.I18n.languages : [];
  const active = languages.find(item => item.code === window.I18n.language) || languages[0] || { code: "en", label: "English" };
  const menuMarkup = languageMenuMarkup();
  document.querySelectorAll("[data-language-menu]").forEach(menu => {
    const code = menu.querySelector("[data-language-code]");
    const label = menu.querySelector("[data-language-current]");
    const options = menu.querySelector("[data-language-options]");
    if (code) code.textContent = String(active.code || "").toUpperCase();
    if (label) label.textContent = active.label || active.code;
    if (options) options.innerHTML = menuMarkup;
  });
  const markup = languageOptionsMarkup();
  const adminSelect = $("adminDefaultLanguage");
  if (adminSelect && markup && adminSelect.dataset.languageOptionsReady !== "1") {
    const current = adminSelect.value || state.adminSettings?.default_language || window.I18n.language;
    adminSelect.innerHTML = markup;
    adminSelect.dataset.languageOptionsReady = "1";
    adminSelect.value = window.I18n.supported.includes(current) ? current : window.I18n.language;
  }
  closeLanguageMenus();
}
async function changeLanguage(language) {
  await window.I18n.setLanguage(language);
  updateLanguageControls();
  updateThemeControls();
  setLoginMode($("loginMode")?.value || "ssh");
  if (state.user) {
    setSessionUser(state.user);
    const activeView = document.querySelector(".view.active")?.id || "dashboardView";
    const [titleKey, subtitleKey] = pageMeta[activeView] || pageMeta.dashboardView;
    $("pageTitle").textContent = t(titleKey);
    $("pageSubtitle").textContent = t(subtitleKey);
    syncCascadingFilterOptions("device");
    syncCascadingFilterOptions("bulk");
    syncCascadingFilterOptions("finder");
    renderDevices();
    renderDashboardDevices();
    renderBulkTargets();
    renderFinderScope();
    renderFinderResult(state.finderResult);
    updateBulkSummary();
    renderActionOptions($("commandSearch")?.value || "");
    renderWorkspaceActionOptions($("workspaceCommandSearch")?.value || "");
    updateActionContext();
    renderRunbookSelect();
    renderRunbookLibrary();
    updateWorkspaceActionContext();
    renderWorkspacePorts();
    renderProfiles();
    if ($("commandPaletteDialog")?.open) renderCommandPalette();
    if (activeView === "activityView") {
      if (activeActivityTab() === "audit") loadAudit();
      else loadJobs();
    }
    if (activeView === "jobsView") loadJobs();
    if (activeView === "auditView") loadAudit();
    if (activeView === "automationView" && isPlatformAdmin()) loadAutomationCenter();
    if (activeView === "adminView" && isPlatformAdmin()) loadAdminPanel();
  }
}

function setSessionUser(session) {
  state.user = session?.authenticated === false ? null : session || null;
  $("currentUser").textContent = state.user?.display_name || state.user?.username || t("common.unknown", {}, "Not signed in");
  $("currentAuthType").textContent = isBootstrapAdmin() ? t("session.admin", {}, "LOCAL BOOTSTRAP ADMIN") : t("session.ssh", {}, "PERSONAL SSH SESSION");
  const roleKey = isBootstrapAdmin() ? "admin" : String(state.user?.role || "read_only");
  const roleFallbacks = { admin: "Administrator", power_user: "Power User", site_admin: "Site Administrator", operator: "Operator", helpdesk: "Helpdesk", read_only: "Read Only" };
  const roleName = t(`roles.${roleKey}`, {}, state.user?.role_name || roleFallbacks[roleKey] || roleKey.replaceAll("_", " "));
  const scope = state.user?.permissions?.scope || {};
  $("currentRole").textContent = scope.global || scope.mode === "all" ? roleName : `${roleName} · ${scopeSummary(scope)}`;
  applyAccessVisibility();
  for (const element of [$("addDeviceButton"), ...document.querySelectorAll("a[href='/api/devices/template'], label.upload-label")]) {
    if (element) element.classList.toggle("hidden", !canManageInventory());
  }
  document.body.classList.toggle("read-only-session", isReadOnlyUser());
  renderActionOptions($("commandSearch")?.value || "");
  renderWorkspaceActionOptions($("workspaceCommandSearch")?.value || "");
}

function setLoginMode(mode) {
  const sshMode = mode !== "admin";
  $("loginMode").value = sshMode ? "ssh" : "admin";
  $("sshLoginMode").classList.toggle("active", sshMode);
  $("adminLoginMode").classList.toggle("active", !sshMode);
  $("loginKicker").textContent = t(sshMode ? "login.sshKicker" : "login.adminKicker");
  $("loginTitle").textContent = t(sshMode ? "login.sshTitle" : "login.adminTitle");
  $("loginDescription").textContent = t(sshMode ? "login.sshDescription" : "login.adminDescription");
  $("loginUsername").placeholder = t(sshMode ? "login.sshUsernamePlaceholder" : "login.adminUsernamePlaceholder");
  $("loginPassword").placeholder = t(sshMode ? "login.sshPasswordPlaceholder" : "login.adminPasswordPlaceholder");
  if (!sshMode && !$("loginUsername").value.trim()) $("loginUsername").value = "admin";
}

async function configureLoginMode() {
  try {
    const status = await api("/api/auth/bootstrap-status");
    applyPasswordPolicy(status.password_policy || {});
    setPlatformTimezone(status.platform_timezone || state.platformTimezone || "UTC");
    $("sshLoginMode").disabled = !status.ssh_login_available;
    if (!localStorage.getItem("osc-language") && status.default_language && status.default_language !== window.I18n.language) {
      await window.I18n.setLanguage(status.default_language);
      updateLanguageControls();
      updateThemeControls();
    }
    setLoginMode(status.default_mode);
  } catch (_) {
    setLoginMode("admin");
  }
}
function showLogin(message = "") {
  clearFinderPolling();
  setSessionUser(null);
  $("appShell").classList.add("hidden");
  $("loginScreen").classList.remove("hidden");
  $("loginError").textContent = message;
  if (state.refreshTimer) { clearInterval(state.refreshTimer); state.refreshTimer = null; }
  if (state.healthRefreshTimer) { clearInterval(state.healthRefreshTimer); state.healthRefreshTimer = null; }
  configureLoginMode().finally(() => setTimeout(() => $("loginUsername").focus(), 20));
}
async function enterApp(session) {
  // User-scoped caches must never survive a new authentication context.
  state.devices = [];
  state.devicesLoadedAt = 0;
  state.devicesRequest = null;
  state.dashboardSwitchAttention = [];
  state.dashboardPowerAttention = [];
  state.adminOverview = null;
  state.adminSettings = null;
  state.adminSessions = [];
  state.adminUsers = [];
  state.adminAccessControl = { roles: [], capabilities: [], actions: [], sites: [], groups: [] };
  state.monitoringProfiles = [];
  state.monitoringVerificationTargets = [];
  state.adminLoadGeneration += 1;
  setSessionUser(session);
  $("loginScreen").classList.add("hidden");
  $("appShell").classList.remove("hidden");
  applyAccessVisibility();
  const active = document.querySelector(".view.active")?.id || "dashboardView";
  if (!viewAllowed(active)) switchView(viewAllowed("dashboardView") ? "dashboardView" : (viewAllowed("devicesView") ? "devicesView" : "roadmapView"));

  // First paint is intentionally small. The dashboard summary and notification
  // badge are enough to make the shell useful; fleet inventory is warmed after
  // the browser has had a chance to paint instead of blocking login.
  const firstPaintTasks = [];
  if (hasCapability("dashboard.view")) firstPaintTasks.push(loadDashboard());
  if (hasCapability("notifications.view")) firstPaintTasks.push(loadNotificationBadge());
  try { await Promise.all(firstPaintTasks); } catch (_) {}

  const warmInventory = () => {
    if (!hasCapability("devices.view")) return;
    loadDevices({ render: false }).catch(() => {});
  };
  if (typeof window.requestIdleCallback === "function") window.requestIdleCallback(warmInventory, { timeout: 1800 });
  else setTimeout(warmInventory, 250);

  if (!state.refreshTimer) {
    state.refreshTimer = setInterval(async () => {
      const activeView = document.querySelector(".view.active")?.id;
      try {
        if (activeView === "dashboardView" && hasCapability("dashboard.view")) await loadDashboard();
        else if ((activeView === "activityView" && activeActivityTab() === "jobs") || activeView === "jobsView") await loadJobs();
      } catch (_) {}
    }, 10000);
  }
  if (!state.healthRefreshTimer) {
    state.healthRefreshTimer = setInterval(async () => {
      const activeView = document.querySelector(".view.active")?.id;
      const tasks = [];
      if (["devicesView", "finderView", "bulkView"].includes(activeView) && hasCapability("devices.view")) tasks.push(loadDevices({ force: true }));
      if (["devicesView", "finderView", "bulkView", "deviceWorkspaceView"].includes(activeView) && hasCapability("devices.view")) tasks.push(loadPendingConfiguration());
      if (activeView === "dashboardView" && hasCapability("dashboard.view")) tasks.push(loadDashboard());
      if (hasCapability("notifications.view")) tasks.push(loadNotificationBadge());
      try { await Promise.all(tasks); } catch (_) {}
    }, 30000);
  }
  if (session.must_change_password) {
    toast(t("password.description", {}, "Change the default administrator password from the account menu."), "error");
  }
}
async function login(event) {
  event.preventDefault();
  const button = $("loginButton");
  $("loginError").textContent = "";
  button.disabled = true;
  button.textContent = t("login.signingIn", {}, "Signing in...");
  try {
    const result = await api("/api/auth/login", {
      method: "POST",
      body: { username: $("loginUsername").value.trim(), password: $("loginPassword").value, mode: $("loginMode").value },
    });
    $("loginPassword").value = "";
    await enterApp(result);
  } catch (error) {
    $("loginError").textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = t("login.signIn", {}, "Sign in");
  }
}
async function logout() {
  disconnectWorkspaceTerminal(true);
  try { await api("/api/auth/logout", { method: "POST" }); } catch (_) {}
  showLogin();
}
function toggleLoginPassword() {
  const input = $("loginPassword");
  const showing = input.type === "text";
  input.type = showing ? "password" : "text";
  $("loginPasswordToggle").setAttribute("aria-label", t(showing ? "login.showPassword" : "login.hidePassword"));
}

async function init() {
  initializeTheme();
  await initializeLanguage();
  renderActionOptions();
  bindEvents();
  updateActionContext();
  try {
    const session = await api("/api/auth/me");
    if (session.authenticated) await enterApp(session);
    else showLogin();
  } catch (error) {
    showLogin(error.message);
  }
}

function bindEvents() {
  $("loginForm").addEventListener("submit", login);
  document.querySelectorAll("[data-language-trigger]").forEach(trigger => trigger.addEventListener("click", event => {
    event.stopPropagation();
    toggleLanguageMenu(trigger.closest("[data-language-menu]"));
  }));
  document.querySelectorAll("[data-language-menu]").forEach(menu => menu.addEventListener("click", event => {
    const option = event.target.closest("[data-language-option]");
    if (!option) return;
    event.stopPropagation();
    closeLanguageMenus();
    changeLanguage(option.dataset.languageOption);
  }));
  document.addEventListener("click", event => { if (!event.target.closest("[data-language-menu]")) closeLanguageMenus(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape") closeLanguageMenus(); });
  $("loginThemeToggle").addEventListener("click", toggleTheme);
  $("loginPasswordToggle").addEventListener("click", toggleLoginPassword);
  $("sshLoginMode").addEventListener("click", () => setLoginMode("ssh"));
  $("adminLoginMode").addEventListener("click", () => setLoginMode("admin"));
  $("logoutButton").addEventListener("click", logout);
  $("themeToggle").addEventListener("click", toggleTheme);
  $("commandPaletteButton")?.addEventListener("click", openCommandPalette);
  $("commandPaletteInput")?.addEventListener("input", () => { state.commandPaletteIndex = 0; renderCommandPalette(); });
  $("commandPaletteInput")?.addEventListener("keydown", handleCommandPaletteKeydown);
  $("commandPaletteDialog")?.addEventListener("click", event => { if (event.target === $("commandPaletteDialog")) closeCommandPalette(); });
  document.addEventListener("keydown", handleGlobalCommandPaletteShortcut);
  $("pendingConfigButton")?.addEventListener("click", openPendingConfigDialog);
  $("saveAllPendingConfig")?.addEventListener("click", saveAllPendingConfiguration);
  $("addDeviceButton").addEventListener("click", () => openDeviceModal());
  $("addUpsButton")?.addEventListener("click", () => openUpsDialog());
  $("powerScanButton")?.addEventListener("click", runPowerScan);
  $("powerIncidentsJump")?.addEventListener("click", () => {
    $("powerIncidentsPanel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  bindPowerMetricCard("powerMetricTotalCard", () => showAllPowerUps());
  bindPowerMetricCard("powerMetricNormalCard", () => filterPowerUpsByHealth("normal"));
  bindPowerMetricCard("powerMetricBatteryCard", () => filterPowerUpsByHealth("on_battery"));
  bindPowerMetricCard("powerMetricCriticalCard", () => filterPowerUpsByHealth("critical"));
  bindPowerMetricCard("powerMetricOfflineCard", () => filterPowerUpsByHealth("offline"));
  bindPowerMetricCard("powerMetricProtectedCard", () => filterPowerUpsByMetric("protected"));
  $("powerUpsSearch")?.addEventListener("input", () => { if (state.power) state.power.inventoryMetricFilter = ""; renderPowerInfrastructure(); });
  for (const id of ["powerUpsSiteFilter", "powerUpsHealthFilter", "powerUpsDriverFilter"]) $(id)?.addEventListener("change", () => { if (state.power) state.power.inventoryMetricFilter = ""; renderPowerInfrastructure(); });
  $("clearPowerUpsFilters")?.addEventListener("click", clearPowerUpsFilters);
  $("powerIncidentSearch")?.addEventListener("input", schedulePowerIncidentReload);
  for (const id of ["powerIncidentStatusFilter", "powerIncidentTypeFilter", "powerIncidentUpsFilter"]) $(id)?.addEventListener("change", () => loadPowerIncidents({ resetPage: true }));
  $("clearPowerIncidentFilters")?.addEventListener("click", clearPowerIncidentFilters);
  $("powerIncidentPrevPage")?.addEventListener("click", () => changePowerIncidentPage(-1));
  $("powerIncidentNextPage")?.addEventListener("click", () => changePowerIncidentPage(1));
  $("upsForm")?.addEventListener("submit", saveUps);
  $("upsVerifyButton")?.addEventListener("click", verifyUpsDialog);
  $("upsDetailsRefresh")?.addEventListener("click", () => refreshUpsDetails(state.powerDetailsUpsId));
  $("upsDriverMode")?.addEventListener("change", () => {
    resetUpsDetected(null);
    if ($("upsVerifySummary")) $("upsVerifySummary").textContent = t("power.verifyHelp", {}, "Verify manufacturer, model, battery and output source before saving.");
  });
  $("upsAssignmentForm")?.addEventListener("submit", saveUpsAssignments);
  $("upsAssignmentSearch")?.addEventListener("input", renderUpsAssignmentGrid);
  $("devicePowerSource")?.addEventListener("change", updateDevicePowerSourceUi);
  $("deviceSite")?.addEventListener("input", () => populateDevicePowerSources($("devicePowerSource")?.value || null));
  $("deviceForm").addEventListener("submit", saveDevice);
  $("deviceHealthMode")?.addEventListener("change", () => updateDeviceHealthMonitorUi(state.devices.find(item => item.id === Number($("deviceId")?.value || 0)) || null));
  $("deviceHealthProfile")?.addEventListener("change", () => updateDeviceHealthMonitorUi(state.devices.find(item => item.id === Number($("deviceId")?.value || 0)) || null));
  $("deviceStackMonitorEnabled")?.addEventListener("change", () => updateDeviceStackMonitorUi(state.devices.find(item => item.id === Number($("deviceId")?.value || 0)) || null));
  $("deviceStackMethod")?.addEventListener("change", () => { populateDeviceStackProfiles(); updateDeviceStackMonitorUi(state.devices.find(item => item.id === Number($("deviceId")?.value || 0)) || null); });
  $("deviceStackRelearn")?.addEventListener("click", relearnCurrentDeviceStack);
  $("addMonitoringProfileButton")?.addEventListener("click", () => openMonitoringProfileDialog());
  $("monitoringProfileMethod")?.addEventListener("change", () => { syncMonitoringProfileMethodUi(); populateMonitoringVerifyTargets(); });
  $("monitoringProfileForm")?.addEventListener("submit", saveMonitoringProfile);
  for (const [id, key] of [["monitoringSshPassword", "ssh"], ["monitoringSnmpAuthPassword", "auth"], ["monitoringSnmpPrivPassword", "priv"]]) {
    $(id)?.addEventListener("keydown", () => { state.monitoringSecretDirty[key] = true; });
    $(id)?.addEventListener("paste", () => { state.monitoringSecretDirty[key] = true; });
  }
  $("deviceSearch").addEventListener("input", () => handleInventoryFilterChange("device"));
  for (const id of ["deviceSiteFilter", "deviceGroupFilter", "deviceModelFilter", "deviceStatusFilter", "deviceProfileFilter"]) $(id).addEventListener("change", () => handleInventoryFilterChange("device"));
  $("clearDeviceFilters").addEventListener("click", () => clearInventoryFilters("device"));
  $("finderQuery").addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); startDeviceFinderSearch(); } });
  $("finderSearchButton").addEventListener("click", startDeviceFinderSearch);
  $("finderDeviceSearch").addEventListener("input", () => handleInventoryFilterChange("finder"));
  for (const id of ["finderSiteFilter", "finderGroupFilter", "finderModelFilter", "finderStatusFilter", "finderProfileFilter"]) $(id).addEventListener("change", () => handleInventoryFilterChange("finder"));
  $("clearFinderFilters").addEventListener("click", () => clearInventoryFilters("finder"));
  $("finderClearResults").addEventListener("click", clearFinderResults);
  document.querySelectorAll("[data-device-sort]").forEach(button => button.addEventListener("click", () => setDeviceSort(button.dataset.deviceSort)));
  $("deviceDetectButton").addEventListener("click", () => detectDevice(true));
  for (const id of ["deviceHost", "deviceSshPort", "deviceProfile", "deviceVerificationUsername", "deviceVerificationPassword"]) $(id).addEventListener("input", scheduleDeviceDetection);
  $("workspaceBackButton").addEventListener("click", () => switchView("devicesView"));
  $("workspaceRefreshPorts").addEventListener("click", () => loadWorkspacePorts(true));
  $("workspaceOpenBulk").addEventListener("click", openWorkspaceInBulk);
  $("workspacePortSearch").addEventListener("input", renderWorkspacePorts);
  $("workspacePortStatus").addEventListener("change", renderWorkspacePorts);
  $("workspaceClearPortFilters").addEventListener("click", clearWorkspacePortFilters);
  document.querySelectorAll("[data-port-view]").forEach(button => button.addEventListener("click", () => setWorkspacePortView(button.dataset.portView)));
  document.querySelectorAll("[data-port-filter]").forEach(button => button.addEventListener("click", () => applyWorkspacePortFilter(button.dataset.portFilter)));
  $("workspaceSavePortAlias").addEventListener("click", saveWorkspacePortAlias);
  $("workspaceDiagnosePort")?.addEventListener("click", runWorkspacePortDiagnosis);
  $("workspaceUsePortCommand").addEventListener("click", useWorkspacePortInCommandCenter);
  document.querySelectorAll("[data-detail-action]").forEach(button => button.addEventListener("click", () => runActiveWorkspacePortAction(button.dataset.detailAction)));
  $("workspaceCommandSearch").addEventListener("input", event => renderWorkspaceActionOptions(event.target.value));
  $("workspaceAction").addEventListener("change", updateWorkspaceActionContext);
  for (const id of ["workspacePort", "workspaceSlot", "workspaceAlias", "workspaceDelay", "workspaceCustom"]) $(id).addEventListener("input", clearWorkspacePreview);
  $("workspaceDryRun").addEventListener("change", clearWorkspacePreview);
  $("workspacePreviewButton").addEventListener("click", previewWorkspaceOperation);
  $("workspaceExecuteButton").addEventListener("click", executeWorkspaceOperation);
  $("workspaceTerminalConnect").addEventListener("click", connectWorkspaceTerminal);
  $("workspaceTerminalDisconnect").addEventListener("click", () => disconnectWorkspaceTerminal(false));
  $("workspaceTerminalClear").addEventListener("click", clearWorkspaceTerminal);
  $("workspaceTerminalForm").addEventListener("submit", event => event.preventDefault());
  $("workspaceTerminalInput").addEventListener("keydown", handleWorkspaceTerminalKeydown);
  $("workspaceTerminalInput").addEventListener("paste", handleWorkspaceTerminalPaste);
  $("workspaceTerminalOutput").addEventListener("click", focusWorkspaceTerminal);
  $("workspaceTerminalCard").addEventListener("click", event => {
    if (!event.target.closest("button")) focusWorkspaceTerminal();
  });
  $("bulkDeviceSearch").addEventListener("input", () => handleInventoryFilterChange("bulk"));
  for (const id of ["bulkSiteFilter", "bulkGroupFilter", "bulkModelFilter", "bulkStatusFilter", "bulkProfileFilter"]) $(id).addEventListener("change", () => handleInventoryFilterChange("bulk"));
  $("commandSearch").addEventListener("input", event => renderActionOptions(event.target.value));
  $("profileSearch").addEventListener("input", renderProfiles);
  $("bulkAction").addEventListener("change", () => { updateActionContext(); updateBulkSummary(); clearPreview(); });
  $("bulkPort").addEventListener("input", handleBulkDefaultChange);
  $("bulkSlot").addEventListener("input", handleBulkDefaultChange);
  $("portAlias").addEventListener("input", () => { updateBulkSummary(); clearPreview(); });
  $("cycleDelay").addEventListener("input", () => { updateBulkSummary(); clearPreview(); });
  $("bulkTargetVlan")?.addEventListener("input", () => { updateBulkSummary(); clearPreview(); });
  $("bulkVlanOperation")?.addEventListener("change", () => { updateBulkSummary(); clearPreview(); });
  $("customCommand").addEventListener("input", () => { updateBulkSummary(); clearPreview(); });
  $("dryRun").addEventListener("change", updateBulkSummary);
  $("previewButton").addEventListener("click", previewOperation);
  $("executeButton").addEventListener("click", prepareExecution);
  $("confirmForm").addEventListener("submit", confirmExecution);
  $("workspaceReloadForm")?.addEventListener("submit", confirmWorkspaceReload);
  $("workspaceReloadDialog")?.addEventListener("close", () => { state.workspacePendingReload = null; });
  $("selectAllFiltered").addEventListener("click", selectAllFiltered);
  $("clearSelection").addEventListener("click", clearSelection);
  $("clearPreview").addEventListener("click", clearPreview);
  $("auditDeviceSearch")?.addEventListener("input", renderFleetAuditScope);
  for (const id of ["auditSiteFilter", "auditGroupFilter", "auditModelFilter", "auditStatusFilter", "auditProfileFilter"]) $(id)?.addEventListener("change", renderFleetAuditScope);
  $("auditSelectFiltered")?.addEventListener("click", selectFilteredAuditDevices);
  $("auditClearSelection")?.addEventListener("click", clearFleetAuditSelection);
  $("fleetAuditExport")?.addEventListener("click", exportCurrentFleetAudit);
  $("jobExportPdfButton")?.addEventListener("click", () => { if (state.currentJobId) downloadJobPdf(state.currentJobId); });
  $("jobsSearch")?.addEventListener("input", () => { resetActivityHistoryPage("jobs"); scheduleHistoryFilter("jobs"); });
  for (const id of ["jobsStatusFilter", "jobsActionFilter", "jobsModeFilter", "jobsSourceFilter", "jobsDateFrom", "jobsDateTo"]) $(id)?.addEventListener("change", () => { resetActivityHistoryPage("jobs"); loadJobs(); });
  $("jobsPageSize")?.addEventListener("change", event => { state.activityHistoryUi.jobsPageSize = Number(event.target.value || 25); resetActivityHistoryPage("jobs"); loadJobs(); });
  $("jobsPrevPage")?.addEventListener("click", () => changeActivityHistoryPage("jobs", -1));
  $("jobsNextPage")?.addEventListener("click", () => changeActivityHistoryPage("jobs", 1));
  $("clearJobsFilters")?.addEventListener("click", clearJobsFilters);
  $("auditSearch")?.addEventListener("input", () => { resetActivityHistoryPage("audit"); scheduleHistoryFilter("audit"); });
  for (const id of ["auditActorFilter", "auditEventFilter", "auditObjectTypeFilter", "auditDateFrom", "auditDateTo"]) $(id)?.addEventListener("change", () => { resetActivityHistoryPage("audit"); loadAudit(); });
  $("auditPageSize")?.addEventListener("change", event => { state.activityHistoryUi.auditPageSize = Number(event.target.value || 25); resetActivityHistoryPage("audit"); loadAudit(); });
  $("auditPrevPage")?.addEventListener("click", () => changeActivityHistoryPage("audit", -1));
  $("auditNextPage")?.addEventListener("click", () => changeActivityHistoryPage("audit", 1));
  $("clearAuditFilters")?.addEventListener("click", clearAuditFilters);
  $("deviceImport").addEventListener("change", importDevices);
  $("changePasswordButton").addEventListener("click", () => { if (!isBootstrapAdmin()) return; $("passwordForm").reset(); $("passwordFormError").textContent = ""; applyPasswordPolicy(state.passwordPolicy); $("passwordDialog").showModal(); });
  $("passwordForm").addEventListener("submit", changePassword);
  $("adminSettingsForm")?.addEventListener("submit", saveAdminSettings);
  document.querySelectorAll('input[name="adminMonitoringMode"]').forEach(input => input.addEventListener("change", syncAdminMonitoringModeUi));
  $("adminMonitorSwitchAvailability")?.addEventListener("change", syncAdminMonitoringModeUi);
  $("adminSaveAuthSources")?.addEventListener("click", saveAuthenticationSources);
  for (const id of ["adminAuthSource1", "adminAuthSource2", "adminAuthSource3", "adminAuthSource4", "adminAuthSource5"]) $(id)?.addEventListener("change", renderAuthenticationPathPreview);
  $("manageAccessRolesButton")?.addEventListener("click", openAccessRoleLibrary);
  $("userAccessForm")?.addEventListener("submit", saveUserAccess);
  $("userAccessRole")?.addEventListener("change", syncUserAccessScopeUi);
  $("userAccessSites")?.addEventListener("change", () => { populateUserAccessGroups(); syncUserAccessScopeUi(); });
  $("userAccessGroups")?.addEventListener("change", () => renderUserAccessScopePicker("userAccessGroups", "userAccessGroupsPicker", "userAccessGroupsCount"));
  $("userAccessSitesPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "userAccessSites"));
  $("userAccessGroupsPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "userAccessGroups"));
  document.querySelectorAll('input[name="userAccessScopeMode"]').forEach(input => input.addEventListener("change", syncUserAccessScopeUi));
  $("newCustomRoleButton")?.addEventListener("click", startNewCustomRole);
  $("saveCustomRoleButton")?.addEventListener("click", saveCustomAccessRole);
  $("deleteCustomRoleButton")?.addEventListener("click", deleteCustomAccessRole);
  $("accessActionSearch")?.addEventListener("input", () => renderAccessActionGrid());
  $("automationCredentialSave")?.addEventListener("click", saveAutomationCredential);
  $("automationCredentialRemove")?.addEventListener("click", removeAutomationCredential);
  $("automationNewScheduleButton")?.addEventListener("click", () => openAutomationScheduleDialog());
  $("automationNewScheduleSecondary")?.addEventListener("click", () => openAutomationScheduleDialog());
  $("automationRunbookLibraryButton")?.addEventListener("click", openRunbookLibrary);
  $("automationScheduleForm")?.addEventListener("submit", saveAutomationSchedule);
  $("automationScheduleAction")?.addEventListener("change", renderAutomationActionSettings);
  $("automationScheduleSites")?.addEventListener("change", () => populateAutomationScopeOptions(selectedOptionValues($("automationScheduleSites")), selectedOptionValues($("automationScheduleGroups"))));
  $("automationScheduleGroups")?.addEventListener("change", () => renderUserAccessScopePicker("automationScheduleGroups", "automationScheduleGroupsPicker", "automationScheduleGroupsCount"));
  $("automationScheduleSitesPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "automationScheduleSites"));
  $("automationScheduleGroupsPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "automationScheduleGroups"));
  $("automationScheduleSafeguardButton")?.addEventListener("click", openSelectedAutomationSafeguard);
  $("bulkRunbook")?.addEventListener("change", () => { renderSelectedRunbook(); updateActionContext(); updateBulkSummary(); clearPreview(); });
  $("openRunbookLibrary")?.addEventListener("click", openRunbookLibrary);
  $("runbookForm")?.addEventListener("submit", saveRunbookForm);
  $("newRunbookButton")?.addEventListener("click", () => editRunbook(null));
  $("addRunbookVariable")?.addEventListener("click", () => addRunbookVariableRow());
  $("addRunbookStep")?.addEventListener("click", () => addRunbookStepRow());
  $("approveRunbookButton")?.addEventListener("click", approveCurrentRunbook);
  $("deleteRunbookButton")?.addEventListener("click", deleteCurrentRunbook);
  $("duplicateRunbookButton")?.addEventListener("click", duplicateCurrentRunbook);
  $("fixUnpSafeguardsForm")?.addEventListener("submit", saveFixUnpSafeguards);
  $("vlanMaintenanceSafeguardsForm")?.addEventListener("submit", saveVlanMaintenanceSafeguards);
  $("notificationPolicyForm")?.addEventListener("submit", saveNotificationPolicy);
  $("notificationAddDestination")?.addEventListener("click", () => openNotificationDestinationDialog());
  $("notificationDestinationForm")?.addEventListener("submit", saveNotificationDestination);
  $("notificationProvider")?.addEventListener("change", updateNotificationProviderHelp);
  $("notificationDeliverySearch")?.addEventListener("input", () => { state.notificationHistoryUi.deliveriesPage = 1; renderNotificationDeliveries(); });
  for (const id of ["notificationDeliveryEvent", "notificationDeliveryProvider", "notificationDeliveryStatusFilter", "notificationDeliveryDestination", "notificationDeliveryDateFrom", "notificationDeliveryDateTo", "notificationDeliveryPageSize"]) {
    $(id)?.addEventListener("change", () => { state.notificationHistoryUi.deliveriesPage = 1; if (id === "notificationDeliveryPageSize") state.notificationHistoryUi.deliveriesPageSize = Number($(id).value || 25); renderNotificationDeliveries(); });
  }
  $("clearNotificationDeliveryFilters")?.addEventListener("click", clearNotificationDeliveryFilters);
  $("notificationDeliveryPrev")?.addEventListener("click", () => { state.notificationHistoryUi.deliveriesPage = Math.max(1, state.notificationHistoryUi.deliveriesPage - 1); renderNotificationDeliveries(); });
  $("notificationDeliveryNext")?.addEventListener("click", () => { state.notificationHistoryUi.deliveriesPage += 1; renderNotificationDeliveries(); });
  $("notificationIncidentSearch")?.addEventListener("input", () => { state.notificationHistoryUi.incidentsPage = 1; renderNotificationIncidents(); });
  for (const id of ["notificationIncidentState", "notificationIncidentDateFrom", "notificationIncidentDateTo", "notificationIncidentPageSize"]) {
    $(id)?.addEventListener("change", () => { state.notificationHistoryUi.incidentsPage = 1; if (id === "notificationIncidentPageSize") state.notificationHistoryUi.incidentsPageSize = Number($(id).value || 25); renderNotificationIncidents(); });
  }
  $("clearNotificationIncidentFilters")?.addEventListener("click", clearNotificationIncidentFilters);
  $("notificationIncidentPrev")?.addEventListener("click", () => { state.notificationHistoryUi.incidentsPage = Math.max(1, state.notificationHistoryUi.incidentsPage - 1); renderNotificationIncidents(); });
  $("notificationIncidentNext")?.addEventListener("click", () => { state.notificationHistoryUi.incidentsPage += 1; renderNotificationIncidents(); });
  $("notificationDestinationSites")?.addEventListener("change", updateNotificationDestinationRoutingUi);
  $("notificationDestinationGroups")?.addEventListener("change", updateNotificationDestinationRoutingUi);
  $("notificationDestinationSitesPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "notificationDestinationSites"));
  $("notificationDestinationGroupsPicker")?.addEventListener("click", event => handleUserAccessScopePickerClick(event, "notificationDestinationGroups"));
  for (const id of ["notificationDestinationOffline", "notificationDestinationRecovery", "notificationDestinationReminder", "notificationDestinationStackDegraded", "notificationDestinationStackRecovery", "notificationDestinationUpsOnBattery", "notificationDestinationUpsRestored", "notificationDestinationUpsLowBattery"]) $(id)?.addEventListener("change", updateNotificationDestinationRoutingUi);
  document.querySelectorAll('input[name="notificationDestinationScopeMode"]').forEach(input => input.addEventListener("change", updateNotificationDestinationRoutingUi));
  $("adminHealthScanButton")?.addEventListener("click", runAdminHealthScan);
  $("adminDatabaseImportButton")?.addEventListener("click", () => $("adminDatabaseImport")?.click());
  $("adminDatabaseImport")?.addEventListener("change", importAdminDatabase);
  $("adminPruneForm")?.addEventListener("submit", pruneAdminData);
  document.addEventListener("click", event => {
    document.querySelectorAll(".notification-destination-menu[open]").forEach(menu => {
      if (!menu.contains(event.target)) menu.removeAttribute("open");
    });
  });

  document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => $(button.dataset.close).close()));
  document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => switchView(button.dataset.view)));
  document.querySelectorAll("[data-more-target]").forEach(button => button.addEventListener("click", () => switchView(button.dataset.moreTarget)));
  document.querySelectorAll("[data-roadmap-tab]").forEach(button => button.addEventListener("click", () => switchRoadmapTab(button.dataset.roadmapTab)));
  document.querySelectorAll("[data-activity-tab]").forEach(button => button.addEventListener("click", () => switchActivityTab(button.dataset.activityTab)));
  document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => {
    switchView(button.dataset.go);
    if (button.dataset.go === "devicesView" && button.dataset.deviceStatus) {
      const statusFilter = $("deviceStatusFilter");
      if (statusFilter) statusFilter.value = button.dataset.deviceStatus;
      renderDevices();
    }
  }));
  document.querySelectorAll("[data-quick]").forEach(button => button.addEventListener("click", () => {
    switchView("bulkView");
    $("commandSearch").value = "";
    renderActionOptions();
    $("bulkAction").value = button.dataset.quick;
    updateActionContext();
    updateBulkSummary();
  }));
}


function commandPaletteNormalize(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase()
    .trim();
}

function commandPaletteScore(entry, query) {
  const normalizedQuery = commandPaletteNormalize(query);
  if (!normalizedQuery) return Number(entry.priority || 0);
  const title = commandPaletteNormalize(entry.title);
  const subtitle = commandPaletteNormalize(entry.subtitle);
  const keywords = commandPaletteNormalize(entry.keywords);
  const haystack = `${title} ${subtitle} ${keywords}`.trim();
  const tokens = normalizedQuery.split(/\s+/).filter(Boolean);
  if (!tokens.every(token => haystack.includes(token))) return -1;
  let score = Number(entry.priority || 0);
  if (title === normalizedQuery) score += 1200;
  else if (title.startsWith(normalizedQuery)) score += 900;
  else if (title.split(/\s+/).some(word => word.startsWith(normalizedQuery))) score += 720;
  else if (title.includes(normalizedQuery)) score += 560;
  else if (subtitle.includes(normalizedQuery)) score += 360;
  else score += 240;
  for (const token of tokens) {
    if (title.startsWith(token)) score += 90;
    else if (title.includes(token)) score += 55;
    else if (subtitle.includes(token)) score += 30;
    else score += 15;
  }
  return score;
}

function commandPalettePageEntries() {
  const entries = [
    ["dashboardView", "nav.dashboard", "Dashboard", "page.dashboard.subtitle", "Fleet health and recent operations", "#i-dashboard", 98],
    ["devicesView", "nav.devices", "Switches", "page.devices.subtitle", "Manage switch inventory and connectivity", "#i-device", 96],
    ["powerView", "nav.power", "Power", "page.power.subtitle", "UPS health, battery telemetry and switch power correlation", "#i-power", 95.5],
    ["finderView", "nav.findDevice", "Find device", "page.finder.subtitle", "Locate an endpoint by IP, MAC, hostname or UNP", "#i-find-device", 95],
    ["bulkView", "nav.operations", "Operations", "page.operations.subtitle", "Run verified commands across selected switches", "#i-bolt", 94],
    ["auditsView", "nav.fleetAudits", "Fleet audits", "page.fleetAudits.subtitle", "Run structured read-only fleet assessments", "#i-fleet-audits", 90],
    ["notificationsView", "nav.notifications", "Notifications", "page.notifications.subtitle", "Incidents, routing and webhook delivery", "#i-notifications", 89],
    ["jobsView", "jobs.title", "Jobs", "page.jobs.subtitle", "Execution history and results", "#i-jobs", 86],
    ["moreView", "nav.more", "More", "page.more.subtitle", "Reference tools and supporting platform capabilities", "#i-more", 85],
    ["profilesView", "nav.library", "Command library", "page.library.subtitle", "Browse verified command templates", "#i-library", 84],
    ["driversView", "more.drivers", "Drivers", "page.drivers.subtitle", "Switch and infrastructure driver registry", "#i-settings", 83],
    ["auditView", "audit.title", "Audit log", "page.audit.subtitle", "Trace administrative and operational activity", "#i-audit-log", 82],
    ["roadmapView", "nav.roadmap", "Roadmap", "page.roadmap.subtitle", "Product direction and changelog", "#i-roadmap", 72],
  ].map(([view, titleKey, titleFallback, subtitleKey, subtitleFallback, icon, priority]) => ({
    type: "page", group: "navigation", view, icon, priority,
    title: t(titleKey, {}, titleFallback), subtitle: t(subtitleKey, {}, subtitleFallback),
    keywords: `${view} ${titleFallback} navigation page`,
    badge: t("commandPalette.page", {}, "Page"),
  }));
  if (isPlatformAdmin()) {
    entries.push({
      type: "page", group: "navigation", view: "automationView", icon: "#i-cycle", priority: 78,
      title: t("nav.automation", {}, "Automation"), subtitle: t("page.automation.subtitle", {}, "Scheduled actions, credentials and safeguards"),
      keywords: "automation scheduler schedules recurring unp safeguards credentials", badge: t("commandPalette.page", {}, "Page"),
    });
    entries.push({
      type: "page", group: "navigation", view: "adminView", icon: "#i-admin", priority: 74,
      title: t("nav.admin", {}, "Admin panel"), subtitle: t("page.admin.subtitle", {}, "Administration and platform settings"),
      keywords: "admin administration users settings database security", badge: t("commandPalette.page", {}, "Page"),
    });
  }
  return entries.filter(entry => viewAllowed(entry.view));
}

function commandPaletteDeviceEntries() {
  if (!hasCapability("devices.live_ports")) return [];
  return (state.devices || []).map(device => ({
    type: "device", group: "devices", deviceId: Number(device.id), icon: "#i-device", priority: 40,
    title: String(device.name || device.host || `Switch ${device.id}`),
    subtitle: `${device.host || ""}${device.site ? ` · ${device.site}` : ""}${device.group_name ? ` · ${device.group_name}` : ""}`,
    keywords: `${device.host || ""} ${device.site || ""} ${device.group_name || ""} ${device.model || ""} ${device.profile || ""} ${device.aos_version || ""} ${device.notes || ""} switch device`,
    badge: String(device.last_status || t("common.unknown", {}, "Unknown")),
  }));
}

function commandPaletteCommandEntries() {
  const profileActions = new Set();
  for (const profile of Object.values(state.profiles || {})) {
    for (const action of Object.keys(profile?.commands || {})) profileActions.add(action);
    for (const action of (profile?.orchestrated_actions || [])) profileActions.add(action);
  }
  for (const action of ["interface_cycle", "poe_cycle", "check_unp", "fix_unp", "custom_command", "custom_runbook"]) profileActions.add(action);
  return [...profileActions].filter(action => actionAllowedForCurrentUser(action) && !actionMeta(action).contextualOnly).map(action => {
    const meta = actionMeta(action);
    return {
      type: "command", group: "commands", action, icon: "#i-terminal", priority: meta.risk === "read" ? 34 : 30,
      title: meta.label, subtitle: `${meta.category} · ${meta.description}`,
      keywords: `${action} ${meta.originalCategory || ""} ${meta.compatibility || ""} command operation cli`,
      badge: t(meta.risk === "change" ? "common.change" : "common.readOnly", {}, meta.risk === "change" ? "Change" : "Read only"),
    };
  });
}

function buildCommandPaletteResults() {
  const query = String($("commandPaletteInput")?.value || "").trim();
  let entries = [...commandPalettePageEntries()];
  if (query) entries.push(...commandPaletteDeviceEntries(), ...commandPaletteCommandEntries());
  else {
    if (canManageInventory()) entries.push({
      type: "add-device", group: "actions", icon: "#i-plus", priority: 60,
      title: t("deviceModal.addTitle", {}, "Add switch"), subtitle: t("deviceModal.connectionHelp", {}, "Add and verify a managed switch"),
      keywords: "add create switch device inventory", badge: t("commandPalette.action", {}, "Action"),
    });
  }
  const endpointLike = query && (/[.:]/.test(query) || /\d/.test(query) || query.includes("-"));
  if (endpointLike && isSshUser() && hasCapability("finder.use")) entries.push({
    type: "finder", group: "actions", finderQuery: query, icon: "#i-find-device", priority: 120,
    title: t("commandPalette.findEndpoint", { query }, `Find endpoint “${query}”`),
    subtitle: t("commandPalette.findEndpointHelp", {}, "Run the live endpoint locator across the selected fleet scope"),
    keywords: `${query} endpoint ip mac arp unp hostname vlan find search`, badge: t("nav.findDevice", {}, "Find device"),
  });
  const scored = entries
    .map(entry => ({ ...entry, score: commandPaletteScore(entry, query) }))
    .filter(entry => entry.score >= 0)
    .sort((a, b) => b.score - a.score || String(a.title).localeCompare(String(b.title), undefined, { sensitivity: "base" }));
  return scored.slice(0, 14);
}

function commandPaletteGroupLabel(group) {
  const labels = {
    navigation: ["commandPalette.groupNavigation", "Navigation"],
    devices: ["commandPalette.groupDevices", "Switches"],
    commands: ["commandPalette.groupCommands", "Commands"],
    actions: ["commandPalette.groupActions", "Actions"],
  };
  const [key, fallback] = labels[group] || ["commandPalette.groupActions", "Actions"];
  return t(key, {}, fallback);
}

function renderCommandPalette() {
  const container = $("commandPaletteResults");
  if (!container) return;
  state.commandPaletteResults = buildCommandPaletteResults();
  if (state.commandPaletteIndex >= state.commandPaletteResults.length) state.commandPaletteIndex = Math.max(0, state.commandPaletteResults.length - 1);
  $("commandPaletteSummary").textContent = t("commandPalette.resultCount", { count: state.commandPaletteResults.length }, `${state.commandPaletteResults.length} results`);
  if (!state.commandPaletteResults.length) {
    container.innerHTML = `<div class="command-palette-empty"><svg><use href="#i-search"></use></svg><strong>${escapeHtml(t("commandPalette.noResults", {}, "No matching result"))}</strong><span>${escapeHtml(t("commandPalette.noResultsHelp", {}, "Try a switch name, IP address, page or command."))}</span></div>`;
    return;
  }
  let previousGroup = "";
  container.innerHTML = state.commandPaletteResults.map((entry, index) => {
    const group = entry.group || "actions";
    const heading = group !== previousGroup ? `<div class="command-palette-group">${escapeHtml(commandPaletteGroupLabel(group))}</div>` : "";
    previousGroup = group;
    return `${heading}<button type="button" class="command-palette-item ${index === state.commandPaletteIndex ? "active" : ""}" data-palette-index="${index}" role="option" aria-selected="${index === state.commandPaletteIndex ? "true" : "false"}">
      <span class="command-palette-item-icon"><svg><use href="${escapeHtml(entry.icon || "#i-search")}"></use></svg></span>
      <span class="command-palette-item-copy"><strong>${escapeHtml(entry.title)}</strong><span>${escapeHtml(entry.subtitle || "")}</span></span>
      <span class="command-palette-item-meta"><span class="command-palette-badge">${escapeHtml(entry.badge || "")}</span></span>
    </button>`;
  }).join("");
  container.querySelectorAll("[data-palette-index]").forEach(button => {
    button.addEventListener("mouseenter", () => {
      state.commandPaletteIndex = Number(button.dataset.paletteIndex || 0);
      container.querySelectorAll(".command-palette-item").forEach((item, idx) => item.classList.toggle("active", idx === state.commandPaletteIndex));
    });
    button.addEventListener("click", () => executeCommandPaletteResult(Number(button.dataset.paletteIndex || 0)));
  });
}

function openCommandPalette() {
  if (!state.user || !$("commandPaletteDialog")) return;
  const dialog = $("commandPaletteDialog");
  state.commandPaletteIndex = 0;
  $("commandPaletteInput").value = "";
  renderCommandPalette();
  if (!dialog.open) dialog.showModal();
  requestAnimationFrame(() => $("commandPaletteInput").focus());
}

function closeCommandPalette() {
  const dialog = $("commandPaletteDialog");
  if (dialog?.open) dialog.close();
}

function executeCommandPaletteResult(index = state.commandPaletteIndex) {
  const entry = state.commandPaletteResults[index];
  if (!entry) return;
  closeCommandPalette();
  if (entry.type === "page") {
    switchView(entry.view);
    return;
  }
  if (entry.type === "device") {
    window.useDevice(entry.deviceId);
    return;
  }
  if (entry.type === "command") {
    window.useCatalogCommand(entry.action);
    return;
  }
  if (entry.type === "add-device") {
    openDeviceModal();
    return;
  }
  if (entry.type === "finder") {
    switchView("finderView");
    $("finderQuery").value = entry.finderQuery;
    requestAnimationFrame(() => startDeviceFinderSearch());
  }
}

function handleCommandPaletteKeydown(event) {
  if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    if (!state.commandPaletteResults.length) return;
    const direction = event.key === "ArrowDown" ? 1 : -1;
    state.commandPaletteIndex = (state.commandPaletteIndex + direction + state.commandPaletteResults.length) % state.commandPaletteResults.length;
    renderCommandPalette();
    requestAnimationFrame(() => $("commandPaletteResults")?.querySelector(".command-palette-item.active")?.scrollIntoView({ block: "nearest" }));
    return;
  }
  if (event.key === "Enter") {
    event.preventDefault();
    executeCommandPaletteResult();
    return;
  }
  if (event.key === "Escape") {
    event.preventDefault();
    closeCommandPalette();
  }
}

function handleGlobalCommandPaletteShortcut(event) {
  const dialog = $("commandPaletteDialog");
  if ((event.ctrlKey || event.metaKey) && event.key.toLocaleLowerCase() === "k") {
    event.preventDefault();
    if (dialog?.open) closeCommandPalette();
    else openCommandPalette();
    return;
  }
  if (event.key === "Escape" && dialog?.open && document.activeElement !== $("commandPaletteInput")) closeCommandPalette();
}

function switchRoadmapTab(tab) {
  const selected = tab === "changelog" ? "changelog" : "plan";
  document.querySelectorAll("[data-roadmap-tab]").forEach(button => {
    const active = button.dataset.roadmapTab === selected;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  });
  document.querySelectorAll("[data-roadmap-panel]").forEach(panel => panel.classList.toggle("active", panel.dataset.roadmapPanel === selected));
}

function resetNavigationScroll(viewId) {
  // Every menu action opens the destination at its beginning. The application
  // can be scrolled by the document or by the content container depending on
  // viewport size, so reset both without an animated jump.
  requestAnimationFrame(() => {
    window.scrollTo(0, 0);
    if (document.scrollingElement) {
      document.scrollingElement.scrollTop = 0;
      document.scrollingElement.scrollLeft = 0;
    }
    for (const element of [document.querySelector(".content"), document.getElementById(viewId)]) {
      if (!element) continue;
      element.scrollTop = 0;
      element.scrollLeft = 0;
    }
  });
}


function activeActivityTab() {
  return state.activityTab === "audit" ? "audit" : "jobs";
}

async function switchActivityTab(tab, { load = true } = {}) {
  let normalized = tab === "audit" ? "audit" : "jobs";
  if (normalized === "audit" && !hasCapability("activity.audit")) normalized = "jobs";
  if (normalized === "jobs" && !hasCapability("activity.jobs") && hasCapability("activity.audit")) normalized = "audit";
  state.activityTab = normalized;
  document.querySelectorAll("[data-activity-tab]").forEach(button => {
    const active = button.dataset.activityTab === normalized;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  });
  document.querySelectorAll("[data-activity-panel]").forEach(panel => panel.classList.toggle("active", panel.dataset.activityPanel === normalized));
  if (!load) return;
  if (normalized === "audit") await loadAudit();
  else await loadJobs();
}

function switchView(viewId) {
  if (viewId === "jobsView") { state.activityTab = "jobs"; viewId = "activityView"; }
  else if (viewId === "auditView") { state.activityTab = "audit"; viewId = "activityView"; }
  if (!viewAllowed(viewId)) {
    toast(t("access.denied", {}, "This role does not have access to that area."), "error");
    viewId = viewAllowed("dashboardView") ? "dashboardView" : (viewAllowed("devicesView") ? "devicesView" : "roadmapView");
  }
  const previousView = document.querySelector(".view.active")?.id;
  if (previousView === "deviceWorkspaceView" && viewId !== "deviceWorkspaceView") disconnectWorkspaceTerminal(true);
  document.querySelectorAll(".view").forEach(view => view.classList.toggle("active", view.id === viewId));
  const moreChild = ["moreView", "profilesView", "driversView"].includes(viewId);
  document.querySelectorAll(".nav-item").forEach(item => item.classList.toggle("active", item.dataset.view === viewId || (item.dataset.view === "moreView" && moreChild)));
  const [titleKey, subtitleKey] = pageMeta[viewId] || pageMeta.dashboardView;
  $("pageTitle").textContent = t(titleKey);
  $("pageSubtitle").textContent = t(subtitleKey);
  resetNavigationScroll(viewId);
  if (viewId === "devicesView" && hasCapability("devices.view")) loadDevices();
  if (viewId === "finderView" && hasCapability("finder.use")) loadDevices();
  if (viewId === "bulkView" && hasCapability("devices.view")) loadDevices();
  if (viewId === "bulkView" && hasCapability("devices.view")) loadPendingConfiguration();
  if (viewId === "bulkView" && hasCapability("command_library.view") && !Object.keys(state.profiles || {}).length) loadProfiles();
  if (viewId === "deviceWorkspaceView" && hasCapability("command_library.view") && !Object.keys(state.profiles || {}).length) loadProfiles().catch(error => toast(error.message, "error"));
  if (viewId === "bulkView" && hasCapability("operations.runbook")) loadRunbooks();
  if (viewId === "auditsView" && hasCapability("audits.view")) loadFleetAuditsView();
  if (viewId === "powerView" && hasCapability("power.view")) loadPowerInfrastructure();
  if (viewId === "notificationsView" && hasCapability("notifications.view")) loadNotifications();
  if (viewId === "activityView") switchActivityTab(activeActivityTab());
  if (viewId === "jobsView") loadJobs();
  if (viewId === "profilesView" && hasCapability("command_library.view")) loadProfiles();
  if (viewId === "driversView") loadDriversView();
  if (viewId === "auditView") loadAudit();
  if (viewId === "automationView" && isPlatformAdmin()) loadAutomationCenter();
  if (viewId === "adminView" && isPlatformAdmin()) loadAdminPanel();
}

async function refreshAll() {
  applyAccessVisibility();
  const active = document.querySelector(".view.active")?.id || "dashboardView";
  if (!viewAllowed(active)) switchView(viewAllowed("dashboardView") ? "dashboardView" : (viewAllowed("devicesView") ? "devicesView" : "roadmapView"));
  const tasks = [];
  if (hasCapability("notifications.view")) tasks.push(loadNotificationBadge());
  if (active === "dashboardView" && hasCapability("dashboard.view")) tasks.push(loadDashboard());
  else if (["devicesView", "finderView", "bulkView"].includes(active) && hasCapability("devices.view")) tasks.push(loadDevices({ force: true }));
  await Promise.all(tasks);
}
async function refreshCurrentView(showToast = true) {
  const current = document.querySelector(".view.active")?.id;
  try {
    if (current === "dashboardView" && hasCapability("dashboard.view")) await loadDashboard();
    else if ((current === "devicesView" || current === "finderView") && hasCapability("devices.view")) await Promise.all([loadDevices({ force: true }), loadPendingConfiguration()]);
    else if (current === "bulkView" && hasCapability("operations.view")) await Promise.all([loadDevices({ force: true }), loadPendingConfiguration(), ...(hasCapability("operations.runbook") ? [loadRunbooks()] : [])]);
    else if (current === "deviceWorkspaceView") await Promise.all([loadWorkspacePorts(false), loadPendingConfiguration(), ...(hasCapability("command_library.view") && !Object.keys(state.profiles || {}).length ? [loadProfiles()] : [])]);
    else if (current === "auditsView" && hasCapability("audits.view")) await loadFleetAuditsView();
    else if (current === "powerView" && hasCapability("power.view")) await loadPowerInfrastructure();
    else if (current === "notificationsView" && hasCapability("notifications.view")) await loadNotifications();
    else if (current === "automationView" && isPlatformAdmin()) await loadAutomationCenter();
    else if (current === "activityView") {
      if (activeActivityTab() === "audit") await loadAudit();
      else await loadJobs();
    }
    else if (current === "jobsView") await loadJobs();
    else if (current === "profilesView" && hasCapability("command_library.view")) await loadProfiles();
    else if (current === "driversView") await loadDriversView();
    else if (current === "auditView") await loadAudit();
    if (showToast) toast("Data refreshed", "success");
  } catch (error) {
    if (showToast) toast(error.message, "error");
  }
}


function fleetAuditSeverityBadge(severity) {
  const normalized = String(severity || "info").toLowerCase();
  const label = t(`fleetAudits.${normalized}`, {}, normalized.replaceAll("_", " "));
  return `<span class="audit-severity ${escapeHtml(normalized)}"><i></i>${escapeHtml(label)}</span>`;
}
function auditUniqueValues(key, devices = state.devices) {
  return [...new Set(devices.map(device => String(device[key] || "").trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}
function populateFleetAuditFilters() {
  const controls = [
    ["auditSiteFilter", "site", t("devices.allSites", {}, "All sites")],
    ["auditGroupFilter", "group_name", t("devices.allGroups", {}, "All groups")],
    ["auditModelFilter", "model", t("devices.allModels", {}, "All models")],
  ];
  for (const [id, key, allLabel] of controls) {
    const select = $(id);
    if (!select) continue;
    const current = select.value;
    select.innerHTML = `<option value="">${escapeHtml(allLabel)}</option>` + auditUniqueValues(key).map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join("");
    if ([...select.options].some(option => option.value === current)) select.value = current;
  }
}
function fleetSwitchCardMarkup(device, { selected = false, mode = "audit", extraHtml = "" } = {}) {
  const id = Number(device.id);
  const status = String(device.last_status || "unknown");
  const site = device.site || t("common.unknown", {}, "No site");
  const model = device.model || device.profile || t("common.notDetected", {}, "Not detected");
  return `<div class="fleet-switch-card ${selected ? "selected" : ""}" data-fleet-card="${id}">
    <button class="fleet-switch-select-surface" type="button" data-fleet-select="${id}" data-fleet-mode="${escapeHtml(mode)}" aria-pressed="${selected ? "true" : "false"}" aria-label="${escapeHtml((selected ? t("operations.deselectSwitch", {}, "Deselect") : t("operations.selectSwitch", {}, "Select")) + " " + (device.name || device.host || id))}">
      <span class="fleet-switch-check" aria-hidden="true"></span>
      <span class="fleet-switch-identity"><strong>${escapeHtml(device.name || device.host)}</strong><small>${escapeHtml(device.host)} · ${escapeHtml(site)} · ${escapeHtml(model)}</small></span>
      <span class="status ${escapeHtml(status)}">${escapeHtml(t(`status.${status}`, {}, status))}</span>
    </button>
    ${extraHtml}
  </div>`;
}
function bindFleetSwitchCards(container, onToggle) {
  if (!container) return;
  container.querySelectorAll("[data-fleet-select]").forEach(button => button.addEventListener("click", () => {
    const id = Number(button.dataset.fleetSelect);
    const selected = button.getAttribute("aria-pressed") === "true";
    onToggle(id, !selected);
  }));
}

function matchedFleetAuditDevices() {
  const query = String($("auditDeviceSearch")?.value || "").trim().toLowerCase();
  const site = $("auditSiteFilter")?.value || "";
  const group = $("auditGroupFilter")?.value || "";
  const model = $("auditModelFilter")?.value || "";
  const status = $("auditStatusFilter")?.value || "";
  const profile = $("auditProfileFilter")?.value || "";
  return state.devices.filter(device => {
    if (!device.enabled) return false;
    if (site && String(device.site || "") !== site) return false;
    if (group && String(device.group_name || "") !== group) return false;
    if (model && String(device.model || "") !== model) return false;
    if (status && String(device.last_status || "unknown") !== status) return false;
    if (profile && String(device.profile || "") !== profile) return false;
    if (query) {
      const haystack = [device.name, device.host, device.site, device.group_name, device.model, device.aos_version, device.profile].join(" ").toLowerCase();
      if (!haystack.includes(query)) return false;
    }
    return true;
  });
}
function renderFleetAuditScope() {
  const container = $("auditScopeList");
  if (!container) return;
  const devices = matchedFleetAuditDevices();
  $("auditSelectedCount").textContent = String(state.fleetAuditSelected.size);
  const visible = devices.slice(0, 700);
  container.innerHTML = visible.map(device => fleetSwitchCardMarkup(device, {
    selected: state.fleetAuditSelected.has(Number(device.id)),
    mode: "audit",
  })).join("") || `<div class="empty-state compact-empty"><strong>${escapeHtml(t("fleetAudits.noScopeMatches", {}, "No switches match this scope."))}</strong></div>`;
  bindFleetSwitchCards(container, (id, checked) => {
    if (checked) state.fleetAuditSelected.add(id); else state.fleetAuditSelected.delete(id);
    renderFleetAuditScope();
    renderFleetAuditCatalog();
  });
}
function selectFilteredAuditDevices() {
  matchedFleetAuditDevices().forEach(device => state.fleetAuditSelected.add(Number(device.id)));
  renderFleetAuditScope();
  renderFleetAuditCatalog();
}
function clearFleetAuditSelection() {
  state.fleetAuditSelected.clear();
  renderFleetAuditScope();
  renderFleetAuditCatalog();
}
function localizedFleetAuditDefinition(auditItem = {}) {
  const id = String(auditItem.id || auditItem.audit_type || "");
  const prefix = `fleetAudits.types.${id}`;
  return {
    label: t(`${prefix}.label`, {}, auditItem.label || id),
    category: t(`${prefix}.category`, {}, auditItem.category || ""),
    description: t(`${prefix}.description`, {}, auditItem.description || ""),
    policy: t(`${prefix}.policy`, {}, auditItem.policy || ""),
  };
}

const FLEET_AUDIT_ICON_MAP = Object.freeze({
  thermal_health: "#i-audit-thermal",
  fan_cooling: "#i-audit-fan",
  power_supply: "#i-audit-psu",
  poe_capacity: "#i-audit-poe",
  interface_errors: "#i-audit-interface",
  port_flapping: "#i-audit-stability",
  uplink_health: "#i-audit-uplink",
  configuration_save: "#i-audit-config",
  full_switch_health: "#i-audit-health",
});
function auditTypeIcon(auditItem) {
  const key = String(auditItem?.id || auditItem?.audit_type || "").trim();
  return FLEET_AUDIT_ICON_MAP[key] || "#i-fleet-audits";
}
function renderFleetAuditCatalog() {
  const container = $("fleetAuditCatalog");
  if (!container) return;
  const count = state.fleetAuditSelected.size;
  const canRunAudits = hasCapability("audits.run");
  container.innerHTML = (state.fleetAuditCatalog || []).map(auditItem => {
    const text = localizedFleetAuditDefinition(auditItem);
    return `<article class="fleet-audit-card">
      <div class="fleet-audit-card-head"><span class="fleet-audit-icon" data-audit-icon="${escapeHtml(auditItem.id || auditItem.audit_type || "generic")}"><svg><use href="${auditTypeIcon(auditItem)}"></use></svg></span><span class="audit-command-load">${Number(auditItem.command_count || 0)} ${escapeHtml(t("fleetAudits.commands", {}, "commands"))}</span></div>
      <div><span class="fleet-audit-category">${escapeHtml(text.category)}</span><h3>${escapeHtml(text.label)}</h3><p>${escapeHtml(text.description)}</p></div>
      <div class="fleet-audit-policy"><strong>${escapeHtml(t("fleetAudits.policy", {}, "Assessment policy"))}</strong><span>${escapeHtml(text.policy)}</span></div>
      <button class="btn primary fleet-audit-run" type="button" data-run-audit="${escapeHtml(auditItem.id)}" ${count && canRunAudits ? "" : "disabled"}>${escapeHtml(canRunAudits ? t("fleetAudits.run", { count }, `Run on ${count} switches`) : "View-only role")}</button>
    </article>`;
  }).join("");
  container.querySelectorAll("[data-run-audit]").forEach(button => button.addEventListener("click", () => startFleetAudit(button.dataset.runAudit)));
}
async function loadFleetAuditCatalog() {
  const result = await api("/api/fleet-audits/catalog");
  state.fleetAuditCatalog = result.audits || [];
  renderFleetAuditCatalog();
}
async function loadFleetAuditHistory() {
  const result = await api("/api/fleet-audits?limit=50");
  state.fleetAuditHistory = result.runs || [];
  renderFleetAuditHistory();
}
function renderFleetAuditHistory() {
  const tbody = $("fleetAuditHistory");
  if (!tbody) return;
  tbody.innerHTML = (state.fleetAuditHistory || []).map(run => `<tr>
    <td>#${Number(run.id)}</td><td><strong>${escapeHtml(localizedFleetAuditDefinition({ audit_type: run.audit_type, label: run.label }).label)}</strong></td><td>${statusBadge(run.status)}</td><td>${Number(run.target_count || 0)}</td><td>${Number(run.warning_count || 0)}</td><td>${Number(run.critical_count || 0)}</td><td>${Number(run.unavailable_count || 0)}</td><td>${formatDate(run.created_at)}</td>
    <td><div class="row-actions"><button class="icon-action" data-open-audit="${Number(run.id)}">${escapeHtml(t("common.open", {}, "Open"))}</button><button class="icon-action" data-export-audit="${Number(run.id)}">PDF</button></div></td>
  </tr>`).join("") || `<tr><td colspan="9"><div class="empty-state">${escapeHtml(t("fleetAudits.noHistory", {}, "No fleet audits have been run yet."))}</div></td></tr>`;
  tbody.querySelectorAll("[data-open-audit]").forEach(button => button.addEventListener("click", () => openFleetAudit(Number(button.dataset.openAudit))));
  tbody.querySelectorAll("[data-export-audit]").forEach(button => button.addEventListener("click", () => downloadFleetAuditPdf(Number(button.dataset.exportAudit))));
}
async function loadFleetAuditsView() {
  try {
    if (!state.devices.length) await loadDevices();
    populateFleetAuditFilters();
    renderFleetAuditScope();
    await Promise.all([loadFleetAuditCatalog(), loadFleetAuditHistory()]);
    if (state.currentFleetAudit) renderFleetAuditRun(state.currentFleetAudit);
  } catch (error) { toast(error.message, "error"); }
}
async function startFleetAudit(auditType) {
  if (!hasCapability("audits.run")) { toast("This role can view Fleet Audits but cannot start a new assessment.", "error"); return; }
  const deviceIds = [...state.fleetAuditSelected];
  if (!deviceIds.length) { toast(t("fleetAudits.selectFirst", {}, "Select at least one switch first."), "error"); return; }
  const definition = (state.fleetAuditCatalog || []).find(item => item.id === auditType);
  const label = localizedFleetAuditDefinition(definition || { id: auditType, label: auditType }).label;
  if (deviceIds.length >= 250 && !confirm(t("fleetAudits.largeScopeConfirm", { count: deviceIds.length, audit: label }, `Run ${label} against ${deviceIds.length} switches? The audit is read-only and uses bounded SSH concurrency.`))) return;
  try {
    const result = await api("/api/fleet-audits", { method: "POST", body: { audit_type: auditType, device_ids: deviceIds } });
    state.currentFleetAudit = result;
    renderFleetAuditRun(result);
    scheduleFleetAuditPoll(Number(result.id));
    await loadFleetAuditHistory();
    document.getElementById("fleetAuditRunPanel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) { toast(error.message, "error"); }
}
function scheduleFleetAuditPoll(runId) {
  if (state.fleetAuditPollTimer) clearTimeout(state.fleetAuditPollTimer);
  const poll = async () => {
    try {
      const result = await api(`/api/fleet-audits/${runId}`);
      state.currentFleetAudit = result;
      renderFleetAuditRun(result);
      if (["queued", "running"].includes(String(result.status || ""))) state.fleetAuditPollTimer = setTimeout(poll, 900);
      else { state.fleetAuditPollTimer = null; await loadFleetAuditHistory(); }
    } catch (error) { state.fleetAuditPollTimer = null; toast(error.message, "error"); }
  };
  state.fleetAuditPollTimer = setTimeout(poll, 450);
}
async function openFleetAudit(runId) {
  try {
    const result = await api(`/api/fleet-audits/${runId}`);
    state.currentFleetAudit = result;
    renderFleetAuditRun(result);
    if (["queued", "running"].includes(String(result.status || ""))) scheduleFleetAuditPoll(runId);
    $("fleetAuditRunPanel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) { toast(error.message, "error"); }
}
function fleetAuditEvidence(item, auditType) {
  const d = item?.details || {};
  const join = parts => parts.filter(Boolean).join(" · ");
  if (auditType === "thermal_health") {
    const sensors = (d.sensors || []).slice(0, 3).map(sensor => {
      const limits = [];
      if (sensor.warning_threshold_c !== null && sensor.warning_threshold_c !== undefined) limits.push(`${t("fleetAudits.warnShort", {}, "Warn")} ${Number(sensor.warning_threshold_c)}°C`);
      if (sensor.danger_threshold_c !== null && sensor.danger_threshold_c !== undefined) limits.push(`${t("fleetAudits.dangerShort", {}, "Danger")} ${Number(sensor.danger_threshold_c)}°C`);
      return `${sensor.name || "Sensor"}: ${Number(sensor.celsius).toFixed(1)}°C${limits.length ? ` (${limits.join(" / ")})` : ""}`;
    });
    if ((d.sensors || []).length > 3) sensors.push(`+${(d.sensors || []).length - 3}`);
    return sensors.join(" · ");
  }
  if (auditType === "fan_cooling") {
    return join([
      `${t("fleetAudits.fanFaults", {}, "Fan faults")}: ${Number(d.fans?.failed || 0)}`,
      d.thermal?.max_celsius !== null && d.thermal?.max_celsius !== undefined ? `${t("fleetAudits.maxTemperature", {}, "Max temperature")}: ${Number(d.thermal.max_celsius).toFixed(1)}°C` : "",
    ]);
  }
  if (auditType === "power_supply") return join([`${t("fleetAudits.psuFaults", {}, "PSU faults")}: ${Number(d.failed || 0)}`, `${t("fleetAudits.healthy", {}, "Healthy")}: ${Number(d.healthy || 0)}`]);
  if (auditType === "poe_capacity") return join([
    d.used_w !== null && d.used_w !== undefined ? `${t("fleetAudits.usedPower", {}, "Used")}: ${Number(d.used_w).toFixed(1)} W` : "",
    d.budget_w !== null && d.budget_w !== undefined ? `${t("fleetAudits.budget", {}, "Budget")}: ${Number(d.budget_w).toFixed(1)} W` : "",
    d.utilization_percent !== null && d.utilization_percent !== undefined ? `${Number(d.utilization_percent).toFixed(1)}%` : "",
    Number(d.faults || 0) ? `${t("fleetAudits.faults", {}, "Faults")}: ${Number(d.faults)}` : "",
    Number(d.denied || 0) ? `${t("fleetAudits.denied", {}, "Denied")}: ${Number(d.denied)}` : "",
  ]);
  if (auditType === "interface_errors") return join([
    `CRC/FCS: ${Number(d.crc_total || 0)}`,
    `${t("fleetAudits.errors", {}, "Errors")}: ${Number(d.error_total || 0)}`,
    `${t("fleetAudits.discards", {}, "Drops/discards")}: ${Number(d.discard_total || 0)}`,
    (d.affected_ports || []).length ? `${t("fleetAudits.topPorts", {}, "Top ports")}: ${(d.affected_ports || []).slice(0, 3).map(x => `${x.port} (${x.count})`).join(", ")}` : "",
  ]);
  if (auditType === "port_flapping") return (d.flapping_ports || []).slice(0, 4).map(x => `${x.port}: ${x.events}`).join(" · ");
  if (auditType === "uplink_health") return join([
    `${t("fleetAudits.managedUplinks", {}, "Managed uplinks")}: ${Number(d.managed_uplink_count || 0)}`,
    (d.uplinks || []).filter(x => ["warning", "critical"].includes(x.severity)).slice(0, 3).map(x => `${x.port} → ${x.neighbor}`).join(", "),
  ]);
  if (auditType === "lag_health") return join([`${t("fleetAudits.lags", {}, "LAGs")}: ${(d.groups || []).length}`, `${t("fleetAudits.degraded", {}, "Degraded")}: ${Number(d.degraded_groups || 0)}`]);
  if (auditType === "configuration_save") return (d.evidence || []).slice(0, 2).join(" · ");
  if (auditType === "vlan_unp_consistency") return (d.conflicts || []).slice(0, 4).map(x => `${x.port}: ${(x.profiles || []).join(" + ")}`).join(" · ");
  if (auditType === "full_switch_health") return join([
    d.cpu_percent !== null && d.cpu_percent !== undefined ? `CPU ${Number(d.cpu_percent).toFixed(1)}%` : "",
    d.memory_percent !== null && d.memory_percent !== undefined ? `${t("fleetAudits.memory", {}, "Memory")} ${Number(d.memory_percent).toFixed(1)}%` : "",
    d.thermal?.max_celsius !== null && d.thermal?.max_celsius !== undefined ? `${t("fleetAudits.maxTemperature", {}, "Max temperature")} ${Number(d.thermal.max_celsius).toFixed(1)}°C` : "",
    d.coverage_percent !== null && d.coverage_percent !== undefined ? `${t("fleetAudits.coverage", {}, "Coverage")} ${Number(d.coverage_percent).toFixed(1)}%` : "",
  ]);
  return "";
}

function renderFleetAuditRun(run) {
  const panel = $("fleetAuditRunPanel");
  if (!panel || !run) return;
  panel.classList.remove("hidden");
  const definition = run.definition || {};
  const localizedDefinition = localizedFleetAuditDefinition({ id: run.audit_type, ...definition });
  $("fleetAuditRunTitle").textContent = localizedDefinition.label || run.audit_type || "Audit";
  $("fleetAuditRunMeta").textContent = `Run #${run.id} · ${run.requested_by || ""} · ${formatDate(run.created_at)}`;
  const completed = Number(run.completed_count || 0), total = Number(run.target_count || 0);
  const progress = total ? Math.min(100, completed / total * 100) : 0;
  $("fleetAuditProgressBar").style.width = `${progress}%`;
  $("fleetAuditProgressText").textContent = `${completed} / ${total} · ${String(run.status || "").toUpperCase()}`;
  $("fleetAuditPolicy").textContent = localizedDefinition.policy || definition.policy || "";
  $("auditMetricHealthy").textContent = Number(run.healthy_count || 0);
  $("auditMetricWarning").textContent = Number(run.warning_count || 0);
  $("auditMetricCritical").textContent = Number(run.critical_count || 0);
  $("auditMetricUnavailable").textContent = Number(run.unavailable_count || 0);
  $("auditMetricInfo").textContent = Number(run.info_count || 0);
  $("fleetAuditExport").disabled = completed <= 0;
  const tbody = $("fleetAuditResults");
  tbody.innerHTML = (run.items || []).map(item => `<tr>
    <td>${fleetAuditSeverityBadge(item.severity)}</td>
    <td><strong>${escapeHtml(item.device_name || item.host)}</strong><div class="muted-line">${escapeHtml(item.profile || "")}</div></td>
    <td><code>${escapeHtml(item.host || "")}</code></td>
    <td>${escapeHtml(item.site || "-")}</td>
    <td>${escapeHtml(item.model || "-")}</td>
    <td>${item.score === null || item.score === undefined ? "-" : `<strong>${Number(item.score)}/100</strong>`}</td>
    <td><strong>${escapeHtml(item.summary || item.error || "-")}</strong>${fleetAuditEvidence(item, run.audit_type) ? `<div class="audit-evidence-line">${escapeHtml(fleetAuditEvidence(item, run.audit_type))}</div>` : ""}${Object.keys(item.command_errors || {}).length ? `<div class="muted-line">${escapeHtml(t("fleetAudits.partialCoverage", {}, "Some metrics were not reported by this AOS/device."))}</div>` : ""}</td>
  </tr>`).join("") || `<tr><td colspan="7"><div class="empty-state compact-empty">${escapeHtml(t("fleetAudits.waitingResults", {}, "Waiting for switch results..."))}</div></td></tr>`;
}
function downloadFleetAuditPdf(runId) {
  if (!runId) return;
  const lang = window.I18n?.language || "en";
  window.location.assign(`/api/fleet-audits/${runId}/pdf?lang=${encodeURIComponent(lang)}`);
}
function exportCurrentFleetAudit() {
  if (state.currentFleetAudit?.id) downloadFleetAuditPdf(Number(state.currentFleetAudit.id));
}

async function loadPendingConfiguration() {
  try {
    state.pendingConfig = await api("/api/pending-config");
  } catch (error) {
    state.pendingConfig = { device_count: 0, change_count: 0, devices: [] };
    throw error;
  } finally {
    renderPendingConfiguration();
  }
}
function renderPendingConfiguration() {
  const data = state.pendingConfig || { device_count: 0, change_count: 0, devices: [] };
  const button = $("pendingConfigButton");
  const count = Number(data.device_count || 0);
  if (button) button.classList.toggle("hidden", count === 0);
  if ($("pendingConfigCount")) $("pendingConfigCount").textContent = count;
  if ($("pendingConfigDeviceTotal")) $("pendingConfigDeviceTotal").textContent = count;
  if ($("pendingConfigChangeTotal")) $("pendingConfigChangeTotal").textContent = Number(data.change_count || 0);
  if ($("saveAllPendingConfig")) $("saveAllPendingConfig").disabled = state.pendingSaveAllRunning || count === 0 || !actionAllowedForCurrentUser("save_config");
  const list = $("pendingConfigList");
  if (!list) return;
  list.innerHTML = (data.devices || []).map(device => {
    const changes = (device.changes || []).map(change => `<li><span><strong>${escapeHtml(actionLabel(change.action))}${change.port ? ` · ${escapeHtml(change.port)}` : ""}</strong><small>${escapeHtml(formatDate(change.created_at))} · ${escapeHtml(change.actor || t("common.unknown", {}, "Unknown"))}</small></span><code>${escapeHtml(change.command || "")}</code></li>`).join("");
    return `<article class="pending-config-device"><header><div><strong>${escapeHtml(device.device_name)}</strong><span>${escapeHtml(device.host)} · ${Number(device.change_count || 0)} ${escapeHtml(t("pending.changes", {}, "pending changes"))}</span></div><div class="pending-device-actions">${hasCapability("devices.live_ports") ? `<button class="btn secondary compact" type="button" onclick="openDeviceWorkspace(${device.device_id}); $('pendingConfigDialog').close();">${escapeHtml(t("pending.openSwitch", {}, "Open switch"))}</button>` : ""}${actionAllowedForCurrentUser("save_config") ? `<button class="btn primary compact" type="button" onclick="savePendingConfiguration(${device.device_id})">${escapeHtml(t("pending.save", {}, "Save"))}</button>` : ""}</div></header><details><summary>${escapeHtml(t("pending.viewChanges", {}, "View changes"))}</summary><ul>${changes}</ul></details></article>`;
  }).join("") || `<div class="empty-state pending-empty"><strong>${escapeHtml(t("pending.none", {}, "All configuration changes are saved."))}</strong></div>`;
}
async function openPendingConfigDialog() {
  try { await loadPendingConfiguration(); } catch (error) { toast(error.message, "error"); return; }
  $("pendingConfigDialog")?.showModal();
}
function setPendingSaveAllState(saving = false) {
  state.pendingSaveAllRunning = saving;
  const button = $("saveAllPendingConfig");
  if (!button) return;
  const label = button.querySelector("span");
  button.classList.toggle("is-saving", saving);
  button.disabled = saving || Number(state.pendingConfig?.device_count || 0) === 0 || !actionAllowedForCurrentUser("save_config");
  if (label) label.textContent = saving
    ? t("pending.savingAll", {}, "Saving...")
    : t("pending.saveAll", {}, "Save All Changes");
}
async function queuePendingSave(deviceIds, { showQueuedToast = true } = {}) {
  const uniqueIds = [...new Set(deviceIds.map(Number).filter(Number.isFinite))];
  if (!uniqueIds.length) return null;
  const response = await api("/api/execute", { method: "POST", body: {
    action: "save_config",
    targets: uniqueIds.map(device_id => ({ device_id, port: "", slot: "" })),
    dry_run: false,
    cycle_delay_seconds: 5,
    port_alias: "",
    custom_command: "",
    confirmation_text: "EXECUTE",
  }});
  if (showQueuedToast) toast(t("pending.saveQueued", { job: response.job_id }, `Save job #${response.job_id} queued`), "success");
  setTimeout(() => Promise.all([loadPendingConfiguration(), loadJobs(), loadDashboard(), loadDevices()]).catch(() => {}), 1800);
  return response;
}
window.savePendingConfiguration = async function(deviceId) {
  try { await queuePendingSave([deviceId]); } catch (error) { toast(error.message, "error"); }
};
async function saveAllPendingConfiguration() {
  if (state.pendingSaveAllRunning) return;
  const deviceIds = (state.pendingConfig.devices || []).map(device => device.device_id);
  if (!deviceIds.length) return;
  setPendingSaveAllState(true);
  try {
    const response = await queuePendingSave(deviceIds, { showQueuedToast: false });
    if (!response?.job_id) return;
    const detail = await waitForWorkspaceJob(response.job_id, 180000);
    await Promise.all([loadPendingConfiguration(), loadJobs(), loadDashboard(), loadDevices()]);
    const status = detail.job?.status;
    if (status === "completed") {
      $("pendingConfigDialog")?.close();
      toast(t("pending.saveAllSuccess", {}, "All configuration changes were saved successfully."), "success");
      return;
    }
    if (status === "partial") {
      toast(t("pending.saveAllPartial", {}, "Some configuration changes could not be saved. Remaining unsaved changes are still shown."), "error");
      return;
    }
    toast(t("pending.saveAllFailed", {}, "Configuration save failed. Remaining unsaved changes are still shown."), "error");
  } catch (error) {
    await loadPendingConfiguration().catch(() => {});
    const message = String(error?.message || "");
    const timeoutMessage = t("workspace.jobTimeout", {}, "The operation is still running. Check Jobs for its final status.");
    toast(message === timeoutMessage ? t("pending.saveAllTimeout", {}, "Saving is still running. Check Jobs for the final status.") : message, "error");
  } finally {
    setPendingSaveAllState(false);
  }
}


function powerStateLabel(value) {
  const stateValue = String(value || "unknown").toLowerCase();
  const labels = {
    normal: t("power.stateNormal", {}, "Normal"), on_battery: t("power.stateOnBattery", {}, "On battery"),
    low_battery: t("power.stateLowBattery", {}, "Low battery"), depleted: t("power.stateDepleted", {}, "Battery depleted"),
    bypass: t("power.stateBypass", {}, "Bypass"), output_off: t("power.stateOutputOff", {}, "Output off"),
    unknown: t("common.unknown", {}, "Unknown"), unreachable: t("power.stateOffline", {}, "Offline"),
    booster: t("power.stateBooster", {}, "Booster"), reducer: t("power.stateReducer", {}, "Reducer"), other: t("common.unknown", {}, "Unknown"),
  };
  return labels[stateValue] || stateValue.replaceAll("_", " ");
}
function powerIncidentLabel(value) {
  const labels = {
    ups_on_battery: t("notifications.upsOnBattery", {}, "UPS on battery"),
    ups_low_battery: t("notifications.upsLowBattery", {}, "UPS low battery"),
    ups_unreachable: t("power.upsOfflineIncident", {}, "UPS offline"),
  };
  return labels[String(value || "")] || String(value || "Power event").replaceAll("_", " ");
}
function powerTelemetryValue(value, suffix = "") {
  return value === null || value === undefined || value === "" ? "—" : `${value}${suffix}`;
}
const BUILTIN_POWER_DRIVER_CATALOG = [
  { key:"auto", name:"Auto detect", protocol:"Identity-first SNMPv3 resolver + RFC 1628 fallback", models:"XPPC, Vertiv/Liebert, Socomec, AccuLine, APC, Eaton, CyberPower and Riello" },
  { key:"generic", name:"Generic UPS-MIB", protocol:"IETF RFC 1628 UPS-MIB", models:"Any RFC 1628 UPS-MIB device" },
  { key:"xppc", name:"Phoenixtec / XPPC", protocol:"Phoenixtec XPPC-MIB + RFC 1628", models:"XPPC-compatible / white-label UPS network cards" },
  { key:"vertiv", name:"Vertiv / Liebert", protocol:"Liebert Global Products MIB + RFC 1628", models:"GXT5, GXE, ITA2, EXM2, EXS, APM2, Trinergy, MTP" },
  { key:"socomec", name:"Socomec / NET VISION / OFYS-RT", protocol:"NET VISION / RT VISION SNMPv3 + RFC 1628", models:"OFYS-RT, NETYS, ITYS, MASTERYS, MODULYS, DELPHYS" },
  { key:"acculine", name:"AccuLine TNmax", protocol:"AccuLine SNMP card + RFC 1628", models:"TNmax series" },
  { key:"cyberpower", name:"CyberPower / RMCARD", protocol:"CyberPower RMCARD SNMP + RFC 1628", models:"RMCARD-managed CyberPower UPS families" },
  { key:"riello", name:"Riello UPS / NetMan", protocol:"Riello NetMan SNMP + RFC 1628", models:"NetMan 204 / NetMan 208 managed Riello UPS" },
  { key:"apc", name:"APC PowerNet", protocol:"APC PowerNet + RFC 1628", models:"Smart-UPS, Easy UPS, Symmetra, Galaxy" },
  { key:"eaton", name:"Eaton xUPS", protocol:"Eaton PowerMIB xUPS + RFC 1628", models:"Eaton / Powerware xUPS families" },
];
function mergePowerDriverCatalog(rows = []) {
  const map = new Map(BUILTIN_POWER_DRIVER_CATALOG.map(item => [item.key, { ...item }]));
  for (const item of (Array.isArray(rows) ? rows : [])) {
    const key = String(item?.key || "").toLowerCase();
    if (!key) continue;
    map.set(key, { ...(map.get(key) || {}), ...item, key });
  }
  return BUILTIN_POWER_DRIVER_CATALOG.map(item => map.get(item.key)).filter(Boolean);
}

function powerDriverLabel(key) {
  const normalized = String(key || "generic").toLowerCase();
  const catalog = Array.isArray(state.power?.drivers) ? state.power.drivers : [];
  const match = catalog.find(item => String(item.key || "").toLowerCase() === normalized);
  if (match?.name) return match.name;
  return normalized === "apc" ? "APC PowerNet" : normalized === "eaton" ? "Eaton xUPS" : normalized === "xppc" ? "Phoenixtec / XPPC" : normalized === "vertiv" ? "Vertiv / Liebert" : normalized === "socomec" ? "Socomec / NET VISION / OFYS-RT" : normalized === "acculine" ? "AccuLine TNmax" : normalized === "cyberpower" ? "CyberPower / RMCARD" : normalized === "riello" ? "Riello UPS / NetMan" : normalized === "auto" ? t("power.driverAuto", {}, "Auto detect") : t("power.driverGeneric", {}, "Generic UPS-MIB");
}
async function ensurePowerData(force = false) {
  if (!hasCapability("power.view")) return state.power;
  if (!force && Array.isArray(state.power?.ups) && state.power.ups.length) return state.power;
  const data = await api("/api/power");
  state.power = { ...state.power, ...data };
  state.drivers.power = mergePowerDriverCatalog(Array.isArray(data.drivers) ? data.drivers : state.drivers.power);
  state.power.drivers = state.drivers.power;
  return state.power;
}

function populatePowerFilterOptions() {
  const rows = Array.isArray(state.power?.ups) ? state.power.ups : [];
  const sites = [...new Set(rows.map(item => String(item.site || "").trim()).filter(Boolean))].sort((a,b) => a.localeCompare(b));
  const drivers = [...new Map(rows.map(item => [
    String(item.driver_key || item.driver_mode || "generic"),
    item.driver_name || powerDriverLabel(item.driver_key || item.driver_mode),
  ])).entries()].map(([key,name]) => ({ key,name })).sort((a,b) => a.name.localeCompare(b.name));

  const siteSelect = $("powerUpsSiteFilter");
  const driverSelect = $("powerUpsDriverFilter");
  const siteCurrent = siteSelect?.value || "";
  const driverCurrent = driverSelect?.value || "";
  if (siteSelect) {
    const first = siteSelect.options?.[0]?.outerHTML || '<option value="">All sites</option>';
    siteSelect.innerHTML = first + sites.map(site => `<option value="${escapeHtml(site)}">${escapeHtml(site)}</option>`).join("");
    if (sites.includes(siteCurrent)) siteSelect.value = siteCurrent;
  }
  if (driverSelect) {
    const first = driverSelect.options?.[0]?.outerHTML || '<option value="">All drivers</option>';
    driverSelect.innerHTML = first + drivers.map(item => `<option value="${escapeHtml(item.key)}">${escapeHtml(item.name)}</option>`).join("");
    if (drivers.some(item => item.key === driverCurrent)) driverSelect.value = driverCurrent;
  }
}

function powerUpsHealthKey(ups) {
  if (String(ups.last_status || "unknown").toLowerCase() === "unreachable") return "offline";
  const stateValue = String(ups.power_state || "unknown").toLowerCase();
  if (["normal", "on_battery", "low_battery"].includes(stateValue)) return stateValue;
  if (stateValue === "depleted") return "low_battery";
  return "other";
}

function powerUpsMatchesHealth(ups, health) {
  if (!health) return true;
  const connection = String(ups.last_status || "unknown").toLowerCase();
  const stateValue = String(ups.power_state || "unknown").toLowerCase();
  const severity = String(ups.severity || "unknown").toLowerCase();
  if (health === "offline") return connection === "unreachable";
  if (health === "normal") return connection === "online" && stateValue === "normal";
  if (health === "on_battery") return connection === "online" && ["on_battery", "low_battery", "depleted"].includes(stateValue);
  if (health === "low_battery") return connection === "online" && ["low_battery", "depleted"].includes(stateValue);
  if (health === "critical") return severity === "critical";
  if (health === "other") return connection !== "unreachable" && powerUpsHealthKey(ups) === "other";
  return powerUpsHealthKey(ups) === health;
}

function filteredPowerUps() {
  const query = String($("powerUpsSearch")?.value || "").trim().toLowerCase();
  const site = String($("powerUpsSiteFilter")?.value || "");
  const health = String($("powerUpsHealthFilter")?.value || "");
  const driver = String($("powerUpsDriverFilter")?.value || "");
  const metricFilter = String(state.power?.inventoryMetricFilter || "");
  return (state.power?.ups || []).filter(ups => {
    if (site && String(ups.site || "") !== site) return false;
    if (!powerUpsMatchesHealth(ups, health)) return false;
    if (metricFilter === "protected" && Number(ups.protected_switch_count || 0) <= 0) return false;
    const driverKey = String(ups.driver_key || ups.driver_mode || "generic");
    if (driver && driverKey !== driver) return false;
    if (!query) return true;
    const haystack = [
      ups.name, ups.host, ups.site, ups.group_name, ups.location,
      ups.manufacturer, ups.model, ups.driver_name, driverKey,
      ups.power_state, ups.last_status,
    ].join(" ").toLowerCase();
    return haystack.includes(query);
  });
}

function bindPowerMetricCard(id, action) {
  const card = $(id);
  if (!card) return;
  card.addEventListener("click", action);
  card.addEventListener("keydown", event => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    action();
  });
}

function resetPowerInventoryControls() {
  for (const id of ["powerUpsSearch", "powerUpsSiteFilter", "powerUpsHealthFilter", "powerUpsDriverFilter"]) {
    if ($(id)) $(id).value = "";
  }
  if (state.power) state.power.inventoryMetricFilter = "";
}

function scrollToPowerUpsInventory() {
  $("powerUpsGrid")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function showAllPowerUps() {
  resetPowerInventoryControls();
  renderPowerInfrastructure();
  scrollToPowerUpsInventory();
}

function filterPowerUpsByHealth(health) {
  resetPowerInventoryControls();
  const filter = $("powerUpsHealthFilter");
  if (filter) filter.value = String(health || "");
  renderPowerInfrastructure();
  scrollToPowerUpsInventory();
}

function filterPowerUpsByMetric(metric) {
  resetPowerInventoryControls();
  if (state.power) state.power.inventoryMetricFilter = String(metric || "");
  renderPowerInfrastructure();
  scrollToPowerUpsInventory();
}

function clearPowerUpsFilters() {
  resetPowerInventoryControls();
  renderPowerInfrastructure();
}

function powerIncidentQuery() {
  const params = new URLSearchParams();
  const values = {
    search: String($("powerIncidentSearch")?.value || "").trim(),
    status: String($("powerIncidentStatusFilter")?.value || ""),
    incident_type: String($("powerIncidentTypeFilter")?.value || ""),
    ups_id: String($("powerIncidentUpsFilter")?.value || ""),
    page: String(state.powerHistoryUi.page || 1),
  };
  Object.entries(values).forEach(([key,value]) => {
    if (value && !(key === "page" && value === "1")) params.set(key,value);
  });
  return params.toString();
}

function populatePowerIncidentFilterOptions(options = state.power?.incidentFilterOptions || {}) {
  const typeSelect = $("powerIncidentTypeFilter");
  const upsSelect = $("powerIncidentUpsFilter");
  const types = Array.isArray(options.types) ? options.types : [];
  const ups = Array.isArray(options.ups) ? options.ups : [];
  const currentType = typeSelect?.value || "";
  const currentUps = upsSelect?.value || "";
  if (typeSelect) {
    const first = typeSelect.options?.[0]?.outerHTML || '<option value="">All events</option>';
    typeSelect.innerHTML = first + types.map(kind => `<option value="${escapeHtml(kind)}">${escapeHtml(powerIncidentLabel(kind))}</option>`).join("");
    if (types.includes(currentType)) typeSelect.value = currentType;
  }
  if (upsSelect) {
    const first = upsSelect.options?.[0]?.outerHTML || '<option value="">All UPS</option>';
    upsSelect.innerHTML = first + ups.map(item => `<option value="${Number(item.id)}">${escapeHtml(item.name)}${item.site ? ` · ${escapeHtml(item.site)}` : ""}</option>`).join("");
    if (ups.some(item => String(item.id) === currentUps)) upsSelect.value = currentUps;
  }
}

async function loadPowerIncidents({ resetPage = false } = {}) {
  if (!hasCapability("power.view")) return;
  if (resetPage) state.powerHistoryUi.page = 1;
  const query = powerIncidentQuery();
  const data = await api(`/api/power/incidents${query ? `?${query}` : ""}`);
  state.power.incidentHistory = Array.isArray(data.items) ? data.items : [];
  state.power.incidentFilterOptions = data.filter_options || { types: [], ups: [] };
  const paging = data.pagination || {};
  state.powerHistoryUi.page = Number(paging.page || 1);
  state.powerHistoryUi.pages = Number(paging.pages || 1);
  state.powerHistoryUi.total = Number(paging.total || 0);
  state.powerHistoryUi.pageSize = 25;
  populatePowerIncidentFilterOptions(state.power.incidentFilterOptions);
  renderPowerIncidents();
}

function schedulePowerIncidentReload() {
  window.clearTimeout(state.powerFilterTimer);
  state.powerFilterTimer = window.setTimeout(() => {
    loadPowerIncidents({ resetPage: true }).catch(error => toast(error.message, "error"));
  }, 220);
}

function clearPowerIncidentFilters() {
  for (const id of ["powerIncidentSearch", "powerIncidentStatusFilter", "powerIncidentTypeFilter", "powerIncidentUpsFilter"]) {
    if ($(id)) $(id).value = "";
  }
  loadPowerIncidents({ resetPage: true }).catch(error => toast(error.message, "error"));
}

function changePowerIncidentPage(delta) {
  const next = Math.max(1, Math.min(
    Number(state.powerHistoryUi.pages || 1),
    Number(state.powerHistoryUi.page || 1) + Number(delta || 0),
  ));
  if (next === state.powerHistoryUi.page) return;
  state.powerHistoryUi.page = next;
  loadPowerIncidents().catch(error => toast(error.message, "error"));
}

async function loadPowerInfrastructure() {
  if (!hasCapability("power.view")) return;
  const requests = [api("/api/power")];
  if (["power.create", "power.edit", "power.verify"].some(hasCapability)) requests.push(api("/api/power/monitoring-profiles"));
  const [data, profiles = state.power.profiles || []] = await Promise.all(requests);
  state.power = { ...state.power, ...data, profiles };
  state.drivers.power = Array.isArray(data.drivers) ? data.drivers : state.drivers.power;
  populatePowerFilterOptions();
  await loadPowerIncidents();
  renderPowerInfrastructure();
}

function renderPowerInfrastructure() {
  const summary = state.power?.summary || {};
  const powerPolicy = state.power?.monitoring_policy || { mode: "full", effective: { power_ups: true } };
  const powerMonitoringPaused = powerPolicy.mode === "management_only" || powerPolicy.effective?.power_ups === false;
  if ($("powerMetricTotal")) $("powerMetricTotal").textContent = Number(summary.ups_total || 0);
  if ($("powerMetricNormal")) $("powerMetricNormal").textContent = powerMonitoringPaused ? "—" : Number(summary.ups_normal || 0);
  if ($("powerMetricBattery")) $("powerMetricBattery").textContent = powerMonitoringPaused ? "—" : Number(summary.ups_on_battery || 0);
  if ($("powerMetricCritical")) $("powerMetricCritical").textContent = powerMonitoringPaused ? "—" : Number(summary.ups_critical || 0);
  if ($("powerMetricOffline")) $("powerMetricOffline").textContent = powerMonitoringPaused ? "—" : Number(summary.ups_offline || 0);
  if ($("powerMetricProtected")) $("powerMetricProtected").textContent = Number(summary.protected_switches || 0);
  document.querySelectorAll(".power-create-only").forEach(el => el.classList.toggle("hidden", !hasCapability("power.create")));
  const attention = powerMonitoringPaused ? 0 : Number(summary.ups_warning || 0) + Number(summary.ups_critical || 0);
  if ($("powerNavCount")) {
    $("powerNavCount").textContent = String(attention);
    $("powerNavCount").classList.toggle("hidden", attention <= 0);
  }
  const monitor = state.power?.monitor || {};
  if ($("powerMonitorState")) {
    $("powerMonitorState").textContent = powerMonitoringPaused
      ? (monitor.last_cycle_at
        ? t("monitoringMode.powerPausedLastScan", { time: formatDate(monitor.last_cycle_at) }, `Monitoring paused · last scan ${formatDate(monitor.last_cycle_at)}`)
        : t("monitoringMode.powerPaused", {}, "Monitoring paused"))
      : (monitor.last_cycle_at
        ? t("power.lastScan", { time: formatDate(monitor.last_cycle_at) }, `Last scan ${formatDate(monitor.last_cycle_at)}`)
        : t("power.waitingScan", {}, "Waiting for first scan"));
  }
  const grid = $("powerUpsGrid");
  if (grid) {
    const allRows = state.power?.ups || [];
    const rows = filteredPowerUps();
    if ($("powerUpsResultSummary")) {
      const metricSuffix = String(state.power?.inventoryMetricFilter || "") === "protected" ? ` · ${t("power.protectedUpsFilter", {}, "with protected switches")}` : "";
      $("powerUpsResultSummary").textContent = t("power.upsResult", { count: rows.length }, `${rows.length} UPS`) + (rows.length !== allRows.length ? ` · ${allRows.length} total` : "") + metricSuffix;
    }
    grid.innerHTML = rows.map(ups => {
      const severity = String(ups.severity || "unknown");
      const communicationOffline = String(ups.last_status || "unknown") === "unreachable";
      const statusState = communicationOffline ? "unreachable" : String(ups.power_state || "unknown");
      const pausedBadge = powerMonitoringPaused;
      const platform = [ups.manufacturer, ups.model].filter(Boolean).join(" · ") || t("power.genericUps", {}, "UPS-MIB device");
      const driverLabel = ups.driver_name || powerDriverLabel(ups.driver_key);
      const location = [ups.site, ups.group_name, ups.location].filter(Boolean).join(" · ") || t("common.noSite", {}, "No site");
      const alarms = Array.isArray(ups.alarms) ? ups.alarms.filter(Boolean) : [];
      const primaryActions = [
        `<button class="btn secondary" type="button" onclick="openUpsDetails(${Number(ups.id)})">${escapeHtml(t("power.details", {}, "Details"))}</button>`,
        hasCapability("power.assign") ? `<button class="btn secondary" type="button" onclick="openUpsAssignments(${Number(ups.id)})">${escapeHtml(t("power.manageSwitches", {}, "Manage switches"))}</button>` : "",
      ].filter(Boolean).join("");
      const menuActions = [
        hasCapability("power.verify") ? `<button type="button" onclick="this.closest('details').removeAttribute('open');verifyUpsAsset(${Number(ups.id)})">${escapeHtml(t("power.verify", {}, "Verify telemetry"))}</button>` : "",
        hasCapability("power.edit") ? `<button type="button" onclick="this.closest('details').removeAttribute('open');editUps(${Number(ups.id)})">${escapeHtml(t("common.edit", {}, "Edit"))}</button>` : "",
        hasCapability("power.delete") ? `<button class="danger" type="button" onclick="this.closest('details').removeAttribute('open');removeUps(${Number(ups.id)})">${escapeHtml(t("common.delete", {}, "Delete"))}</button>` : "",
      ].filter(Boolean).join("");
      const moreActions = menuActions ? `<details class="power-ups-menu"><summary aria-label="UPS actions" title="UPS actions"><span aria-hidden="true">•••</span></summary><div class="power-ups-menu-popover">${menuActions}</div></details>` : "";
      const actions = (primaryActions || moreActions) ? `<div class="power-ups-actions">${primaryActions}${moreActions}</div>` : "";
      return `<article class="power-ups-card ${communicationOffline ? "communication-offline" : escapeHtml(severity)}">
        <div class="power-ups-card-head"><span class="power-ups-icon"><svg><use href="#i-power"></use></svg></span><div class="power-ups-identity"><strong>${escapeHtml(ups.name)}</strong><span>${escapeHtml(ups.host)} · ${escapeHtml(location)}</span></div><span class="power-health-badge ${pausedBadge ? "paused" : (communicationOffline ? "offline" : escapeHtml(severity))}"><i></i>${escapeHtml(pausedBadge ? t("monitoringMode.paused", {}, "Monitoring paused") : powerStateLabel(statusState))}</span></div>
        ${pausedBadge ? `<div class="power-ups-paused-note">${escapeHtml(t("monitoringMode.powerLastKnown", { state: powerStateLabel(statusState) }, `Last known state: ${powerStateLabel(statusState)}. Stored telemetry and UPS assignments are preserved.`))}</div>` : (communicationOffline ? `<div class="power-ups-paused-note">${escapeHtml(t("power.communicationOfflineHelp", { state: powerStateLabel(ups.power_state || "unknown") }, `SNMP telemetry is currently unavailable. Last known power state: ${powerStateLabel(ups.power_state || "unknown")}.`))}</div>` : "")}
        <div class="power-telemetry-grid"><article><span>${escapeHtml(t("power.source", {}, "Source"))}</span><strong>${escapeHtml(powerStateLabel(ups.output_source || "unknown"))}</strong></article><article><span>${escapeHtml(t("power.battery", {}, "Battery"))}</span><strong>${escapeHtml((ups.battery_charge_percent !== null && ups.battery_charge_percent !== undefined) ? powerTelemetryValue(ups.battery_charge_percent, "%") : powerStateLabel(ups.battery_status || "unknown"))}</strong></article><article><span>${escapeHtml(t("power.runtime", {}, "Runtime"))}</span><strong>${escapeHtml(powerTelemetryValue(ups.runtime_minutes, " min"))}</strong></article><article><span>${escapeHtml(t("power.load", {}, "Load"))}</span><strong>${escapeHtml(powerTelemetryValue(ups.load_percent, "%"))}</strong></article></div>
        <div class="power-ups-meta"><span class="power-protected-count"><svg><use href="#i-device"></use></svg><strong>${Number(ups.protected_switch_count || 0)}</strong> ${escapeHtml(t("power.switches", {}, "switches"))}</span><span class="power-platform-meta"><svg><use href="#i-activity"></use></svg>${escapeHtml(platform)}</span><span class="power-driver-chip"><svg><use href="#i-settings"></use></svg>${escapeHtml(driverLabel)}</span></div>
        ${alarms.length ? `<div class="power-ups-alarms"><strong>${escapeHtml(t("power.activeAlarms", {}, "Active alarms"))}:</strong> ${escapeHtml(alarms.slice(0, 3).join(" · "))}${alarms.length > 3 ? ` · +${alarms.length - 3}` : ""}</div>` : ""}
        <div class="power-ups-footer"><small>${escapeHtml(t("power.lastChecked", {}, "Last checked"))}: ${escapeHtml(formatDate(ups.last_checked))}</small>${actions}</div>
      </article>`;
    }).join("") || `<div class="power-empty"><div><svg><use href="#i-power"></use></svg><strong>${escapeHtml(t("power.noMatchingUps", {}, "No UPS assets match these filters"))}</strong><span>${escapeHtml(t("power.noMatchingUpsHelp", {}, "Clear one or more filters to return to the full monitored power inventory."))}</span></div></div>`;
  }
  renderPowerIncidents();
}


function powerDetailsParseDate(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  let match = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (match) return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (match) {
    let year = Number(match[3]);
    if (year < 100) year += year >= 70 ? 1900 : 2000;
    return new Date(year, Number(match[1]) - 1, Number(match[2]));
  }
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function powerDetailsAgeText(value) {
  const date = powerDetailsParseDate(value);
  if (!date || date.getTime() > Date.now()) return "";
  const years = (Date.now() - date.getTime()) / (365.2425 * 86400000);
  if (years >= 1) return `${years.toFixed(years >= 10 ? 0 : 1)} years`;
  const months = Math.max(0, Math.round(years * 12));
  if (months >= 1) return `${months} months`;
  const days = Math.max(0, Math.round(years * 365.2425));
  return `${days} days`;
}

function powerDetailsWithDerivedMetrics(telemetry) {
  const result = {};
  for (const [section, items] of Object.entries(telemetry || {})) result[section] = Array.isArray(items) ? items.map(item => ({ ...item })) : [];
  const findMetric = key => Object.values(result).flat().find(item => item?.key === key);
  const batteryDate = findMetric("battery_last_replaced")?.value;
  const batteryAge = powerDetailsAgeText(batteryDate);
  if (batteryAge) {
    result.battery ||= [];
    result.battery.splice(1, 0, { key: "battery_age", label: "Battery age", value: batteryAge, unit: "", source: "Calculated from replacement date" });
  }
  const manufactureDate = findMetric("manufacture_date")?.value;
  const upsAge = powerDetailsAgeText(manufactureDate);
  if (upsAge) {
    result.identity ||= [];
    result.identity.push({ key: "ups_age", label: "UPS age", value: upsAge, unit: "", source: "Calculated from manufacture date" });
  }
  return result;
}

function powerDetailsMetricValue(metric) {
  const value = metric?.value;
  if (value === null || value === undefined || value === "") return "—";
  let formatted = value;
  if (typeof value === "number") formatted = Number.isInteger(value) ? String(value) : value.toLocaleString(undefined, { maximumFractionDigits: 2 });
  return `${formatted}${metric?.unit ? ` ${metric.unit}` : ""}`;
}

function powerDetailsSectionMeta(section) {
  return {
    identity: ["DEVICE IDENTITY", "Identity & platform"],
    battery: ["BATTERY SYSTEM", "Battery health"],
    input: ["UTILITY INPUT", "Input power"],
    output: ["UPS OUTPUT", "Output & load"],
    bypass: ["BYPASS PATH", "Bypass"],
    environment: ["ENVIRONMENT", "Environmental sensors"],
    diagnostics: ["DIAGNOSTICS", "Tests & health"],
    monitoring: ["MONITORING", "Collection details"],
  }[section] || [String(section || "TELEMETRY").toUpperCase(), String(section || "Telemetry")];
}

function renderUpsDetails(payload, { live = false } = {}) {
  if (!payload) return;
  state.powerDetailsPayload = payload;
  const ups = payload.ups || (state.power?.ups || []).find(item => Number(item.id) === Number(state.powerDetailsUpsId)) || {};
  const current = payload.live || ups;
  const statusState = String(current.last_status || ups.last_status || "unknown") === "unreachable" ? "unreachable" : String(current.power_state || ups.power_state || "unknown");
  const severity = String(ups.severity || (statusState === "normal" ? "healthy" : "warning"));
  const healthClass = statusState === "unreachable" ? "offline" : severity;
  if ($("upsDetailsTitle")) $("upsDetailsTitle").textContent = `${t("power.details", {}, "UPS details")} · ${ups.name || "UPS"}`;
  if ($("upsDetailsName")) $("upsDetailsName").textContent = ups.name || "UPS";
  if ($("upsDetailsMeta")) $("upsDetailsMeta").textContent = [ups.host, ups.site, ups.group_name, ups.location].filter(Boolean).join(" · ");
  const health = $("upsDetailsHealth");
  if (health) {
    health.className = `power-health-badge ${healthClass}`;
    health.innerHTML = `<i></i><span>${escapeHtml(powerStateLabel(statusState))}</span>`;
  }
  const summary = $("upsDetailsSummary");
  if (summary) {
    const hasLive = Boolean(payload.live);
    const battery = hasLive && Object.prototype.hasOwnProperty.call(current, "battery_charge_percent") ? current.battery_charge_percent : ups.battery_charge_percent;
    const runtime = hasLive && Object.prototype.hasOwnProperty.call(current, "runtime_minutes") ? current.runtime_minutes : ups.runtime_minutes;
    const load = hasLive && Object.prototype.hasOwnProperty.call(current, "load_percent") ? current.load_percent : ups.load_percent;
    const source = hasLive && Object.prototype.hasOwnProperty.call(current, "output_source") ? current.output_source : ups.output_source;
    summary.innerHTML = [
      ["Power source", powerStateLabel(source || "unknown"), "Current UPS output source"],
      ["Battery", battery !== null && battery !== undefined ? `${battery}%` : powerStateLabel(current.battery_status || ups.battery_status || "unknown"), "Available capacity"],
      ["Runtime", runtime !== null && runtime !== undefined ? `${runtime} min` : "—", "Estimated at present load"],
      ["Load", load !== null && load !== undefined ? `${load}%` : "—", "Current UPS output load"],
    ].map(([label, value, help]) => `<article><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value))}</strong><small>${escapeHtml(help)}</small></article>`).join("");
  }

  const telemetry = powerDetailsWithDerivedMetrics(payload.telemetry || {});
  const sections = $("upsDetailsSections");
  if (sections) {
    const metricClass = (index, count, columns) => {
      const remainder = count % columns;
      if (!remainder) return "";
      const tailStart = count - remainder;
      if (index < tailStart) return "";
      if (columns === 2 && remainder === 1) return " metric-span-all";
      if (columns === 4 && remainder === 1) return " metric-span-all";
      if (columns === 4 && remainder === 2) return " metric-span-half";
      return "";
    };
    const renderSection = (section, wide = false) => {
      const items = telemetry[section] || [];
      if (!items.length) return "";
      const [kicker, title] = powerDetailsSectionMeta(section);
      const columns = wide ? 4 : 2;
      const rows = items.map((metric, index) => `<article class="power-details-metric${metricClass(index, items.length, columns)}"><span>${escapeHtml(metric.label || metric.key || "Metric")}</span><strong>${escapeHtml(powerDetailsMetricValue(metric))}</strong>${metric.source ? `<small>${escapeHtml(metric.source)}</small>` : ""}</article>`).join("");
      return `<section class="power-details-section${wide ? " power-details-section-wide" : ""}"><div class="power-details-section-head"><div><span class="section-kicker">${escapeHtml(kicker)}</span><strong>${escapeHtml(title)}</strong></div><span>${items.length} ${items.length === 1 ? "metric" : "metrics"}</span></div><div class="power-details-metrics${wide ? " is-wide" : ""}">${rows}</div></section>`;
    };
    const renderPair = (left, right) => {
      const cards = [renderSection(left), renderSection(right)].filter(Boolean);
      if (!cards.length) return "";
      return `<div class="power-details-section-row${cards.length === 1 ? " single" : ""}">${cards.join("")}</div>`;
    };
    const blocks = [
      (telemetry.identity || []).length ? `<div class="power-details-section-row single">${renderSection("identity", true)}</div>` : "",
      renderPair("battery", "diagnostics"),
      renderPair("input", "output"),
      renderPair("bypass", "environment"),
      (telemetry.monitoring || []).length ? `<div class="power-details-section-row single">${renderSection("monitoring", true)}</div>` : "",
    ].filter(Boolean);
    sections.innerHTML = blocks.join("") || `<div class="power-details-empty">${escapeHtml(t("power.noDetailedTelemetry", {}, "No detailed telemetry has been collected yet."))}</div>`;
  }

  const switches = Array.isArray(payload.protected_switches) ? payload.protected_switches : [];
  if ($("upsDetailsProtectedCount")) $("upsDetailsProtectedCount").textContent = String(switches.length);
  if ($("upsDetailsSwitches")) $("upsDetailsSwitches").innerHTML = switches.map(item => `<article class="power-details-switch-item"><div><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml([item.host, item.group_name].filter(Boolean).join(" · "))}</span></div><span class="power-details-mini-state ${escapeHtml(item.last_status || "unknown")}">${escapeHtml(String(item.last_status || "unknown").replaceAll("_", " "))}</span></article>`).join("") || `<div class="power-details-empty">${escapeHtml(t("power.noProtectedSwitches", {}, "No switches are assigned to this UPS."))}</div>`;

  const incidents = Array.isArray(payload.recent_incidents) ? payload.recent_incidents : [];
  if ($("upsDetailsIncidents")) $("upsDetailsIncidents").innerHTML = incidents.map(item => {
    const communicationEvent = String(item.incident_type || "") === "ups_unreachable";
    const stateText = communicationEvent
      ? (item.status === "closed" ? t("power.communicationRestored", {}, "Communication restored") : t("power.offline", {}, "Offline"))
      : (item.status === "closed" ? t("power.recovered", {}, "Recovered") : t("power.active", {}, "Active"));
    return `<article class="power-details-incident-item"><div><strong>${escapeHtml(powerIncidentLabel(item.incident_type))}</strong><span>${escapeHtml(formatDate(item.recovered_at || item.opened_at))}</span></div><span class="power-details-mini-state ${escapeHtml(item.status || "open")}${communicationEvent ? " info" : ""}">${escapeHtml(stateText)}</span></article>`;
  }).join("") || `<div class="power-details-empty">${escapeHtml(t("power.noIncidents", {}, "No power incidents recorded yet."))}</div>`;

  const status = $("upsDetailsStatus");
  if (status) {
    const metricCount = Object.values(telemetry).reduce((total, items) => total + (Array.isArray(items) ? items.length : 0), 0);
    status.className = `power-details-status${live ? " live" : ""}`;
    if (live) status.textContent = `Live read-only telemetry collected · ${metricCount} reported metrics · ${formatDate(payload.telemetry_updated_at)}`;
    else if (payload.telemetry_updated_at) status.textContent = `Last detailed telemetry: ${formatDate(payload.telemetry_updated_at)} · refreshing live data…`;
    else status.textContent = t("power.collectingDetailedTelemetry", {}, "Collecting detailed read-only telemetry from the UPS…");
  }
}

window.openUpsDetails = async function(id) {
  state.powerDetailsUpsId = Number(id);
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(id));
  if (!ups) return;
  const dialog = $("upsDetailsDialog");
  if (!dialog) return;
  renderUpsDetails({ ups, telemetry: {}, protected_switches: ups.protected_switches || [], recent_incidents: [] });
  dialog.showModal();
  try {
    const stored = await api(`/api/power/ups/${Number(id)}/details`);
    if (Number(state.powerDetailsUpsId) !== Number(id)) return;
    renderUpsDetails(stored);
  } catch (error) {
    const status = $("upsDetailsStatus");
    if (status) { status.className = "power-details-status error"; status.textContent = error.message; }
  }
  await refreshUpsDetails(id);
};

async function refreshUpsDetails(id) {
  const upsId = Number(id || 0);
  if (!upsId || Number(state.powerDetailsUpsId) !== upsId) return;
  const requestSequence = ++state.powerDetailsRefreshSequence;
  const button = $("upsDetailsRefresh");
  if (button) { button.disabled = true; button.classList.add("is-loading"); }
  const status = $("upsDetailsStatus");
  if (status) {
    status.className = "power-details-status";
    status.textContent = t("power.collectingDetailedTelemetry", {}, "Collecting detailed read-only telemetry from the UPS…");
  }
  try {
    const payload = await apiWithTimeout(`/api/power/ups/${upsId}/details/refresh`, { method: "POST" }, 60000);
    if (Number(state.powerDetailsUpsId) !== upsId || requestSequence !== state.powerDetailsRefreshSequence) return;
    renderUpsDetails(payload, { live: true });
  } catch (error) {
    if (Number(state.powerDetailsUpsId) !== upsId || requestSequence !== state.powerDetailsRefreshSequence) return;
    let fallback = null;
    try {
      fallback = await apiWithTimeout(`/api/power/ups/${upsId}/details`, {}, 8000);
      if (Number(state.powerDetailsUpsId) === upsId && requestSequence === state.powerDetailsRefreshSequence) renderUpsDetails(fallback);
      await loadPowerInfrastructure();
    } catch (_) {}
    if (status && Number(state.powerDetailsUpsId) === upsId && requestSequence === state.powerDetailsRefreshSequence) {
      const failedChecks = Number(fallback?.ups?.consecutive_failures || 0);
      const threshold = Number(state.power?.monitor?.failure_threshold || 3);
      const offline = String(fallback?.ups?.last_status || "").toLowerCase() === "unreachable";
      const checkText = failedChecks > 0 && !offline ? ` · Communication check ${Math.min(failedChecks, threshold)}/${threshold} failed.` : "";
      const stateText = offline ? ` · ${t("power.offline", {}, "Offline")}.` : checkText;
      status.className = "power-details-status error";
      status.textContent = `${error.message || "Unable to collect live UPS telemetry."}${stateText}${state.powerDetailsPayload?.telemetry_updated_at ? " · Showing the last stored detailed telemetry." : ""}`;
    }
  } finally {
    if (requestSequence === state.powerDetailsRefreshSequence && button) {
      button.disabled = false;
      button.classList.remove("is-loading");
    }
  }
}

function renderPowerIncidents() {
  const incidents = $("powerIncidentList");
  const rows = state.power?.incidentHistory || [];
  if (incidents) {
    incidents.innerHTML = rows.map(item => {
      const details = item.details || {};
      const power = details.power_state ? details : (details.power || details);
      const status = String(item.status || "open");
      const communicationEvent = String(item.incident_type || "") === "ups_unreachable";
      const detailText = [
        power.reason,
        communicationEvent ? "" : (power.battery_charge_percent !== null && power.battery_charge_percent !== undefined ? `${power.battery_charge_percent}% battery` : ""),
        communicationEvent ? "" : (power.runtime_minutes !== null && power.runtime_minutes !== undefined ? `${power.runtime_minutes} min runtime` : ""),
      ].filter(Boolean).join(" · ");
      const incidentState = communicationEvent
        ? (status === "open" ? t("power.offline", {}, "Offline") : t("power.communicationRestored", {}, "Communication restored"))
        : (status === "open" ? t("power.active", {}, "Active") : t("power.recovered", {}, "Recovered"));
      return `<article class="power-incident-item ${status}${communicationEvent ? " info" : ""}"><span class="power-incident-icon"><svg><use href="#i-activity"></use></svg></span><div class="power-incident-copy"><strong>${escapeHtml(item.ups_name || "UPS")} · ${escapeHtml(powerIncidentLabel(item.incident_type))}</strong><span>${escapeHtml(detailText || (status === "open" ? t("power.incidentOpen", {}, "Active power condition") : t("power.incidentClosed", {}, "Power condition recovered")))}</span></div><span class="power-incident-state ${status}${communicationEvent ? " info" : ""}">${escapeHtml(incidentState)}</span><span class="power-incident-time">${escapeHtml(formatDate(item.recovered_at || item.opened_at))}</span></article>`;
    }).join("") || `<div class="empty-state">${escapeHtml(t("power.noIncidents", {}, "No power incidents recorded yet."))}</div>`;
  }
  const total = Number(state.powerHistoryUi.total || 0);
  const page = Number(state.powerHistoryUi.page || 1);
  const pages = Number(state.powerHistoryUi.pages || 1);
  if ($("powerIncidentResultSummary")) $("powerIncidentResultSummary").textContent = t("power.incidentResult", { count: total }, `${total} incidents`);
  if ($("powerIncidentPageLabel")) $("powerIncidentPageLabel").textContent = t("power.pageLabel", { page, pages }, `Page ${page} of ${pages}`);
  if ($("powerIncidentPrevPage")) $("powerIncidentPrevPage").disabled = page <= 1;
  if ($("powerIncidentNextPage")) $("powerIncidentNextPage").disabled = page >= pages;
}

function switchDriverDescription(item) {
  const profile = String(item?.profile || "").toUpperCase();
  if (profile === "AOS6") return t("drivers.aos6Help", {}, "Alcatel-Lucent Enterprise OmniSwitch AOS 6 driver for platform detection, validated CLI rendering and learned capability behavior.");
  if (profile === "AOS8") return t("drivers.aos8Help", {}, "Alcatel-Lucent Enterprise OmniSwitch AOS 8 driver for platform detection, validated CLI rendering and learned capability behavior.");
  return t("drivers.unavailable", {}, "Driver metadata");
}

function powerDriverDescription(item) {
  const key = String(item?.key || "generic").toLowerCase();
  if (key === "auto") return t("drivers.autoDetectHelp", {}, "Identity-first resolver that selects Phoenixtec/XPPC, Vertiv/Liebert, Socomec, AccuLine, APC, Eaton, CyberPower, Riello or RFC 1628 from live SNMP evidence.");
  if (key === "xppc") return t("drivers.xppcHelp", {}, "Phoenixtec XPPC-MIB telemetry for model, runtime, battery, input/output and load, with RFC 1628 fallback.");
  if (key === "apc") return t("drivers.apcHelp", {}, "Schneider Electric / APC PowerNet enrichment layered over RFC 1628 for APC-specific telemetry.");
  if (key === "eaton") return t("drivers.eatonHelp", {}, "Eaton PowerMIB xUPS enrichment layered over RFC 1628 for Eaton-specific telemetry.");
  if (key === "vertiv") return t("drivers.vertivHelp", {}, "Vertiv / Liebert Global Products MIB enrichment layered over RFC 1628 for power, battery, electrical, environment and alarm telemetry.");
  if (key === "socomec") return t("drivers.socomecHelp", {}, "Socomec OFYS-RT, NET VISION and RT VISION identity-aware SNMPv3 driver using the standards-based RFC 1628 UPS telemetry exposed by Socomec WEB/SNMP interfaces.");
  if (key === "acculine") return t("drivers.acculineHelp", {}, "AccuLine TNmax identity-aware SNMPv3 driver using the UPS network card RFC 1628 telemetry path.");
  if (key === "cyberpower") return t("drivers.cyberpowerHelp", {}, "CyberPower RMCARD identity-aware SNMPv3 driver using RFC 1628 telemetry with vendor identity detection.");
  if (key === "riello") return t("drivers.rielloHelp", {}, "Riello NetMan identity-aware SNMPv3 driver using RFC 1628 telemetry, with private-MIB expansion ready for supported cards.");
  return t("drivers.genericHelp", {}, "Standards-based UPS driver using IETF RFC 1628 UPS-MIB.");
}

function renderDriversView() {
  const switchGrid = $("switchDriverGrid");
  const powerGrid = $("powerDriverGrid");
  if (switchGrid) {
    const rows = Array.isArray(state.drivers.switches) ? state.drivers.switches : [];
    switchGrid.innerHTML = rows.map(item => {
      const caps = Array.isArray(item.capabilities) ? item.capabilities : [];
      return `<article class="driver-card"><div class="driver-card-head"><span class="driver-card-icon"><svg><use href="#i-device"></use></svg></span><div><strong>${escapeHtml(item.profile || item.os_family || item.key || "Switch driver")}</strong><span>${escapeHtml(item.vendor || "Network platform")}</span></div><span class="driver-family-badge">${escapeHtml(item.os_family || "OS")}</span></div><p>${escapeHtml(switchDriverDescription(item))}</p><div class="driver-facts"><span><small>${escapeHtml(t("drivers.profile", {}, "Profile"))}</small><strong>${escapeHtml(item.profile || "—")}</strong></span><span><small>${escapeHtml(t("drivers.transport", {}, "Transport"))}</small><strong>${escapeHtml(item.netmiko_device_type || "SSH")}</strong></span><span><small>${escapeHtml(t("drivers.capabilities", {}, "capabilities"))}</small><strong>${caps.length}</strong></span></div></article>`;
    }).join("") || `<div class="empty-state">${escapeHtml(t("drivers.unavailable", {}, "No driver metadata is available for your current access scope."))}</div>`;
  }
  if (powerGrid) {
    const rows = mergePowerDriverCatalog(state.drivers.power);
    powerGrid.innerHTML = rows.map(item => `<article class="driver-card"><div class="driver-card-head"><span class="driver-card-icon power"><svg><use href="#i-power"></use></svg></span><div><strong>${escapeHtml(item.name || item.key || "UPS driver")}</strong><span>${escapeHtml(item.key === "auto" ? "Driver resolver" : "Read-only SNMPv3")}</span></div><span class="driver-family-badge">${escapeHtml(item.key === "auto" ? "AUTO" : "UPS")}</span></div><p>${escapeHtml(powerDriverDescription(item))}</p><div class="driver-facts power"><span><small>${escapeHtml(t("drivers.protocol", {}, "Protocol"))}</small><strong>${escapeHtml(item.protocol || "RFC 1628")}</strong></span><span class="models"><small>${escapeHtml(t("drivers.models", {}, "Families"))}</small><strong>${escapeHtml(item.models || "Standards-compatible UPS")}</strong></span></div></article>`).join("") || `<div class="empty-state">${escapeHtml(t("drivers.unavailable", {}, "No driver metadata is available for your current access scope."))}</div>`;
  }
}

async function loadDriversView() {
  if (!hasCapability("drivers.view")) return;
  const [switchDrivers, powerDrivers] = await Promise.all([
    api("/api/platform/drivers"),
    api("/api/platform/drivers/power"),
  ]);
  state.drivers.switches = Array.isArray(switchDrivers) ? switchDrivers : [];
  state.drivers.power = mergePowerDriverCatalog(powerDrivers);
  renderDriversView();
}

async function runPowerScan() {
  if (!hasCapability("power.view")) return;
  const button = $("powerScanButton");
  if (button) button.disabled = true;
  try {
    await api("/api/power/scan", { method: "POST" });
    toast(t("power.scanQueued", {}, "Power scan queued"), "success");
    window.setTimeout(() => loadPowerInfrastructure().catch(() => {}), 1200);
  } catch (error) { toast(error.message, "error"); }
  finally { if (button) button.disabled = false; }
}
function resetUpsDetected(snapshot = null) {
  if ($("upsDetectedModel")) $("upsDetectedModel").textContent = snapshot ? ([snapshot.manufacturer, snapshot.model].filter(Boolean).join(" · ") || t("power.genericUps", {}, "UPS-MIB device")) : t("power.notVerified", {}, "Not verified");
  if ($("upsDetectedDriver")) $("upsDetectedDriver").textContent = snapshot ? (snapshot.driver_name || powerDriverLabel(snapshot.driver_key || snapshot.driver_mode)) : t("power.notVerified", {}, "Not verified");
  if ($("upsDetectedState")) $("upsDetectedState").textContent = snapshot ? powerStateLabel(snapshot.power_state) : t("common.unknown", {}, "Unknown");
  if ($("upsDetectedBattery")) $("upsDetectedBattery").textContent = snapshot ? ((snapshot.battery_charge_percent !== null && snapshot.battery_charge_percent !== undefined) ? powerTelemetryValue(snapshot.battery_charge_percent, "%") : powerStateLabel(snapshot.battery_status || "unknown")) : t("common.unknown", {}, "Unknown");
}
function populateUpsProfiles(selected = null) {
  const select = $("upsMonitoringProfile"); if (!select) return;
  const profiles = state.power?.profiles || [];
  select.innerHTML = `<option value="">${escapeHtml(t("power.selectCredential", {}, "Select a monitoring profile"))}</option>` + profiles.map(profile => `<option value="${Number(profile.id)}">${escapeHtml(profile.name)} · ${escapeHtml(String(profile.snmp_auth_protocol || "SHA"))}/${escapeHtml(String(profile.snmp_priv_protocol || "AES"))}</option>`).join("");
  if (selected && profiles.some(profile => Number(profile.id) === Number(selected))) select.value = String(selected);
}
window.verifyUpsAsset = async function(id) {
  if (!hasCapability("power.verify")) return;
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(id));
  if (!ups) return;
  try {
    const result = await api("/api/power/verify", { method:"POST", body:{ host:ups.host, monitoring_profile_id:Number(ups.monitoring_profile_id || 0), driver_mode:String(ups.driver_mode || "auto") } });
    const details = [result.driver_name || powerDriverLabel(result.driver_key), result.battery_charge_percent !== null && result.battery_charge_percent !== undefined ? `${result.battery_charge_percent}% battery` : "", result.runtime_minutes !== null && result.runtime_minutes !== undefined ? `${result.runtime_minutes} min runtime` : ""].filter(Boolean).join(" · ");
    toast(`${ups.name}: ${details || t("power.verified", {}, "SNMPv3 UPS-MIB telemetry verified successfully.")}`, "success");
  } catch (error) { toast(error.message, "error"); }
};

async function openUpsDialog(ups = null) {
  const requiredCapability = ups ? "power.edit" : "power.create";
  if (!hasCapability(requiredCapability)) return;
  try {
    if (!Array.isArray(state.power?.profiles) || !state.power.profiles.length) state.power.profiles = await api("/api/power/monitoring-profiles");
  } catch (error) { toast(error.message, "error"); return; }
  $("upsForm")?.reset();
  $("upsId").value = ups?.id || "";
  $("upsDialogTitle").textContent = ups ? t("power.editUps", {}, "Edit UPS") : t("power.addUps", {}, "Add UPS");
  $("upsName").value = ups?.name || ""; $("upsHost").value = ups?.host || ""; $("upsSite").value = ups?.site || ""; $("upsGroup").value = ups?.group_name || ""; $("upsLocation").value = ups?.location || "";
  $("upsEnabled").checked = ups ? Boolean(ups.enabled) : true;
  if ($("upsDriverMode")) $("upsDriverMode").value = String(ups?.driver_mode || "auto");
  populateUpsProfiles(ups?.monitoring_profile_id || null);
  $("upsFormError").textContent = "";
  const verifyButton = $("upsVerifyButton");
  if (verifyButton) verifyButton.classList.toggle("hidden", !hasCapability("power.verify"));
  $("upsVerifySummary").textContent = hasCapability("power.verify")
    ? t("power.verifyHelp", {}, "Verify manufacturer, model, battery and output source before saving.")
    : t("power.verifyRestricted", {}, "UPS telemetry verification is not permitted by this role.");
  resetUpsDetected(ups || null);
  $("upsDialog")?.showModal();
}
window.editUps = function(id) { const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(id)); if (ups) openUpsDialog(ups); };
async function verifyUpsDialog() {
  if (!hasCapability("power.verify")) return;
  const host = $("upsHost")?.value.trim(); const profileId = Number($("upsMonitoringProfile")?.value || 0);
  $("upsFormError").textContent = "";
  if (!host || !profileId) { $("upsFormError").textContent = t("power.verifyRequired", {}, "Enter the UPS management address and select an SNMPv3 credential."); return; }
  const button = $("upsVerifyButton"); if (button) button.disabled = true;
  if ($("upsVerifySummary")) $("upsVerifySummary").textContent = t("power.verifying", {}, "Reading UPS-MIB telemetry…");
  try {
    const result = await api("/api/power/verify", { method:"POST", body:{ host, monitoring_profile_id:profileId, driver_mode:String($("upsDriverMode")?.value || "auto") } });
    resetUpsDetected(result);
    if ($("upsVerifySummary")) $("upsVerifySummary").textContent = t("power.verified", {}, "SNMPv3 UPS-MIB telemetry verified successfully.");
  } catch (error) {
    const message = String(error?.message || t("power.verifyFailed", {}, "Verification failed"));
    $("upsFormError").textContent = message;
    if ($("upsVerifySummary")) $("upsVerifySummary").textContent = message;
  }
  finally { if (button) button.disabled = false; }
}
async function saveUps(event) {
  event.preventDefault();
  const id = Number($("upsId")?.value || 0);
  if (!hasCapability(id ? "power.edit" : "power.create")) return;
  const body = { name:$("upsName").value.trim(), host:$("upsHost").value.trim(), site:$("upsSite").value.trim(), group_name:$("upsGroup").value.trim(), location:$("upsLocation").value.trim(), monitoring_profile_id:Number($("upsMonitoringProfile").value || 0), driver_mode:String($("upsDriverMode")?.value || "auto"), enabled:Boolean($("upsEnabled").checked) };
  $("upsFormError").textContent = "";
  const submit = event.submitter || $("upsForm")?.querySelector('button[type="submit"]'); if (submit) submit.disabled = true;
  try {
    await api(id ? `/api/power/ups/${id}` : "/api/power/ups", { method:id ? "PUT" : "POST", body });
    $("upsDialog")?.close();
    await loadPowerInfrastructure();
    if (hasCapability("devices.view")) await loadDevices();
    toast(t("power.saved", {}, "UPS saved"), "success");
  } catch (error) { $("upsFormError").textContent = error.message; }
  finally { if (submit) submit.disabled = false; }
}
window.openUpsAssignments = async function(id) {
  if (!hasCapability("power.assign")) return;
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(id));
  if (!ups) return;
  try {
    if (!state.devices.length && hasCapability("devices.view")) await loadDevices();
  } catch (error) { toast(error.message, "error"); return; }
  state.powerAssignmentUpsId = Number(id);
  state.powerAssignmentSelected = new Set((state.devices || []).filter(device => Number(device.power_source_ups_id || 0) === Number(id)).map(device => Number(device.id)));
  if ($("upsAssignmentUpsName")) $("upsAssignmentUpsName").textContent = ups.name || "UPS";
  if ($("upsAssignmentUpsMeta")) $("upsAssignmentUpsMeta").textContent = [ups.host, ups.site, ups.location].filter(Boolean).join(" · ");
  if ($("upsAssignmentSearch")) $("upsAssignmentSearch").value = "";
  renderUpsAssignmentGrid();
  $("upsAssignmentDialog")?.showModal();
};
function renderUpsAssignmentGrid() {
  const grid = $("upsAssignmentGrid");
  if (!grid) return;
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(state.powerAssignmentUpsId));
  if (!ups) { grid.innerHTML = ""; return; }
  const query = String($("upsAssignmentSearch")?.value || "").trim().toLowerCase();
  const upsSite = String(ups.site || "").trim().toLowerCase();
  const candidates = (state.devices || []).filter(device => {
    const deviceSite = String(device.site || "").trim().toLowerCase();
    if (upsSite && deviceSite !== upsSite) return false;
    if (!query) return true;
    return [device.name, device.host, device.site, device.group_name, device.model].some(value => String(value || "").toLowerCase().includes(query));
  }).sort((a,b) => String(a.group_name || "").localeCompare(String(b.group_name || ""), undefined, { numeric:true }) || String(a.name || "").localeCompare(String(b.name || ""), undefined, { numeric:true }));
  if ($("upsAssignmentCount")) $("upsAssignmentCount").textContent = t("power.selectedSwitchCount", { count: state.powerAssignmentSelected.size }, `${state.powerAssignmentSelected.size} selected`);
  grid.innerHTML = candidates.map(device => {
    const selected = state.powerAssignmentSelected.has(Number(device.id));
    const currentUps = Number(device.power_source_ups_id || 0) ? (state.power?.ups || []).find(item => Number(item.id) === Number(device.power_source_ups_id)) : null;
    const sourceText = currentUps && Number(currentUps.id) !== Number(ups.id)
      ? t("power.currentlyProtectedBy", { name: currentUps.name }, `Currently protected by ${currentUps.name}`)
      : selected ? t("power.protectedByThisUps", {}, "Protected by this UPS") : t("power.unassignedPower", {}, "No UPS assigned");
    return `<label class="power-assignment-switch ${selected ? "selected" : ""}"><input type="checkbox" ${selected ? "checked" : ""} onchange="toggleUpsAssignmentSwitch(${Number(device.id)}, this.checked)"/><span class="power-assignment-check"><svg><use href="#i-check"></use></svg></span><span class="power-assignment-copy"><strong>${escapeHtml(device.name || device.host)}</strong><span>${escapeHtml(device.host)} · ${escapeHtml(device.group_name || device.site || t("common.noSite", {}, "No site"))}</span><small>${escapeHtml(sourceText)}</small></span><span class="status ${String(device.last_status || "unknown") === "online" ? "online" : String(device.last_status || "unknown") === "offline" ? "offline" : "unknown"}">${escapeHtml(t(`status.${String(device.last_status || "unknown")}`, {}, String(device.last_status || "unknown")))}</span></label>`;
  }).join("") || `<div class="power-assignment-empty">${escapeHtml(t("power.noAssignmentMatches", {}, "No switches match this UPS Site and search."))}</div>`;
}
window.toggleUpsAssignmentSwitch = function(deviceId, checked) {
  const id = Number(deviceId);
  if (checked) state.powerAssignmentSelected.add(id); else state.powerAssignmentSelected.delete(id);
  renderUpsAssignmentGrid();
};
async function saveUpsAssignments(event) {
  event.preventDefault();
  if (!hasCapability("power.assign") || !state.powerAssignmentUpsId) return;
  const submit = event.submitter || $("upsAssignmentForm")?.querySelector('button[type="submit"]');
  if (submit) submit.disabled = true;
  try {
    await api(`/api/power/ups/${Number(state.powerAssignmentUpsId)}/assignments`, { method:"PUT", body:{ device_ids:[...state.powerAssignmentSelected] } });
    $("upsAssignmentDialog")?.close();
    await Promise.all([loadPowerInfrastructure(), loadDevices()]);
    toast(t("power.assignmentsSaved", {}, "Protected switches updated"), "success");
  } catch (error) { toast(error.message, "error"); }
  finally { if (submit) submit.disabled = false; }
}

window.removeUps = async function(id) {
  if (!hasCapability("power.delete")) return;
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(id));
  const protectedCount = Number(ups?.protected_switch_count || 0);
  if (!confirm(t("power.deleteConfirm", { name:ups?.name || "UPS", count:protectedCount }, `Delete ${ups?.name || "this UPS"}? ${protectedCount} linked switch(es) will be unassigned from this power source.`))) return;
  try { await api(`/api/power/ups/${id}`, { method:"DELETE" }); await loadPowerInfrastructure(); if (hasCapability("devices.view")) await loadDevices(); toast(t("power.deleted", {}, "UPS removed"), "success"); }
  catch (error) { toast(error.message, "error"); }
};
function populateDevicePowerSources(selected = null) {
  const card = $("devicePowerSourceCard"), select = $("devicePowerSource"); if (!card || !select) return;
  const canView = hasCapability("power.view"); card.classList.toggle("hidden", !canView);
  if (!canView) return;
  const site = String($("deviceSite")?.value || "").trim().toLowerCase();
  const allUps = state.power?.ups || [];
  const options = allUps.filter(ups => {
    const upsSite = String(ups.site || "").trim().toLowerCase();
    return site ? (!upsSite || upsSite === site) : !upsSite;
  });
  const current = selected ?? select.value;
  select.innerHTML = `<option value="">${escapeHtml(t("deviceModal.noPowerSource", {}, "No UPS assigned"))}</option>` + options.map(ups => `<option value="${Number(ups.id)}">${escapeHtml(ups.name)} · ${escapeHtml(ups.host)} · ${escapeHtml(powerStateLabel(String(ups.last_status || "") === "unreachable" ? "unreachable" : ups.power_state))}</option>`).join("");
  if (current && allUps.some(ups => Number(ups.id) === Number(current))) {
    if (!options.some(ups => Number(ups.id) === Number(current))) {
      const ups = allUps.find(item => Number(item.id) === Number(current));
      select.insertAdjacentHTML("beforeend", `<option value="${Number(ups.id)}">${escapeHtml(ups.name)} · ${escapeHtml(ups.host)}</option>`);
    }
    select.value = String(current);
  }
  select.disabled = !hasCapability("power.assign");
  updateDevicePowerSourceUi();
}
function updateDevicePowerSourceUi() {
  const select = $("devicePowerSource"), badge = $("devicePowerSourceState"); if (!select || !badge) return;
  const ups = (state.power?.ups || []).find(item => Number(item.id) === Number(select.value || 0));
  if (!ups) { badge.className = "power-source-state"; badge.textContent = t("deviceModal.powerNotAssigned", {}, "Not assigned"); return; }
  const stateValue = String(ups.last_status || "") === "unreachable" ? "unreachable" : String(ups.power_state || "unknown");
  badge.className = `power-source-state ${escapeHtml(stateValue === "unreachable" ? "offline" : (ups.severity || ""))}`;
  badge.textContent = powerStateLabel(stateValue);
}

async function loadDashboard() {
  const data = await api("/api/dashboard");
  state.monitoringPolicy = data.monitoring_policy || { mode: "full", effective: {} };
  const managementOnly = state.monitoringPolicy.mode === "management_only";
  $("dashboardMonitoringModeBanner")?.classList.toggle("hidden", !managementOnly);
  const effectiveMonitoring = state.monitoringPolicy.effective || {};
  const availabilityMonitoringActive = state.monitoringPolicy.mode !== "management_only" && effectiveMonitoring.switch_availability !== false;
  const stackMonitoringActive = state.monitoringPolicy.mode !== "management_only" && effectiveMonitoring.stack_health !== false;
  const powerMonitoringActive = state.monitoringPolicy.mode !== "management_only" && effectiveMonitoring.power_ups !== false;
  $("metricTotal").textContent = data.devices_total;
  $("metricOnline").textContent = availabilityMonitoringActive ? data.devices_online : "—";
  $("metricOffline").textContent = availabilityMonitoringActive ? data.devices_offline : "—";
  const degradedStacks = Math.max(0, Number(data.stacks_degraded || 0));
  if ($("metricDegradedStacks")) $("metricDegradedStacks").textContent = stackMonitoringActive ? degradedStacks : "—";
  $("metricJobs").textContent = data.active_jobs;
  state.dashboardPowerAttention = Array.isArray(data.ups_attention) ? data.ups_attention : [];
  state.dashboardSwitchAttention = Array.isArray(data.switch_attention) ? data.switch_attention : [];
  const powerAttentionCount = Number(data.ups_attention_count || 0);
  if ($("metricPowerAttention")) $("metricPowerAttention").textContent = powerMonitoringActive ? powerAttentionCount : "—";
  const powerAttentionCard = $("powerAttentionMetricCard");
  if (powerAttentionCard) {
    const hasCriticalPowerAttention = state.dashboardPowerAttention.some(item => {
      const stateValue = String(item.power_state || "unknown").toLowerCase();
      return ["depleted", "low_battery", "output_off"].includes(stateValue);
    });
    const hasPowerAttention = powerMonitoringActive && powerAttentionCount > 0;
    powerAttentionCard.classList.toggle("warning", hasPowerAttention && !hasCriticalPowerAttention);
    powerAttentionCard.classList.toggle("danger", hasPowerAttention && hasCriticalPowerAttention);
    powerAttentionCard.classList.toggle("paused", !powerMonitoringActive);
  }
  document.querySelectorAll(".power-capability-only").forEach(element => element.classList.toggle("hidden", !hasCapability("power.view")));
  const unknown = Number.isFinite(Number(data.devices_unknown))
    ? Number(data.devices_unknown)
    : Math.max(0, data.devices_total - data.devices_online - data.devices_offline);
  const healthyOnline = Math.max(0, Number(data.devices_online || 0) - degradedStacks);
  const rawPercent = data.devices_total ? (data.devices_online / data.devices_total) * 100 : 0;
  const healthyPercent = data.devices_total ? (healthyOnline / data.devices_total) * 100 : 0;
  const percent = Number.isFinite(Number(data.connectivity_percent))
    ? Number(data.connectivity_percent)
    : (data.devices_online === data.devices_total && data.devices_total > 0
      ? 100
      : Math.floor(rawPercent * 10) / 10);
  const percentLabel = Number.isInteger(percent) ? `${percent}%` : `${percent.toFixed(1)}%`;
  $("fleetPercent").textContent = availabilityMonitoringActive ? percentLabel : "—";
  $("fleetOnline").textContent = availabilityMonitoringActive ? healthyOnline : "—";
  if ($("fleetDegraded")) $("fleetDegraded").textContent = stackMonitoringActive ? degradedStacks : "—";
  $("fleetOffline").textContent = availabilityMonitoringActive ? data.devices_offline : "—";
  $("fleetUnknown").textContent = availabilityMonitoringActive ? unknown : "—";
  $("fleetRing").style.setProperty("--healthy-angle", availabilityMonitoringActive ? `${Math.max(0, Math.min(100, healthyPercent)) * 3.6}deg` : "0deg");
  $("fleetRing").style.setProperty("--reachable-angle", availabilityMonitoringActive ? `${Math.max(0, Math.min(100, rawPercent)) * 3.6}deg` : "0deg");
  $("dashboardJobs").innerHTML = data.recent_jobs.slice(0, 5).map(job => `
    <tr><td><strong>#${job.id}</strong></td><td>${escapeHtml(actionLabel(job.action))}</td><td>${statusBadge(job.status)}</td>
    <td>${job.target_count}</td><td>${job.success_count}</td><td>${job.failure_count}</td><td>${formatDate(job.created_at)}</td></tr>`).join("") || `<tr><td colspan="7"><div class="empty-state">${escapeHtml(t("dashboard.noJobs", {}, "No jobs yet."))}</div></td></tr>`;
  renderDashboardDevices();
}
function renderDashboardDevices() {
  const policy = state.monitoringPolicy || { mode: "full", effective: {} };
  const effective = policy.effective || {};
  const managementOnly = policy.mode === "management_only";
  const availabilityActive = !managementOnly && effective.switch_availability !== false;
  const stackActive = !managementOnly && effective.stack_health !== false;
  const powerActive = !managementOnly && effective.power_ups !== false;
  if (managementOnly) {
    $("dashboardDevices").innerHTML = `<div class="dashboard-healthy-state"><span class="dashboard-healthy-icon"><svg><use href="#i-activity"></use></svg></span><div><strong>${escapeHtml(t("monitoringMode.managementOnly", {}, "Management only"))}</strong><span>${escapeHtml(t("monitoringMode.attentionPausedHelp", {}, "Infrastructure attention is paused because background monitoring is disabled."))}</span></div></div>`;
    return;
  }
  const switchIssues = [...(state.dashboardSwitchAttention || [])]
    .filter(device => {
      const connectivity = String(device.last_status || "").toLowerCase();
      const stackState = String(device.stack_last_status || "").toLowerCase();
      return (availabilityActive && connectivity === "offline") || (stackActive && connectivity === "online" && Boolean(device.stack_monitor_enabled) && stackState === "degraded");
    })
    .map(device => ({ type: String(device.last_status || "").toLowerCase() === "offline" ? "switch_offline" : "stack_degraded", data: device }));
  const powerIssues = hasCapability("power.view") && powerActive ? (state.dashboardPowerAttention || []).map(ups => ({ type: "ups", data: ups })) : [];
  const priority = item => {
    if (item.type === "ups" && (String(item.data.last_status || "") === "unreachable" || ["depleted","output_off"].includes(String(item.data.power_state || "")))) return 0;
    if (item.type === "switch_offline") return 1;
    if (item.type === "ups") return 2;
    return 3;
  };
  const issues = [...powerIssues, ...switchIssues].sort((a,b) => priority(a)-priority(b)).slice(0,5);
  if (!issues.length) {
    $("dashboardDevices").innerHTML = `<div class="dashboard-healthy-state"><span class="dashboard-healthy-icon"><svg><use href="#i-check"></use></svg></span><div><strong>${escapeHtml(t("dashboard.noInfrastructureIssues", {}, "No infrastructure issues"))}</strong><span>${escapeHtml(t("dashboard.allInfrastructureHealthy", {}, "All switches and monitored power sources are healthy."))}</span></div></div>`;
    return;
  }
  $("dashboardDevices").innerHTML = issues.map(issue => {
    const device = issue.data;
    if (issue.type === "ups") {
      const stateValue = String(device.last_status || "") === "unreachable" ? "unreachable" : String(device.power_state || "unknown");
      const detail = [device.battery_charge_percent !== null && device.battery_charge_percent !== undefined ? `${device.battery_charge_percent}% battery` : "", device.runtime_minutes !== null && device.runtime_minutes !== undefined ? `${device.runtime_minutes} min runtime` : ""].filter(Boolean).join(" · ");
      return `<button class="dashboard-device dashboard-device-degraded" type="button" onclick="openPowerFromDashboard()"><span class="dashboard-device-icon"><svg><use href="#i-power"></use></svg></span><span class="dashboard-device-copy"><strong>${escapeHtml(device.name)}</strong><span>${escapeHtml(device.host)} · ${escapeHtml(device.site || t("common.noSite", {}, "No site"))}</span></span><span class="dashboard-device-meta"><span class="stack-health-inline degraded">${escapeHtml(powerStateLabel(stateValue))}</span><span>${escapeHtml(detail || t("power.needsAttention", {}, "Power source needs attention"))}</span></span></button>`;
    }
    if (issue.type === "switch_offline") {
      const upsAssigned = Boolean(device.power_source_ups_name);
      let powerContext = `<span class="dashboard-power-context no-ups"><strong>${escapeHtml(t("dashboard.powerSource", {}, "Power source"))}</strong><span>${escapeHtml(t("dashboard.noUpsAssigned", {}, "No UPS assigned"))}</span></span>`;
      if (upsAssigned) {
        const upsState = String(device.power_source_ups_status || "") === "unreachable" ? "unreachable" : String(device.power_source_power_state || "unknown");
        const upsTelemetry = [];
        if (device.power_source_battery_charge_percent !== null && device.power_source_battery_charge_percent !== undefined) upsTelemetry.push(t("dashboard.upsBatteryValue", { value: device.power_source_battery_charge_percent }, `Battery ${device.power_source_battery_charge_percent}%`));
        else upsTelemetry.push(t("dashboard.upsBatteryUnavailable", {}, "Battery not reported"));
        if (device.power_source_runtime_minutes !== null && device.power_source_runtime_minutes !== undefined) upsTelemetry.push(t("dashboard.upsRuntimeValue", { value: device.power_source_runtime_minutes }, `Runtime ${device.power_source_runtime_minutes} min`));
        powerContext = `<span class="dashboard-power-context"><strong>${escapeHtml(t("dashboard.assignedUps", { name: device.power_source_ups_name }, `UPS · ${device.power_source_ups_name}`))}</strong><span>${escapeHtml(`${powerStateLabel(upsState)} · ${upsTelemetry.join(" · ")}`)}</span></span>`;
      }
      return `<button class="dashboard-device dashboard-device-offline" type="button" onclick="openDeviceFromDashboard(${device.id})"><span class="dashboard-device-icon"><svg><use href="#i-device"></use></svg></span><span class="dashboard-device-copy"><strong>${escapeHtml(device.name)}</strong><span>${escapeHtml(device.host)} · ${escapeHtml(device.site || t("common.noSite", {}, "No site"))}</span></span><span class="dashboard-device-meta dashboard-device-meta-power">${statusBadge("offline")}${powerContext}</span></button>`;
    }
    const expected = Number((device.stack_baseline_member_ids || []).length || device.stack_expected_members || 0);
    const current = Number(device.stack_current_members || 0);
    return `<button class="dashboard-device dashboard-device-degraded" type="button" onclick="openDeviceFromDashboard(${device.id})"><span class="dashboard-device-icon"><svg><use href="#i-activity"></use></svg></span><span class="dashboard-device-copy"><strong>${escapeHtml(device.name)}</strong><span>${escapeHtml(device.host)} · ${escapeHtml(device.site || t("common.noSite", {}, "No site"))}</span></span><span class="dashboard-device-meta"><span class="stack-health-inline degraded">${escapeHtml(t("dashboard.stackMembers", { current, expected }, `Stack ${current}/${expected}`))}</span><span>${escapeHtml(t("dashboard.membersMissing", { count:Math.max(0,expected-current) }, `${Math.max(0,expected-current)} members missing`))}</span></span></button>`;
  }).join("");
}

window.openDeviceFromDashboard = async function(id) {
  let device = state.devices.find(item => item.id === id);
  if (!device) {
    try { await loadDevices({ render: false }); } catch (error) { toast(error.message, "error"); return; }
    device = state.devices.find(item => item.id === id);
  }
  if (device) useDevice(id);
};
window.openPowerFromDashboard = function() { if (hasCapability("power.view")) switchView("powerView"); };

function renderDeviceDataForActiveView() {
  const activeView = document.querySelector(".view.active")?.id || "";
  if (activeView === "devicesView") {
    syncCascadingFilterOptions("device");
    renderDevices();
  } else if (activeView === "bulkView") {
    syncCascadingFilterOptions("bulk");
    renderBulkTargets();
    updateBulkSummary();
  } else if (activeView === "finderView") {
    syncCascadingFilterOptions("finder");
    renderFinderScope();
  } else if (activeView === "adminView" && isPlatformAdmin()) {
    populateAuthenticationSources(state.adminSettings?.authentication_source_device_ids || []);
    renderAuthenticationPathPreview();
  }
}

async function loadDevices({ force = false, render = true } = {}) {
  const cacheAge = Date.now() - Number(state.devicesLoadedAt || 0);
  if (!force && state.devices.length && cacheAge < 15000) {
    if (render) renderDeviceDataForActiveView();
    return state.devices;
  }
  if (!state.devicesRequest) {
    state.devicesRequest = api("/api/devices")
      .then(devices => {
        state.devices = Array.isArray(devices) ? devices : [];
        state.devicesLoadedAt = Date.now();
        for (const id of [...state.selected.keys()]) if (!state.devices.some(device => device.id === id)) state.selected.delete(id);
        return state.devices;
      })
      .finally(() => { state.devicesRequest = null; });
  }
  await state.devicesRequest;
  if (render) renderDeviceDataForActiveView();
  return state.devices;
}
const INVENTORY_FILTERS = [
  { key: "site", field: "site", deviceId: "deviceSiteFilter", bulkId: "bulkSiteFilter", finderId: "finderSiteFilter", allKey: "devices.allSites", allFallback: "All sites" },
  { key: "group", field: "group_name", deviceId: "deviceGroupFilter", bulkId: "bulkGroupFilter", finderId: "finderGroupFilter", allKey: "devices.allGroups", allFallback: "All groups" },
  { key: "model", field: "model", deviceId: "deviceModelFilter", bulkId: "bulkModelFilter", finderId: "finderModelFilter", allKey: "devices.allModels", allFallback: "All models" },
  { key: "status", field: "last_status", deviceId: "deviceStatusFilter", bulkId: "bulkStatusFilter", finderId: "finderStatusFilter", allKey: "devices.allStatuses", allFallback: "All statuses" },
  { key: "profile", field: "profile", deviceId: "deviceProfileFilter", bulkId: "bulkProfileFilter", finderId: "finderProfileFilter", allKey: "devices.allAos", allFallback: "All AOS" },
];

function inventoryFilterId(scope, definition) { return scope === "bulk" ? definition.bulkId : scope === "finder" ? definition.finderId : definition.deviceId; }
function inventorySearchId(scope) { return scope === "bulk" ? "bulkDeviceSearch" : scope === "finder" ? "finderDeviceSearch" : "deviceSearch"; }
function inventoryRawValue(device, definition) {
  if (definition.key === "status") return String(device.last_status || "unknown").trim();
  return String(device[definition.field] || "").trim();
}
function inventoryComparable(value) { return String(value || "").trim().toLocaleLowerCase(); }
function inventoryHaystack(device) {
  return `${device.name || ""} ${device.host || ""} ${device.site || ""} ${device.group_name || ""} ${device.model || ""} ${device.aos_version || ""} ${device.profile || ""} ${device.notes || ""}`.toLocaleLowerCase();
}
function inventoryOptionLabel(definition, value) {
  const normalized = inventoryComparable(value);
  if (definition.key === "status") return t(`status.${normalized}`, {}, normalized || t("common.unknown", {}, "Unknown"));
  if (definition.key === "profile") {
    if (normalized === "aos8") return "AOS 8";
    if (normalized === "aos6") return "AOS 6";
  }
  return value;
}
function inventoryDeviceMatches(device, scope, ignoredKey = "") {
  const query = String($(inventorySearchId(scope))?.value || "").trim().toLocaleLowerCase();
  if (query && !inventoryHaystack(device).includes(query)) return false;
  for (const definition of INVENTORY_FILTERS) {
    if (definition.key === ignoredKey) continue;
    const select = $(inventoryFilterId(scope, definition));
    const selected = inventoryComparable(select?.value);
    if (selected && inventoryComparable(inventoryRawValue(device, definition)) !== selected) return false;
  }
  return true;
}
function updateCascadingFilterSelect(scope, definition) {
  const select = $(inventoryFilterId(scope, definition));
  if (!select) return false;
  const current = select.value;
  const values = [...new Set(
    state.devices
      .filter(device => inventoryDeviceMatches(device, scope, definition.key))
      .map(device => inventoryRawValue(device, definition))
      .filter(Boolean)
  )].sort((a, b) => inventoryOptionLabel(definition, a).localeCompare(inventoryOptionLabel(definition, b), undefined, { numeric: true }));
  select.innerHTML = `<option value="">${escapeHtml(t(definition.allKey, {}, definition.allFallback))}</option>${values.map(value => `<option value="${escapeHtml(value)}">${escapeHtml(inventoryOptionLabel(definition, value))}</option>`).join("")}`;
  const matchingOption = [...select.options].find(option => inventoryComparable(option.value) === inventoryComparable(current));
  if (matchingOption) select.value = matchingOption.value;
  else select.value = "";
  return Boolean(current) && !matchingOption;
}
function syncCascadingFilterOptions(scope) {
  // Recalculate every facet from records that satisfy all the other active
  // facets. If a previous selection becomes impossible, clear it and repeat
  // so all dropdowns always describe combinations that actually exist.
  for (let pass = 0; pass < INVENTORY_FILTERS.length + 1; pass += 1) {
    let selectionCleared = false;
    for (const definition of INVENTORY_FILTERS) selectionCleared = updateCascadingFilterSelect(scope, definition) || selectionCleared;
    if (!selectionCleared) break;
  }
}
function handleInventoryFilterChange(scope) {
  syncCascadingFilterOptions(scope);
  if (scope === "bulk") renderBulkTargets();
  else if (scope === "finder") renderFinderScope();
  else renderDevices();
}
function clearInventoryFilters(scope) {
  const search = $(inventorySearchId(scope));
  if (search) search.value = "";
  for (const definition of INVENTORY_FILTERS) {
    const select = $(inventoryFilterId(scope, definition));
    if (select) select.value = "";
  }
  syncCascadingFilterOptions(scope);
  if (scope === "bulk") renderBulkTargets();
  else if (scope === "finder") renderFinderScope();
  else renderDevices();
}
function filteredDevices() {
  return state.devices.filter(device => inventoryDeviceMatches(device, "device"));
}


function filteredFinderDevices() {
  return state.devices.filter(device => device.enabled && inventoryDeviceMatches(device, "finder"));
}
function renderFinderScope() {
  const devices = filteredFinderDevices();
  const count = $("finderScopeCount");
  if (count) count.textContent = t("finder.scopeCount", { count: devices.length }, `${devices.length} switches`);
  const adminNote = $("finderAdminNote");
  if (adminNote) adminNote.classList.toggle("hidden", isSshUser());
  const button = $("finderSearchButton");
  if (button) button.disabled = !isSshUser() || !devices.length;
}
function clearFinderPolling() {
  if (state.finderPollTimer) clearTimeout(state.finderPollTimer);
  state.finderPollTimer = null;
}
function finderPhaseLabel(result) {
  const phase = String(result?.phase || "primary");
  const labels = {
    queued: t("finder.phaseQueued", {}, "Preparing search..."),
    primary: t("finder.phasePrimary", {}, "Scanning live endpoint tables..."),
    active_probe: t("finder.phaseProbe", {}, "Actively resolving the IP..."),
    arp_retry: t("finder.phaseArpRetry", {}, "Retrying ARP after active resolution..."),
    unp_fallback: t("finder.phaseUnpFallback", {}, "Checking UNP fallback..."),
    mac_resolution: t("finder.phaseMacResolution", {}, "Resolving the physical MAC path..."),
    topology: t("finder.phaseTopology", {}, "Verifying edge ports and uplinks..."),
    arp_enrichment: t("finder.phaseArpEnrichment", {}, "Enriching the result with IP data..."),
  };
  return labels[phase] || t("finder.searching", {}, "Searching live switch tables...");
}
function setFinderProgress(result) {
  const progress = $("finderProgress");
  if (!progress) return;
  const active = result && ["queued", "running"].includes(result.status);
  progress.classList.toggle("hidden", !active);
  if (!active) return;
  const total = Math.max(1, Number(result.progress_total || result.total || 0));
  const done = Math.min(total, Number(result.progress_done || result.scanned || 0));
  const percent = Math.max(2, Math.round((done / total) * 100));
  $("finderProgressBar").style.width = `${percent}%`;
  $("finderProgressTitle").textContent = finderPhaseLabel(result);
  $("finderProgressMeta").textContent = t("finder.progressSmart", {
    scanned: result.scanned || 0,
    total: result.total || 0,
    found: result.endpoint_found ?? result.found ?? 0,
  }, `${result.scanned || 0} of ${result.total || 0} switches scanned · ${result.endpoint_found ?? result.found ?? 0} endpoints located`);
}
function finderIdentity(result) {
  return result.hostname || result.username || result.profile_name || result.profile || t("common.unknown", {}, "Unknown");
}
function finderConfidenceClass(item) {
  if (item.last_known) return "last-known";
  if (item.is_uplink) return "upstream";
  const score = Number(item.confidence || 0);
  if (score >= 90) return "confirmed";
  if (score >= 75) return "high";
  if (score >= 55) return "probable";
  return "observed";
}
function finderEvidence(item) {
  const evidence = Array.isArray(item.evidence) ? item.evidence : String(item.source || "").split(",").map(value => value.trim()).filter(Boolean);
  return evidence.map(value => `<span>${escapeHtml(value)}</span>`).join("") || `<span>${escapeHtml(t("finder.noEvidence", {}, "Observation"))}</span>`;
}
function finderLocationBadge(item) {
  if (item.is_uplink) return `<span class="finder-location-badge upstream">${escapeHtml(t("finder.upstream", {}, "Upstream"))}</span>`;
  if (item.topology_verified && item.is_edge_port) return `<span class="finder-location-badge edge">${escapeHtml(t("finder.edgePort", {}, "Edge port"))}</span>`;
  return `<span class="finder-location-badge pending">${escapeHtml(t("finder.locationPending", {}, "Resolving"))}</span>`;
}
function finderOperateButton(item, compact = false) {
  if (!Number(item.device_id || 0)) return "";
  return `<button class="${compact ? "btn primary" : "icon-action primary"}" onclick="openFinderDevice(${Number(item.device_id)}, '${escapeHtml(item.port || "")}')"><svg><use href="#i-port"></use></svg>${escapeHtml(t("devices.operate", {}, "Operate"))}</button>`;
}
function finderLastKnownCard(item, liveResults) {
  if (!item) return "";
  const sameMacLive = (liveResults || []).some(result => normalizeFinderMac(result.mac) && normalizeFinderMac(result.mac) === normalizeFinderMac(item.mac));
  if (sameMacLive) return "";
  return `<div class="finder-last-known-card">
    <div><span class="finder-last-known-kicker">${escapeHtml(t("finder.lastKnown", {}, "LAST KNOWN LOCATION"))}</span><strong>${escapeHtml(item.switch_name || t("common.unknown", {}, "Unknown"))} · ${escapeHtml(item.port || t("finder.notResolved", {}, "Not resolved"))}</strong><span>${escapeHtml(t("finder.lastSeenAt", { time: formatDate(item.last_seen) }, `Last seen ${formatDate(item.last_seen)}`))}</span></div>
    <div class="finder-last-known-meta"><code>${escapeHtml(item.ip || "—")}</code><code>${escapeHtml(item.mac || "—")}</code>${finderOperateButton(item, true)}</div>
  </div>`;
}
function normalizeFinderMac(value) { return String(value || "").toLowerCase().replace(/[^0-9a-f]/g, ""); }
function finderBestMatchCard(item) {
  if (!item) return "";
  const profile = item.profile_name || item.profile || "";
  const notes = [];
  if (Number(item.upstream_count || 0) > 0) notes.push(t("finder.upstreamCount", { count: item.upstream_count }, `Also learned through ${item.upstream_count} upstream switches`));
  if (Number(item.alternate_edge_count || 0) > 0) notes.push(t("finder.alternateEdgeCount", { count: item.alternate_edge_count }, `${item.alternate_edge_count} additional edge candidates require attention`));
  const upstreamNote = notes.length ? `<span>${escapeHtml(notes.join(" · "))}</span>` : "";
  return `<div class="finder-best-card">
    <div class="finder-best-head"><div><span class="finder-best-kicker">${escapeHtml(t("finder.bestMatch", {}, "BEST MATCH"))}</span><h3>${escapeHtml(item.switch_name)} <span>·</span> ${escapeHtml(item.port || t("finder.notResolved", {}, "Not resolved"))}</h3><p>${escapeHtml(item.switch_host || "")} ${item.site ? `· ${escapeHtml(item.site)}` : ""}</p></div><span class="finder-confidence ${finderConfidenceClass(item)}"><strong>${escapeHtml(item.confidence_label || "")}</strong><small>${Number(item.confidence || 0)}%</small></span></div>
    <div class="finder-best-grid">
      <div><span>${escapeHtml(t("finder.columnIp", {}, "IP"))}</span><code>${escapeHtml(item.ip || "—")}</code></div>
      <div><span>${escapeHtml(t("finder.columnMac", {}, "MAC"))}</span><code>${escapeHtml(item.mac || "—")}</code></div>
      <div><span>${escapeHtml(t("finder.identity", {}, "Identity"))}</span><strong>${escapeHtml(finderIdentity(item))}</strong></div>
      <div><span>${escapeHtml(t("finder.vlan", {}, "VLAN"))}</span><strong>${escapeHtml(item.vlan || "—")}</strong></div>
      <div><span>${escapeHtml(t("finder.unpProfile", {}, "UNP profile"))}</span><strong>${escapeHtml(profile || "—")}</strong>${item.profile_id ? `<small>ID ${escapeHtml(item.profile_id)}</small>` : ""}</div>
      <div><span>${escapeHtml(t("finder.location", {}, "Location"))}</span>${finderLocationBadge(item)}</div>
    </div>
    <div class="finder-best-foot"><div class="finder-evidence">${finderEvidence(item)}</div><div class="finder-best-actions">${upstreamNote}${finderOperateButton(item, true)}</div></div>
  </div>`;
}
function renderFinderResult(result) {
  const container = $("finderResults");
  if (!container) return;
  setFinderProgress(result);
  $("finderClearResults")?.classList.toggle("hidden", !result);
  if (!result) {
    $("finderResultsSubtitle").textContent = t("finder.resultsDescription", {}, "Run a search to locate an endpoint and its physical switch port.");
    container.innerHTML = `<div class="empty-state finder-empty"><svg><use href="#i-find-device"></use></svg><strong>${escapeHtml(t("finder.emptyTitle", {}, "Find any connected device"))}</strong><span>${escapeHtml(t("finder.emptyDescription", {}, "Search by IP, MAC, hostname, UNP username, profile or VLAN across the filtered switch inventory."))}</span></div>`;
    $("finderErrors").className = "finder-errors hidden";
    $("finderErrors").innerHTML = "";
    return;
  }
  const results = result.results || [];
  const completed = result.status === "completed" || result.status === "failed";
  const endpointCount = Number(result.endpoint_found ?? results.filter(item => item.best_match && !item.is_uplink).length);
  const upstreamCount = Number(result.upstream_found ?? results.filter(item => item.is_uplink).length);
  $("finderResultsSubtitle").textContent = completed
    ? t("finder.completedSmartSummary", { found: endpointCount, scanned: result.scanned || 0, upstream: upstreamCount }, `${endpointCount} endpoint locations across ${result.scanned || 0} switches`)
    : t("finder.progressSmart", { scanned: result.scanned || 0, total: result.total || 0, found: endpointCount }, `${result.scanned || 0} of ${result.total || 0} switches scanned · ${endpointCount} endpoints located`);

  const lastKnown = finderLastKnownCard(result.last_known, results);
  const bestMatches = results.filter(item => item.best_match && !item.is_uplink);
  const singleBest = result.search_type !== "vlan" && bestMatches.length === 1 ? finderBestMatchCard(bestMatches[0]) : "";
  let body = "";
  if (!results.length) {
    body = completed
      ? `<div class="empty-state finder-empty"><svg><use href="#i-search"></use></svg><strong>${escapeHtml(t("finder.noMatchesTitle", {}, "No live device found"))}</strong><span>${escapeHtml(result.last_known ? t("finder.noLiveUseLastKnown", {}, "No live location was verified. The last known location is shown above.") : t("finder.noMatchesDescription", {}, "Try another identifier or expand the switch scope."))}</span></div>`
      : `<div class="finder-searching-placeholder"><span class="finder-spinner"></span><span>${escapeHtml(finderPhaseLabel(result))}</span></div>`;
  } else {
    body = `<div class="table-wrap finder-table-wrap"><table class="finder-table"><thead><tr><th>${escapeHtml(t("finder.columnSwitch", {}, "Switch"))}</th><th>${escapeHtml(t("finder.columnPort", {}, "Port"))}</th><th>${escapeHtml(t("finder.location", {}, "Location"))}</th><th>${escapeHtml(t("finder.columnIdentity", {}, "Identity"))}</th><th>${escapeHtml(t("finder.columnIp", {}, "IP"))}</th><th>${escapeHtml(t("finder.columnMac", {}, "MAC"))}</th><th>${escapeHtml(t("finder.columnNetwork", {}, "VLAN / Profile"))}</th><th>${escapeHtml(t("finder.confidence", {}, "Confidence"))}</th><th>${escapeHtml(t("finder.evidence", {}, "Evidence"))}</th><th></th></tr></thead><tbody>${results.map(item => `<tr class="${item.best_match ? "finder-best-row" : ""} ${item.is_uplink ? "finder-upstream-row" : ""}">
      <td><div class="finder-switch-cell"><span class="device-icon"><svg><use href="#i-device"></use></svg></span><div><strong>${escapeHtml(item.switch_name)}</strong><span>${escapeHtml(item.switch_host)} · ${escapeHtml(item.site || t("common.noSite", {}, "No site"))}</span></div></div></td>
      <td><span class="finder-port">${escapeHtml(item.port || t("finder.notResolved", {}, "Not resolved"))}</span>${item.best_match ? `<span class="finder-best-inline">${escapeHtml(t("finder.best", {}, "Best"))}</span>` : ""}</td>
      <td>${finderLocationBadge(item)}${item.neighbor_name ? `<small class="finder-neighbor">${escapeHtml(item.neighbor_name)}</small>` : ""}</td>
      <td><div class="finder-identity"><strong>${escapeHtml(finderIdentity(item))}</strong><span>${escapeHtml(item.matched_field || "")}</span></div></td>
      <td><code>${escapeHtml(item.ip || "—")}</code></td><td><code>${escapeHtml(item.mac || "—")}</code></td>
      <td><div class="finder-network"><strong>${escapeHtml(item.vlan || "—")}</strong><span>${escapeHtml(item.profile_name || item.profile || "")}${item.profile_id ? ` · ID ${escapeHtml(item.profile_id)}` : ""}</span></div></td>
      <td><span class="finder-confidence compact ${finderConfidenceClass(item)}"><strong>${escapeHtml(item.confidence_label || "")}</strong><small>${Number(item.confidence || 0)}%</small></span></td>
      <td><div class="finder-evidence compact">${finderEvidence(item)}</div></td>
      <td>${finderOperateButton(item)}</td>
    </tr>`).join("")}</tbody></table></div>`;
  }
  const probeNote = result.active_probe_attempted
    ? `<div class="finder-probe-note"><strong>${escapeHtml(t("finder.activeResolution", {}, "Active IP resolution"))}</strong><span>${escapeHtml(result.active_probe_replied ? t("finder.probeReply", {}, "The target replied and ARP was refreshed.") : t("finder.probeNoReply", {}, "A probe was sent to refresh ARP. No ICMP reply was required for discovery."))}</span></div>`
    : "";
  container.innerHTML = `${lastKnown}${singleBest}${probeNote}${body}`;

  const errors = result.errors || [];
  const errorPanel = $("finderErrors");
  if (errors.length) {
    errorPanel.className = "finder-errors";
    errorPanel.innerHTML = `<details><summary>${escapeHtml(t("finder.partialErrors", { count: errors.length }, `${errors.length} switch checks could not be completed`))}</summary>${errors.map(item => `<div><strong>${escapeHtml(item.switch_name)}</strong><span>${item.phase ? `${escapeHtml(item.phase)} · ` : ""}${escapeHtml(item.error)}</span></div>`).join("")}</details>`;
  } else {
    errorPanel.className = "finder-errors hidden";
    errorPanel.innerHTML = "";
  }
}
async function startDeviceFinderSearch() {
  if (!isSshUser()) { toast(t("finder.sshRequiredDescription", {}, "Sign in as an SSH user to search live switch tables."), "error"); return; }
  const query = $("finderQuery").value.trim();
  if (!query) { toast(t("finder.queryRequired", {}, "Enter an IP, MAC, hostname, username or VLAN."), "error"); $("finderQuery").focus(); return; }
  const devices = filteredFinderDevices();
  if (!devices.length) { toast(t("finder.noScope", {}, "No enabled switches match the selected scope."), "error"); return; }
  clearFinderPolling();
  const button = $("finderSearchButton");
  button.disabled = true;
  state.finderResult = { status: "queued", total: devices.length, scanned: 0, found: 0, results: [], errors: [] };
  renderFinderResult(state.finderResult);
  try {
    const result = await api("/api/device-finder/search", { method: "POST", body: { query, search_type: $("finderType").value, device_ids: devices.map(device => device.id) } });
    state.finderSearchId = result.search_id;
    state.finderResult = result;
    renderFinderResult(result);
    pollDeviceFinderSearch();
  } catch (error) {
    state.finderResult = { status: "failed", total: devices.length, scanned: 0, found: 0, results: [], errors: [{ switch_name: t("finder.search", {}, "Search"), error: error.message }] };
    renderFinderResult(state.finderResult);
    toast(error.message, "error");
    button.disabled = false;
  }
}
async function pollDeviceFinderSearch() {
  clearFinderPolling();
  if (!state.finderSearchId) return;
  try {
    const result = await api(`/api/device-finder/search/${encodeURIComponent(state.finderSearchId)}`);
    state.finderResult = result;
    renderFinderResult(result);
    if (["queued", "running"].includes(result.status)) {
      state.finderPollTimer = setTimeout(pollDeviceFinderSearch, 900);
    } else {
      $("finderSearchButton").disabled = !isSshUser() || !filteredFinderDevices().length;
    }
  } catch (error) {
    $("finderSearchButton").disabled = false;
    toast(error.message, "error");
  }
}
function clearFinderResults() {
  clearFinderPolling();
  state.finderSearchId = null;
  state.finderResult = null;
  renderFinderResult(null);
}
window.openFinderDevice = function(deviceId, port) {
  openDeviceWorkspace(deviceId);
  if (port) {
    setTimeout(() => {
      if ($("workspacePort")) $("workspacePort").value = port;
      if ($("workspacePortSearch")) $("workspacePortSearch").value = port;
      renderWorkspacePorts();
    }, 200);
  }
};

const deviceSortCollator = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
function deviceSortValue(device, key) {
  if (key === "name") return device.name || "";
  if (key === "host") return device.host || "";
  if (key === "site") return `${device.site || ""} ${device.group_name || ""}`;
  if (key === "model") return `${device.model || ""} ${device.aos_version || ""} ${device.profile || ""}`;
  if (key === "status") return String(device.last_status || "unknown").toLowerCase();
  if (key === "last_checked") return Date.parse(device.last_checked || device.last_seen || "") || 0;
  return device[key] || "";
}
function compareDeviceSortValues(a, b, key) {
  if (key === "last_checked") return Number(a) - Number(b);
  if (key === "status") {
    const rank = { offline: 0, unknown: 1, online: 2 };
    const diff = (rank[a] ?? 9) - (rank[b] ?? 9);
    if (diff) return diff;
  }
  return deviceSortCollator.compare(String(a || ""), String(b || ""));
}
function sortedDevices(devices) {
  const { key, direction } = state.deviceSort;
  const multiplier = direction === "desc" ? -1 : 1;
  return [...devices].sort((left, right) => {
    const compared = compareDeviceSortValues(deviceSortValue(left, key), deviceSortValue(right, key), key);
    if (compared) return compared * multiplier;
    return deviceSortCollator.compare(String(left.name || ""), String(right.name || ""));
  });
}
function setDeviceSort(key) {
  if (!key) return;
  if (state.deviceSort.key === key) state.deviceSort.direction = state.deviceSort.direction === "asc" ? "desc" : "asc";
  else {
    state.deviceSort.key = key;
    state.deviceSort.direction = key === "last_checked" ? "desc" : "asc";
  }
  renderDevices();
}
function updateDeviceSortHeaders() {
  document.querySelectorAll("[data-device-sort]").forEach(button => {
    const th = button.closest("th");
    const active = button.dataset.deviceSort === state.deviceSort.key;
    const direction = active ? state.deviceSort.direction : "none";
    if (th) th.setAttribute("aria-sort", direction === "none" ? "none" : direction === "asc" ? "ascending" : "descending");
    button.classList.toggle("active", active);
    const indicator = button.querySelector(".sort-indicator");
    if (indicator) indicator.textContent = active ? (direction === "asc" ? "↑" : "↓") : "↕";
  });
}
function stackHealthDetail(device) {
  if (!device?.stack_monitor_enabled) return "";
  const expected = Number(device.stack_expected_members || (device.stack_baseline_member_ids || []).length || 0);
  const current = Number(device.stack_current_members || 0);
  const status = String(device.stack_last_status || "unknown").toLowerCase();
  const method = String(device.stack_monitor_method || "ssh").toUpperCase();
  const members = Array.isArray(device.stack_members) ? device.stack_members : [];
  const memberSummary = members.map(item => `${item.id}${item.role ? ` ${item.role}` : ""}${item.status ? ` · ${item.status}` : ""}`).join("\n");
  const title = [method, memberSummary].filter(Boolean).join("\n");
  if (status === "healthy") return `<span class="stack-health-inline healthy" title="${escapeHtml(title)}">${escapeHtml(t("devices.stackHealthy", { current, expected }, `Stack ${current}/${expected}`))}</span>`;
  if (status === "degraded") return `<span class="stack-health-inline degraded" title="${escapeHtml(title)}">${escapeHtml(t("devices.stackDegraded", { current, expected }, `Stack ${current}/${expected} degraded`))}</span>`;
  if (status === "learning") return `<span class="stack-health-inline pending" title="${escapeHtml(title)}">${escapeHtml(t("devices.stackLearning", { current }, `Learning stack · ${current} detected`))}</span>`;
  if (device.stack_last_error) return `<span class="stack-health-inline unavailable" title="${escapeHtml(device.stack_last_error)}">${escapeHtml(stackUnavailableLabel(device.stack_last_error))}</span>`;
  return `<span class="stack-health-inline pending">${escapeHtml(t("devices.stackPendingAuto", {}, "Stack baseline pending"))}</span>`;
}
function stackUnavailableLabel(error = "") {
  const text = String(error || "").toLowerCase();
  if (text.includes("credentials required")) return t("devices.stackCredentialsRequired", {}, "Stack credentials required");
  if (text.includes("authentication failed")) return t("devices.stackAuthenticationFailed", {}, "Stack authentication failed");
  if (text.includes("command unsupported")) return t("devices.stackCommandUnsupported", {}, "Stack command unsupported");
  if (text.includes("evidence unavailable") || text.includes("entity-mib")) return t("devices.stackEvidenceUnavailable", {}, "Stack evidence unavailable");
  return t("devices.stackUnavailable", {}, "Stack check unavailable");
}
function renderDevices() {
  const rows = sortedDevices(filteredDevices());
  updateDeviceSortHeaders();
  $("devicesTable").innerHTML = rows.map(device => {
    const manageActions = canManageInventory()
      ? `<button class="icon-action" onclick="editDevice(${device.id})">${escapeHtml(t("common.edit", {}, "Edit"))}</button><button class="icon-action danger" onclick="deleteDevice(${device.id})">${escapeHtml(t("common.delete", {}, "Delete"))}</button>`
      : "";
    const stackMemberCount = device.stack_monitor_enabled ? Number((device.stack_baseline_member_ids || []).length || device.stack_current_members || 0) : 0;
    const logicalStackLabel = stackMemberCount > 1 ? ` · <em class="stack-logical-inline">${escapeHtml(t("devices.logicalStack", { count: stackMemberCount }, `Logical stack · ${stackMemberCount} members`))}</em>` : "";
    return `<tr>
      <td><div class="device-cell"><span class="device-icon"><svg><use href="#i-device"></use></svg></span><div class="device-copy"><strong>${escapeHtml(device.name)}</strong><span>${escapeHtml(device.group_name || t("common.noGroup", {}, "No group"))}${logicalStackLabel}${Number(device.pending_config_count || 0) ? ` · <em class="unsaved-inline">${escapeHtml(t("pending.unsaved", {}, "Unsaved"))} ${Number(device.pending_config_count)}</em>` : ""}</span></div></div></td>
      <td><div class="address-cell"><code>${escapeHtml(device.host)}</code><div class="muted-line">SSH ${device.ssh_port}</div></div></td>
      <td><div class="platform-cell"><strong>${escapeHtml(device.site || t("common.unassigned", {}, "Unassigned"))}</strong><span>${escapeHtml(device.notes || t("common.noNotes", {}, "No notes"))}</span></div></td>
      <td><div class="platform-cell"><strong>${escapeHtml(device.model || t("common.notDetected", {}, "Not detected"))}</strong><span>${escapeHtml(device.profile)}${device.aos_version ? ` · ${escapeHtml(device.aos_version)}` : ""}</span></div></td>
      <td><div class="connection-cell"><div class="connection-health-row">${statusBadge(device.last_status)}${stackHealthDetail(device)}</div>${connectionDetail(device)}</div></td>
      <td>${formatDate(device.last_checked || device.last_seen)}</td>
      <td><div class="row-actions">${hasCapability("devices.live_ports") ? `<button class="icon-action primary" onclick="useDevice(${device.id})"><svg><use href="#i-port"></use></svg>${escapeHtml(t("devices.operate", {}, "Open"))}</button>` : ""}${isSshUser() && hasCapability("devices.live_ports") ? `<button class="icon-action" onclick="testDevice(${device.id})">${escapeHtml(t("devices.verifyMySsh", {}, "Verify my SSH"))}</button>` : ""}${manageActions}</div></td>
    </tr>`;
  }).join("") || `<tr><td colspan="7"><div class="empty-state">${escapeHtml(t("devices.noSwitches", {}, "No switches found."))}</div></td></tr>`;
}


window.useDevice = function(id) {
  if (!hasCapability("devices.live_ports")) { toast(t("access.livePortsDenied", {}, "Live port access is not available for this role."), "error"); return; }
  openDeviceWorkspace(id);
};
function setDeviceConnectionState(type = "", message = "") {
  const element = $("deviceConnectionState");
  if (!message) { element.className = "connection-state hidden"; element.textContent = ""; return; }
  element.className = `connection-state ${type}`.trim(); element.textContent = message;
}
function deviceConnectionFingerprint() {
  return [$("deviceHost").value.trim(), $("deviceSshPort").value, $("deviceProfile").value, isBootstrapAdmin() ? $("deviceVerificationUsername").value.trim() : state.user?.username || ""].join("|");
}
function updateDetectedPlatform(model = "", aos = "") {
  $("deviceModel").value = model;
  $("deviceAosVersion").value = aos;
  $("deviceModelDisplay").textContent = model || t("deviceModal.notDetected", {}, "Not detected yet");
  $("deviceAosDisplay").textContent = aos || t("deviceModal.notDetected", {}, "Not detected yet");
}
function invalidateDeviceVerification() {
  state.deviceVerification = null;
  updateDetectedPlatform("", "");
  setDeviceConnectionState();
}
function scheduleDeviceDetection() {
  invalidateDeviceVerification();
  if (state.deviceDetectionTimer) clearTimeout(state.deviceDetectionTimer);
  const host = $("deviceHost").value.trim();
  const hasCredentials = isSshUser() || ($("deviceVerificationUsername").value.trim() && $("deviceVerificationPassword").value);
  if (!host || !hasCredentials) return;
  state.deviceDetectionTimer = setTimeout(() => detectDevice(false), 700);
}
async function detectDevice(showErrors = true) {
  const host = $("deviceHost").value.trim();
  const sshPort = Number($("deviceSshPort").value);
  if (!host || !Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535) {
    if (showErrors) setDeviceConnectionState("error", t("deviceModal.enterConnection", {}, "Enter a valid management address and SSH port."));
    return false;
  }
  if (isBootstrapAdmin() && (!$("deviceVerificationUsername").value.trim() || !$("deviceVerificationPassword").value)) {
    if (showErrors) setDeviceConnectionState("error", t("deviceModal.enterTemporaryCredentials", {}, "Enter one-time SSH credentials for model detection."));
    return false;
  }
  const fingerprint = deviceConnectionFingerprint();
  $("deviceDetectButton").disabled = true;
  setDeviceConnectionState("testing", t("deviceModal.detecting", {}, "Connecting with SSH and reading model information..."));
  try {
    const result = await api("/api/devices/verify", { method: "POST", body: {
      device_id: Number($("deviceId").value) || null, host, ssh_port: sshPort, profile: $("deviceProfile").value,
      verification_username: isBootstrapAdmin() ? $("deviceVerificationUsername").value.trim() : "",
      verification_password: isBootstrapAdmin() ? $("deviceVerificationPassword").value : "",
    }});
    if (!result.ok) throw new Error(result.error || t("deviceModal.detectionFailed", {}, "The switch could not be detected."));
    const detected = result.detected || {};
    if (detected.profile) $("deviceProfile").value = detected.profile;
    updateDetectedPlatform(detected.model || "", detected.aos_version || "");
    state.deviceVerification = { fingerprint: deviceConnectionFingerprint(), detected };
    setDeviceConnectionState("success", t("deviceModal.detected", { model: detected.model || "OmniSwitch", aos: detected.aos_version || detected.profile || "AOS" }, `Detected ${detected.model || "OmniSwitch"} · ${detected.aos_version || detected.profile || "AOS"}`));
    return true;
  } catch (error) {
    state.deviceVerification = null;
    updateDetectedPlatform("", "");
    setDeviceConnectionState("error", error.message);
    if (showErrors) $("deviceFormError").textContent = error.message;
    return false;
  } finally {
    $("deviceDetectButton").disabled = false;
  }
}
function monitoringProfilesForMethod(method) {
  return (state.monitoringProfiles || []).filter(profile => String(profile.method || "") === String(method || ""));
}
async function ensureMonitoringProfiles() {
  if (!isPlatformAdmin()) return [];
  try { state.monitoringProfiles = await api("/api/admin/monitoring-profiles"); }
  catch (_) { state.monitoringProfiles = state.monitoringProfiles || []; }
  return state.monitoringProfiles;
}
function populateDeviceHealthProfiles(selected = null) {
  const select = $("deviceHealthProfile");
  if (!select) return;
  const current = selected ?? select.value;
  const profiles = monitoringProfilesForMethod("snmpv3");
  select.innerHTML = `<option value="">${escapeHtml(t("deviceModal.noHealthSnmpProfile", {}, "No SNMPv3 secondary telemetry"))}</option>` + profiles.map(profile => `<option value="${Number(profile.id)}">${escapeHtml(profile.name)} · ${escapeHtml(profile.last_status === "verified" ? t("monitoring.verified", {}, "Verified") : t("monitoring.unverified", {}, "Unverified"))}</option>`).join("");
  if (current && profiles.some(profile => Number(profile.id) === Number(current))) select.value = String(current);
}
function updateDeviceHealthMonitorUi(device = null) {
  const card = $("deviceHealthMonitorCard");
  if (!card) return;
  card.classList.toggle("hidden", !isPlatformAdmin());
  const rawMode = String($("deviceHealthMode")?.value || device?.health_probe_mode || "auto");
  const mode = ["auto", "ping", "snmp"].includes(rawMode) ? rawMode : "auto";
  const profile = $("deviceHealthProfile");
  if (profile) profile.disabled = !isPlatformAdmin() || !["auto", "snmp"].includes(mode);
  const status = $("deviceHealthStatus");
  const summary = $("deviceHealthSummary");
  if (status) {
    const lastMethod = String(device?.last_health_probe_method || "").toUpperCase();
    status.className = `stack-monitor-state ${String(device?.last_status || "unknown").toLowerCase()}`;
    status.textContent = lastMethod ? `${mode.toUpperCase()} · ${lastMethod}` : mode.toUpperCase();
  }
  if (summary) {
    const snmpState = String(device?.health_snmp_status || "unknown");
    const probe = String(device?.last_health_probe_method || "not checked").toUpperCase();
    summary.textContent = t("deviceModal.healthRuntimeSummary", { probe, snmp: snmpState }, `Last reachability: ${probe} · SNMP telemetry: ${snmpState}`);
  }
}
function populateDeviceStackProfiles(selected = null) {
  const select = $("deviceStackProfile");
  if (!select) return;
  const method = $("deviceStackMethod")?.value || "ssh";
  const current = selected ?? select.value;
  const profiles = monitoringProfilesForMethod(method);
  select.innerHTML = `<option value="">${escapeHtml(t("deviceModal.selectMonitoringProfile", {}, "Select a monitoring profile"))}</option>` + profiles.map(profile => `<option value="${Number(profile.id)}">${escapeHtml(profile.name)} · ${escapeHtml(profile.last_status === "verified" ? t("monitoring.verified", {}, "Verified") : t("monitoring.unverified", {}, "Unverified"))}</option>`).join("");
  if (current && profiles.some(profile => Number(profile.id) === Number(current))) select.value = String(current);
}
function updateDeviceStackMonitorUi(device = null) {
  const card = $("deviceStackMonitorCard");
  if (!card) return;
  card.classList.toggle("hidden", !isPlatformAdmin());
  const enabled = Boolean($("deviceStackMonitorEnabled")?.checked);
  if ($("deviceStackMethod")) $("deviceStackMethod").disabled = !enabled || !isPlatformAdmin();
  if ($("deviceStackProfile")) $("deviceStackProfile").disabled = !enabled || !isPlatformAdmin();
  const status = $("deviceStackStatus");
  const baseline = $("deviceStackBaselineSummary");
  const relearn = $("deviceStackRelearn");
  if (!status || !baseline) return;
  const currentDevice = device || null;
  if (!currentDevice?.stack_monitor_enabled) {
    status.className = "stack-monitor-state"; status.textContent = t("deviceModal.stackNotConfigured", {}, "Not configured");
    baseline.textContent = t("deviceModal.stackBaselineHelp", {}, "Portivo learns the same member set across three stable checks, then continuously compares against it.");
    relearn?.classList.add("hidden");
    return;
  }
  const expected = Number(currentDevice.stack_expected_members || (currentDevice.stack_baseline_member_ids || []).length || 0);
  const current = Number(currentDevice.stack_current_members || 0);
  const value = String(currentDevice.stack_last_status || "unknown").toLowerCase();
  status.className = `stack-monitor-state ${value}`;
  if (value === "healthy") status.textContent = t("deviceModal.stackHealthy", { current, expected }, `Healthy · ${current}/${expected}`);
  else if (value === "degraded") status.textContent = t("deviceModal.stackDegraded", { current, expected }, `Degraded · ${current}/${expected}`);
  else if (value === "learning") status.textContent = t("deviceModal.stackLearning", {}, "Learning baseline");
  else if (currentDevice.stack_last_error) status.textContent = stackUnavailableLabel(currentDevice.stack_last_error);
  else status.textContent = t("deviceModal.stackPending", {}, "Waiting for first check");
  const baselineIds = Array.isArray(currentDevice.stack_baseline_member_ids) ? currentDevice.stack_baseline_member_ids : [];
  const stable = Number(currentDevice.stack_baseline_stable_checks || 0);
  baseline.textContent = baselineIds.length
    ? t("deviceModal.stackBaselineLearned", { members: baselineIds.join(", "), method: String(currentDevice.stack_monitor_method || "ssh").toUpperCase() }, `Baseline members ${baselineIds.join(", ")} · ${String(currentDevice.stack_monitor_method || "ssh").toUpperCase()}`)
    : t("deviceModal.stackBaselineLearning", { stable }, `Learning automatically · ${stable}/3 stable checks`);
  relearn?.classList.toggle("hidden", !currentDevice?.id || !baselineIds.length);
}
async function relearnCurrentDeviceStack() {
  const id = Number($("deviceId")?.value || 0); if (!id) return;
  try { await api(`/api/devices/${id}/stack/relearn`, { method: "POST" }); toast(t("deviceModal.stackRelearnStarted", {}, "Stack baseline learning restarted"), "success"); await loadDevices(); const device = state.devices.find(item => item.id === id); updateDeviceStackMonitorUi(device); }
  catch (error) { toast(error.message, "error"); }
}
function openDeviceModal(device = null) {
  if (!canManageInventory()) { toast(t("devices.managementDenied", {}, "You do not have permission to manage switch inventory."), "error"); return; }
  $("deviceForm").reset();
  $("deviceId").value = device?.id || "";
  $("deviceModalTitle").textContent = t(device ? "deviceModal.editTitle" : "deviceModal.addTitle", {}, device ? "Edit switch" : "Add switch");
  $("deviceFormError").textContent = "";
  $("bootstrapCredentialFields").classList.toggle("hidden", !isBootstrapAdmin());
  $("deviceVerificationUsername").value = "";
  $("deviceVerificationPassword").value = "";
  $("deviceSshPort").value = device?.ssh_port || 22;
  $("deviceProfile").value = device?.profile || "AOS8";
  $("deviceEnabled").checked = device ? Boolean(device.enabled) : true;
  $("deviceHealthMode").value = ["auto", "ping", "snmp"].includes(String(device?.health_probe_mode || "auto")) ? String(device?.health_probe_mode || "auto") : "auto";
  populateDeviceHealthProfiles(device?.health_monitor_profile_id || null);
  $("deviceStackMonitorEnabled").checked = device ? Boolean(device.stack_monitor_enabled) : false;
  $("deviceStackMethod").value = device?.stack_monitor_method || "ssh";
  populateDeviceStackProfiles(device?.stack_monitor_profile_id || null);
  if (isPlatformAdmin()) ensureMonitoringProfiles().then(() => { populateDeviceHealthProfiles(device?.health_monitor_profile_id || null); populateDeviceStackProfiles(device?.stack_monitor_profile_id || null); updateDeviceHealthMonitorUi(device); updateDeviceStackMonitorUi(device); });
  if (device) {
    $("deviceName").value = device.name || ""; $("deviceHost").value = device.host || "";
    $("deviceSite").value = device.site || ""; $("deviceGroup").value = device.group_name || "";
    $("deviceNotes").value = device.notes || "";
    updateDetectedPlatform(device.model || "", device.aos_version || "");
    state.deviceVerification = device.model ? { fingerprint: deviceConnectionFingerprint(), detected: { model: device.model, aos_version: device.aos_version, profile: device.profile } } : null;
  } else {
    updateDetectedPlatform("", ""); state.deviceVerification = null;
  }
  updateDeviceHealthMonitorUi(device);
  updateDeviceStackMonitorUi(device);
  if (hasCapability("power.view")) {
    ensurePowerData().then(() => populateDevicePowerSources(device?.power_source_ups_id || null)).catch(() => { $("devicePowerSourceCard")?.classList.add("hidden"); });
  } else { $("devicePowerSourceCard")?.classList.add("hidden"); }
  setDeviceConnectionState();
  $("deviceDialog").showModal();
}
window.editDevice = function(id) { const device = state.devices.find(item => item.id === id); if (device) openDeviceModal(device); };
async function saveDevice(event) {
  event.preventDefault();
  if (!canManageInventory()) return;
  const id = $("deviceId").value;
  const sshPort = Number($("deviceSshPort").value);
  $("deviceFormError").textContent = "";
  if (!Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535) { $("deviceFormError").textContent = t("deviceModal.invalidPort", {}, "Enter a valid SSH port from 1 to 65535."); return; }
  const existing = id ? state.devices.find(device => device.id === Number(id)) : null;
  const connectionChanged = !existing || existing.host !== $("deviceHost").value.trim() || Number(existing.ssh_port) !== sshPort || existing.profile !== $("deviceProfile").value;
  if (connectionChanged || !$("deviceModel").value.trim()) {
    const verified = state.deviceVerification?.fingerprint === deviceConnectionFingerprint() || await detectDevice(true);
    if (!verified) return;
  }
  const payload = {
    name: $("deviceName").value.trim(), host: $("deviceHost").value.trim(), ssh_port: sshPort,
    site: $("deviceSite").value.trim(), group_name: $("deviceGroup").value.trim(),
    model: $("deviceModel").value.trim(), aos_version: $("deviceAosVersion").value.trim(),
    profile: $("deviceProfile").value, enabled: $("deviceEnabled").checked, notes: $("deviceNotes").value.trim(),
    verification_username: isBootstrapAdmin() ? $("deviceVerificationUsername").value.trim() : "",
    verification_password: isBootstrapAdmin() ? $("deviceVerificationPassword").value : "",
  };
  if (hasCapability("power.assign")) payload.power_source_ups_id = $("devicePowerSource")?.value ? Number($("devicePowerSource").value) : null;
  if (isPlatformAdmin()) {
    payload.health_probe_mode = $("deviceHealthMode")?.value || "auto";
    payload.health_monitor_profile_id = $("deviceHealthProfile")?.value ? Number($("deviceHealthProfile").value) : null;
    if (payload.health_probe_mode === "snmp" && !payload.health_monitor_profile_id && !($("deviceStackMonitorEnabled")?.checked && $("deviceStackMethod")?.value === "snmpv3" && $("deviceStackProfile")?.value)) {
      $("deviceFormError").textContent = t("deviceModal.healthProfileRequired", {}, "SNMPv3-only health mode requires an SNMPv3 Monitoring Credential profile.");
      return;
    }
    payload.stack_monitor_enabled = Boolean($("deviceStackMonitorEnabled").checked);
    payload.stack_expected_members = 0;
    payload.stack_monitor_method = $("deviceStackMethod").value || "ssh";
    payload.stack_monitor_profile_id = $("deviceStackProfile").value ? Number($("deviceStackProfile").value) : null;
    if (payload.stack_monitor_enabled && !payload.stack_monitor_profile_id) {
      $("deviceFormError").textContent = t("deviceModal.stackProfileRequired", {}, "Select a Monitoring Credential profile for Stack Member Health.");
      return;
    }
  }
  const saveButton = $("deviceSaveButton");
  saveButton.disabled = true; saveButton.textContent = t("deviceModal.saving", {}, "Saving...");
  try {
    const saved = await api(id ? `/api/devices/${id}` : "/api/devices", { method: id ? "PUT" : "POST", body: payload });
    $("deviceVerificationPassword").value = "";
    await Promise.all([loadDevices(), loadDashboard()]);
    $("deviceDialog").close(); toast(t("devices.saved", { name: saved.name }, `${saved.name} saved successfully`), "success");
  } catch (error) { setDeviceConnectionState("error", error.message); $("deviceFormError").textContent = error.message; }
  finally { saveButton.disabled = false; saveButton.innerHTML = `<svg><use href="#i-check"></use></svg>${escapeHtml(t("deviceModal.save", {}, "Save switch"))}`; }
}

window.deleteDevice = async function(id) {
  if (!canManageInventory()) return;
  const device = state.devices.find(item => item.id === id);
  if (!device || !confirm(t("devices.deleteConfirm", { name: device.name }, `Delete ${device.name}?`))) return;
  try { await api(`/api/devices/${id}`, { method: "DELETE" }); state.selected.delete(id); toast(t("devices.deleted", {}, "Switch deleted"), "success"); await Promise.all([loadDevices(), loadDashboard()]); } catch (error) { toast(error.message, "error"); }
};
window.testDevice = async function(id) {
  if (!isSshUser()) { toast(t("devices.managementDenied", {}, "Sign in with your personal SSH account to verify a switch"), "error"); return; }
  const device = state.devices.find(item => item.id === id);
  toast(t("devices.testing", { name: device?.name || "switch" }, `Testing ${device?.name || "switch"} with your personal SSH account...`));
  try {
    const result = await api("/api/devices/test", { method: "POST", body: { device_id: id } });
    if (!result.ok) toast(result.error || "Connection failed", "error");
    else { const detected = result.detected || {}; const details = [detected.model, detected.aos_version].filter(Boolean).join(" · "); toast(details ? `Connected: ${details}` : t("devices.authSucceeded", {}, "Personal SSH authentication succeeded"), "success"); }
    await Promise.all([loadDevices(), loadDashboard()]);
  } catch (error) { toast(error.message, "error"); }
};


window.toggleSelected = function(id, checked) {
  const device = state.devices.find(item => item.id === id); if (!device) return;
  if (checked) state.selected.set(id, state.selected.get(id) || { device_id: id, port: "", slot: "", port_override: false, slot_override: false }); else state.selected.delete(id);
  renderBulkTargets(); updateBulkSummary(); clearPreview();
};
function workspaceDevice() { return state.devices.find(device => device.id === state.currentWorkspaceDeviceId) || null; }
function openDeviceWorkspace(id) {
  const device = state.devices.find(item => item.id === id);
  if (!device) return;
  if (state.terminalDeviceId !== null && state.terminalDeviceId !== id) disconnectWorkspaceTerminal(true);
  if (state.terminalAutoConnectTimer) {
    clearTimeout(state.terminalAutoConnectTimer);
    state.terminalAutoConnectTimer = null;
  }
  state.currentWorkspaceDeviceId = id;
  state.workspacePortResult = null;
  state.activeWorkspacePort = null;
  state.workspacePortsLoading = false;
  state.workspacePorts = buildWorkspaceLayoutPorts(device);
  clearWorkspacePortFilters();
  updateWorkspacePortMetrics({ total: state.workspacePorts.length });
  setWorkspaceInventoryStatus(state.workspacePorts.length ? "layout" : "unavailable");
  setWorkspacePortView(state.workspacePortView || "map");
  $("workspaceDeviceName").textContent = device.name;
  $("workspaceDeviceMeta").innerHTML = `${escapeHtml(device.host)} · ${escapeHtml(device.model || device.profile)} · ${escapeHtml(device.site || t("common.noSite", {}, "No site"))}${Number(device.pending_config_count || 0) ? ` · <span class="unsaved-inline">${escapeHtml(t("pending.unsaved", {}, "Unsaved"))} ${Number(device.pending_config_count)}</span>` : ""}`;
  renderWorkspaceActionOptions(); updateWorkspaceActionContext(); clearWorkspacePreview(); renderWorkspacePorts();
  resetWorkspaceTerminalUi();
  switchView("deviceWorkspaceView");
  if (isSshUser()) loadWorkspacePorts(false);
}

function terminalSetStatus(status, message = "") {
  const badge = $("workspaceTerminalStatus");
  if (!badge) return;
  badge.className = `terminal-status ${status}`;
  const label = badge.querySelector("span");
  const fallback = status === "connected" ? "Connected" : status === "connecting" ? "Connecting" : "Disconnected";
  if (label) label.textContent = message || t(`terminal.${status}`, {}, fallback);
  $("workspaceTerminalConnect").disabled = status === "connected" || status === "connecting" || state.workspacePortsLoading || !canUseTerminal();
  if ($("workspaceRefreshPorts")) $("workspaceRefreshPorts").disabled = state.workspacePortsLoading || status === "connected" || status === "connecting";
  $("workspaceTerminalDisconnect").disabled = status === "disconnected";
  $("workspaceTerminalInput").disabled = status !== "connected";
  $("workspaceTerminalCard")?.classList.toggle("terminal-live", status === "connected");
}

function terminalResetBuffer() {
  state.terminalLines = [""];
  state.terminalRow = 0;
  state.terminalColumn = 0;
  state.terminalEscape = "";
  if ($("workspaceTerminalOutput")) $("workspaceTerminalOutput").textContent = "";
}

function terminalEnsureRow(row) {
  while (state.terminalLines.length <= row) state.terminalLines.push("");
}

function terminalApplyCsi(sequence) {
  const final = sequence.at(-1) || "";
  const rawParams = sequence.slice(2, -1).replace(/^\?/, "");
  const params = rawParams.split(";").filter(Boolean).map(value => Number(value) || 0);
  const count = Math.max(1, params[0] || 1);
  if (final === "m") return;
  if (final === "A") state.terminalRow = Math.max(0, state.terminalRow - count);
  else if (final === "B") { state.terminalRow += count; terminalEnsureRow(state.terminalRow); }
  else if (final === "C") state.terminalColumn += count;
  else if (final === "D") state.terminalColumn = Math.max(0, state.terminalColumn - count);
  else if (final === "G") state.terminalColumn = Math.max(0, (params[0] || 1) - 1);
  else if (final === "H" || final === "f") {
    state.terminalRow = Math.max(0, (params[0] || 1) - 1);
    state.terminalColumn = Math.max(0, (params[1] || 1) - 1);
    terminalEnsureRow(state.terminalRow);
  } else if (final === "K") {
    terminalEnsureRow(state.terminalRow);
    const line = state.terminalLines[state.terminalRow] || "";
    const mode = params[0] || 0;
    if (mode === 1) state.terminalLines[state.terminalRow] = " ".repeat(state.terminalColumn) + line.slice(state.terminalColumn);
    else if (mode === 2) { state.terminalLines[state.terminalRow] = ""; state.terminalColumn = 0; }
    else state.terminalLines[state.terminalRow] = line.slice(0, state.terminalColumn);
  } else if (final === "J" && (params[0] || 0) === 2) {
    terminalResetBuffer();
  }
}

function terminalRender() {
  const output = $("workspaceTerminalOutput");
  if (!output) return;
  if (state.terminalLines.length > 4000) {
    const removeCount = state.terminalLines.length - 3000;
    state.terminalLines.splice(0, removeCount);
    state.terminalRow = Math.max(0, state.terminalRow - removeCount);
  }
  output.textContent = state.terminalLines.join("\n");
  output.scrollTop = output.scrollHeight;
}

function terminalAppend(text) {
  if (text === undefined || text === null) return;
  const data = String(text);
  for (let index = 0; index < data.length; index += 1) {
    const character = data[index];
    if (state.terminalEscape) {
      state.terminalEscape += character;
      if (state.terminalEscape.startsWith("\x1b]") && (character === "\x07" || state.terminalEscape.endsWith("\x1b\\"))) {
        state.terminalEscape = "";
      } else if (state.terminalEscape.startsWith("\x1b[") && /[A-Za-z@`~]/.test(character)) {
        terminalApplyCsi(state.terminalEscape);
        state.terminalEscape = "";
      } else if (!state.terminalEscape.startsWith("\x1b[") && !state.terminalEscape.startsWith("\x1b]")) {
        state.terminalEscape = "";
      } else if (state.terminalEscape.length > 64) {
        state.terminalEscape = "";
      }
      continue;
    }
    if (character === "\x1b") { state.terminalEscape = character; continue; }
    if (character === "\r") { state.terminalColumn = 0; continue; }
    if (character === "\n") {
      state.terminalRow += 1;
      state.terminalColumn = 0;
      terminalEnsureRow(state.terminalRow);
      continue;
    }
    if (character === "\b" || character === "\x7f") {
      state.terminalColumn = Math.max(0, state.terminalColumn - 1);
      continue;
    }
    if (character === "\x07" || character === "\x00") continue;
    terminalEnsureRow(state.terminalRow);
    const line = state.terminalLines[state.terminalRow] || "";
    const padded = line.padEnd(state.terminalColumn, " ");
    state.terminalLines[state.terminalRow] = `${padded.slice(0, state.terminalColumn)}${character}${padded.slice(state.terminalColumn + 1)}`;
    state.terminalColumn += 1;
  }
  terminalRender();
}

function clearWorkspaceTerminal() {
  terminalResetBuffer();
  focusWorkspaceTerminal();
}

function focusWorkspaceTerminal() {
  if (state.terminalConnected) $("workspaceTerminalInput")?.focus({ preventScroll: true });
}

function resetWorkspaceTerminalUi() {
  if (!$("workspaceTerminalOutput")) return;
  if (state.terminalConnected && state.terminalDeviceId === state.currentWorkspaceDeviceId) {
    terminalSetStatus("connected");
    focusWorkspaceTerminal();
    return;
  }
  terminalResetBuffer();
  state.terminalHistoryIndex = state.terminalHistory.length;
  $("workspaceTerminalPrompt").textContent = "SSH";
  terminalSetStatus("disconnected");
  terminalAppend(`${t("terminal.manualWelcome", {}, "Terminal disconnected. Connect only when direct CLI access is required.")}\n`);
  if (!canUseTerminal()) terminalAppend(`${t("terminal.privilegedRequired", {}, "Administrator or Power User access is required to use the terminal.")}\n`);
}

function terminalWebSocketUrl(deviceId) {
  const scheme = window.location.protocol === "https:" ? "wss" : "ws";
  return `${scheme}://${window.location.host}/ws/devices/${encodeURIComponent(deviceId)}/terminal`;
}

function sendTerminalPayload(payload) {
  const socket = state.terminalSocket;
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  socket.send(JSON.stringify(payload));
  return true;
}

function terminalDimensions() {
  const output = $("workspaceTerminalOutput");
  if (!output) return { columns: 160, rows: 40 };
  const computed = getComputedStyle(output);
  const fontSize = Number.parseFloat(computed.fontSize) || 12;
  const lineHeight = Number.parseFloat(computed.lineHeight) || fontSize * 1.6;
  return {
    columns: Math.max(40, Math.min(320, Math.floor(output.clientWidth / (fontSize * 0.61)))),
    rows: Math.max(12, Math.min(120, Math.floor(output.clientHeight / lineHeight))),
  };
}

function resizeWorkspaceTerminal() {
  if (!state.terminalConnected) return;
  sendTerminalPayload({ type: "resize", ...terminalDimensions() });
}

function connectWorkspaceTerminal(auto = false) {
  const device = workspaceDevice();
  if (!device) return;
  if (!canUseTerminal()) {
    if (!auto) toast(t("terminal.privilegedRequired", {}, "Administrator or Power User access is required to use the terminal."), "error");
    return;
  }
  if (state.terminalSocket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(state.terminalSocket.readyState)) return;
  state.terminalManualClose = false;
  state.terminalConnecting = true;
  state.terminalConnected = false;
  state.terminalDeviceId = device.id;
  terminalSetStatus("connecting");
  terminalAppend(`${t("terminal.connectingTo", { device: device.name }, `Connecting to ${device.name}...`)}\n`);
  const socket = new WebSocket(terminalWebSocketUrl(device.id));
  state.terminalSocket = socket;
  socket.onmessage = event => {
    let message;
    try { message = JSON.parse(event.data); } catch (_) { terminalAppend(String(event.data)); return; }
    if (message.type === "status") {
      terminalSetStatus(message.state || "connecting", message.message || "");
      return;
    }
    if (message.type === "ready") {
      state.terminalConnecting = false;
      state.terminalConnected = true;
      state.terminalPrompt = message.prompt || "";
      terminalSetStatus("connected");
      terminalAppend(`${state.terminalPrompt}${state.terminalPrompt.endsWith(" ") ? "" : " "}`);
      sendTerminalPayload({ type: "resize", ...terminalDimensions() });
      focusWorkspaceTerminal();
      return;
    }
    if (message.type === "data" || message.type === "output") {
      terminalAppend(String(message.data || ""));
      return;
    }
    if (message.type === "error") {
      terminalAppend(`\n[${t("common.error", {}, "Error")}] ${message.message || t("terminal.connectionError", {}, "Terminal connection failed.")}\n`);
    }
  };
  socket.onerror = () => terminalAppend(`\n[${t("common.error", {}, "Error")}] ${t("terminal.connectionError", {}, "The terminal connection could not be established.")}\n`);
  socket.onclose = () => {
    const wasManual = state.terminalManualClose;
    state.terminalSocket = null;
    state.terminalConnected = false;
    state.terminalConnecting = false;
    terminalSetStatus("disconnected");
    if (!wasManual) terminalAppend(`\n${t("terminal.sessionClosed", {}, "SSH terminal session closed.")}\n`);
  };
}

function disconnectWorkspaceTerminal(silent = false) {
  if (state.terminalAutoConnectTimer) {
    clearTimeout(state.terminalAutoConnectTimer);
    state.terminalAutoConnectTimer = null;
  }
  const socket = state.terminalSocket;
  state.terminalManualClose = true;
  if (socket && socket.readyState === WebSocket.OPEN) {
    try { socket.send(JSON.stringify({ type: "disconnect" })); } catch (_) {}
    try { socket.close(1000, "User disconnected"); } catch (_) {}
  } else if (socket && socket.readyState === WebSocket.CONNECTING) {
    try { socket.close(); } catch (_) {}
  }
  state.terminalSocket = null;
  state.terminalConnected = false;
  state.terminalConnecting = false;
  state.terminalDeviceId = null;
  terminalSetStatus("disconnected");
  if (!silent && $("workspaceTerminalOutput")) terminalAppend(`\n${t("terminal.disconnectedMessage", {}, "Disconnected from the switch.")}\n`);
}

function terminalKeyData(event) {
  if (event.ctrlKey && !event.altKey && !event.metaKey) {
    const key = event.key.toLowerCase();
    if (key === "l") return "\x0c";
    if (key.length === 1 && key >= "a" && key <= "z") return String.fromCharCode(key.charCodeAt(0) - 96);
    if (key === "[") return "\x1b";
  }
  const special = {
    Enter: "\r", Tab: "\t", Backspace: "\x7f", Escape: "\x1b",
    ArrowUp: "\x1b[A", ArrowDown: "\x1b[B", ArrowRight: "\x1b[C", ArrowLeft: "\x1b[D",
    Home: "\x1b[H", End: "\x1b[F", Delete: "\x1b[3~", PageUp: "\x1b[5~", PageDown: "\x1b[6~",
  };
  if (special[event.key]) return special[event.key];
  if (!event.ctrlKey && !event.metaKey && !event.altKey && event.key.length === 1) return event.key;
  return "";
}

function handleWorkspaceTerminalKeydown(event) {
  if (!state.terminalConnected) return;
  const data = terminalKeyData(event);
  if (!data) return;
  event.preventDefault();
  if (event.ctrlKey && event.key.toLowerCase() === "l") terminalResetBuffer();
  sendTerminalPayload({ type: "input", data });
}

function handleWorkspaceTerminalPaste(event) {
  if (!state.terminalConnected) return;
  event.preventDefault();
  const text = event.clipboardData?.getData("text") || "";
  if (!text) return;
  sendTerminalPayload({ type: "input", data: text.replace(/\r?\n/g, "\r") });
}

function submitWorkspaceTerminalCommand(event) {
  event?.preventDefault();
}

window.addEventListener("resize", () => {
  clearTimeout(window.__oscTerminalResizeTimer);
  window.__oscTerminalResizeTimer = setTimeout(resizeWorkspaceTerminal, 120);
});

function openWorkspaceInBulk() {
  const device = workspaceDevice(); if (!device) return;
  state.selected.clear(); state.selected.set(device.id, { device_id: device.id, port: "", slot: "", port_override: false, slot_override: false });
  renderBulkTargets(); updateBulkSummary(); switchView("bulkView");
}
function renderWorkspaceActionOptions(filter = "") {
  const select = $("workspaceAction"); if (!select) return;
  const current = select.value || "interface_status_all";
  const query = String(filter || "").trim().toLowerCase();
  const grouped = new Map();
  for (const [key, meta] of availableActionEntries()) {
    if (key === "vlan_port_maintenance" || key === "custom_runbook") continue;
    const haystack = `${key} ${meta.label} ${meta.category} ${meta.description}`.toLowerCase();
    if (query && !haystack.includes(query)) continue;
    if (!grouped.has(meta.category)) grouped.set(meta.category, []);
    grouped.get(meta.category).push([key, meta]);
  }
  select.innerHTML = [...grouped.entries()].map(([category, entries]) => `<optgroup label="${escapeHtml(category)}">${entries.map(([key, meta]) => `<option value="${escapeHtml(key)}">${escapeHtml(meta.label)}</option>`).join("")}</optgroup>`).join("");
  if ([...select.options].some(option => option.value === current)) select.value = current; else if (select.options.length) select.selectedIndex = 0;
  updateWorkspaceActionContext();
}
function updateWorkspaceActionContext() {
  const action = $("workspaceAction").value || "interface_status_all";
  const meta = actionMeta(action);
  $("workspaceActionContext").innerHTML = `<span class="context-icon"><svg><use href="#${actionIconId(action, meta)}"></use></svg></span><div class="context-copy"><span class="context-category">${escapeHtml(meta.category)}</span><strong>${escapeHtml(meta.label)}</strong><span class="context-description">${escapeHtml(meta.description)}</span></div><span class="risk-badge ${meta.risk}">${escapeHtml(t(meta.risk === "change" ? "common.change" : "common.readOnly", {}, meta.risk === "change" ? "Change" : "Read only"))}</span>`;
  $("workspacePortField").classList.toggle("hidden", !meta.needsPort);
  $("workspaceSlotField").classList.toggle("hidden", !meta.needsSlot);
  $("workspaceAliasField").classList.toggle("hidden", !meta.needsAlias);
  $("workspaceDelayField").classList.toggle("hidden", !meta.needsDelay);
  $("workspaceCustomField").classList.toggle("hidden", !meta.custom);
  $("workspaceExecuteButton").classList.toggle("danger", meta.risk === "change");
  $("workspaceExecuteButton").classList.toggle("primary", meta.risk !== "change");
  const forceLive = Boolean(meta.liveReadOnly || action === "check_unp" || action === "vlan_port_maintenance");
  if ($("workspaceDryRun")) {
    $("workspaceDryRun").disabled = forceLive;
    if (forceLive) $("workspaceDryRun").checked = false;
  }
  $("workspaceDryRunRow")?.classList.toggle("hidden", forceLive);
  clearWorkspacePreview();
}
function workspaceTarget() {
  const device = workspaceDevice();
  return device ? [{ device_id: device.id, port: $("workspacePort").value.trim(), slot: $("workspaceSlot").value.trim() }] : [];
}
function workspacePayload(confirmationText = "") {
  const action = $("workspaceAction").value;
  const meta = actionMeta(action);
  return { action, targets: workspaceTarget(), dry_run: (meta.liveReadOnly || action === "check_unp") ? false : $("workspaceDryRun").checked, cycle_delay_seconds: Number($("workspaceDelay").value || 5), port_alias: $("workspaceAlias").value.trim(), confirmation_text: confirmationText, custom_command: action === "custom_command" ? $("workspaceCustom").value : "" };
}
async function previewWorkspaceOperation() {
  if (!workspaceDevice()) return null;
  try {
    const payload = workspacePayload();
    const result = await api("/api/preview", { method: "POST", body: { action: payload.action, targets: payload.targets, cycle_delay_seconds: payload.cycle_delay_seconds, port_alias: payload.port_alias, custom_command: payload.custom_command } });
    $("workspacePreviewPanel").innerHTML = result.items.map(item => item.error ? `<div class="preview-item error"><strong>${escapeHtml(item.device || "Switch")}</strong>${escapeHtml(item.error)}</div>` : `<div class="preview-item"><strong>${escapeHtml(item.device)} · ${escapeHtml(item.profile)}</strong><code>${escapeHtml(item.command)}${item.verification ? `\nVERIFY: ${escapeHtml(item.verification)}` : ""}</code></div>`).join("");
    return result;
  } catch (error) { toast(error.message, "error"); return null; }
}
function clearWorkspacePreview() {
  if (!$("workspacePreviewPanel")) return;
  $("workspacePreviewPanel").innerHTML = `<div class="empty-state compact-empty"><svg><use href="#i-terminal"></use></svg><strong>${escapeHtml(t("workspace.noPreview", {}, "No preview yet"))}</strong></div>`;
}
async function executeWorkspaceOperation() {
  if (!isSshUser()) { toast(t("workspace.sshRequired", {}, "Sign in with a personal SSH account to run commands."), "error"); return; }
  const preview = await previewWorkspaceOperation(); if (!preview || preview.items.some(item => item.error)) return;
  const payload = workspacePayload();
  const meta = actionMeta(payload.action);
  if (!payload.dry_run && meta.risk === "change" && !confirm(t("workspace.confirmChange", {}, "Run this live change on the selected switch?"))) return;
  if (!payload.dry_run && meta.risk === "change") payload.confirmation_text = "EXECUTE";
  try { const result = await api("/api/execute", { method: "POST", body: payload }); toast(t("operations.jobQueued", { id: result.job_id }, `Job #${result.job_id} queued`), "success"); } catch (error) { toast(error.message, "error"); }
}
function portStateLabel(value) {
  const normalized = String(value || "unknown").toLowerCase();
  if (normalized === "unknown") return t("workspace.notReported", {}, "Not reported");
  if (normalized === "enabled") return t("status.enabled", {}, "Enabled");
  if (normalized === "disabled") return t("status.disabled", {}, "Disabled");
  if (normalized === "up") return t("status.up", {}, "Up");
  if (normalized === "down") return t("status.down", {}, "Down");
  return normalized;
}
function portStateBadge(value) {
  const normalized = String(value || "unknown").toLowerCase();
  return `<span class="status port-state ${escapeHtml(normalized)}">${escapeHtml(portStateLabel(normalized))}</span>`;
}
function formatObservedDuration(seconds, stateValue = "") {
  const numeric = Number(seconds);
  if (!Number.isFinite(numeric) || numeric < 0 || !["up", "down"].includes(String(stateValue))) return t("workspace.notAvailable", {}, "Not available");
  const days = Math.floor(numeric / 86400);
  const hours = Math.floor((numeric % 86400) / 3600);
  const minutes = Math.floor((numeric % 3600) / 60);
  if (days) return `${days}d ${hours}h`;
  if (hours) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}
function workspacePortMedia(port) {
  const speed = port.detected_speed || port.configured_speed || "";
  const duplex = port.detected_duplex || port.configured_duplex || "";
  return [speed, duplex].filter(Boolean).join(" · ") || t("workspace.notReported", {}, "Not reported");
}
function workspacePortStateClass(port) {
  if (port.admin_state === "disabled") return "disabled";
  if (port.link_state === "up") return "up";
  if (port.link_state === "down") return "down";
  return "unreported";
}
function workspacePortGroup(port) {
  const parts = String(port.port || "").split("/");
  return parts.length > 2 ? parts.slice(0, -1).join("/") : (parts[0] || "Ports");
}
function workspacePortNumber(port) {
  return String(port.port || "").split("/").pop() || port.port;
}
function updateWorkspacePortMetrics(summary = {}) {
  const total = Number(summary.total ?? state.workspacePorts.length);
  const complete = Number(summary.complete || 0);
  $("workspaceMetricPorts").textContent = total;
  $("workspaceMetricUp").textContent = Number(summary.link_up || 0);
  $("workspaceMetricDown").textContent = Number(summary.link_down || 0);
  $("workspaceMetricDisabled").textContent = Number(summary.admin_disabled || 0);
  $("workspaceMetricPoe").textContent = Number(summary.poe_on || 0);
  $("workspaceMetricQuality").textContent = `${total ? Math.round((complete / total) * 100) : 0}%`;
}
function workspaceDecodedMembers(device, key) {
  const value = device?.[key];
  if (Array.isArray(value)) return value.filter(item => item && typeof item === "object");
  if (!value) return [];
  try {
    const decoded = JSON.parse(String(value));
    return Array.isArray(decoded) ? decoded.filter(item => item && typeof item === "object") : [];
  } catch (_) { return []; }
}
function workspaceMemberId(member) {
  const raw = String(member?.id ?? member?.config_id ?? "").trim();
  return /^\d+$/.test(raw) ? String(Number(raw)) : "";
}
function workspacePortChassisId(port, device = workspaceDevice()) {
  const parts = String(port?.port || port || "").split("/").filter(Boolean);
  if (!parts.length || !/^\d+$/.test(parts[0])) return "1";
  const profile = String(device?.profile || "AOS8").toUpperCase();
  if (profile === "AOS8" && parts.length >= 3) return String(Number(parts[0]));
  if (profile === "AOS6" && parts.length >= 2) return String(Number(parts[0]));
  return "1";
}
function workspaceKnownChassisIds(device, livePorts = []) {
  const ids = new Set();
  for (const key of ["stack_members", "stack_baseline_members"]) {
    workspaceDecodedMembers(device, key).forEach(member => {
      const id = workspaceMemberId(member); if (id) ids.add(id);
    });
  }
  for (const key of ["stack_member_ids", "stack_baseline_member_ids"]) {
    const values = Array.isArray(device?.[key]) ? device[key] : [];
    values.forEach(value => { const raw = String(value ?? "").trim(); if (/^\d+$/.test(raw)) ids.add(String(Number(raw))); });
  }
  (livePorts || []).forEach(port => {
    const id = workspacePortChassisId(port, device); if (id) ids.add(id);
  });
  if (!ids.size) ids.add("1");
  return [...ids].sort((a,b) => Number(a) - Number(b));
}
function workspaceChassisMeta(device, chassisId) {
  const id = String(Number(chassisId || 1));
  const current = workspaceDecodedMembers(device, "stack_members");
  const baseline = workspaceDecodedMembers(device, "stack_baseline_members");
  const currentMember = current.find(member => workspaceMemberId(member) === id) || null;
  const baselineMember = baseline.find(member => workspaceMemberId(member) === id) || null;
  const member = currentMember || baselineMember || {};
  return {
    id,
    role: String(member.role || "").trim(),
    status: String(member.status || member.state || "").trim(),
    model: String(member.model || "").trim(),
    mac: String(member.mac || member.chassis_mac || "").trim(),
    current: Boolean(currentMember),
    learned: Boolean(baselineMember),
  };
}
function workspacePortForChassis(portName, chassisId) {
  const parts = String(portName || "").split("/");
  if (parts.length >= 2) parts[0] = String(chassisId);
  return parts.join("/");
}
function workspaceCompactOs6360Model(device) {
  const normalized = String(device?.model || "").toUpperCase().trim().replace(/\s+/g, "-");
  return /OS6360[-_]?P?10(?!\d)/i.test(normalized);
}
function workspaceOs6360Family(device) {
  return /OS6360(?!\d)/i.test(String(device?.model || "").toUpperCase());
}
function workspaceCompactOs6360FromPorts(device, livePorts = []) {
  if (workspaceCompactOs6360Model(device)) return true;
  if (!workspaceOs6360Family(device)) return false;
  const numbers = new Set();
  for (const item of livePorts || []) {
    const raw = String(item?.port || item || "").trim();
    const parts = raw.split("/");
    if (![2, 3].includes(parts.length) || !parts.every(part => /^\d+$/.test(part))) continue;
    numbers.add(Number(parts[parts.length - 1]));
  }
  for (let number = 1; number <= 12; number += 1) if (!numbers.has(number)) return false;
  for (const number of numbers) if (number >= 13 && number < 100) return false;
  if (![...numbers].some(number => number >= 100)) return false;
  return true;
}
function workspaceCompactOs6360Layout(device) {
  const profile = String(device?.profile || "AOS8").toUpperCase();
  const portName = number => profile === "AOS8" ? `1/1/${number}` : `1/${number}`;
  const access = Array.from({ length: 8 }, (_, index) => portName(index + 1));
  const uplinks = Array.from({ length: 4 }, (_, index) => portName(index + 9));
  return {
    known: true, access_ports: 8, uplink_ports: 4, total_ports: 12, inferred: true,
    modules: [
      { id: "access", label: "Access ports", role: "access", ports: access },
      { id: "uplinks", label: "Uplinks", role: "uplink", ports: uplinks },
    ],
  };
}
function workspaceEffectivePortLayout(device, livePorts = []) {
  if (workspaceCompactOs6360FromPorts(device, livePorts)) return workspaceCompactOs6360Layout(device);
  return device?.port_layout || { known: false, access_ports: 0, uplink_ports: 0, total_ports: 0, modules: [] };
}
function workspaceSanitizeLivePorts(device, livePorts = []) {
  if (!workspaceCompactOs6360FromPorts(device, livePorts)) return livePorts || [];
  return (livePorts || []).filter(item => {
    const parts = String(item?.port || "").trim().split("/");
    if (![2, 3].includes(parts.length) || !parts.every(part => /^\d+$/.test(part))) return false;
    const number = Number(parts[parts.length - 1]);
    return number >= 1 && number <= 12;
  });
}
function workspacePortModuleInfo(port, device, livePorts = []) {
  const number = Number(workspacePortNumber(port));
  const layout = workspaceEffectivePortLayout(device, livePorts);
  const accessPorts = Number(layout?.access_ports || 0);
  const uplinkPorts = Number(layout?.uplink_ports || 0);
  const totalPorts = Number(layout?.total_ports || 0);
  if (Number.isFinite(number) && number > 0 && accessPorts && number <= accessPorts) {
    return { label: t("workspace.accessPorts", {}, "Access ports"), role: "access", order: 0, portIndex: number - 1 };
  }
  if (Number.isFinite(number) && number > accessPorts && uplinkPorts && number <= totalPorts) {
    return { label: t("workspace.uplinks", {}, "Uplinks"), role: "uplink", order: 1, portIndex: number - accessPorts - 1 };
  }
  return { label: t("workspace.additionalInterfaces", {}, "Additional interfaces"), role: "additional", order: 2, portIndex: Number.isFinite(number) ? number - 1 : 999 };
}
function buildWorkspaceLayoutPorts(device, livePorts = []) {
  const layout = workspaceEffectivePortLayout(device, livePorts);
  const modules = layout?.modules || [];
  const ports = [];
  const chassisIds = workspaceKnownChassisIds(device, livePorts);
  chassisIds.forEach((chassisId, chassisIndex) => {
    modules.forEach((module, moduleIndex) => {
      (module.ports || []).forEach((port, portIndex) => ports.push({
        port: workspacePortForChassis(port, chassisId),
        alias: "",
        admin_state: "unknown",
        link_state: "unknown",
        autoneg_state: "unknown",
        detected_speed: "",
        configured_speed: "",
        detected_duplex: "",
        configured_duplex: "",
        vlans: [],
        poe_state: "unknown",
        data_quality: "unreported",
        placeholder: true,
        _chassisId: chassisId,
        _chassisIndex: chassisIndex,
        _layoutModule: module.role === "access" ? t("workspace.accessPorts", {}, "Access ports") : module.role === "uplink" ? t("workspace.uplinks", {}, "Uplinks") : (module.label || module.id || t("workspace.module", {}, "Module")),
        _layoutRole: module.role || "access",
        _layoutModuleIndex: moduleIndex,
        _layoutPortIndex: portIndex,
      }));
    });
  });
  return ports;
}
function hydrateWorkspacePorts(device, livePorts = []) {
  const sanitizedLivePorts = workspaceSanitizeLivePorts(device, livePorts);
  const effectiveLayout = workspaceEffectivePortLayout(device, sanitizedLivePorts);
  if (effectiveLayout?.known) device.port_layout = effectiveLayout;
  const expected = buildWorkspaceLayoutPorts(device, sanitizedLivePorts);
  if (!expected.length) return sanitizedLivePorts.map((port, index) => {
    const info = workspacePortModuleInfo(port, device, sanitizedLivePorts);
    return { ...port, placeholder: false, _chassisId: workspacePortChassisId(port, device), _layoutModule: info.label, _layoutRole: info.role, _layoutModuleIndex: info.order, _layoutPortIndex: info.portIndex ?? index };
  });
  const liveByPort = new Map(sanitizedLivePorts.map(port => [String(port.port), port]));
  const used = new Set();
  const hydrated = expected.map(port => {
    const live = liveByPort.get(String(port.port));
    if (!live) return port;
    used.add(String(port.port));
    return { ...port, ...live, placeholder: false };
  });
  const expectedTotal = Number(effectiveLayout?.total_ports || 0);
  sanitizedLivePorts.forEach((port, index) => {
    if (used.has(String(port.port))) return;
    const number = Number(workspacePortNumber(port));
    const plausiblePhysicalPort = Number.isFinite(number) && number > 0 && (!expectedTotal || number <= expectedTotal + 16);
    if (!plausiblePhysicalPort) return;
    const info = workspacePortModuleInfo(port, device, sanitizedLivePorts);
    hydrated.push({
      ...port,
      placeholder: false,
      _chassisId: workspacePortChassisId(port, device),
      _layoutModule: info.label,
      _layoutRole: info.role,
      _layoutModuleIndex: info.order,
      _layoutPortIndex: info.portIndex ?? index,
    });
  });
  return hydrated;
}
function setWorkspaceInventoryStatus(status, detail = "") {
  const badge = $("workspaceInventoryStatus");
  if (!badge) return;
  const labels = {
    layout: t("workspace.layoutReady", {}, "Model layout"),
    refreshing: t("workspace.refreshing", {}, "Refreshing"),
    live: t("workspace.live", {}, "Live"),
    partial: t("workspace.livePartial", {}, "Live · partial"),
    cached: t("workspace.cached", {}, "Cached"),
    unavailable: t("workspace.unavailable", {}, "Unavailable"),
  };
  badge.className = `inventory-status ${status}`;
  const label = badge.querySelector("span");
  if (label) label.textContent = labels[status] || status;
  badge.title = detail || labels[status] || status;
}
function renderWorkspaceDataAssurance() {
  const result = state.workspacePortResult;
  if (!result) return;
  if (result.cached) setWorkspaceInventoryStatus("cached", result.refresh_error || "");
  else if (result.partial) setWorkspaceInventoryStatus("partial", (result.warnings || []).join("\n"));
  else setWorkspaceInventoryStatus("live", result.refreshed_at ? formatDate(result.refreshed_at) : "");
}
async function loadWorkspacePorts(showLoading = true) {
  const device = workspaceDevice();
  if (!device || !isSshUser() || state.workspacePortsLoading) return;
  const button = $("workspaceRefreshPorts");
  state.workspacePortsLoading = true;
  button.disabled = true;
  if ($("workspaceTerminalConnect")) $("workspaceTerminalConnect").disabled = true;
  setWorkspaceInventoryStatus("refreshing");
  try {
    const result = await api(`/api/devices/${device.id}/port-inventory`, { method: "POST" });
    if (state.currentWorkspaceDeviceId !== device.id) return;
    state.workspacePortResult = result;
    // Live inventory can learn a more specific hardware SKU than the device
    // object that opened the workspace. Apply the returned identity/layout
    // immediately so a compact switch is rendered correctly on this refresh,
    // without requiring the user to close and reopen the workspace.
    const liveDevice = result.device || device;
    if (result.device && device) Object.assign(device, result.device);
    const effectiveLayout = workspaceEffectivePortLayout(liveDevice, result.ports || []);
    if (effectiveLayout?.known) {
      liveDevice.port_layout = effectiveLayout;
      if (device) device.port_layout = effectiveLayout;
    }
    state.workspacePorts = hydrateWorkspacePorts(liveDevice, result.ports || []);
    const summary = { ...(result.summary || {}) };
    summary.total = Math.max(Number(summary.total || 0), state.workspacePorts.length);
    updateWorkspacePortMetrics(summary);
    renderWorkspaceDataAssurance();
    renderWorkspacePorts();
    if (result.cached && showLoading && result.refresh_error) {
      toast(t("workspace.cachedRefresh", {}, "Live refresh was unavailable. The last successful port data is still displayed."), "warning");
    }
  } catch (error) {
    if (state.currentWorkspaceDeviceId !== device.id) return;
    setWorkspaceInventoryStatus("unavailable", error.message);
    if (showLoading) toast(error.message, "error");
    renderWorkspacePorts();
  } finally {
    state.workspacePortsLoading = false;
    button.disabled = state.terminalConnected || state.terminalConnecting;
    if ($("workspaceTerminalConnect")) $("workspaceTerminalConnect").disabled = state.terminalConnected || state.terminalConnecting || !canUseTerminal();
  }
}

function workspacePortMatches(port) {
  const query = $("workspacePortSearch").value.trim().toLowerCase();
  const status = $("workspacePortStatus").value;
  const haystack = [
    port.port, port.alias, ...(port.vlans || []), port.admin_state, port.link_state,
    port.detected_speed, port.configured_speed, port.detected_duplex, port.configured_duplex,
    port.poe_state, port.poe_oper_status, port.poe_type, port.poe_class,
  ].filter(Boolean).join(" ").toLowerCase();
  if (query && !haystack.includes(query)) return false;
  if (status === "up" && port.link_state !== "up") return false;
  if (status === "down" && port.link_state !== "down") return false;
  if (status === "disabled" && port.admin_state !== "disabled") return false;
  if (status === "poe" && port.poe_state !== "on") return false;
  if (status === "no-alias" && String(port.alias || "").trim()) return false;
  if (status === "incomplete" && port.data_quality === "complete") return false;
  return true;
}
function workspaceChassisReloadState(device, chassisId, stacked) {
  const allowed = actionAllowedForCurrentUser(stacked ? "reload_stack_member" : "reload_switch");
  if (!allowed) return { allowed: false, reason: t("workspace.reloadDenied", {}, "Your assigned role cannot reload switches.") };
  const meta = workspaceChassisMeta(device, chassisId);
  const status = String(meta.status || "").toLowerCase();
  if (stacked && status && /(not[- ]?joined|missing|unassigned|down|offline|absent)/.test(status)) {
    return { allowed: false, reason: t("workspace.reloadUnavailableMember", {}, "This chassis is not currently available for reload.") };
  }
  if (stacked && String(device?.profile || "").toUpperCase() === "AOS6" && !meta.role) {
    return { allowed: false, reason: t("workspace.reloadRoleRequired", {}, "Refresh Stack Member Health first so the AOS6 member role is known.") };
  }
  return { allowed: true, reason: "" };
}
function renderWorkspacePortMap(ports) {
  const container = $("workspacePortMap");
  const device = workspaceDevice();
  if (!container || !device) return;
  const chassisGroups = new Map();
  ports.forEach(port => {
    const chassisId = String(port._chassisId || workspacePortChassisId(port, device));
    if (!chassisGroups.has(chassisId)) chassisGroups.set(chassisId, new Map());
    const modules = chassisGroups.get(chassisId);
    const group = port._layoutModule || workspacePortGroup(port);
    if (!modules.has(group)) modules.set(group, { items: [], role: port._layoutRole || "dynamic", order: port._layoutModuleIndex ?? 500 });
    modules.get(group).items.push(port);
  });
  const chassisIds = [...chassisGroups.keys()].sort((a,b) => Number(a) - Number(b));
  const stacked = chassisIds.length > 1 || workspaceKnownChassisIds(device, state.workspacePorts).length > 1;
  const totalMembers = Math.max(chassisIds.length, workspaceKnownChassisIds(device, state.workspacePorts).length);
  container.innerHTML = chassisIds.map((chassisId, chassisIndex) => {
    const modules = chassisGroups.get(chassisId);
    const meta = workspaceChassisMeta(device, chassisId);
    const reloadState = workspaceChassisReloadState(device, chassisId, stacked);
    const role = meta.role || (stacked ? t("workspace.stackMember", {}, "Stack member") : t("workspace.standaloneSwitch", {}, "Standalone switch"));
    const status = meta.status || (meta.current ? t("workspace.present", {}, "Present") : "");
    const memberLabel = stacked
      ? t("workspace.memberOf", { index: chassisIndex + 1, total: totalMembers }, `Member ${chassisIndex + 1} of ${totalMembers}`)
      : t("workspace.singleChassis", {}, "Single chassis");
    const reloadLabel = stacked ? t("workspace.reloadChassis", {}, "Reload chassis") : t("workspace.reloadSwitch", {}, "Reload switch");
    const reloadButton = reloadState.allowed
      ? `<button class="chassis-reload-button" type="button" onclick="openWorkspaceReload('${escapeHtml(chassisId)}')" title="${escapeHtml(reloadLabel)}"><svg><use href="#i-power"></use></svg><span>${escapeHtml(reloadLabel)}</span></button>`
      : `<button class="chassis-reload-button" type="button" disabled title="${escapeHtml(reloadState.reason)}"><svg><use href="#i-power"></use></svg><span>${escapeHtml(reloadLabel)}</span></button>`;
    const sortedGroups = [...modules.entries()].sort((a,b) => a[1].order - b[1].order);
    const moduleHtml = sortedGroups.map(([group, entry]) => {
      const items = entry.items.sort((a,b) => (a._layoutPortIndex ?? 999) - (b._layoutPortIndex ?? 999));
      const accessClass = entry.role === "access" ? "access-module" : "auxiliary-module";
      const gridClass = entry.role === "access" && items.length === 48 ? "layout-48" : entry.role === "access" && items.length === 24 ? "layout-24" : "";
      return `<section class="logical-switch-module ${accessClass}"><header><span>${escapeHtml(entry.role === "access" ? t("workspace.frontPanel", {}, "Front panel") : t("workspace.module", {}, "Module"))}</span><strong>${escapeHtml(group)}</strong><small>${items.length} ${escapeHtml(t("workspace.ports", {}, "ports"))}</small></header><div class="logical-port-grid ${gridClass}">${items.map(port => {
        const stateClass = port.placeholder ? "pending" : workspacePortStateClass(port);
        const alias = port.placeholder ? "" : (port.alias || t("workspace.noAlias", {}, "No alias"));
        const duration = port.placeholder ? "" : formatObservedDuration(port.observed_link_seconds, port.link_state);
        const action = port.placeholder ? "" : `onclick="openWorkspacePort('${escapeHtml(port.port)}')"`;
        const title = port.placeholder ? port.port : `${port.port} · ${alias} · ${portStateLabel(port.link_state)}`;
        return `<button class="logical-port ${stateClass}" type="button" ${action} ${port.placeholder ? "disabled" : ""} title="${escapeHtml(title)}"><span class="logical-port-led"></span><strong>${escapeHtml(workspacePortNumber(port))}</strong><small>${escapeHtml(alias)}</small><em>${escapeHtml(duration)}</em>${port.poe_state === "on" ? `<i class="poe-dot" title="PoE active"></i>` : ""}</button>`;
      }).join("")}</div></section>`;
    }).join("");
    return `<section class="logical-chassis-card" data-chassis-id="${escapeHtml(chassisId)}">
      <header class="logical-chassis-card-head">
        <div class="logical-chassis-controls">${reloadButton}<span class="logical-chassis-index">${escapeHtml(String(chassisIndex + 1).padStart(2,"0"))}</span></div>
        <div class="logical-chassis-identity"><span>${escapeHtml(stacked ? t("workspace.stackChassis", {}, "STACK CHASSIS") : t("workspace.switchChassis", {}, "SWITCH CHASSIS"))}</span><strong>${escapeHtml(stacked ? `Chassis ${chassisId}` : device.name)}</strong><small>${escapeHtml([role, memberLabel, status].filter(Boolean).join(" · "))}</small></div>
        <div class="logical-chassis-meta">${meta.model ? `<span>${escapeHtml(meta.model)}</span>` : ""}${meta.mac ? `<code>${escapeHtml(meta.mac)}</code>` : ""}</div>
      </header>
      <div class="logical-chassis-modules">${moduleHtml}</div>
    </section>`;
  }).join("") || `<div class="empty-state port-map-empty"><svg><use href="#i-device"></use></svg><strong>${escapeHtml(t("workspace.layoutUnavailable", {}, "The detected model does not expose a known port layout."))}</strong></div>`;
}


window.openWorkspaceReload = async function(chassisId = "1") {
  const device = workspaceDevice();
  if (!device) return;
  const knownChassis = workspaceKnownChassisIds(device, state.workspacePorts);
  const stacked = knownChassis.length > 1;
  const action = stacked ? "reload_stack_member" : "reload_switch";
  const normalizedChassis = String(Number(chassisId || knownChassis[0] || 1));
  const reloadState = workspaceChassisReloadState(device, normalizedChassis, stacked);
  if (!reloadState.allowed) { toast(reloadState.reason, "error"); return; }
  if (Number(device.pending_config_count || 0) > 0) {
    toast(t("workspace.reloadUnsaved", {}, "This switch has unsaved Portivo changes. Save All Changes before reloading it."), "error");
    return;
  }
  try {
    const preview = await api("/api/preview", {
      method: "POST",
      body: {
        action,
        targets: [{ device_id: Number(device.id), port: "", slot: stacked ? normalizedChassis : "" }],
        cycle_delay_seconds: 5,
        port_alias: "",
        custom_command: "",
      },
    });
    const item = preview?.items?.[0];
    if (!item || item.error) throw new Error(item?.error || t("workspace.reloadPreviewFailed", {}, "Portivo could not build a safe reload plan."));
    const meta = workspaceChassisMeta(device, normalizedChassis);
    const target = stacked ? `Chassis ${normalizedChassis}` : device.name;
    state.workspacePendingReload = { action, deviceId: Number(device.id), chassisId: stacked ? normalizedChassis : "", target, command: item.command || "", stacked };
    $("workspaceReloadDialogTitle").textContent = stacked
      ? t("workspace.reloadChassisTitle", { chassis: normalizedChassis }, `Reload Chassis ${normalizedChassis}`)
      : t("workspace.reloadSwitchTitle", { switch: device.name }, `Reload ${device.name}`);
    $("workspaceReloadDialogSubtitle").textContent = stacked
      ? t("workspace.reloadChassisHelp", {}, "Only the selected physical stack member will receive the reload command.")
      : t("workspace.reloadSwitchHelp", {}, "The complete standalone switch will restart and temporarily become unreachable.");
    $("workspaceReloadTarget").textContent = target;
    $("workspaceReloadTargetMeta").textContent = stacked
      ? [meta.role || t("workspace.stackMember", {}, "Stack member"), meta.status || "", `${device.profile}`].filter(Boolean).join(" · ")
      : [device.host, device.model || device.profile, device.site].filter(Boolean).join(" · ");
    $("workspaceReloadCommand").textContent = item.command || "";
    $("workspaceReloadConfirmation").value = "";
    $("workspaceReloadError").textContent = "";
    $("workspaceReloadSubmit").disabled = false;
    $("workspaceReloadDialog").showModal();
    setTimeout(() => $("workspaceReloadConfirmation")?.focus(), 60);
  } catch (error) {
    state.workspacePendingReload = null;
    toast(error.message || String(error), "error");
  }
};
async function confirmWorkspaceReload(event) {
  event.preventDefault();
  const pending = state.workspacePendingReload;
  if (!pending) return;
  const typed = String($("workspaceReloadConfirmation")?.value || "").trim().toUpperCase();
  if (typed !== "RELOAD") {
    $("workspaceReloadError").textContent = t("workspace.typeReload", {}, "Type RELOAD to confirm this restart.");
    return;
  }
  const button = $("workspaceReloadSubmit");
  button.disabled = true;
  $("workspaceReloadError").textContent = "";
  try {
    const result = await api("/api/execute", {
      method: "POST",
      body: {
        action: pending.action,
        targets: [{ device_id: pending.deviceId, port: "", slot: pending.chassisId }],
        dry_run: false,
        cycle_delay_seconds: 5,
        port_alias: "",
        custom_command: "",
        confirmation_text: "EXECUTE",
      },
    });
    $("workspaceReloadDialog").close();
    state.workspacePendingReload = null;
    toast(t("workspace.reloadQueued", { id: result.job_id }, `Reload Job #${result.job_id} queued`), "success");
    Promise.allSettled([loadJobs(), loadDashboard()]);
    setTimeout(() => { if (workspaceDevice()?.id === pending.deviceId) loadWorkspacePorts(false); }, 15000);
  } catch (error) {
    $("workspaceReloadError").textContent = error.message || String(error);
  } finally {
    button.disabled = false;
  }
}

function renderWorkspacePortTable(ports) {
  $("workspacePortsTable").innerHTML = ports.map(port => {
    const vlans = (port.vlans || []).length ? port.vlans.map(vlan => `<span class="vlan-chip">${escapeHtml(vlan)}</span>`).join("") : `<span class="muted-line">${escapeHtml(t("workspace.notReported", {}, "Not reported"))}</span>`;
    const poeLabel = port.poe_state === "on" ? `${t("workspace.poeOn", {}, "PoE on")}${port.poe_power_mw != null ? ` · ${port.poe_power_mw} mW` : ""}` : port.poe_state === "off" ? (port.poe_oper_status || t("workspace.poeOff", {}, "PoE off")) : port.poe_state === "fault" ? (port.poe_oper_status || t("workspace.poeFault", {}, "PoE fault")) : t("workspace.notReported", {}, "Not reported");
    const alias = port.alias ? `<strong>${escapeHtml(port.alias)}</strong>` : `<span class="alias-empty">${escapeHtml(t("workspace.noAlias", {}, "No alias"))}</span>`;
    return `<tr class="port-row ${escapeHtml(workspacePortStateClass(port))}"><td><button class="port-link" onclick="openWorkspacePort('${escapeHtml(port.port)}')">${escapeHtml(port.port)}</button></td><td><div class="port-alias-cell">${alias}${actionAllowedForCurrentUser("interface_alias") ? `<button class="inline-edit" onclick="openWorkspacePort('${escapeHtml(port.port)}',true)" title="${escapeHtml(t("workspace.editAlias", {}, "Edit alias"))}">✎</button>` : ""}</div></td><td>${portStateBadge(port.admin_state)}</td><td>${portStateBadge(port.link_state)}</td><td><div class="observed-duration"><strong>${escapeHtml(formatObservedDuration(port.observed_link_seconds, port.link_state))}</strong><span>${escapeHtml(port.last_link_change_at ? formatDate(port.last_link_change_at) : t("workspace.notAvailable", {}, "Not available"))}</span></div></td><td><div class="media-cell"><strong>${escapeHtml(workspacePortMedia(port))}</strong><span>${escapeHtml(port.autoneg_state !== "unknown" ? `Auto-neg: ${portStateLabel(port.autoneg_state)}` : t("workspace.notReported", {}, "Not reported"))}</span></div></td><td><div class="vlan-list">${vlans}</div></td><td><span class="poe-state ${escapeHtml(port.poe_state)}">${escapeHtml(poeLabel)}</span></td><td><button class="btn secondary compact" onclick="openWorkspacePort('${escapeHtml(port.port)}')"><svg><use href="#i-eye"></use></svg>${escapeHtml(t("workspace.inspect", {}, "Inspect"))}</button></td></tr>`;
  }).join("") || `<tr><td colspan="9"><div class="empty-state">${escapeHtml(t("workspace.noPorts", {}, "No ports are available for this filter. Refresh live ports first."))}</div></td></tr>`;
}
function renderWorkspacePorts() {
  const ports = state.workspacePorts.filter(workspacePortMatches);
  renderWorkspacePortMap(ports);
  renderWorkspacePortTable(ports);
  document.querySelectorAll("[data-port-filter]").forEach(button => button.classList.toggle("active", button.dataset.portFilter === $("workspacePortStatus").value));
}
function setWorkspacePortView(view) {
  state.workspacePortView = view === "table" ? "table" : "map";
  $("workspacePortMapView").classList.toggle("hidden", state.workspacePortView !== "map");
  $("workspacePortTableView").classList.toggle("hidden", state.workspacePortView !== "table");
  document.querySelectorAll("[data-port-view]").forEach(button => button.classList.toggle("active", button.dataset.portView === state.workspacePortView));
}
function clearWorkspacePortFilters() {
  $("workspacePortSearch").value = "";
  $("workspacePortStatus").value = "";
  renderWorkspacePorts();
}
function applyWorkspacePortFilter(filter) {
  $("workspacePortStatus").value = filter || "";
  renderWorkspacePorts();
}
function detailItem(label, value, note = "") {
  return `<article><span>${escapeHtml(label)}</span><strong>${escapeHtml(value || t("workspace.notReported", {}, "Not reported"))}</strong>${note ? `<small>${escapeHtml(note)}</small>` : ""}</article>`;
}
window.openWorkspacePort = function(portId, focusAlias = false) {
  const port = state.workspacePorts.find(item => item.port === portId);
  if (!port || port.placeholder) return;
  state.workspacePortDialogSession += 1;
  state.activeWorkspacePort = port;
  $("workspacePortDialogTitle").textContent = `${t("workspace.port", {}, "Port")} ${port.port}`;
  $("workspacePortDialogSubtitle").textContent = port.alias || t("workspace.portDetailsHelp", {}, "Switch-reported state and controlled port operations.");
  $("workspacePortDetailStatus").innerHTML = `${portStateBadge(port.admin_state)}${portStateBadge(port.link_state)}<span class="port-quality ${escapeHtml(port.data_quality || "unreported")}">${escapeHtml(port.data_quality === "complete" ? t("workspace.verifiedFields", {}, "Core fields verified") : t("workspace.incompleteData", {}, "Incomplete data"))}</span>`;
  const vlans = (port.vlans || []).join(", ") || t("workspace.notReported", {}, "Not reported");
  const poePower = port.poe_power_mw != null ? `${port.poe_power_mw} mW${port.poe_max_mw != null ? ` / ${port.poe_max_mw} mW` : ""}` : t("workspace.notReported", {}, "Not reported");
  $("workspacePortDetailGrid").innerHTML = [
    detailItem(t("workspace.adminState", {}, "Admin state"), portStateLabel(port.admin_state), t("workspace.adminStateHelp", {}, "Configured availability")),
    detailItem(t("workspace.physicalLink", {}, "Physical link"), portStateLabel(port.link_state), t("workspace.physicalLinkHelp", {}, "Carrier state reported by switch")),
    detailItem(t("workspace.observedDuration", {}, "Observed duration"), formatObservedDuration(port.observed_link_seconds, port.link_state), port.last_link_change_at ? `${t("workspace.lastChange", {}, "Last change")}: ${formatDate(port.last_link_change_at)}` : ""),
    detailItem(t("workspace.detectedMedia", {}, "Detected media"), [port.detected_speed, port.detected_duplex].filter(Boolean).join(" · ") || t("workspace.notReported", {}, "Not reported")),
    detailItem(t("workspace.configuredMedia", {}, "Configured media"), [port.configured_speed, port.configured_duplex].filter(Boolean).join(" · ") || t("workspace.notReported", {}, "Not reported")),
    detailItem("VLAN", vlans),
    detailItem(t("workspace.poeStatus", {}, "PoE status"), port.poe_oper_status || portStateLabel(port.poe_state), [port.poe_priority, port.poe_class ? `Class ${port.poe_class}` : "", port.poe_type].filter(Boolean).join(" · ")),
    detailItem(t("workspace.poePower", {}, "PoE power"), poePower),
  ].join("");
  renderWorkspacePortDiagnosisEmpty();
  $("workspacePortAliasInput").value = port.alias || "";
  $("workspacePortAliasInput").disabled = !actionAllowedForCurrentUser("interface_alias");
  $("workspaceSavePortAlias").disabled = !actionAllowedForCurrentUser("interface_alias");
  setWorkspaceAliasStatus();
  setWorkspaceAliasSaveState("idle");
  document.querySelectorAll("[data-detail-action]").forEach(button => button.disabled = !actionAllowedForCurrentUser(button.dataset.detailAction));
  if (!$("workspacePortDialog").open) $("workspacePortDialog").showModal();
  if (focusAlias && actionAllowedForCurrentUser("interface_alias")) setTimeout(() => $("workspacePortAliasInput").focus(), 50);
};

function renderWorkspacePortDiagnosisEmpty() {
  const target = $("workspacePortDiagnostics");
  if (!target) return;
  target.className = "port-diagnostics-content is-empty";
  target.innerHTML = `<div class="diagnostic-empty-state"><div class="diagnostic-empty-icon"><svg><use href="#i-activity"></use></svg></div><div><strong>${escapeHtml(t("troubleshooter.readyTitle", {}, "Ready to diagnose"))}</strong><span>${escapeHtml(t("troubleshooter.readyHelp", {}, "The check is read-only and runs only against this switch and port."))}</span></div></div>`;
  const button = $("workspaceDiagnosePort");
  if (button) {
    button.disabled = !isSshUser();
    button.classList.remove("is-loading");
    const label = button.querySelector("span");
    if (label) label.textContent = t("troubleshooter.run", {}, "Diagnose port");
  }
}
function diagnosticHealthLabel(value) {
  return t(`troubleshooter.health.${value || "normal"}`, {}, String(value || "normal"));
}
function diagnosticFindingText(item) {
  const params = item?.params || {};
  return t(`troubleshooter.finding.${item?.code || "unknown"}`, params, item?.code || "Finding");
}
function diagnosticMetric(label, value, note = "") {
  return `<article class="diagnostic-metric"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value || t("workspace.notReported", {}, "Not reported"))}</strong>${note ? `<small>${escapeHtml(note)}</small>` : ""}</article>`;
}
function diagnosticListBlock(title, items, emptyText = "") {
  const safeItems = (items || []).filter(Boolean);
  return `<section class="diagnostic-list-block"><div class="diagnostic-subhead"><strong>${escapeHtml(title)}</strong><span>${safeItems.length}</span></div>${safeItems.length ? `<div class="diagnostic-chip-list">${safeItems.map(item => `<span>${escapeHtml(item)}</span>`).join("")}</div>` : `<p>${escapeHtml(emptyText || t("troubleshooter.noneDetected", {}, "None detected"))}</p>`}</section>`;
}
function renderWorkspacePortDiagnosis(result) {
  const target = $("workspacePortDiagnostics");
  if (!target) return;
  const port = result?.state || {};
  const endpoint = result?.endpoint || {};
  const counters = result?.counters || {};
  const findings = result?.findings || [];
  const commandErrors = result?.command_errors || {};
  const commands = result?.commands || [];
  const successfulCommands = commands.filter(item => item.ok).length;
  const vlans = (port.vlans || []).join(", ") || t("workspace.notReported", {}, "Not reported");
  const media = [port.speed, port.duplex].filter(Boolean).join(" · ") || t("workspace.notReported", {}, "Not reported");
  const poePower = port.poe_power_mw != null
    ? `${port.poe_power_mw} mW${port.poe_max_mw != null ? ` / ${port.poe_max_mw} mW` : ""}`
    : t("workspace.notReported", {}, "Not reported");
  const findingHtml = findings.length
    ? findings.map(item => `<article class="diagnostic-finding ${escapeHtml(item.severity || "info")}"><span class="diagnostic-finding-dot"></span><div><strong>${escapeHtml(diagnosticFindingText(item))}</strong><small>${escapeHtml(t(`troubleshooter.findingHelp.${item.code}`, item.params || {}, ""))}</small></div></article>`).join("")
    : `<div class="diagnostic-no-findings">${escapeHtml(t("troubleshooter.noFindings", {}, "No notable conditions were detected."))}</div>`;
  const signalRows = (counters.signals || []).length
    ? `<div class="diagnostic-counter-list">${counters.signals.map(item => `<div><span>${escapeHtml(item.name)}</span><strong class="${Number(item.value) > 0 ? "has-value" : ""}">${escapeHtml(item.value)}</strong></div>`).join("")}</div>`
    : `<p class="diagnostic-muted">${escapeHtml(t("troubleshooter.noCounterSignals", {}, "No error counter fields were reported by this AOS response."))}</p>`;
  const activity = result.recent_activity || [];
  const activityHtml = activity.length
    ? `<div class="diagnostic-activity-list">${activity.map(item => `<article><div><strong>${escapeHtml(actionLabel(item.action))}</strong><span>Job #${escapeHtml(item.job_id)} · ${escapeHtml(item.requested_by || "")}</span></div><div><span class="status ${escapeHtml(item.status || "unknown")}">${escapeHtml(t(`status.${item.status}`, {}, item.status || "unknown"))}</span><small>${escapeHtml(formatDate(item.created_at))}</small></div></article>`).join("")}</div>`
    : `<p class="diagnostic-muted">${escapeHtml(t("troubleshooter.noRecentActivity", {}, "No recent Portivo jobs were recorded for this port."))}</p>`;
  const failedCommands = commands.filter(item => !item.ok);
  const errorsHtml = failedCommands.length
    ? `<details class="diagnostic-command-errors"><summary>${escapeHtml(t("troubleshooter.partialCoverage", { count: failedCommands.length }, `${failedCommands.length} checks were not available`))}</summary>${failedCommands.map(item => `<div><strong>${escapeHtml(item.command || item.key)}</strong><span>${escapeHtml(item.error || commandErrors[item.key] || "")}</span></div>`).join("")}</details>`
    : "";

  target.className = "port-diagnostics-content";
  target.innerHTML = `
    <div class="diagnostic-summary-row">
      <div class="diagnostic-health ${escapeHtml(result.health || "normal")}"><span></span><div><small>${escapeHtml(t("troubleshooter.overallAssessment", {}, "Overall assessment"))}</small><strong>${escapeHtml(diagnosticHealthLabel(result.health))}</strong></div></div>
      <div class="diagnostic-meta"><span>${escapeHtml(t("troubleshooter.liveReadOnly", {}, "Live · read-only"))}</span><strong>${escapeHtml(formatDate(result.diagnosed_at))}</strong></div>
    </div>
    <div class="diagnostic-findings">${findingHtml}</div>
    <div class="diagnostic-metrics-grid">
      ${diagnosticMetric(t("workspace.adminState", {}, "Admin state"), portStateLabel(port.admin_state))}
      ${diagnosticMetric(t("workspace.physicalLink", {}, "Physical link"), portStateLabel(port.link_state), port.last_link_change_at ? `${t("workspace.lastChange", {}, "Last change")}: ${formatDate(port.last_link_change_at)}` : "")}
      ${diagnosticMetric(t("workspace.media", {}, "Speed / duplex"), media)}
      ${diagnosticMetric("VLAN", vlans)}
      ${diagnosticMetric(t("workspace.poeStatus", {}, "PoE status"), port.poe_oper_status || portStateLabel(port.poe_state), poePower)}
      ${diagnosticMetric(t("troubleshooter.macCount", {}, "Learned MACs"), String(endpoint.mac_count ?? 0))}
    </div>
    <div class="diagnostic-endpoint-grid">
      ${diagnosticListBlock(t("troubleshooter.macAddresses", {}, "MAC addresses"), endpoint.mac_addresses, t("troubleshooter.noMac", {}, "No MAC address learned on this port."))}
      ${diagnosticListBlock(t("troubleshooter.unpUsers", {}, "UNP users"), endpoint.unp_users, t("troubleshooter.noUnp", {}, "No UNP user reported on this port."))}
      ${diagnosticListBlock(t("troubleshooter.unpProfiles", {}, "UNP profiles"), endpoint.unp_profiles, t("troubleshooter.noUnpProfile", {}, "No UNP profile reported on this port."))}
      ${diagnosticListBlock(t("troubleshooter.lldpNeighbors", {}, "LLDP neighbors"), endpoint.lldp_neighbors, t("troubleshooter.noLldp", {}, "No LLDP neighbor reported on this port."))}
    </div>
    <div class="diagnostic-detail-grid">
      <section class="diagnostic-detail-card"><div class="diagnostic-subhead"><strong>${escapeHtml(t("troubleshooter.errorCounters", {}, "Error counters"))}</strong><span>${escapeHtml((counters.signals || []).length)}</span></div>${signalRows}</section>
      <section class="diagnostic-detail-card"><div class="diagnostic-subhead"><strong>${escapeHtml(t("troubleshooter.recentActivity", {}, "Recent port activity"))}</strong><span>${escapeHtml(activity.length)}</span></div>${activityHtml}</section>
    </div>
    <div class="diagnostic-coverage"><div><strong>${escapeHtml(t("troubleshooter.evidenceCoverage", {}, "Evidence coverage"))}</strong><span>${escapeHtml(t("troubleshooter.commandsSucceeded", { ok: successfulCommands, total: commands.length }, `${successfulCommands} of ${commands.length} checks completed`))}</span></div>${errorsHtml}</div>`;
}
async function runWorkspacePortDiagnosis() {
  const port = state.activeWorkspacePort;
  const device = workspaceDevice();
  if (!port || !device || !isSshUser()) return;
  const context = {
    requestId: ++state.workspaceDiagnosisSequence,
    sessionId: state.workspacePortDialogSession,
    deviceId: device.id,
    portId: port.port,
  };
  const button = $("workspaceDiagnosePort");
  const target = $("workspacePortDiagnostics");
  if (button) {
    button.disabled = true;
    button.classList.add("is-loading");
    const label = button.querySelector("span");
    if (label) label.textContent = t("troubleshooter.running", {}, "Diagnosing...");
  }
  if (target) {
    target.className = "port-diagnostics-content is-loading";
    target.innerHTML = `<div class="diagnostic-loading"><span class="diagnostic-spinner"></span><div><strong>${escapeHtml(t("troubleshooter.runningTitle", { port: context.portId }, `Diagnosing port ${context.portId}`))}</strong><span>${escapeHtml(t("troubleshooter.runningHelp", {}, "Collecting live interface, counter, endpoint, UNP, PoE and LLDP evidence over one serialized SSH session."))}</span></div></div>`;
  }
  const isActive = () => Boolean(
    $("workspacePortDialog")?.open
    && state.workspaceDiagnosisSequence === context.requestId
    && state.workspacePortDialogSession === context.sessionId
    && state.currentWorkspaceDeviceId === context.deviceId
    && state.activeWorkspacePort?.port === context.portId
  );
  try {
    const result = await api(`/api/devices/${context.deviceId}/port-diagnostics`, { method: "POST", body: { port: context.portId } });
    if (isActive()) renderWorkspacePortDiagnosis(result);
    else toast(t("troubleshooter.completedBackground", { port: context.portId }, `Diagnosis completed for ${context.portId}.`), "success");
  } catch (error) {
    if (isActive() && target) {
      target.className = "port-diagnostics-content has-error";
      target.innerHTML = `<div class="diagnostic-error-state"><strong>${escapeHtml(t("troubleshooter.failed", {}, "Diagnosis could not be completed"))}</strong><span>${escapeHtml(error.message)}</span></div>`;
    } else {
      toast(t("troubleshooter.failedBackground", { port: context.portId, error: error.message }, `Diagnosis failed for ${context.portId}: ${error.message}`), "error");
    }
  } finally {
    if (isActive() && button) {
      button.disabled = false;
      button.classList.remove("is-loading");
      const label = button.querySelector("span");
      if (label) label.textContent = t("troubleshooter.runAgain", {}, "Run again");
    }
  }
}

async function waitForWorkspaceJob(jobId, timeoutMs = 45000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const detail = await api(`/api/jobs/${jobId}`);
    const status = detail.job?.status;
    if (["completed", "failed", "partial"].includes(status)) return detail;
    await new Promise(resolve => setTimeout(resolve, 800));
  }
  throw new Error(t("workspace.jobTimeout", {}, "The operation is still running. Check Jobs for its final status."));
}
function setWorkspaceAliasStatus(message = "", tone = "") {
  const status = $("workspacePortAliasStatus");
  if (!status) return;
  status.textContent = message;
  status.className = `form-message${tone ? ` ${tone}` : ""}`;
}
function setWorkspaceAliasSaveState(mode = "idle") {
  const button = $("workspaceSavePortAlias");
  if (!button) return;
  const label = button.querySelector("span");
  const icon = button.querySelector("use");
  button.classList.toggle("is-saving", mode === "saving");
  button.classList.toggle("is-saved", mode === "saved");
  if (label) {
    label.textContent = mode === "saving"
      ? t("workspace.savingAlias", {}, "Saving...")
      : mode === "saved"
        ? t("workspace.aliasSavedButton", {}, "Saved")
        : t("workspace.saveAlias", {}, "Save alias");
  }
  if (icon) icon.setAttribute("href", mode === "saving" ? "#i-refresh" : "#i-check");
}
function createWorkspaceAliasContext(device, port, alias) {
  const context = {
    operationId: ++state.workspaceAliasOperationSequence,
    sessionId: state.workspacePortDialogSession,
    deviceId: device.id,
    portId: port.port,
    alias,
  };
  state.workspaceAliasOperations.set(context.operationId, context);
  return context;
}
function isWorkspaceAliasContextActive(context) {
  const dialog = $("workspacePortDialog");
  return Boolean(
    dialog?.open
    && state.workspacePortDialogSession === context.sessionId
    && state.currentWorkspaceDeviceId === context.deviceId
    && state.activeWorkspacePort?.port === context.portId
  );
}
function workspaceAliasOperationPendingForDevice(deviceId) {
  return [...state.workspaceAliasOperations.values()].some(context => context.deviceId === deviceId);
}
function scheduleWorkspaceAliasInventoryRefresh(deviceId, delayMs = 650) {
  if (state.workspaceAliasRefreshTimer) clearTimeout(state.workspaceAliasRefreshTimer);
  state.workspaceAliasRefreshTimer = setTimeout(async () => {
    state.workspaceAliasRefreshTimer = null;
    if (workspaceAliasOperationPendingForDevice(deviceId) || state.workspacePortsLoading) {
      scheduleWorkspaceAliasInventoryRefresh(deviceId, 500);
      return;
    }
    if (state.currentWorkspaceDeviceId !== deviceId) return;

    const activePortId = state.activeWorkspacePort?.port || null;
    const activeSessionId = state.workspacePortDialogSession;
    await loadWorkspacePorts(false);

    // A silent inventory refresh may replace workspacePorts with new objects. Preserve the
    // currently open port only when the user is still in the exact same modal session.
    if (
      $("workspacePortDialog")?.open
      && state.currentWorkspaceDeviceId === deviceId
      && state.workspacePortDialogSession === activeSessionId
      && state.activeWorkspacePort?.port === activePortId
    ) {
      const refreshed = state.workspacePorts.find(item => item.port === activePortId);
      if (refreshed) state.activeWorkspacePort = refreshed;
    }
  }, delayMs);
}
async function saveWorkspacePortAlias() {
  const port = state.activeWorkspacePort;
  const device = workspaceDevice();
  if (!port || !device || !actionAllowedForCurrentUser("interface_alias")) return;
  const alias = $("workspacePortAliasInput").value.trim();
  if (!alias) {
    setWorkspaceAliasStatus(t("workspace.aliasRequired", {}, "Enter an alias before saving."), "error");
    return;
  }

  const context = createWorkspaceAliasContext(device, port, alias);
  const button = $("workspaceSavePortAlias");
  const input = $("workspacePortAliasInput");
  button.disabled = true;
  input.disabled = true;
  setWorkspaceAliasSaveState("saving");
  setWorkspaceAliasStatus(
    t("workspace.aliasSaving", {}, "Applying the alias to running configuration..."),
    "working",
  );

  let saved = false;
  try {
    const result = await api("/api/execute", {
      method: "POST",
      body: {
        action: "interface_alias",
        targets: [{ device_id: context.deviceId, port: context.portId, slot: "" }],
        dry_run: false,
        cycle_delay_seconds: 5,
        port_alias: context.alias,
        custom_command: "",
        confirmation_text: "EXECUTE",
      },
    });
    const detail = await waitForWorkspaceJob(result.job_id, 180000);
    const failedItem = (detail.items || []).find(item => item.status === "failed");
    const partialItem = (detail.items || []).find(item => item.status === "partial");
    if (detail.job?.status === "failed" || failedItem) {
      throw new Error(failedItem?.error || t("workspace.aliasSaveFailed", {}, "The switch rejected the alias command."));
    }
    if (detail.job?.status === "partial" || partialItem) {
      throw new Error(partialItem?.error || t("workspace.aliasSavePartial", {}, "The alias command completed, but verification did not fully confirm the requested state."));
    }

    saved = true;

    // Update the data model for the port that actually completed. Never redirect the
    // currently open dialog to an older asynchronous operation.
    if (state.currentWorkspaceDeviceId === context.deviceId) {
      const currentPort = state.workspacePorts.find(item => item.port === context.portId);
      if (currentPort) currentPort.alias = context.alias;
      renderWorkspacePorts();
      if (isWorkspaceAliasContextActive(context) && currentPort) state.activeWorkspacePort = currentPort;
    }

    if (isWorkspaceAliasContextActive(context)) {
      $("workspacePortDialogSubtitle").textContent = context.alias;
      $("workspacePortAliasInput").value = context.alias;
      setWorkspaceAliasSaveState("saved");
      setWorkspaceAliasStatus(
        t("workspace.aliasSavedInline", { port: context.portId }, `Alias applied to ${context.portId}. Configuration is pending save.`),
        "success",
      );
    }
    toast(t("workspace.aliasSaved", { port: context.portId }, `Alias applied to ${context.portId} · save pending`), "success");

    // The switch operation already succeeded. Auxiliary UI refreshes must never turn a
    // successful alias change into a false failure if one of these requests is unavailable.
    await Promise.allSettled([loadPendingConfiguration(), loadDevices()]);
  } catch (error) {
    if (isWorkspaceAliasContextActive(context)) {
      setWorkspaceAliasStatus(error.message, "error");
    } else {
      toast(
        t("workspace.aliasSaveFailedPort", { port: context.portId, error: error.message }, `Alias update failed on ${context.portId}: ${error.message}`),
        "error",
      );
    }
  } finally {
    state.workspaceAliasOperations.delete(context.operationId);

    // These controls belong to whichever modal session is on screen now. An older save
    // completion is not allowed to enable, disable or relabel a newer port dialog.
    if (isWorkspaceAliasContextActive(context)) {
      input.disabled = !actionAllowedForCurrentUser("interface_alias");
      button.disabled = !actionAllowedForCurrentUser("interface_alias");
      if (saved) {
        const completedSessionId = context.sessionId;
        setTimeout(() => {
          if (
            state.workspacePortDialogSession === completedSessionId
            && isWorkspaceAliasContextActive(context)
          ) setWorkspaceAliasSaveState("idle");
        }, 1800);
      } else {
        setWorkspaceAliasSaveState("idle");
      }
    }

    if (saved) scheduleWorkspaceAliasInventoryRefresh(context.deviceId);
  }
}

function useWorkspacePortInCommandCenter() {
  const port = state.activeWorkspacePort;
  if (!port) return;
  $("workspacePort").value = port.port;
  $("workspacePortDialog").close();
  $("workspaceAction").focus();
  clearWorkspacePreview();
}
async function runActiveWorkspacePortAction(action) {
  const port = state.activeWorkspacePort;
  if (!port) return;
  $("workspacePortDialog").close();
  await window.runWorkspacePortAction(port.port, action);
}
window.selectWorkspacePort = function(port) { $("workspacePort").value = port; clearWorkspacePreview(); };
window.runWorkspacePortAction = async function(port, action) {
  if (!actionAllowedForCurrentUser(action)) { toast(t("roles.changeDenied", {}, "This operation is not permitted by your assigned role."), "error"); return; }
  const label = action === "poe_cycle" ? t("workspace.restartPoe", {}, "Restart PoE") : t("workspace.restartInterface", {}, "Restart interface");
  if (!confirm(t("workspace.confirmPortRestart", { action: label, port }, `${label} on ${port}?`))) return;
  const device = workspaceDevice(); if (!device) return;
  try {
    const result = await api("/api/execute", { method: "POST", body: { action, targets: [{ device_id: device.id, port, slot: "" }], dry_run: false, cycle_delay_seconds: Number($("workspaceRestartDelay").value || 5), port_alias: "", custom_command: "", confirmation_text: "EXECUTE" } });
    toast(t("operations.jobQueued", { id: result.job_id }, `Job #${result.job_id} queued`), "success");
    setTimeout(() => loadWorkspacePorts(false), (Number($("workspaceRestartDelay").value || 5) + 3) * 1000);
  } catch (error) { toast(error.message, "error"); }
};


function filteredBulkDevices() {
  return state.devices.filter(device => inventoryDeviceMatches(device, "bulk"));
}
function renderBulkTargets() {
  const container = $("bulkDeviceList");
  if (!container) return;
  const rows = filteredBulkDevices();
  const action = $("bulkAction")?.value || "";
  const meta = actionMeta(action || "interface_status_all");
  container.innerHTML = rows.map(device => {
    const selected = state.selected.has(device.id);
    const target = state.selected.get(device.id) || { port: "", slot: "", port_override: false, slot_override: false };
    const defaultPort = $("bulkPort").value.trim();
    const defaultSlot = $("bulkSlot").value.trim();
    const portValue = target.port_override ? target.port : "";
    const slotValue = target.slot_override ? target.slot : "";
    const portPlaceholder = defaultPort ? `${t("operations.defaultValue", {}, "Default")}: ${defaultPort}` : t("workspace.port", {}, "Port");
    const slotPlaceholder = defaultSlot ? `${t("operations.defaultValue", {}, "Default")}: ${defaultSlot}` : t("operations.defaultSlot", {}, "Slot");
    const overrides = selected && (meta.needsPort || meta.needsSlot) ? `<div class="fleet-switch-overrides">
      ${meta.needsPort ? `<label><span>${escapeHtml(t("operations.portOverride", {}, "Port override"))}</span><input data-bulk-override="port" data-device-id="${Number(device.id)}" type="text" placeholder="${escapeHtml(portPlaceholder)}" value="${escapeHtml(portValue)}"></label>` : ""}
      ${meta.needsSlot ? `<label><span>${escapeHtml(t("operations.slotOverride", {}, "Slot override"))}</span><input data-bulk-override="slot" data-device-id="${Number(device.id)}" type="text" placeholder="${escapeHtml(slotPlaceholder)}" value="${escapeHtml(slotValue)}"></label>` : ""}
    </div>` : "";
    return fleetSwitchCardMarkup(device, { selected, mode: "operations", extraHtml: overrides });
  }).join("") || `<div class="empty-state compact-empty"><strong>${escapeHtml(t("devices.noSwitches", {}, "No switches match this filter."))}</strong></div>`;
  bindFleetSwitchCards(container, (id, checked) => window.toggleSelected(id, checked));
  container.querySelectorAll("[data-bulk-override]").forEach(input => input.addEventListener("input", event => {
    const id = Number(event.target.dataset.deviceId);
    setTargetField(id, event.target.dataset.bulkOverride, event.target.value);
  }));
}
window.setTargetField = function(id, field, value) {
  if (!state.selected.has(id)) return;
  const target = state.selected.get(id);
  const normalizedValue = String(value || "").trim();
  target[field] = normalizedValue;
  target[`${field}_override`] = Boolean(normalizedValue);
  state.selected.set(id, target);
  updateBulkSummary();
  clearPreview();
};
function selectAllFiltered() {
  filteredBulkDevices().forEach(device => {
    if (!state.selected.has(device.id)) state.selected.set(device.id, { device_id: device.id, port: "", slot: "", port_override: false, slot_override: false });
  });
  renderBulkTargets(); updateBulkSummary(); clearPreview();
}
function clearSelection() { state.selected.clear(); renderBulkTargets(); updateBulkSummary(); clearPreview(); }
function handleBulkDefaultChange() {
  // Defaults remain defaults. They are no longer copied into every selected row,
  // so changing the default cannot leave a stale hidden per-switch override behind.
  renderBulkTargets();
  updateBulkSummary();
  clearPreview();
}
function buildTargets() {
  const defaultPort = $("bulkPort").value.trim(), defaultSlot = $("bulkSlot").value.trim();
  return [...state.selected.values()].map(target => ({
    device_id: target.device_id,
    port: target.port_override ? String(target.port || "").trim() : defaultPort,
    slot: target.slot_override ? String(target.slot || "").trim() : defaultSlot,
  }));
}

function selectedRunbook() {
  const id = Number($("bulkRunbook")?.value || 0);
  return (state.runbooks || []).find(item => Number(item.id) === id) || null;
}
function runbookRiskMeta(runbook) {
  const risk = String(runbook?.risk || "change");
  if (risk === "read") return { risk: "read", label: t("runbooks.readRisk", {}, "READ") };
  if (risk === "high") return { risk: "high", label: t("runbooks.highRisk", {}, "HIGH RISK") };
  return { risk: "change", label: t("runbooks.changeRisk", {}, "CHANGE") };
}
async function loadRunbooks() {
  try {
    const data = await api("/api/runbooks");
    state.runbooks = data.items || [];
    state.runbookCanManage = Boolean(data.can_manage);
    renderRunbookSelect();
    renderRunbookLibrary();
  } catch (error) {
    state.runbooks = [];
    renderRunbookSelect();
  }
}
function renderRunbookSelect() {
  const select = $("bulkRunbook");
  if (!select) return;
  const current = Number(select.value || 0);
  select.innerHTML = `<option value="">${escapeHtml(t("runbooks.selectRunbook", {}, "Select runbook"))}</option>${(state.runbooks || []).map(item => `<option value="${Number(item.id)}">${escapeHtml(item.name)} · ${escapeHtml(item.status === "approved" ? t("runbooks.approved", {}, "Approved") : t("runbooks.draft", {}, "Draft"))}</option>`).join("")}`;
  if ([...select.options].some(option => Number(option.value) === current)) select.value = String(current);
  renderSelectedRunbook();
}
function renderSelectedRunbook() {
  const runbook = selectedRunbook();
  const summary = $("bulkRunbookSummary");
  const variables = $("bulkRunbookVariables");
  if (!summary || !variables) return;
  if (!runbook) {
    summary.innerHTML = `<span class="empty">${escapeHtml(t("runbooks.selectHelp", {}, "Select a runbook to see its approval, risk and execution policy."))}</span>`;
    variables.innerHTML = "";
    return;
  }
  const risk = runbookRiskMeta(runbook);
  const statusLabel = runbook.status === "approved" ? t("runbooks.approved", {}, "Approved") : t("runbooks.draft", {}, "Draft");
  const failureLabel = runbook.failure_policy === "stop_all" ? t("runbooks.failureStopAll", {}, "Stop remaining switches") : t("runbooks.failureContinue", {}, "Stop this switch and continue");
  summary.innerHTML = `<div class="runbook-summary-title"><strong>${escapeHtml(runbook.name)}</strong><span class="status ${runbook.status === "approved" ? "online" : "unknown"}">${escapeHtml(statusLabel)}</span><span class="runbook-risk-pill ${escapeHtml(risk.risk)}">${escapeHtml(risk.label)}</span></div><p>${escapeHtml(runbook.description || t("runbooks.noDescription", {}, "No description"))}</p><div class="runbook-summary-meta"><span>${escapeHtml(t("runbooks.stepCount", { count: Number((runbook.steps || []).length) }, `${Number((runbook.steps || []).length)} steps`))}</span><span>${escapeHtml(t("runbooks.targetLimit", { count: Number(runbook.max_targets || 1) }, `max ${Number(runbook.max_targets || 1)} targets`))}</span><span>${escapeHtml(t("runbooks.concurrent", { count: Number(runbook.concurrency || 1) }, `${Number(runbook.concurrency || 1)} concurrent`))}</span><span>${escapeHtml(failureLabel)}</span></div>`;
  variables.innerHTML = (runbook.variables || []).map(spec => `<label class="field-label"><span>${escapeHtml(spec.label || spec.name)}${spec.required ? " *" : ""}</span><input data-runbook-variable="${escapeHtml(spec.name)}" value="${escapeHtml(spec.default || "")}" maxlength="200" placeholder="${escapeHtml(spec.name)}"/></label>`).join("");
  variables.querySelectorAll("input").forEach(input => input.addEventListener("input", () => { updateBulkSummary(); clearPreview(); }));
}
function collectRunbookVariables() {
  const values = {};
  document.querySelectorAll("#bulkRunbookVariables [data-runbook-variable]").forEach(input => { values[input.dataset.runbookVariable] = input.value; });
  return values;
}

function availableActionEntries() {
  const keys = new Set(["interface_cycle", "poe_cycle", "check_unp", "fix_unp", "vlan_port_maintenance", "custom_command", "custom_runbook"]);
  for (const profile of Object.values(state.profiles || {})) {
    for (const action of Object.keys(profile.commands || {})) keys.add(action);
    for (const action of (profile.orchestrated_actions || [])) keys.add(action);
  }
  return [...keys]
    .filter(action => actionAllowedForCurrentUser(action) && !actionMeta(action).contextualOnly)
    .map(key => [key, actionMeta(key)]);
}

function renderActionOptions(filter = "") {
  const select = $("bulkAction");
  const current = select?.value || "interface_status_all";
  const query = String(filter || "").trim().toLowerCase();
  const grouped = new Map();
  for (const [key,meta] of availableActionEntries()) {
    const haystack = `${key} ${meta.label} ${meta.category} ${meta.description}`.toLowerCase();
    if (query && !haystack.includes(query)) continue;
    if (!grouped.has(meta.category)) grouped.set(meta.category,[]);
    grouped.get(meta.category).push([key,meta]);
  }
  const translatedOrder = categoryOrder.map(category => t(`categories.${category}`, {}, category));
  const orderedCategories = [...translatedOrder.filter(category => grouped.has(category)), ...[...grouped.keys()].filter(category => !translatedOrder.includes(category))];
  select.innerHTML = orderedCategories.map(category => `<optgroup label="${escapeHtml(category)}">${grouped.get(category).map(([key,meta]) => `<option value="${escapeHtml(key)}">${escapeHtml(meta.label)}</option>`).join("")}</optgroup>`).join("");
  if ([...select.options].some(option => option.value === current)) select.value = current; else if (select.options.length) select.selectedIndex = 0;
  updateActionContext();
}
function actionIconId(action, meta) {
  if (action === "custom_command" || action === "custom_runbook") return "i-terminal";
  if (action.includes("cycle")) return "i-cycle";
  const category = meta.originalCategory || meta.category;
  if (category === "Interfaces") return "i-port";
  if (category === "Power over Ethernet") return "i-bolt";
  if (category === "UNP") return "i-users";
  if (category === "Layer 2" || category === "Layer 3") return "i-network";
  if (category === "Security") return "i-key";
  if (category === "Configuration") return "i-library";
  if (category === "Diagnostics") return "i-audit";
  return "i-info";
}
function updateActionContext() {
  const action = $("bulkAction").value;
  const baseMeta = actionMeta(action || "interface_status_all");
  const runbook = action === "custom_runbook" ? selectedRunbook() : null;
  const riskMeta = runbook ? runbookRiskMeta(runbook) : { risk: baseMeta.risk, label: baseMeta.risk === "change" ? t("common.change", {}, "Change") : t("common.readOnly", {}, "Read only") };
  const meta = { ...baseMeta, risk: riskMeta.risk };
  const iconId = actionIconId(action, meta);
  const safeguardAction = action === "fix_unp"
    ? `<button class="context-policy-button" type="button" onclick="openFixUnpSafeguards()"><svg><use href="#i-admin"></use></svg><span>${escapeHtml(t("automation.safeguards", {}, "Safeguards"))}</span></button>`
    : action === "vlan_port_maintenance"
      ? `<button class="context-policy-button" type="button" onclick="openVlanMaintenanceSafeguards()"><svg><use href="#i-admin"></use></svg><span>${escapeHtml(t("automation.safeguards", {}, "Safeguards"))}</span></button>`
      : "";
  const displayedRisk = meta.risk === "high" ? t("runbooks.highRisk", {}, "HIGH RISK") : t(meta.risk === "change" ? "common.change" : "common.readOnly", {}, meta.risk === "change" ? "Change" : "Read only");
  $("actionContext").innerHTML = `<span class="context-icon"><svg><use href="#${iconId}"></use></svg></span><div class="context-copy"><span class="context-category">${escapeHtml(meta.category)}</span><strong>${escapeHtml(meta.label)}</strong><span class="context-description">${escapeHtml(meta.description)}</span></div><div class="context-action-meta"><span class="risk-badge ${meta.risk}"><i></i>${escapeHtml(displayedRisk)}</span>${safeguardAction}</div>`;
  $("portField").classList.toggle("hidden", !meta.needsPort);
  $("slotField").classList.toggle("hidden", !meta.needsSlot);
  $("aliasField").classList.toggle("hidden", !meta.needsAlias);
  $("delayField").classList.toggle("hidden", !meta.needsDelay);
  $("vlanTargetField")?.classList.toggle("hidden", action !== "vlan_port_maintenance");
  $("vlanMaintenanceOperationField")?.classList.toggle("hidden", action !== "vlan_port_maintenance");
  $("customCommandField").classList.toggle("hidden", !meta.custom);
  $("runbookOperationField")?.classList.toggle("hidden", action !== "custom_runbook");
  $("parameterGrid").classList.toggle("hidden", !meta.needsPort && !meta.needsSlot && !meta.needsAlias && !meta.needsDelay && action !== "vlan_port_maintenance");
  $("executeButton").classList.toggle("danger", meta.risk === "change" || meta.risk === "high");
  $("executeButton").classList.toggle("primary", meta.risk === "read");
  const forceLive = Boolean(meta.liveReadOnly || action === "check_unp" || action === "vlan_port_maintenance");
  if ($("dryRun")) {
    $("dryRun").disabled = forceLive;
    if (forceLive) $("dryRun").checked = false;
  }
  $("dryRunRow")?.classList.toggle("hidden", forceLive);
  const targetPanel = document.querySelector(".target-panel");
  targetPanel?.classList.toggle("show-port", Boolean(meta.needsPort));
  targetPanel?.classList.toggle("show-slot", Boolean(meta.needsSlot));
  renderBulkTargets();
}
function updateBulkSummary() {
  const count = state.selected.size;
  const action = $("bulkAction").value;
  const meta = actionMeta(action);
  const forceLive = Boolean(meta.liveReadOnly || action === "check_unp" || action === "vlan_port_maintenance");
  const mode = (!forceLive && $("dryRun").checked) ? t("operations.simulation", {}, "Simulation") : t("operations.live", {}, "Live");
  const extras = [];
  if (action === "vlan_port_maintenance") {
    const vlan = Number($("bulkTargetVlan")?.value || 1);
    const operation = $("bulkVlanOperation")?.value === "interface_cycle" ? t("operations.restartInterface", {}, "Restart interface") : t("operations.restartPoe", {}, "Restart PoE");
    extras.push(`VLAN ${vlan}`, operation);
  }
  if (meta.needsDelay) extras.push(`${Number($("cycleDelay").value || 5)} ${t("common.seconds", {}, "seconds")}`);
  if (meta.needsAlias && $("portAlias").value.trim()) extras.push(`alias: ${$("portAlias").value.trim()}`);
  if (action === "custom_command") extras.push(`${$("customCommand").value.split(/\r?\n/).filter(line => line.trim()).length} commands`);
  if (action === "custom_runbook") { const rb = selectedRunbook(); if (rb) extras.push(rb.name, `${Number((rb.steps || []).length)} steps`, String(rb.risk || "change").toUpperCase()); }
  $("bulkSummary").innerHTML = count ? `<span><strong>${count}</strong> · ${escapeHtml(meta.label)} · ${escapeHtml(mode)}${extras.length ? ` · ${escapeHtml(extras.join(" · "))}` : ""}</span>` : `<span>${escapeHtml(t("operations.noTargets", {}, "No targets selected"))}</span>`;
  if ($("bulkSelectedCount")) $("bulkSelectedCount").textContent = String(count);
  $("selectedNavCount").textContent = count;
  $("selectedNavCount").classList.toggle("hidden", !count);
}

async function previewOperation() {
  const targets = buildTargets();
  if (!targets.length) { toast(t("operations.selectTargetError", {}, "Select at least one target"), "error"); return null; }
  const action = $("bulkAction").value;
  try {
    state.lastPreview = await api("/api/preview", { method: "POST", body: {
      action, targets, cycle_delay_seconds: Number($("cycleDelay").value || 5), port_alias: $("portAlias").value.trim(),
      custom_command: action === "custom_command" ? $("customCommand").value : "",
      target_vlan: Number($("bulkTargetVlan")?.value || 1),
      vlan_maintenance_operation: $("bulkVlanOperation")?.value || "poe_cycle",
      runbook_id: action === "custom_runbook" ? Number($("bulkRunbook")?.value || 0) : 0,
      runbook_variables: action === "custom_runbook" ? collectRunbookVariables() : {},
    }});
    renderPreview(state.lastPreview); return state.lastPreview;
  } catch (error) { toast(error.message,"error"); return null; }
}
function commandSupportLabel(stateValue) {
  const labels = {
    documented: t("library.supportDocumented", {}, "ALE documented"),
    orchestrated: t("library.supportOrchestrated", {}, "ALE-aware workflow"),
    model_dependent: t("library.supportModelDependent", {}, "Model / release dependent"),
    unsupported: t("library.supportUnsupported", {}, "Unsupported"),
  };
  return labels[stateValue] || String(stateValue || "").replaceAll("_", " ");
}

function renderPreview(data) {
  $("previewPanel").innerHTML = data.items.map(item => {
    const device = item.device || `Device ${item.device_id}`;
    if (item.error) {
      return `<article class="preview-item preview-item-error"><div class="preview-item-head"><span class="preview-device-icon error"><svg><use href="#i-warning"></use></svg></span><div class="preview-device-copy"><strong>${escapeHtml(device)}</strong><span>${escapeHtml(item.host || t("common.unavailable", {}, "Unavailable"))}</span></div><span class="preview-error-badge">${escapeHtml(t("common.error", {}, "Error"))}</span></div><div class="preview-error-message">${escapeHtml(item.error)}</div></article>`;
    }
    const commandText = `${item.command || ""}${item.verification ? `\nVERIFY: ${item.verification}` : ""}`;
    const lineCount = commandText.split(/\r?\n/).filter(line => line.trim()).length;
    return `<article class="preview-item"><div class="preview-item-head"><span class="preview-device-icon"><svg><use href="#i-terminal"></use></svg></span><div class="preview-device-copy"><strong>${escapeHtml(device)}</strong><span>${escapeHtml(item.host || "")} · ${escapeHtml(item.profile || "")}</span></div><div class="preview-item-badges">${item.support_state ? `<span class="command-support ${escapeHtml(item.support_state)}">${escapeHtml(commandSupportLabel(item.support_state))}</span>` : ""}</div></div>${item.support_note ? `<small class="preview-support-note">${escapeHtml(item.support_note)}</small>` : ""}<div class="preview-command-shell"><div class="preview-command-shell-head"><span>${escapeHtml(t("operations.exactCli", {}, "Exact CLI"))}</span><span>${lineCount} ${escapeHtml(t("operations.lines", {}, lineCount === 1 ? "line" : "lines"))}</span></div><code>${escapeHtml(commandText)}</code></div></article>`;
  }).join("");
}
function clearPreview() {
  state.lastPreview = null;
  $("previewPanel").innerHTML = `<div class="empty-state compact-empty"><svg><use href="#i-terminal"></use></svg><strong>${escapeHtml(t("operations.noPreview", {}, "No preview yet"))}</strong><span>${escapeHtml(t("operations.noPreviewDescription", {}, "Select switches, choose an operation and press Preview commands."))}</span></div>`;
}
async function prepareExecution() {
  const targets = buildTargets();
  if (!targets.length) { toast(t("operations.selectTargetError", {}, "Select at least one target"),"error"); return; }

  // Execution confirmation must be immediate. Preview is an optional user action
  // and may perform a live scan for orchestrated operations such as Fix UNP.
  // Connectivity is checked independently for each switch only after the job is queued.
  if ($("dryRun").checked) { await executeOperation(""); return; }
  const action = $("bulkAction").value;
  const meta = actionMeta(action);
  const effectiveRisk = action === "custom_runbook" && selectedRunbook() ? String(selectedRunbook().risk || "change") : meta.risk;
  if (effectiveRisk === "read") { await executeOperation(""); return; }
  $("confirmationText").value = "";
  $("confirmDialog").showModal();
}
async function confirmExecution(event) {
  event.preventDefault();
  const text = $("confirmationText").value;
  if (text.trim().toUpperCase() !== "EXECUTE") { toast(t("operations.typeExecute", {}, "Type EXECUTE to continue"),"error"); return; }
  $("confirmDialog").close(); await executeOperation(text);
}
async function executeOperation(confirmationText) {
  const action = $("bulkAction").value;
  const meta = actionMeta(action);
  const payload = { action, targets: buildTargets(), dry_run: (meta.liveReadOnly || action === "check_unp") ? false : $("dryRun").checked, cycle_delay_seconds: Number($("cycleDelay").value || 5), port_alias: $("portAlias").value.trim(), confirmation_text: confirmationText, custom_command: action === "custom_command" ? $("customCommand").value : "", target_vlan: Number($("bulkTargetVlan")?.value || 1), vlan_maintenance_operation: $("bulkVlanOperation")?.value || "poe_cycle", runbook_id: action === "custom_runbook" ? Number($("bulkRunbook")?.value || 0) : 0, runbook_variables: action === "custom_runbook" ? collectRunbookVariables() : {} };
  try { const result = await api("/api/execute", { method: "POST", body: payload }); toast(t("operations.jobQueued", { id: result.job_id }, `Job #${result.job_id} queued`),"success"); switchView("jobsView"); await Promise.all([loadJobs(),loadDashboard()]); } catch (error) { toast(error.message,"error"); }
}

function historyQuery(parameters) {
  const query = new URLSearchParams();
  Object.entries(parameters).forEach(([key, value]) => {
    const normalized = String(value ?? "").trim();
    if (normalized) query.set(key, normalized);
  });
  const encoded = query.toString();
  return encoded ? `?${encoded}` : "";
}
function replaceSelectOptions(select, values, defaultKey, defaultFallback, labelBuilder = value => value) {
  if (!select) return;
  const selected = select.value;
  select.innerHTML = `<option value="">${escapeHtml(t(defaultKey, {}, defaultFallback))}</option>${(values || []).map(value => `<option value="${escapeHtml(value)}">${escapeHtml(labelBuilder(value))}</option>`).join("")}`;
  if ([...select.options].some(option => option.value === selected)) select.value = selected;
}
function scheduleHistoryFilter(type) {
  const key = type === "jobs" ? "jobFilterTimer" : "auditFilterTimer";
  clearTimeout(state[key]);
  state[key] = setTimeout(() => type === "jobs" ? loadJobs() : loadAudit(), 260);
}
function resetActivityHistoryPage(type) {
  if (type === "jobs") state.activityHistoryUi.jobsPage = 1;
  else state.activityHistoryUi.auditPage = 1;
}
function changeActivityHistoryPage(type, delta) {
  const prefix = type === "jobs" ? "jobs" : "audit";
  const pageKey = `${prefix}Page`;
  const pagesKey = `${prefix}Pages`;
  const current = Number(state.activityHistoryUi[pageKey] || 1);
  const pages = Math.max(1, Number(state.activityHistoryUi[pagesKey] || 1));
  const next = Math.min(pages, Math.max(1, current + Number(delta || 0)));
  if (next === current) return;
  state.activityHistoryUi[pageKey] = next;
  if (type === "jobs") loadJobs();
  else loadAudit();
}
function renderActivityHistoryPager(type, payload) {
  const prefix = type === "jobs" ? "jobs" : "audit";
  const total = Math.max(0, Number(payload?.total || 0));
  const page = Math.max(1, Number(payload?.page || 1));
  const pageSize = Math.max(1, Number(payload?.page_size || state.activityHistoryUi[`${prefix}PageSize`] || 25));
  const pages = Math.max(1, Number(payload?.pages || Math.ceil(total / pageSize) || 1));
  state.activityHistoryUi[`${prefix}Page`] = page;
  state.activityHistoryUi[`${prefix}PageSize`] = pageSize;
  state.activityHistoryUi[`${prefix}Pages`] = pages;
  state.activityHistoryUi[`${prefix}Total`] = total;

  const start = total ? ((page - 1) * pageSize) + 1 : 0;
  const end = total ? Math.min(total, start + pageSize - 1) : 0;
  const summary = $(`${prefix}ResultSummary`);
  if (summary) summary.textContent = total
    ? t("activity.showingRange", { start, end, total }, `Showing ${start}–${end} of ${total}`)
    : t("filters.results", { count: 0 }, "0 results");
  const pageLabel = $(`${prefix}PageLabel`);
  if (pageLabel) pageLabel.textContent = t("activity.pageOf", { page, pages }, `Page ${page} of ${pages}`);
  const prev = $(`${prefix}PrevPage`);
  const next = $(`${prefix}NextPage`);
  if (prev) prev.disabled = page <= 1;
  if (next) next.disabled = page >= pages || total === 0;
  const select = $(`${prefix}PageSize`);
  if (select && String(select.value) !== String(pageSize)) select.value = String(pageSize);
}
async function ensureJobFilterOptions() {
  if (!state.jobFilterOptions) state.jobFilterOptions = await api("/api/jobs/filter-options");
  const options = state.jobFilterOptions || { actions: [], sources: [], statuses: [] };
  replaceSelectOptions($("jobsStatusFilter"), options.statuses, "filters.allStatuses", "All statuses", value => t(`status.${String(value).toLowerCase()}`, {}, value));
  replaceSelectOptions($("jobsActionFilter"), options.actions, "jobs.allActions", "All operations", actionLabel);
  replaceSelectOptions($("jobsSourceFilter"), options.sources, "jobs.allSources", "All sources");
}
function currentJobFilters() {
  return {
    q: $("jobsSearch")?.value,
    status: $("jobsStatusFilter")?.value,
    action: $("jobsActionFilter")?.value,
    mode: $("jobsModeFilter")?.value,
    source: $("jobsSourceFilter")?.value,
    date_from: $("jobsDateFrom")?.value,
    date_to: $("jobsDateTo")?.value,
  };
}
function updateHistoryDateBounds(prefix) {
  const from = $(`${prefix}DateFrom`);
  const to = $(`${prefix}DateTo`);
  if (!from || !to) return;
  to.min = from.value || "";
  from.max = to.value || "";
}
async function loadJobs() {
  const requestSequence = ++state.jobsRequestSequence;
  await ensureJobFilterOptions();
  updateHistoryDateBounds("jobs");
  const pagination = state.activityHistoryUi;
  const response = await api(`/api/jobs${historyQuery({
    ...currentJobFilters(),
    page: pagination.jobsPage || 1,
    page_size: pagination.jobsPageSize || 25,
  })}`);
  if (requestSequence !== state.jobsRequestSequence) return;
  const rows = Array.isArray(response) ? response : (response.items || []);
  const jobOptions = state.jobFilterOptions || { actions: [], sources: [], statuses: [] };
  jobOptions.actions = [...new Set([...(jobOptions.actions || []), ...rows.map(row => row.action).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b)));
  jobOptions.sources = [...new Set([...(jobOptions.sources || []), ...rows.map(row => row.requested_by).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: "base" }));
  jobOptions.statuses = [...new Set([...(jobOptions.statuses || []), ...rows.map(row => row.status).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b)));
  state.jobFilterOptions = jobOptions;
  await ensureJobFilterOptions();
  state.jobs = rows;
  renderActivityHistoryPager("jobs", Array.isArray(response) ? { items: rows, total: rows.length, page: 1, page_size: rows.length || 25, pages: 1 } : response);
  $("jobsTable").innerHTML = rows.map(job => {
    const stopped = Number(job.interrupted_count || 0) + Number(job.cancelled_count || 0);
    return `<tr><td><strong>#${job.id}</strong>${job.retry_of_job_id ? `<div class="muted-line">${escapeHtml(t("jobs.retryOf", { id: job.retry_of_job_id }, `Retry of Job #${job.retry_of_job_id}`))}</div>` : ""}</td><td>${escapeHtml(actionLabel(job.action))}</td><td>${statusBadge(job.status)}</td><td>${job.dry_run ? escapeHtml(t("operations.simulation", {}, "Simulation")) : escapeHtml(t("operations.live", {}, "Live"))}</td><td>${job.target_count}</td><td>${job.success_count}</td><td>${job.failure_count}</td><td>${stopped}</td><td>${escapeHtml(job.requested_by)}</td><td>${formatDate(job.created_at)}</td><td><div class="row-actions"><button class="icon-action" onclick="showJob(${job.id})">${escapeHtml(t("common.details", {}, "Details"))}</button><button class="icon-action pdf-action" onclick="downloadJobPdf(${job.id})" title="${escapeHtml(t("jobs.exportPdfTitle", {}, "Export this job as PDF"))}"><svg><use href="#i-download"></use></svg><span>PDF</span></button></div></td></tr>`;
  }).join("") || `<tr><td colspan="11"><div class="empty-state">${escapeHtml(t("jobs.noMatches", {}, "No jobs match the selected filters."))}</div></td></tr>`;
}
function clearJobsFilters() {
  clearTimeout(state.jobFilterTimer);
  for (const id of ["jobsSearch", "jobsStatusFilter", "jobsActionFilter", "jobsModeFilter", "jobsSourceFilter", "jobsDateFrom", "jobsDateTo"]) if ($(id)) $(id).value = "";
  updateHistoryDateBounds("jobs");
  resetActivityHistoryPage("jobs");
  loadJobs();
}

window.downloadJobPdf = function(id) {
  const jobId = Number(id);
  if (!Number.isInteger(jobId) || jobId <= 0) return;
  const language = window.I18n?.language || "en";
  const link = document.createElement("a");
  link.href = `/api/jobs/${jobId}/pdf?lang=${encodeURIComponent(language)}`;
  link.rel = "noopener";
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  toast(t("jobs.exportStarted", { id: jobId }, `Preparing PDF report for Job #${jobId}`), "success");
};

window.showJob = async function(id) {
  try {
    const data = await api(`/api/jobs/${id}`);
    state.currentJobId = Number(id);
    $("jobModalTitle").textContent = t("jobs.detailsTitle", { id, action: actionLabel(data.job.action) }, `Job #${id} · ${actionLabel(data.job.action)}`);
    const job = data.job || {};
    const lifecycle = data.lifecycle || {};
    const stopped = Number(job.interrupted_count || 0) + Number(job.cancelled_count || 0);
    const lifecycleActions = [
      lifecycle.can_cancel ? `<button class="btn secondary" type="button" onclick="cancelJob(${job.id})">${escapeHtml(t("jobs.cancelJob", {}, "Cancel job"))}</button>` : "",
      lifecycle.can_retry ? `<button class="btn secondary" type="button" onclick="retryJob(${job.id})">${escapeHtml(t("jobs.retryJob", {}, "Retry"))}</button>` : "",
      lifecycle.can_remove ? `<button class="btn ghost danger-text" type="button" onclick="removeJob(${job.id})">${escapeHtml(t("jobs.removeJob", {}, "Remove"))}</button>` : "",
    ].filter(Boolean).join("");
    const reason = job.interrupted_reason ? `<div class="job-interruption-note"><strong>${escapeHtml(t("jobs.interruptionReason", {}, "Interruption reason"))}</strong><span>${escapeHtml(job.interrupted_reason)}</span></div>` : "";
    $("jobDetailContent").innerHTML = `<div class="job-detail-scroll"><section class="job-lifecycle-panel"><div class="job-lifecycle-heading"><div><span class="section-kicker">${escapeHtml(t("jobs.lifecycle", {}, "JOB LIFECYCLE"))}</span><div class="job-lifecycle-status">${statusBadge(job.status)}${job.retry_of_job_id ? `<span class="job-retry-link">${escapeHtml(t("jobs.retryOf", { id: job.retry_of_job_id }, `Retry of Job #${job.retry_of_job_id}`))}</span>` : ""}</div></div><div class="job-lifecycle-actions">${lifecycleActions}</div></div><div class="job-lifecycle-metrics"><article><span>${escapeHtml(t("jobs.started", {}, "Started"))}</span><strong>${escapeHtml(formatDate(job.started_at))}</strong></article><article><span>${escapeHtml(t("jobs.lastHeartbeat", {}, "Last heartbeat"))}</span><strong>${escapeHtml(formatDate(job.heartbeat_at))}</strong></article><article><span>${escapeHtml(t("dashboard.success", {}, "Success"))}</span><strong>${Number(job.success_count || 0)}</strong></article><article><span>${escapeHtml(t("jobs.stopped", {}, "Stopped"))}</span><strong>${stopped}</strong></article></div>${reason}</section><div class="job-items">${data.items.map(item => `<article class="job-item"><div class="job-item-header"><div><strong>${escapeHtml(item.device_name || item.host || `Device ${item.device_id}`)}</strong><div>${escapeHtml(item.host)}${item.port ? ` · Port ${escapeHtml(item.port)}` : ""}${item.slot ? ` · Slot ${escapeHtml(item.slot)}` : ""}</div></div>${statusBadge(item.status)}</div>${item.command ? `<h5>${escapeHtml(t("jobs.command", {}, "Command"))}</h5><pre>${escapeHtml(item.command)}</pre>` : ""}${item.output ? `<h5>${escapeHtml(t("jobs.output", {}, "Output"))}</h5><pre>${escapeHtml(item.output)}</pre>` : ""}${item.verification_output ? `<h5>${escapeHtml(t("jobs.verification", {}, "Verification"))}</h5><pre>${escapeHtml(item.verification_output)}</pre>` : ""}${item.error ? `<div class="form-error">${escapeHtml(item.error)}</div>` : ""}</article>`).join("")}</div></div>`;
    $("jobDialog").showModal();
  } catch (error) { toast(error.message,"error"); }
};
window.cancelJob = async function(id) {
  if (!confirm(t("jobs.cancelConfirm", {}, "Cancel this Job? Portivo will stop remaining targets at a safe boundary."))) return;
  try {
    await api(`/api/jobs/${Number(id)}/cancel`, { method: "POST" });
    toast(t("jobs.cancelRequested", {}, "Cancellation requested"), "success");
    state.jobFilterOptions = null;
    await loadJobs();
    await showJob(Number(id));
  } catch (error) { toast(error.message, "error"); }
};
window.retryJob = async function(id) {
  try {
    const result = await api(`/api/jobs/${Number(id)}/retry`, { method: "POST" });
    toast(t("jobs.retryCreated", { id: result.job_id }, `Retry Job #${result.job_id} created`), "success");
    state.jobFilterOptions = null;
    await loadJobs();
    $("jobDialog")?.close();
    await showJob(Number(result.job_id));
  } catch (error) { toast(error.message, "error"); }
};
window.removeJob = async function(id) {
  if (!confirm(t("jobs.removeConfirm", {}, "Remove this Job from history?"))) return;
  try {
    await api(`/api/jobs/${Number(id)}`, { method: "DELETE" });
    $("jobDialog")?.close();
    toast(t("jobs.removed", {}, "Job removed from history"), "success");
    state.jobFilterOptions = null;
    await loadJobs();
  } catch (error) { toast(error.message, "error"); }
};

async function loadProfiles({ force = false } = {}) {
  const alreadyLoaded = Object.keys(state.profiles || {}).length > 0 && Object.keys(state.catalog || {}).length > 0;
  if (!force && alreadyLoaded) {
    renderActionOptions($("commandSearch")?.value || "");
    renderWorkspaceActionOptions($("workspaceCommandSearch")?.value || "");
    if (document.querySelector(".view.active")?.id === "profilesView") renderProfiles();
    return { profiles: state.profiles, catalog: state.catalog };
  }
  if (state.profilesRequest) return state.profilesRequest;
  state.profilesRequest = (async () => {
    const [profiles, catalog] = await Promise.all([api("/api/profiles"), api("/api/catalog")]);
    state.profiles = profiles || {};
    state.catalog = catalog || {};
    if (!state.profiles[state.activeProfile]) state.activeProfile = Object.keys(state.profiles)[0] || "AOS8";
    renderActionOptions($("commandSearch")?.value || "");
    renderWorkspaceActionOptions($("workspaceCommandSearch")?.value || "");
    if (document.querySelector(".view.active")?.id === "profilesView") renderProfiles();
    return { profiles: state.profiles, catalog: state.catalog };
  })();
  try {
    return await state.profilesRequest;
  } finally {
    state.profilesRequest = null;
  }
}
function renderProfiles() {
  const profileNames = Object.keys(state.profiles || {});
  if (!profileNames.length) {
    $("profileTabs").innerHTML = "";
    $("profilesGrid").innerHTML = `<div class="empty-state">${escapeHtml(t("library.noProfiles", {}, "No command profiles are available."))}</div>`;
    return;
  }
  if (!state.profiles[state.activeProfile]) state.activeProfile = profileNames[0];
  $("profileTabs").innerHTML = profileNames.map(name => {
    const actions = [...Object.keys(state.profiles[name].commands || {}), ...(state.profiles[name].orchestrated_actions || [])];
    const visibleCount = actions.filter(action => !actionMeta(action).contextualOnly && actionAllowedForCurrentUser(action)).length;
    return `<button type="button" class="profile-tab ${name === state.activeProfile ? "active" : ""}" onclick="selectCommandProfile('${escapeHtml(name)}')" role="tab" aria-selected="${name === state.activeProfile}">${escapeHtml(name)}<span>${visibleCount}</span></button>`;
  }).join("");

  const query = $("profileSearch").value.trim().toLowerCase();
  const profileName = state.activeProfile;
  const profile = state.profiles[profileName];
  const profileEntries = [
    ...Object.entries(profile.commands || {}),
    ...(profile.orchestrated_actions || []).map(action => [action, t("library.orchestrated", {}, "Portivo ALE-aware workflow")]),
  ];
  const available = profileEntries.filter(([action,command]) => {
    const meta = actionMeta(action);
    const support = profile.compatibility?.[action]?.state || "model_dependent";
    if (!actionAllowedForCurrentUser(action) || meta.contextualOnly) return false;
    return !query || `${profileName} ${profile.label} ${action} ${command} ${meta.label} ${meta.category} ${meta.description} ${meta.compatibility || ""} ${support}`.toLowerCase().includes(query);
  });
  if (!available.length) {
    $("profilesGrid").innerHTML = `<div class="empty-state"><svg><use href="#i-search"></use></svg><strong>${escapeHtml(t("library.noMatches", {}, "No matching commands"))}</strong><span>${escapeHtml(t("library.noMatchesDescription", {}, "Try another word or clear the filter."))}</span></div>`;
    return;
  }

  const grouped = new Map();
  for (const entry of available) {
    const category = actionMeta(entry[0]).category || "Other";
    if (!grouped.has(category)) grouped.set(category, []);
    grouped.get(category).push(entry);
  }
  const translatedCategoryOrder = categoryOrder.map(category => t(`categories.${category}`, {}, category));
  const orderedCategories = [...translatedCategoryOrder.filter(category => grouped.has(category)), ...[...grouped.keys()].filter(category => !translatedCategoryOrder.includes(category))];
  $("profilesGrid").innerHTML = `<article class="profile-card profile-card-full">
    <header><div><span class="section-kicker">${escapeHtml(t("library.profile", { name: profileName }, `${profileName} PROFILE`))}</span><h3>${escapeHtml(profile.label)}</h3><p>${escapeHtml(t("library.visibleTemplates", { count: available.length }, `${available.length} visible templates.`))}</p></div><span class="profile-count">${escapeHtml(t("library.templates", { count: available.length }, `${available.length} templates`))}</span></header>
    <div class="command-category-grid">${orderedCategories.map((category,index) => `<details class="command-category" ${index < 3 ? "open" : ""}><summary><span class="category-title">${escapeHtml(category)}</span><span class="category-count">${grouped.get(category).length}</span></summary><div class="command-list">${grouped.get(category).map(([action,command]) => { const meta = actionMeta(action); const support = profile.compatibility?.[action]?.state || 'model_dependent'; return `<button type="button" class="command-row" onclick="useCatalogCommand('${escapeHtml(action)}')"><span class="command-name">${escapeHtml(meta.label)}</span><code>${escapeHtml(command)}</code><span class="command-risk ${escapeHtml(meta.risk || 'read')}">${escapeHtml(t(meta.risk === 'change' ? 'common.change' : 'library.read', {}, meta.risk === 'change' ? 'Change' : 'Read'))}</span><span class="command-support ${escapeHtml(support)}">${escapeHtml(commandSupportLabel(support))}</span></button>`; }).join("")}</div></details>`).join("")}</div>
  </article>`;
}
window.selectCommandProfile = function(name) { if (state.profiles[name]) { state.activeProfile = name; renderProfiles(); } };
window.useCatalogCommand = function(action) {
  if (!actionAllowedForCurrentUser(action)) { toast(t("roles.changeDenied", {}, "Administrator or Power User access is required for configuration changes."), "error"); return; }
  switchView("bulkView");
  $("commandSearch").value = "";
  renderActionOptions();
  if ([...$("bulkAction").options].some(option => option.value === action)) $("bulkAction").value = action;
  updateActionContext();
  updateBulkSummary();
  clearPreview();
};

async function ensureAuditFilterOptions() {
  if (!state.auditFilterOptions) state.auditFilterOptions = await api("/api/audit/filter-options");
  const options = state.auditFilterOptions || { actors: [], events: [], object_types: [] };
  replaceSelectOptions($("auditActorFilter"), options.actors, "audit.allActors", "All users");
  replaceSelectOptions($("auditEventFilter"), options.events, "audit.allEvents", "All events", value => String(value).replaceAll("_", " "));
  replaceSelectOptions($("auditObjectTypeFilter"), options.object_types, "audit.allObjectTypes", "All object types", value => String(value).replaceAll("_", " "));
}
function currentAuditFilters() {
  return {
    q: $("auditSearch")?.value,
    actor: $("auditActorFilter")?.value,
    event: $("auditEventFilter")?.value,
    object_type: $("auditObjectTypeFilter")?.value,
    date_from: $("auditDateFrom")?.value,
    date_to: $("auditDateTo")?.value,
  };
}
async function loadAudit() {
  const requestSequence = ++state.auditRequestSequence;
  await ensureAuditFilterOptions();
  updateHistoryDateBounds("audit");
  const pagination = state.activityHistoryUi;
  const response = await api(`/api/audit${historyQuery({
    ...currentAuditFilters(),
    page: pagination.auditPage || 1,
    page_size: pagination.auditPageSize || 25,
  })}`);
  if (requestSequence !== state.auditRequestSequence) return;
  const rows = Array.isArray(response) ? response : (response.items || []);
  const auditOptions = state.auditFilterOptions || { actors: [], events: [], object_types: [] };
  auditOptions.actors = [...new Set([...(auditOptions.actors || []), ...rows.map(row => row.actor).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: "base" }));
  auditOptions.events = [...new Set([...(auditOptions.events || []), ...rows.map(row => row.event).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: "base" }));
  auditOptions.object_types = [...new Set([...(auditOptions.object_types || []), ...rows.map(row => row.object_type).filter(Boolean)])].sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: "base" }));
  state.auditFilterOptions = auditOptions;
  await ensureAuditFilterOptions();
  renderActivityHistoryPager("audit", Array.isArray(response) ? { items: rows, total: rows.length, page: 1, page_size: rows.length || 25, pages: 1 } : response);
  $("auditTable").innerHTML = rows.map(row => `<tr><td>#${row.id}</td><td>${escapeHtml(row.actor)}</td><td>${escapeHtml(row.event)}</td><td>${escapeHtml(row.object_type)}:${escapeHtml(row.object_id)}</td><td><code title="${escapeHtml(row.details_json)}">${escapeHtml(row.details_json)}</code></td><td>${formatDate(row.created_at)}</td></tr>`).join("") || `<tr><td colspan="6"><div class="empty-state">${escapeHtml(t("audit.noMatches", {}, "No audit entries match the selected filters."))}</div></td></tr>`;
}
function clearAuditFilters() {
  clearTimeout(state.auditFilterTimer);
  for (const id of ["auditSearch", "auditActorFilter", "auditEventFilter", "auditObjectTypeFilter", "auditDateFrom", "auditDateTo"]) if ($(id)) $(id).value = "";
  updateHistoryDateBounds("audit");
  resetActivityHistoryPage("audit");
  loadAudit();
}
async function importDevices(event) {
  const file = event.target.files[0]; if (!file) return;
  const form = new FormData(); form.append("file", file);
  const importLabel = document.querySelector('label[for="deviceImport"]') || event.target.closest("label");
  if (importLabel) importLabel.classList.add("is-loading");
  try {
    const result = await api("/api/devices/import", { method: "POST", body: form });
    const verification = result.verification || { attempted: 0, successful: 0, failed: 0, skipped: 0 };
    let message;
    let type = "success";
    if (verification.skipped) {
      message = t("devices.importCompletedVerificationSkipped", { inserted: result.inserted, updated: result.updated, skipped: verification.skipped }, `Imported ${result.inserted}, updated ${result.updated}. Live detection was skipped for ${verification.skipped} switches.`);
      type = "";
    } else if (verification.failed || result.errors.length) {
      message = t("devices.importCompletedWithIssues", { inserted: result.inserted, updated: result.updated, successful: verification.successful, failed: verification.failed, errors: result.errors.length }, `Imported ${result.inserted}, updated ${result.updated}. Detected ${verification.successful}; ${verification.failed} verification failures; ${result.errors.length} row errors.`);
      type = "";
    } else {
      message = t("devices.importCompleted", { inserted: result.inserted, updated: result.updated, successful: verification.successful }, `Imported ${result.inserted}, updated ${result.updated}. Live model detection completed for ${verification.successful} switches.`);
    }
    toast(message, type);
    if (result.errors.length) console.table(result.errors);
    if (verification.errors?.length) console.table(verification.errors);
    await Promise.all([loadDevices(), loadDashboard()]);
  } catch (error) {
    toast(error.message, "error");
  } finally {
    if (importLabel) importLabel.classList.remove("is-loading");
    event.target.value = "";
  }
}


async function importAdminDatabase(event) {
  const input = event.target;
  const file = input.files?.[0];
  if (!file) return;
  if (!isBootstrapAdmin()) {
    toast(t("admin.importDatabaseInvalid", {}, "Bootstrap administrator access is required."), "error");
    input.value = "";
    return;
  }
  const confirmed = confirm(t("admin.importDatabaseConfirm", {}, "Importing this file replaces the current database. Continue?"));
  if (!confirmed) { input.value = ""; return; }
  const form = new FormData();
  form.append("file", file);
  const button = $("adminDatabaseImportButton");
  button?.classList.add("is-loading");
  toast(t("admin.importDatabaseStarted", {}, "Importing database backup..."));
  try {
    await api("/api/admin/database/import", { method: "POST", body: form });
    toast(t("admin.importDatabaseCompleted", {}, "Database imported successfully. The application will reload."), "success");
    setTimeout(() => window.location.reload(), 1600);
  } catch (error) {
    toast(error.message || t("admin.importDatabaseInvalid", {}, "Invalid database backup."), "error");
  } finally {
    button?.classList.remove("is-loading");
    input.value = "";
  }
}


function notificationProviderLabel(provider) {
  return {
    microsoft: "Microsoft Teams / Power Automate",
    slack: "Slack Incoming Webhook",
    discord: "Discord Webhook",
    generic: t("notifications.providerGeneric", {}, "Generic JSON Webhook"),
  }[String(provider || "generic")] || String(provider || "Webhook");
}
function notificationProviderIcon(provider) {
  return {
    microsoft: "i-notifications",
    slack: "i-hash",
    discord: "i-chat",
    generic: "i-webhook",
  }[String(provider || "generic")] || "i-webhook";
}
function notificationEventLabel(eventType) {
  return {
    switch_offline: t("notifications.eventOffline", {}, "Switch offline"),
    switch_recovered: t("notifications.eventRecovered", {}, "Switch recovered"),
    switch_offline_reminder: t("notifications.eventReminder", {}, "Still offline"),
    stack_degraded: t("notifications.stackDegraded", {}, "Stack degraded"),
    stack_recovered: t("notifications.stackRecovered", {}, "Stack recovered"),
    ups_on_battery: t("notifications.upsOnBattery", {}, "UPS on battery"),
    ups_power_restored: t("notifications.upsRestored", {}, "UPS power restored"),
    ups_low_battery: t("notifications.upsLowBattery", {}, "UPS low battery"),
    ups_unreachable: t("power.upsOfflineIncident", {}, "UPS offline"),
    test: t("notifications.eventTest", {}, "Integration test"),
  }[String(eventType || "")] || String(eventType || "Notification").replaceAll("_", " ");
}
function notificationDeliveryStatus(status, provider = "") {
  const value = String(status || "unknown").toLowerCase();
  const labels = {
    delivered: provider === "microsoft" ? t("notifications.accepted", {}, "Accepted") : t("notifications.delivered", {}, "Delivered"), queued: t("notifications.queued", {}, "Queued"),
    retrying: t("notifications.retrying", {}, "Retrying"), delivering: t("notifications.delivering", {}, "Delivering"),
    failed: t("notifications.failed", {}, "Failed"), cancelled: t("notifications.cancelled", {}, "Cancelled"),
  };
  return `<span class="status ${value === "delivered" ? "online" : value === "failed" ? "offline" : "unknown"}">${escapeHtml(labels[value] || value)}</span>`;
}
function notificationIncidentDuration(item) {
  const start = item.opened_at ? new Date(item.opened_at) : null;
  const end = item.recovered_at ? new Date(item.recovered_at) : new Date();
  if (!start || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return "—";
  return formatDuration(Math.max(0, (end.getTime() - start.getTime()) / 1000));
}
function selectedNotificationDestinationScopeMode() {
  return document.querySelector('input[name="notificationDestinationScopeMode"]:checked')?.value || "all";
}
function notificationSelectedValues(id) {
  return selectedOptionValues($(id));
}
function populateNotificationDestinationScopeOptions(destination = null) {
  const inventory = state.notifications?.inventory || {};
  const siteSelect = $("notificationDestinationSites");
  const groupSelect = $("notificationDestinationGroups");
  if (!siteSelect || !groupSelect) return;
  const selectedSites = new Set(destination?.sites || []);
  const selectedGroups = new Set(destination?.groups || []);
  siteSelect.innerHTML = (inventory.available_sites || []).map(value => `<option value="${escapeHtml(value)}" ${selectedSites.has(value) ? "selected" : ""}>${escapeHtml(value)}</option>`).join("");
  groupSelect.innerHTML = (inventory.available_groups || []).map(value => `<option value="${escapeHtml(value)}" ${selectedGroups.has(value) ? "selected" : ""}>${escapeHtml(value)}</option>`).join("");
  renderUserAccessScopePicker("notificationDestinationSites", "notificationDestinationSitesPicker", "notificationDestinationSitesCount");
  renderUserAccessScopePicker("notificationDestinationGroups", "notificationDestinationGroupsPicker", "notificationDestinationGroupsCount");
}
function updateNotificationDestinationCoveragePreview() {
  const inventory = state.notifications?.inventory || {};
  const totalSwitches = Number(inventory.enabled_switch_count || 0);
  const totalUps = Number(inventory.enabled_ups_count || 0);
  const switchEvents = Boolean($("notificationDestinationOffline")?.checked || $("notificationDestinationStackDegraded")?.checked);
  const upsEvents = Boolean($("notificationDestinationUpsOnBattery")?.checked || $("notificationDestinationUpsLowBattery")?.checked);
  let coveredSwitches = 0;
  let coveredUps = 0;
  if (selectedNotificationDestinationScopeMode() === "all") {
    coveredSwitches = switchEvents ? totalSwitches : 0;
    coveredUps = upsEvents ? totalUps : 0;
  } else {
    const sites = new Set(notificationSelectedValues("notificationDestinationSites").map(value => value.toLowerCase()));
    const groups = new Set(notificationSelectedValues("notificationDestinationGroups").map(value => value.toLowerCase()));
    const matches = item => {
      const siteOk = !sites.size || sites.has(String(item.site || "").toLowerCase());
      const groupOk = !groups.size || groups.has(String(item.group_name || "").toLowerCase());
      return siteOk && groupOk && Boolean(sites.size || groups.size);
    };
    if (switchEvents) coveredSwitches = (state.devices || []).filter(device => device.enabled && matches(device)).length;
    if (upsEvents) coveredUps = (state.power?.ups || []).filter(ups => ups.enabled && matches(ups)).length;
  }
  if ($("notificationDestinationCoverage")) {
    $("notificationDestinationCoverage").textContent = totalUps
      ? t("notifications.coverageInfrastructure", { switches: coveredSwitches, totalSwitches, ups: coveredUps, totalUps }, `${coveredSwitches} / ${totalSwitches} switches · ${coveredUps} / ${totalUps} UPS`)
      : t("notifications.coverageValue", { covered: coveredSwitches, total: totalSwitches }, `${coveredSwitches} / ${totalSwitches} switches`);
  }
}
function updateNotificationDestinationRoutingUi() {
  const selected = selectedNotificationDestinationScopeMode() === "selected";
  $("notificationDestinationScopeSelectors")?.classList.toggle("is-disabled", !selected);
  if ($("notificationDestinationSites")) $("notificationDestinationSites").disabled = !selected || !isPlatformAdmin();
  if ($("notificationDestinationGroups")) $("notificationDestinationGroups").disabled = !selected || !isPlatformAdmin();
  renderUserAccessScopePicker("notificationDestinationSites", "notificationDestinationSitesPicker", "notificationDestinationSitesCount");
  renderUserAccessScopePicker("notificationDestinationGroups", "notificationDestinationGroupsPicker", "notificationDestinationGroupsCount");
  const offlineEnabled = Boolean($("notificationDestinationOffline")?.checked);
  for (const id of ["notificationDestinationRecovery", "notificationDestinationReminder"]) {
    const control = $(id);
    if (!control) continue;
    control.disabled = !offlineEnabled || !isPlatformAdmin();
    if (!offlineEnabled) control.checked = false;
  }
  const stackEnabled = Boolean($("notificationDestinationStackDegraded")?.checked);
  if ($("notificationDestinationStackRecovery")) {
    $("notificationDestinationStackRecovery").disabled = !stackEnabled || !isPlatformAdmin();
    if (!stackEnabled) $("notificationDestinationStackRecovery").checked = false;
  }
  const upsBatteryEnabled = Boolean($("notificationDestinationUpsOnBattery")?.checked);
  if ($("notificationDestinationUpsRestored")) {
    $("notificationDestinationUpsRestored").disabled = !upsBatteryEnabled || !isPlatformAdmin();
    if (!upsBatteryEnabled) $("notificationDestinationUpsRestored").checked = false;
  }
  updateNotificationDestinationCoveragePreview();
}
function updateNotificationProviderHelp() {
  const provider = $("notificationProvider")?.value || "generic";
  const help = {
    microsoft: t("notifications.providerMicrosoftHelp", {}, "For Microsoft Teams Workflows / Power Automate webhook endpoints. Portivo sends both a text message and a Teams-compatible Adaptive Card envelope for broad workflow-template compatibility."),
    slack: t("notifications.providerSlackHelp", {}, "For Slack Incoming Webhooks. Portivo formats each incident as a Slack Block Kit message."),
    discord: t("notifications.providerDiscordHelp", {}, "For Discord channel webhooks. Portivo sends a compact embed with switch and incident details."),
    generic: t("notifications.providerGenericHelp", {}, "For any public HTTPS endpoint that accepts JSON. Portivo sends the neutral Portivo event schema."),
  };
  if ($("notificationProviderHelp")) $("notificationProviderHelp").textContent = help[provider] || help.generic;
}
async function loadNotificationBadge() {
  try {
    const summary = await api("/api/notifications/summary");
    const badge = $("notificationsNavCount");
    if (!badge) return;
    const open = Number(summary.open_incidents || 0);
    badge.textContent = String(open);
    badge.classList.toggle("hidden", open <= 0);
  } catch (_) {}
}
async function loadNotifications() {
  try {
    const requests = [api("/api/notifications?history_limit=500"), state.devices.length ? Promise.resolve() : loadDevices()];
    if (hasCapability("power.view")) requests.push(api("/api/power"));
    const [data, , powerData = null] = await Promise.all(requests);
    state.notifications = data;
    if (powerData) state.power = { ...state.power, ...powerData };
    renderNotifications();
  } catch (error) {
    toast(error.message, "error");
  }
}
function renderNotifications() {
  const data = state.notifications || {};
  const policy = data.policy || {};
  const summary = data.summary || {};
  const inventory = data.inventory || {};
  const destinations = data.destinations || [];
  const activeDestinations = destinations.filter(item => item.enabled && item.webhook_configured).length;
  if ($("notificationMetricDestinations")) $("notificationMetricDestinations").textContent = String(destinations.length);
  if ($("notificationMetricDestinationsHelp")) $("notificationMetricDestinationsHelp").textContent = t("notifications.activeDestinations", { count: activeDestinations }, `${activeDestinations} active`);
  if ($("notificationMetricCoverage")) $("notificationMetricCoverage").textContent = String(Number(inventory.covered_switch_count || 0) + Number(inventory.covered_ups_count || 0));
  if ($("notificationMetricCoverageHelp")) $("notificationMetricCoverageHelp").textContent = Number(inventory.enabled_ups_count || 0)
    ? t("notifications.coverageHelpInfrastructure", { switches: inventory.enabled_switch_count || 0, ups: inventory.enabled_ups_count || 0 }, `${inventory.enabled_switch_count || 0} switches · ${inventory.enabled_ups_count || 0} UPS`)
    : t("notifications.coverageHelpValue", { total: inventory.enabled_switch_count || 0 }, `${inventory.enabled_switch_count || 0} enabled switches`);
  if ($("notificationMetricIncidents")) $("notificationMetricIncidents").textContent = String(summary.open_incidents || 0);
  if ($("notificationMetricQueue")) $("notificationMetricQueue").textContent = String(summary.pending_deliveries || 0);
  if ($("notificationMetricQueueHelp")) $("notificationMetricQueueHelp").textContent = Number(summary.failed_deliveries || 0)
    ? t("notifications.failedDeliveryCount", { count: summary.failed_deliveries }, `${summary.failed_deliveries} failed deliveries`)
    : t("notifications.noDeliveryIssues", {}, "No failed deliveries");
  if ($("notificationsHeroStatus")) $("notificationsHeroStatus").textContent = policy.enabled && activeDestinations
    ? t("notifications.active", {}, "Active") : activeDestinations ? t("notifications.paused", {}, "Configured · paused") : t("notifications.notConfigured", {}, "No destination configured");
  if ($("notificationsNavCount")) {
    const open = Number(summary.open_incidents || 0);
    $("notificationsNavCount").textContent = String(open);
    $("notificationsNavCount").classList.toggle("hidden", open <= 0);
  }
  const badge = $("notificationPolicyBadge");
  if (badge) {
    badge.className = `status ${policy.enabled && activeDestinations ? "online" : "unknown"}`;
    badge.textContent = policy.enabled && activeDestinations ? t("notifications.active", {}, "Active") : t("notifications.paused", {}, "Paused");
  }
  if ($("notificationEnabled")) $("notificationEnabled").checked = Boolean(policy.enabled);
  if ($("notificationFailureThreshold")) $("notificationFailureThreshold").value = String(policy.failure_threshold || 3);
  if ($("notificationReminder")) $("notificationReminder").value = String(policy.reminder_minutes || 0);
  const editable = isPlatformAdmin();
  for (const id of ["notificationEnabled", "notificationFailureThreshold", "notificationReminder"]) if ($(id)) $(id).disabled = !editable;
  renderNotificationDestinations();
  renderNotificationIncidents();
  renderNotificationDeliveries();
}
function notificationSelectOptions(selectId, items, allLabel) {
  const select = $(selectId);
  if (!select) return;
  const previous = select.value;
  select.innerHTML = `<option value="">${escapeHtml(allLabel)}</option>` + items.map(item => `<option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>`).join("");
  if ([...select.options].some(option => option.value === previous)) select.value = previous;
}
function notificationMatchesDate(value, fromValue, toValue) {
  if (!fromValue && !toValue) return true;
  const key = platformDateKey(value);
  if (!key) return false;
  if (fromValue && key < fromValue) return false;
  if (toValue && key > toValue) return false;
  return true;
}
function notificationPagination(rows, page, pageSize) {
  const size = Math.max(10, Number(pageSize || 25));
  const pages = Math.max(1, Math.ceil(rows.length / size));
  const safePage = Math.min(Math.max(1, Number(page || 1)), pages);
  const start = (safePage - 1) * size;
  return { page: safePage, pages, pageSize: size, start, end: Math.min(rows.length, start + size), items: rows.slice(start, start + size) };
}
function renderNotificationDestinations() {
  const container = $("notificationDestinationList");
  if (!container) return;
  const rows = state.notifications?.destinations || [];
  const count = $("notificationDestinationCount");
  if (count) count.textContent = t("notifications.destinationCount", { count: rows.length }, `${rows.length} destination${rows.length === 1 ? "" : "s"}`);
  if (!rows.length) {
    container.innerHTML = `<div class="notification-empty"><svg><use href="#i-webhook"></use></svg><strong>${escapeHtml(t("notifications.noDestinations", {}, "No webhook destinations"))}</strong><span>${escapeHtml(t("notifications.noDestinationsHelp", {}, "Add Microsoft Teams, Slack, Discord or a generic HTTPS webhook to start routing confirmed incidents."))}</span></div>`;
    return;
  }
  const editable = isPlatformAdmin();
  container.innerHTML = rows.map(item => {
    const health = item.enabled ? (item.last_delivery_status === "failed" || item.last_test_status === "failed" ? "failed" : "active") : "paused";
    const statusText = item.enabled ? (health === "failed" ? t("notifications.deliveryIssue", {}, "Delivery issue") : t("notifications.enabled", {}, "Enabled")) : t("notifications.disabled", {}, "Disabled");
    const lastActivity = item.last_delivery_at || item.last_test_at;
    const activityLabel = item.last_delivery_at ? t("notifications.lastDelivery", {}, "Last delivery") : item.last_test_at ? t("notifications.lastTest", {}, "Last test") : "";
    const events = [
      item.notify_offline ? t("notifications.offlineShort", {}, "Offline") : "",
      item.notify_recovery ? t("notifications.recoveryShort", {}, "Recovery") : "",
      item.notify_reminder ? t("notifications.reminderShort", {}, "Reminder") : "",
      item.notify_stack_degraded ? t("notifications.stackShort", {}, "Stack") : "",
      item.notify_stack_recovery ? t("notifications.stackRecoveryShort", {}, "Stack recovery") : "",
      item.notify_ups_on_battery ? t("notifications.upsBatteryShort", {}, "UPS battery") : "",
      item.notify_ups_power_restored ? t("notifications.upsRestoreShort", {}, "UPS restore") : "",
      item.notify_ups_low_battery ? t("notifications.upsLowShort", {}, "UPS low") : "",
    ].filter(Boolean);
    const switchCount = Number(item.scope_mode === "all" ? item.enabled_switch_count : item.covered_switch_count || 0);
    const upsCount = Number(item.scope_mode === "all" ? item.enabled_ups_count : item.covered_ups_count || 0);
    const scope = upsCount || Number(item.enabled_ups_count || 0)
      ? t("notifications.infrastructureScopeSummary", { switches: switchCount, ups: upsCount }, `${switchCount} switches · ${upsCount} UPS`)
      : (item.scope_mode === "all"
        ? t("notifications.allEnabledCount", { count: item.enabled_switch_count || 0 }, `All ${item.enabled_switch_count || 0} enabled switches`)
        : t("notifications.selectedCoverage", { count: item.covered_switch_count || 0 }, `${item.covered_switch_count || 0} selected switches`));
    return `<article class="notification-destination-card notification-destination-tile ${health}" data-provider="${escapeHtml(item.provider)}">
      <div class="notification-destination-tile-head">
        <span class="notification-destination-icon"><svg><use href="#${notificationProviderIcon(item.provider)}"></use></svg></span>
        <div class="notification-destination-title-block"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(notificationProviderLabel(item.provider))}</span></div>
        <span class="notification-destination-status ${health}"><i></i>${escapeHtml(statusText)}</span>
        ${editable ? `<details class="notification-destination-menu"><summary aria-label="${escapeHtml(t("notifications.destinationActions", {}, "Destination actions"))}" title="${escapeHtml(t("notifications.destinationActions", {}, "Destination actions"))}"><span aria-hidden="true">•••</span></summary><div class="notification-destination-menu-popover"><button type="button" onclick="this.closest('details').removeAttribute('open');testNotificationDestination(${item.id})">${escapeHtml(t("notifications.test", {}, "Test destination"))}</button><button type="button" onclick="this.closest('details').removeAttribute('open');editNotificationDestination(${item.id})">${escapeHtml(t("common.edit", {}, "Edit"))}</button><button class="danger" type="button" onclick="this.closest('details').removeAttribute('open');removeNotificationDestination(${item.id})">${escapeHtml(t("common.remove", {}, "Remove"))}</button></div></details>` : ""}
      </div>
      <div class="notification-destination-event-chips">${events.length ? events.map(label => `<span>${escapeHtml(label)}</span>`).join("") : `<span class="muted">${escapeHtml(t("notifications.none", {}, "No events"))}</span>`}</div>
      <div class="notification-destination-tile-foot"><span><b>${escapeHtml(t("notifications.scopeTitle", {}, "Scope"))}</b>${escapeHtml(scope)}</span><span><b>${escapeHtml(lastActivity ? activityLabel : t("notifications.activity", {}, "Activity"))}</b>${escapeHtml(lastActivity ? formatDate(lastActivity) : t("notifications.noDeliveryYet", {}, "No delivery yet"))}</span></div>
    </article>`;
  }).join("");
}

function filteredNotificationIncidents() {
  const rows = state.notifications?.incidents || [];
  const q = String($("notificationIncidentSearch")?.value || "").trim().toLowerCase();
  const status = $("notificationIncidentState")?.value || "";
  const from = $("notificationIncidentDateFrom")?.value || "";
  const to = $("notificationIncidentDateTo")?.value || "";
  return rows.filter(item => {
    if (status && item.status !== status) return false;
    if (!notificationMatchesDate(item.opened_at, from, to)) return false;
    if (!q) return true;
    return [item.device_name, item.host, item.site, item.group_name, item.model, item.status, item.incident_type]
      .some(value => String(value || "").toLowerCase().includes(q));
  });
}
function clearNotificationIncidentFilters() {
  for (const id of ["notificationIncidentSearch", "notificationIncidentState", "notificationIncidentDateFrom", "notificationIncidentDateTo"]) if ($(id)) $(id).value = "";
  state.notificationHistoryUi.incidentsPage = 1;
  renderNotificationIncidents();
}
function renderNotificationIncidents() {
  const body = $("notificationIncidentsTable");
  if (!body) return;
  const rows = filteredNotificationIncidents();
  const pageSize = Number($("notificationIncidentPageSize")?.value || state.notificationHistoryUi.incidentsPageSize || 25);
  const pager = notificationPagination(rows, state.notificationHistoryUi.incidentsPage, pageSize);
  state.notificationHistoryUi.incidentsPage = pager.page;
  state.notificationHistoryUi.incidentsPageSize = pager.pageSize;
  body.innerHTML = pager.items.map(item => {
    const isPower = item.source_type === "ups" || String(item.incident_type || "").startsWith("ups_");
    const isStack = !isPower && item.incident_type === "stack_degraded";
    const stackDetails = item.details || {};
    const stateLabel = isPower
      ? (item.status === "open" ? powerIncidentLabel(item.incident_type) : t("notifications.powerRecoveredState", {}, "Power recovered"))
      : isStack
        ? (item.status === "open" ? t("notifications.stackDegradedState", {}, "Stack degraded") : t("notifications.stackRecoveredState", {}, "Stack recovered"))
        : (item.status === "open" ? t("notifications.offlineState", {}, "Offline") : t("notifications.recoveredState", {}, "Recovered"));
    const powerLine = isPower ? `<div class="muted-line">${escapeHtml([stackDetails.power_state ? powerStateLabel(stackDetails.power_state) : "", stackDetails.battery_charge_percent !== null && stackDetails.battery_charge_percent !== undefined ? `${stackDetails.battery_charge_percent}% battery` : "", stackDetails.runtime_minutes !== null && stackDetails.runtime_minutes !== undefined ? `${stackDetails.runtime_minutes} min runtime` : ""].filter(Boolean).join(" · "))}</div>` : "";
    const stackLine = isStack && stackDetails.expected_members ? `<div class="muted-line">${escapeHtml(t("notifications.stackMembersValue", { current: Number(stackDetails.current_members || 0), expected: Number(stackDetails.expected_members || 0) }, `${Number(stackDetails.current_members || 0)}/${Number(stackDetails.expected_members || 0)} members`))}</div>` : "";
    const affectedIds = item.status === "open"
      ? (Array.isArray(stackDetails.missing_member_ids) ? stackDetails.missing_member_ids : [])
      : (Array.isArray(stackDetails.recovered_member_ids) ? stackDetails.recovered_member_ids : (Array.isArray(stackDetails.affected_member_ids) ? stackDetails.affected_member_ids : []));
    const affectedMembers = item.status === "open"
      ? (Array.isArray(stackDetails.missing_members) ? stackDetails.missing_members : [])
      : (Array.isArray(stackDetails.recovered_members) ? stackDetails.recovered_members : (Array.isArray(stackDetails.affected_members) ? stackDetails.affected_members : []));
    let chassisLine = "";
    if (isStack && affectedIds.length) {
      const idText = affectedIds.map(String).join(", ");
      const title = item.status === "open"
        ? t("notifications.missingChassisValue", { ids: idText }, `Chassis ${idText} missing`)
        : t("notifications.recoveredChassisValue", { ids: idText }, `Chassis ${idText} recovered`);
      const one = affectedMembers.length === 1 && affectedMembers[0] && typeof affectedMembers[0] === "object" ? affectedMembers[0] : null;
      const meta = [];
      if (one?.state && item.status === "open") meta.push(String(one.state));
      if (one?.last_known_role) meta.push(t("notifications.lastKnownRoleValue", { role: one.last_known_role }, `Last role ${one.last_known_role}`));
      if (one?.last_known_mac) meta.push(String(one.last_known_mac));
      chassisLine = `<div class="notification-stack-member-detail ${item.status === "open" ? "open" : "closed"}"><strong>${escapeHtml(title)}</strong>${meta.length ? `<span>${escapeHtml(meta.join(" · "))}</span>` : ""}</div>`;
    }
    return `<tr>
    <td><span class="notification-state ${item.status === "open" ? "open" : "closed"}"><i></i>${escapeHtml(stateLabel)}</span></td>
    <td><strong>${escapeHtml(item.device_name || item.ups_name || "Unknown")}</strong><div class="muted-line"><code>${escapeHtml(item.host || "")}</code></div>${powerLine}${stackLine}${chassisLine}</td>
    <td>${escapeHtml(item.site || "—")}</td><td>${escapeHtml(formatDate(item.opened_at))}</td><td>${item.recovered_at ? escapeHtml(formatDate(item.recovered_at)) : "—"}</td><td>${escapeHtml(notificationIncidentDuration(item))}</td>
  </tr>`;
  }).join("") || `<tr><td colspan="6"><div class="empty-state">${escapeHtml(t("notifications.noIncidentMatches", {}, "No incidents match the current filters."))}</div></td></tr>`;
  const summary = $("notificationIncidentResultSummary");
  if (summary) summary.textContent = rows.length ? t("notifications.showingRange", { start: pager.start + 1, end: pager.end, total: rows.length }, `Showing ${pager.start + 1}–${pager.end} of ${rows.length}`) : t("notifications.zeroResults", {}, "0 results");
  if ($("notificationIncidentPageLabel")) $("notificationIncidentPageLabel").textContent = t("notifications.pageOf", { page: pager.page, pages: pager.pages }, `Page ${pager.page} of ${pager.pages}`);
  if ($("notificationIncidentPrev")) $("notificationIncidentPrev").disabled = pager.page <= 1;
  if ($("notificationIncidentNext")) $("notificationIncidentNext").disabled = pager.page >= pager.pages;
}
function filteredNotificationDeliveries() {
  const rows = state.notifications?.deliveries || [];
  const q = String($("notificationDeliverySearch")?.value || "").trim().toLowerCase();
  const eventType = $("notificationDeliveryEvent")?.value || "";
  const provider = $("notificationDeliveryProvider")?.value || "";
  const status = $("notificationDeliveryStatusFilter")?.value || "";
  const destinationId = $("notificationDeliveryDestination")?.value || "";
  const from = $("notificationDeliveryDateFrom")?.value || "";
  const to = $("notificationDeliveryDateTo")?.value || "";
  return rows.filter(item => {
    if (eventType && item.event_type !== eventType) return false;
    if (provider && item.provider !== provider) return false;
    if (status && item.status !== status) return false;
    if (destinationId && String(item.destination_id || "") !== destinationId) return false;
    if (!notificationMatchesDate(item.delivered_at || item.created_at, from, to)) return false;
    if (!q) return true;
    return [notificationEventLabel(item.event_type), item.destination_name, notificationProviderLabel(item.provider), item.device_name, item.status, item.last_error, item.http_status]
      .some(value => String(value || "").toLowerCase().includes(q));
  });
}
function clearNotificationDeliveryFilters() {
  for (const id of ["notificationDeliverySearch", "notificationDeliveryEvent", "notificationDeliveryProvider", "notificationDeliveryStatusFilter", "notificationDeliveryDestination", "notificationDeliveryDateFrom", "notificationDeliveryDateTo"]) if ($(id)) $(id).value = "";
  state.notificationHistoryUi.deliveriesPage = 1;
  renderNotificationDeliveries();
}
function renderNotificationDeliveries() {
  const body = $("notificationDeliveryTable");
  if (!body) return;
  const allRows = state.notifications?.deliveries || [];
  const destinations = state.notifications?.destinations || [];
  notificationSelectOptions("notificationDeliveryDestination", destinations.map(item => ({ value: String(item.id), label: item.name })), t("notifications.allDestinations", {}, "All destinations"));
  const rows = filteredNotificationDeliveries();
  const pageSize = Number($("notificationDeliveryPageSize")?.value || state.notificationHistoryUi.deliveriesPageSize || 25);
  const pager = notificationPagination(rows, state.notificationHistoryUi.deliveriesPage, pageSize);
  state.notificationHistoryUi.deliveriesPage = pager.page;
  state.notificationHistoryUi.deliveriesPageSize = pager.pageSize;
  body.innerHTML = pager.items.map(item => {
    const microsoftAccepted = item.provider === "microsoft" && item.status === "delivered";
    const statusHtml = notificationDeliveryStatus(item.status, item.provider);
    const providerNote = microsoftAccepted ? `<span class="notification-delivery-note">${escapeHtml(t("notifications.workflowAcceptedHelp", {}, "Accepted by the Microsoft workflow. Final Teams posting depends on the workflow actions."))}</span>` : "";
    return `<tr>
      <td><strong>${escapeHtml(notificationEventLabel(item.event_type))}</strong></td>
      <td><strong>${escapeHtml(item.destination_name || "Legacy destination")}</strong><div class="muted-line">${escapeHtml(notificationProviderLabel(item.provider))}</div></td>
      <td>${escapeHtml(item.device_name || "—")}</td>
      <td>${statusHtml}${providerNote}${item.last_error ? `<span class="notification-delivery-error" title="${escapeHtml(item.last_error)}">${escapeHtml(String(item.last_error).slice(0, 140))}${String(item.last_error).length > 140 ? "…" : ""}</span>` : ""}</td>
      <td>${Number(item.attempts || 0)}</td><td>${escapeHtml(formatDate(item.delivered_at || item.created_at))}</td>
    </tr>`;
  }).join("") || `<tr><td colspan="6"><div class="empty-state">${escapeHtml(t("notifications.noDeliveryMatches", {}, "No webhook deliveries match the current filters."))}</div></td></tr>`;
  const summary = $("notificationDeliveryResultSummary");
  if (summary) summary.textContent = rows.length ? t("notifications.showingRange", { start: pager.start + 1, end: pager.end, total: rows.length }, `Showing ${pager.start + 1}–${pager.end} of ${rows.length}`) : t("notifications.zeroResults", {}, "0 results");
  if ($("notificationDeliveryPageLabel")) $("notificationDeliveryPageLabel").textContent = t("notifications.pageOf", { page: pager.page, pages: pager.pages }, `Page ${pager.page} of ${pager.pages}`);
  if ($("notificationDeliveryPrev")) $("notificationDeliveryPrev").disabled = pager.page <= 1;
  if ($("notificationDeliveryNext")) $("notificationDeliveryNext").disabled = pager.page >= pager.pages;
  const totalHint = $("notificationDeliveryLoadedSummary");
  if (totalHint) totalHint.textContent = t("notifications.loadedHistory", { count: allRows.length }, `${allRows.length} recent delivery records loaded`);
}
async function saveNotificationPolicy(event) {
  event.preventDefault();
  if (!isPlatformAdmin()) return;
  const submit = event.submitter || $("notificationPolicyForm")?.querySelector('button[type="submit"]');
  submit?.classList.add("is-loading");
  try {
    state.notifications = await api("/api/notifications/policy", { method: "PUT", body: {
      enabled: $("notificationEnabled").checked,
      failure_threshold: Number($("notificationFailureThreshold").value || 3), reminder_minutes: Number($("notificationReminder").value || 0),
    }});
    renderNotifications();
    toast(t("notifications.policySaved", {}, "Notification policy saved"), "success");
  } catch (error) { toast(error.message, "error"); }
  finally { submit?.classList.remove("is-loading"); }
}
function openNotificationDestinationDialog(destination = null) {
  if (!isPlatformAdmin()) return;
  $("notificationDestinationForm")?.reset();
  $("notificationDestinationId").value = destination?.id ? String(destination.id) : "";
  $("notificationDestinationName").value = destination?.name || "";
  $("notificationProvider").value = destination?.provider || "microsoft";
  $("notificationDestinationEnabled").checked = destination ? Boolean(destination.enabled) : true;
  $("notificationDestinationOffline").checked = destination ? destination.notify_offline !== false : true;
  $("notificationDestinationRecovery").checked = destination ? destination.notify_recovery !== false : true;
  $("notificationDestinationReminder").checked = destination ? destination.notify_reminder !== false : true;
  $("notificationDestinationStackDegraded").checked = destination ? destination.notify_stack_degraded !== false : true;
  $("notificationDestinationStackRecovery").checked = destination ? destination.notify_stack_recovery !== false : true;
  $("notificationDestinationUpsOnBattery").checked = destination ? destination.notify_ups_on_battery !== false : true;
  $("notificationDestinationUpsRestored").checked = destination ? destination.notify_ups_power_restored !== false : true;
  $("notificationDestinationUpsLowBattery").checked = destination ? destination.notify_ups_low_battery !== false : true;
  const routeMode = destination?.scope_mode === "selected" ? "selected" : "all";
  const routeRadio = document.querySelector(`input[name="notificationDestinationScopeMode"][value="${routeMode}"]`);
  if (routeRadio) routeRadio.checked = true;
  populateNotificationDestinationScopeOptions(destination);
  $("notificationWebhookUrl").value = "";
  $("notificationWebhookUrl").placeholder = destination?.webhook_configured ? t("notifications.keepWebhook", {}, "Leave empty to keep the saved endpoint") : "https://...";
  if ($("notificationWebhookSummary")) $("notificationWebhookSummary").textContent = destination?.webhook_configured ? `${t("notifications.configured", {}, "Configured")}: ${destination.webhook_masked || "encrypted endpoint"}` : t("notifications.webhookSecretHelp", {}, "Stored encrypted and never returned in clear text after saving.");
  if ($("notificationDestinationDialogTitle")) $("notificationDestinationDialogTitle").textContent = destination ? t("notifications.editDestination", {}, "Edit destination") : t("notifications.addDestination", {}, "Add destination");
  updateNotificationProviderHelp();
  updateNotificationDestinationRoutingUi();
  $("notificationDestinationDialog")?.showModal();
}
window.editNotificationDestination = function(destinationId) {
  const destination = (state.notifications?.destinations || []).find(item => Number(item.id) === Number(destinationId));
  if (destination) openNotificationDestinationDialog(destination);
};
async function saveNotificationDestination(event) {
  event.preventDefault();
  if (!isPlatformAdmin()) return;
  const id = Number($("notificationDestinationId").value || 0);
  const body = {
    name: $("notificationDestinationName").value.trim(), provider: $("notificationProvider").value,
    enabled: $("notificationDestinationEnabled").checked, webhook_url: $("notificationWebhookUrl").value.trim() || null,
    scope_mode: selectedNotificationDestinationScopeMode(),
    sites: notificationSelectedValues("notificationDestinationSites"), groups: notificationSelectedValues("notificationDestinationGroups"),
    notify_offline: $("notificationDestinationOffline").checked, notify_recovery: $("notificationDestinationRecovery").checked,
    notify_reminder: $("notificationDestinationReminder").checked,
    notify_stack_degraded: $("notificationDestinationStackDegraded").checked,
    notify_stack_recovery: $("notificationDestinationStackRecovery").checked,
    notify_ups_on_battery: $("notificationDestinationUpsOnBattery").checked,
    notify_ups_power_restored: $("notificationDestinationUpsRestored").checked,
    notify_ups_low_battery: $("notificationDestinationUpsLowBattery").checked,
    notify_ups_unreachable: false,
  };
  const submit = event.submitter || $("notificationDestinationForm")?.querySelector('button[type="submit"]');
  submit?.classList.add("is-loading");
  try {
    const result = await api(id ? `/api/notifications/destinations/${id}` : "/api/notifications/destinations", { method: id ? "PUT" : "POST", body });
    state.notifications = result;
    $("notificationDestinationDialog")?.close();
    renderNotifications();
    toast(t("notifications.destinationSaved", {}, "Webhook destination saved"), "success");
  } catch (error) { toast(error.message, "error"); }
  finally { submit?.classList.remove("is-loading"); }
}
window.testNotificationDestination = async function(destinationId) {
  if (!isPlatformAdmin()) return;
  try {
    const result = await api(`/api/notifications/destinations/${destinationId}/test`, { method: "POST" });
    const destination = (state.notifications?.destinations || []).find(item => Number(item.id) === Number(destinationId));
    const message = destination?.provider === "microsoft"
      ? t("notifications.testAcceptedMicrosoft", { status: result.http_status }, `Microsoft workflow accepted the test (HTTP ${result.http_status}). Check the Teams channel or flow run history for the final post.`)
      : t("notifications.testDelivered", { status: result.http_status }, `Test delivered (HTTP ${result.http_status})`);
    toast(message, "success");
    await loadNotifications();
  } catch (error) {
    toast(error.message, "error");
    await loadNotifications();
  }
};
window.removeNotificationDestination = async function(destinationId) {
  if (!isPlatformAdmin()) return;
  const destination = (state.notifications?.destinations || []).find(item => Number(item.id) === Number(destinationId));
  if (!confirm(t("notifications.removeConfirm", { name: destination?.name || "" }, `Remove ${destination?.name || "this destination"}?`))) return;
  try {
    state.notifications = await api(`/api/notifications/destinations/${destinationId}`, { method: "DELETE" });
    renderNotifications();
    toast(t("notifications.destinationRemoved", {}, "Webhook destination removed"), "success");
  } catch (error) { toast(error.message, "error"); }
};

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  return `${(value / 1024 / 1024 / 1024).toFixed(2)} GB`;
}
function formatDuration(seconds) {
  const total = Math.max(0, Number(seconds || 0));
  if (total < 60) return `${Math.round(total)}s`;
  if (total < 3600) return `${Math.floor(total / 60)}m`;
  return `${Math.floor(total / 3600)}h ${Math.floor((total % 3600) / 60)}m`;
}
function renderAuthenticationPathPreview() {
  const host = $("adminAuthPath");
  if (!host) return;
  const selectedIds = [1,2,3,4,5].map(index => Number($("adminAuthSource" + index)?.value || 0)).filter(Boolean);
  const auth = state.adminOverview?.authentication || {};
  const automatic = selectedIds.length === 0;
  const effective = automatic
    ? (Array.isArray(auth.effective_sources) ? auth.effective_sources : [])
    : selectedIds.map(id => adminManagedSwitches().find(device => Number(device.id) === id)).filter(Boolean);
  const maxSources = Number(auth.max_sources || 5);
  const modeText = automatic ? t("admin.authPathAutomatic", {}, "Automatic candidates") : t("admin.authPathConfigured", {}, "Configured order");
  const countText = t("admin.authPathCount", { count: effective.length, max: maxSources }, `${effective.length} / ${maxSources} sources`);
  const sourceRows = effective.slice(0, maxSources).map((device, index) => {
    const status = String(device.last_status || "unknown").toLowerCase();
    const statusLabel = status === "online" ? t("common.online", {}, "Online") : status === "offline" ? t("common.offline", {}, "Offline") : t("common.unknown", {}, "Unknown");
    const statusClass = status === "online" ? "online" : status === "offline" ? "offline" : "unknown";
    const roleLabel = automatic
      ? t("admin.authCandidate", { index: index + 1 }, `Candidate ${index + 1}`)
      : [t("admin.authSourcePrimary", {}, "Primary"), t("admin.authSourceSecondary", {}, "Secondary"), t("admin.authSourceFallback1", {}, "Fallback 1"), t("admin.authSourceFallback2", {}, "Fallback 2"), t("admin.authSourceFallback3", {}, "Fallback 3")][index];
    const site = String(device.site || "").trim();
    const address = String(device.host || "");
    return `<div class="admin-auth-path-row"><span class="admin-auth-path-order">${index + 1}</span><span class="admin-auth-path-copy"><strong>${escapeHtml(roleLabel)} · ${escapeHtml(device.name || address || t("common.unknown", {}, "Unknown"))}</strong><small>${escapeHtml([address, site].filter(Boolean).join(" · "))}</small></span><span class="admin-auth-path-status ${statusClass}"><i></i>${escapeHtml(statusLabel)}</span></div>`;
  }).join("");
  host.innerHTML = `<div class="admin-auth-path-head"><div><span class="section-kicker">${escapeHtml(t("admin.authPathKicker", {}, "EFFECTIVE LOGIN PATH"))}</span><strong>${escapeHtml(t("admin.authPathTitle", {}, "SSH validation order"))}</strong><small>${escapeHtml(t("admin.authPathHelp", {}, "Portivo probes these sources for reachability before validating personal SSH credentials."))}</small></div><span>${escapeHtml(modeText)} · ${escapeHtml(countText)}</span></div><div class="admin-auth-path-list">${sourceRows || `<div class="admin-auth-path-empty">${escapeHtml(t("admin.authPathEmpty", {}, "No enabled switches are currently available as authentication sources."))}</div>`}</div>`;
}

function adminManagedSwitches() {
  const inventory = (state.devices || []).filter(device => Boolean(device.enabled));
  if (inventory.length) return inventory;
  return (state.monitoringVerificationTargets || [])
    .filter(item => item.type === "switch")
    .map(item => ({ ...item, enabled: true, last_status: item.last_status || "unknown" }));
}
function populateAuthenticationSources(selectedIds = []) {
  const devices = adminManagedSwitches().slice().sort((a, b) => String(a.name || a.host).localeCompare(String(b.name || b.host), undefined, { numeric: true }));
  const selected = (selectedIds || []).map(Number).filter(Number.isFinite).slice(0, 5);
  for (let index = 1; index <= 5; index += 1) {
    const select = $("adminAuthSource" + index);
    if (!select) continue;
    const emptyLabel = index === 1 ? t("admin.authSourceAutomatic", {}, "Automatic selection") : t("common.none", {}, "None");
    select.innerHTML = `<option value="">${escapeHtml(emptyLabel)}</option>` + devices.map(device => `<option value="${Number(device.id)}">${escapeHtml(device.name || device.host)} · ${escapeHtml(device.host)}</option>`).join("");
    select.value = selected[index - 1] ? String(selected[index - 1]) : "";
  }
}
function selectedAuthenticationSourceIds() {
  const result = [];
  const seen = new Set();
  for (let index = 1; index <= 5; index += 1) {
    const value = Number($("adminAuthSource" + index)?.value || 0);
    if (!value || seen.has(value)) continue;
    seen.add(value);
    result.push(value);
  }
  return result;
}

function accessRoleById(roleId) {
  return (state.adminAccessControl?.roles || []).find(role => Number(role.id) === Number(roleId)) || null;
}
function accessRoleName(role) {
  if (!role) return t("access.role", {}, "Role");
  return role.built_in ? t(`roles.${role.key}`, {}, role.name || role.key) : (role.name || role.key);
}
function accessRoleDescription(role) {
  if (!role) return "";
  return role.built_in ? t(`access.roleDescription.${role.key}`, {}, role.description || "") : (role.description || "");
}
function accessScopeText(scope = {}) {
  if (scope.global || scope.mode === "all") return t("access.allSites", {}, "All Sites");
  if (scope.mode !== "selected") return t("access.noScope", {}, "No scope assigned");
  const sites = scope.sites || [];
  const groups = scope.groups || [];
  if (!groups.length) return sites.length === 1 ? sites[0] : t("access.siteCount", { count: sites.length }, `${sites.length} Sites`);
  const siteLabel = sites.length === 1 ? t("access.site", {}, "Site") : t("access.sites", {}, "Sites");
  const groupLabel = groups.length === 1 ? t("access.group", {}, "Group") : t("access.groups", {}, "Groups");
  return `${sites.length} ${siteLabel} · ${groups.length} ${groupLabel}`;
}
function renderAccessRoleStrip() {
  const builtins = (state.adminAccessControl?.roles || []).filter(role => role.built_in);
  const container = $("accessRoleStrip");
  if (!container) return;
  container.innerHTML = builtins.map(role => `<article class="access-role-chip ${role.global_role ? "global" : "scoped"}"><strong>${escapeHtml(accessRoleName(role))}</strong><span>${escapeHtml(role.global_role ? t("access.globalAccess", {}, "Global access") : t("access.scopedAccess", {}, "Site / Group scoped"))}</span></article>`).join("");
}
function currentAdminMonitoringMode() {
  return document.querySelector('input[name="adminMonitoringMode"]:checked')?.value || "full";
}
function syncAdminMonitoringModeUi() {
  const mode = currentAdminMonitoringMode();
  const managementOnly = mode === "management_only";
  const services = $("adminMonitoringServices");
  services?.classList.toggle("is-paused", managementOnly);
  for (const id of ["adminMonitorSwitchAvailability", "adminMonitorStackHealth", "adminMonitorPowerUps", "adminMonitorIncidentDetection"]) {
    const input = $(id); if (input) input.disabled = managementOnly;
  }
  if ($("adminPollInterval")) $("adminPollInterval").disabled = managementOnly || !Boolean($("adminMonitorSwitchAvailability")?.checked);
  const status = $("adminMonitoringModeStatus");
  if (status) {
    status.textContent = managementOnly ? t("monitoringMode.managementOnly", {}, "Management only") : t("monitoringMode.full", {}, "Full monitoring");
    status.classList.toggle("management-only", managementOnly);
  }
  const hint = $("adminMonitoringServicesHint");
  if (hint) hint.textContent = managementOnly
    ? t("monitoringMode.servicesPausedHelp", {}, "Saved service choices are preserved and will resume when Full monitoring is restored.")
    : t("monitoringMode.servicesHelp", {}, "Fine-tune Full monitoring without changing stored credentials or assignments.");
  const liveTitle = $("adminLiveStateTitle");
  const liveHelp = $("adminLiveStateHelp");
  if (liveTitle) liveTitle.textContent = managementOnly ? t("monitoringMode.pausedDataTitle", {}, "Monitoring paused, configuration preserved") : t("admin.liveStateOnly", {}, "Live status only");
  if (liveHelp) liveHelp.textContent = managementOnly
    ? t("monitoringMode.pausedDataHelp", {}, "Last-known switch, stack and UPS state is retained. On-demand operations continue normally and no automatic incidents are created.")
    : t("admin.liveStateOnlyHelp", {}, "Each health check updates the current switch state. Individual probes are not stored.");
}
function applyAdminCore(overview, settingsData) {
  state.adminOverview = overview;
  state.adminSettings = settingsData;
  $("adminMetricDevices").textContent = overview.counts.devices;
  $("adminMetricSessions").textContent = overview.active_ssh_sessions;
  $("adminMetricDatabase").textContent = formatBytes(overview.database.size_bytes);
  $("adminMetricUsers").textContent = overview.counts.ssh_users || state.adminUsers.length || 0;
  $("adminDatabasePath").textContent = overview.database.path || "data/portivo.db";
  $("adminDefaultLanguage").value = settingsData.default_language;
  setPlatformTimezone(settingsData.platform_timezone || state.platformTimezone || "UTC");
  const timezoneSelect = $("adminPlatformTimezone");
  if (timezoneSelect) {
    const zones = settingsData.available_timezones || [state.platformTimezone || "UTC"];
    timezoneSelect.innerHTML = zones.map(zone => `<option value="${escapeHtml(zone)}">${escapeHtml(zone)}</option>`).join("");
    timezoneSelect.value = state.platformTimezone || "UTC";
  }
  $("adminPollInterval").value = settingsData.health_poll_interval_seconds;
  $("adminSshInventory").checked = Boolean(settingsData.ssh_users_manage_inventory);
  const monitoringMode = settingsData.monitoring_mode === "management_only" ? "management_only" : "full";
  const monitoringModeRadio = document.querySelector(`input[name="adminMonitoringMode"][value="${monitoringMode}"]`);
  if (monitoringModeRadio) monitoringModeRadio.checked = true;
  if ($("adminMonitorSwitchAvailability")) $("adminMonitorSwitchAvailability").checked = settingsData.monitoring_switch_availability !== false;
  if ($("adminMonitorStackHealth")) $("adminMonitorStackHealth").checked = settingsData.monitoring_stack_health !== false;
  if ($("adminMonitorPowerUps")) $("adminMonitorPowerUps").checked = settingsData.monitoring_power_ups !== false;
  if ($("adminMonitorIncidentDetection")) $("adminMonitorIncidentDetection").checked = settingsData.monitoring_incident_detection !== false;
  syncAdminMonitoringModeUi();
  populateAuthenticationSources(settingsData.authentication_source_device_ids || []);
  renderAuthenticationPathPreview();
  const health = overview.health_monitor || {};
  const auth = overview.authentication || {};
  const monitoringPaused = settingsData.monitoring_mode === "management_only";
  $("adminReliabilityStatus").innerHTML = `
    <article><span class="admin-security-icon"><svg><use href="#i-key"></use></svg></span><div><strong>${escapeHtml(t("admin.authMode", {}, "Authentication mode"))}: ${escapeHtml(auth.mode === "configured" ? t("admin.authModeConfigured", {}, "Configured sources") : t("admin.authModeAutomatic", {}, "Automatic sources"))}</strong><small>${escapeHtml(t("admin.authFastPolicy", { connect: auth.connect_timeout_seconds || 2.5, global: auth.global_timeout_seconds || 5 }, `Per-source timeout ${auth.connect_timeout_seconds || 2.5}s. Global login window ${auth.global_timeout_seconds || 5}s.`))}</small></div></article>
    <article><span class="admin-security-icon"><svg><use href="#i-activity"></use></svg></span><div><strong>${escapeHtml(monitoringPaused ? t("monitoringMode.managementOnly", {}, "Management only") : t("admin.healthEngine", {}, "Independent health engine"))}${monitoringPaused ? "" : `: ${Number(health.workers || 0)} ${escapeHtml(t("admin.healthWorkers", {}, "workers"))}`}</strong><small>${escapeHtml(monitoringPaused ? t("monitoringMode.authPanelPausedHelp", {}, "Background switch, stack and UPS monitoring is paused by Platform settings.") : t("admin.healthEngineHelp", { ping: health.ping_timeout_seconds || 1.5, snmp: health.snmp_poll_interval_seconds || 120, seconds: health.last_cycle_seconds || 0, checked: health.last_checked || 0 }, `ICMP-first health · SNMP telemetry every ${health.snmp_poll_interval_seconds || 120}s · Last cycle ${health.last_cycle_seconds || 0}s, ${health.last_checked || 0} switches checked.`))}</small></div></article>`;
}

async function loadAdminPanel() {
  if (!isPlatformAdmin()) return;
  // Re-entering Admin paints the last data from this authenticated session
  // immediately, while a fresh request updates it in the background.
  if (state.adminOverview && state.adminSettings) {
    applyAdminCore(state.adminOverview, state.adminSettings);
    renderAdminSessions();
    renderAdminUsers();
    renderAccessRoleStrip();
    renderMonitoringProfiles();
  }
  const generation = ++state.adminLoadGeneration;
  const overviewRequest = api("/api/admin/overview");
  const settingsRequest = api("/api/admin/settings");
  const deferredRequests = [
    api("/api/admin/sessions"),
    api("/api/admin/ssh-users"),
    api("/api/admin/access-control"),
    api("/api/admin/monitoring-profiles"),
    api("/api/admin/monitoring-verification-targets"),
  ];
  try {
    const [overview, settingsData] = await Promise.all([overviewRequest, settingsRequest]);
    if (generation !== state.adminLoadGeneration) return;
    applyAdminCore(overview, settingsData);

    // Heavy Admin tables and target inventories arrive independently after the
    // core settings have already painted. A slow secondary endpoint therefore
    // cannot hold the whole Admin panel hostage.
    const results = await Promise.allSettled(deferredRequests);
    if (generation !== state.adminLoadGeneration) return;
    const [sessionsResult, usersResult, accessResult, profilesResult, targetsResult] = results;
    if (sessionsResult.status === "fulfilled") {
      state.adminSessions = sessionsResult.value || [];
      renderAdminSessions();
    }
    if (usersResult.status === "fulfilled") {
      state.adminUsers = usersResult.value || [];
      $("adminMetricUsers").textContent = overview.counts.ssh_users || state.adminUsers.length;
      renderAdminUsers();
    }
    if (accessResult.status === "fulfilled") {
      state.adminAccessControl = accessResult.value || { roles: [], capabilities: [], actions: [], sites: [], groups: [] };
      renderAccessRoleStrip();
    }
    if (profilesResult.status === "fulfilled") {
      state.monitoringProfiles = profilesResult.value || [];
      renderMonitoringProfiles();
    }
    if (targetsResult.status === "fulfilled") {
      state.monitoringVerificationTargets = targetsResult.value || [];
      populateAuthenticationSources(settingsData.authentication_source_device_ids || []);
      renderAuthenticationPathPreview();
    }
    const failed = results.find(item => item.status === "rejected");
    if (failed) console.warn("Some Admin data could not be refreshed", failed.reason);
  } catch (error) { toast(error.message, "error"); }
}
function renderMonitoringProfiles() {
  const table = $("monitoringProfilesTable");
  const summary = $("monitoringProfileSummary");
  if (!table || !summary) return;
  const profiles = state.monitoringProfiles || [];
  const sshCount = profiles.filter(item => item.method === "ssh").length;
  const snmpCount = profiles.filter(item => item.method === "snmpv3").length;
  summary.innerHTML = `<span>${escapeHtml(t("monitoring.summarySsh", { count: sshCount }, `${sshCount} SSH read-only`))}</span><span>${escapeHtml(t("monitoring.summarySnmp", { count: snmpCount }, `${snmpCount} SNMPv3`))}</span>`;
  table.innerHTML = profiles.map(profile => `<tr><td><strong>${escapeHtml(profile.name)}</strong><div class="muted-line">#${Number(profile.id)}</div></td><td><span class="monitoring-method-badge ${escapeHtml(profile.method)}">${escapeHtml(profile.method === "snmpv3" ? "SNMPv3" : "SSH")}</span></td><td><strong>${escapeHtml(profile.username)}</strong><div class="muted-line">${profile.method === "snmpv3" ? `UDP ${Number(profile.snmp_port || 161)} · ${escapeHtml(profile.snmp_auth_protocol || "SHA")} / ${escapeHtml(profile.snmp_priv_protocol || "AES")}` : escapeHtml(t("monitoring.readOnlyExpected", {}, "Read-only account expected"))}</div></td><td>${profile.last_status === "verified" ? `<span class="status online">${escapeHtml(t("monitoring.verified", {}, "Verified"))}</span><div class="muted-line">${escapeHtml(profile.verified_device_name || "")}</div>` : `<span class="status unknown">${escapeHtml(t("monitoring.unverified", {}, "Unverified"))}</span>`}</td><td><div class="row-actions"><button class="icon-action" type="button" onclick="editMonitoringProfile(${Number(profile.id)})">${escapeHtml(t("common.edit", {}, "Edit"))}</button><button class="icon-action danger" type="button" onclick="deleteMonitoringProfile(${Number(profile.id)})">${escapeHtml(t("common.delete", {}, "Delete"))}</button></div></td></tr>`).join("") || `<tr><td colspan="5"><div class="empty-state">${escapeHtml(t("monitoring.empty", {}, "No monitoring credential profiles configured yet."))}</div></td></tr>`;
}
function syncMonitoringProfileMethodUi() {
  const method = $("monitoringProfileMethod")?.value || "ssh";
  $("monitoringSshFields")?.classList.toggle("hidden", method !== "ssh");
  $("monitoringSnmpFields")?.classList.toggle("hidden", method !== "snmpv3");
}
function monitoringVerifyTargetValue(type, id) {
  return type && id ? `${type}:${Number(id)}` : "";
}
function populateMonitoringVerifyTargets(selectedType = null, selectedId = null) {
  const select = $("monitoringVerifyDevice"); if (!select) return;
  const method = $("monitoringProfileMethod")?.value || "ssh";
  const targets = (state.monitoringVerificationTargets || []).filter(item => method === "snmpv3" || item.type === "switch");
  const switches = targets.filter(item => item.type === "switch");
  const upsTargets = targets.filter(item => item.type === "ups");
  const optionHtml = item => `<option value="${escapeHtml(monitoringVerifyTargetValue(item.type, item.id))}">${escapeHtml(item.name)} · ${escapeHtml(item.host)}</option>`;
  let html = `<option value="">${escapeHtml(t("monitoring.saveWithoutVerification", {}, "Save without verification"))}</option>`;
  if (switches.length) html += `<optgroup label="${escapeHtml(t("monitoring.verifySwitches", {}, "Switches"))}">${switches.map(optionHtml).join("")}</optgroup>`;
  if (method === "snmpv3" && upsTargets.length) html += `<optgroup label="${escapeHtml(t("monitoring.verifyUps", {}, "UPS"))}">${upsTargets.map(optionHtml).join("")}</optgroup>`;
  select.innerHTML = html;
  const selected = monitoringVerifyTargetValue(selectedType, selectedId);
  if (selected && Array.from(select.options).some(option => option.value === selected)) select.value = selected;
}
function openMonitoringProfileDialog(profile = null) {
  if (!isPlatformAdmin()) return;
  $("monitoringProfileForm").reset(); $("monitoringProfileError").textContent = "";
  if ($("monitoringSaveFeedback")) $("monitoringSaveFeedback").textContent = "";
  state.monitoringSecretDirty = { ssh: false, auth: false, priv: false };
  $("monitoringProfileId").value = profile?.id || "";
  $("monitoringProfileDialogTitle").textContent = profile ? t("monitoring.editTitle", {}, "Edit monitoring profile") : t("monitoring.createTitle", {}, "Create monitoring profile");
  $("monitoringProfileName").value = profile?.name || "";
  $("monitoringProfileMethod").value = profile?.method || "ssh";
  $("monitoringSshUsername").value = profile?.method === "ssh" ? (profile.username || "") : "";
  $("monitoringSshPassword").value = "";
  $("monitoringSnmpUsername").value = profile?.method === "snmpv3" ? (profile.username || "") : "";
  $("monitoringSnmpPort").value = profile?.snmp_port || 161;
  $("monitoringSnmpAuthProtocol").value = profile?.snmp_auth_protocol || "SHA256";
  $("monitoringSnmpAuthPassword").value = "";
  $("monitoringSnmpPrivProtocol").value = profile?.snmp_priv_protocol || "AES";
  $("monitoringSnmpPrivPassword").value = "";
  populateMonitoringVerifyTargets(profile?.verified_target_type || (profile?.verified_device_id ? "switch" : null), profile?.verified_target_id || profile?.verified_device_id || null);
  syncMonitoringProfileMethodUi(); $("monitoringProfileDialog").showModal();
  // Password managers can try to refill these fields after the dialog opens.
  // Clear them once more and keep stored secrets unless the operator actually edits them.
  window.setTimeout(() => {
    for (const id of ["monitoringSshPassword", "monitoringSnmpAuthPassword", "monitoringSnmpPrivPassword"]) { const field = $(id); if (field) field.value = ""; }
    state.monitoringSecretDirty = { ssh: false, auth: false, priv: false };
  }, 80);
}
window.editMonitoringProfile = function(id) { const profile = (state.monitoringProfiles || []).find(item => Number(item.id) === Number(id)); if (profile) openMonitoringProfileDialog(profile); };
async function saveMonitoringProfile(event) {
  event.preventDefault();
  const id = Number($("monitoringProfileId").value || 0);
  const method = $("monitoringProfileMethod").value;
  const verifySelect = $("monitoringVerifyDevice");
  const verifyValue = String(verifySelect?.value || "");
  const [verifyTargetTypeRaw, verifyTargetIdRaw] = verifyValue ? verifyValue.split(":", 2) : ["", ""];
  const verifyTargetType = verifyTargetTypeRaw || null;
  const verifyTargetId = verifyTargetIdRaw ? Number(verifyTargetIdRaw) : null;
  const submit = $("monitoringProfileSubmit") || event.submitter;
  const cancel = $("monitoringProfileCancel");
  const label = $("monitoringProfileSubmitLabel");
  const feedback = $("monitoringSaveFeedback");
  const isEdit = Boolean(id);
  const body = {
    name: $("monitoringProfileName").value.trim(), method,
    username: method === "ssh" ? $("monitoringSshUsername").value.trim() : $("monitoringSnmpUsername").value.trim(),
    password: method === "ssh" && (!isEdit || state.monitoringSecretDirty.ssh) ? $("monitoringSshPassword").value : "",
    snmp_port: Number($("monitoringSnmpPort").value || 161),
    snmp_auth_protocol: $("monitoringSnmpAuthProtocol").value,
    snmp_auth_password: method === "snmpv3" && (!isEdit || state.monitoringSecretDirty.auth) ? $("monitoringSnmpAuthPassword").value : "",
    snmp_priv_protocol: $("monitoringSnmpPrivProtocol").value,
    snmp_priv_password: method === "snmpv3" && (!isEdit || state.monitoringSecretDirty.priv) ? $("monitoringSnmpPrivPassword").value : "",
    verify_target_type: verifyTargetType,
    verify_target_id: verifyTargetId,
  };
  $("monitoringProfileError").textContent = "";
  const deviceName = verifySelect?.selectedOptions?.[0]?.textContent?.trim() || "";
  const workingText = verifyTargetId
    ? t("monitoring.verifying", { device: deviceName }, `Verifying ${method === "snmpv3" ? "SNMPv3" : "SSH"} against ${deviceName}…`)
    : t("monitoring.saving", {}, "Saving monitoring profile…");
  if (feedback) feedback.textContent = workingText;
  if (label) label.textContent = verifyTargetId ? t("monitoring.verifyingButton", {}, "Verifying…") : t("monitoring.savingButton", {}, "Saving…");
  if (submit) { submit.disabled = true; submit.classList.add("is-loading"); submit.setAttribute("aria-busy", "true"); }
  if (cancel) cancel.disabled = true;
  try {
    await api(id ? `/api/admin/monitoring-profiles/${id}` : "/api/admin/monitoring-profiles", { method: id ? "PUT" : "POST", body });
    if (feedback) { feedback.textContent = t("monitoring.savedInline", {}, "Profile saved successfully"); feedback.classList.add("success"); }
    state.monitoringProfiles = await api("/api/admin/monitoring-profiles");
    renderMonitoringProfiles(); populateDeviceStackProfiles();
    $("monitoringProfileDialog").close();
    toast(t("monitoring.saved", {}, "Monitoring profile saved"), "success");
  } catch (error) {
    $("monitoringProfileError").textContent = error.message;
    if (feedback) { feedback.textContent = t("monitoring.failedInline", {}, "Verification or save failed"); feedback.classList.remove("success"); }
    $("monitoringProfileError")?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  } finally {
    if (submit) { submit.disabled = false; submit.classList.remove("is-loading"); submit.removeAttribute("aria-busy"); }
    if (cancel) cancel.disabled = false;
    if (label) label.textContent = t("monitoring.save", {}, "Save profile");
  }
}
window.deleteMonitoringProfile = async function(id) { if (!confirm(t("monitoring.deleteConfirm", {}, "Delete this monitoring profile?"))) return; try { await api(`/api/admin/monitoring-profiles/${id}`, { method: "DELETE" }); state.monitoringProfiles = await api("/api/admin/monitoring-profiles"); renderMonitoringProfiles(); toast(t("monitoring.deleted", {}, "Monitoring profile deleted"), "success"); } catch (error) { toast(error.message, "error"); } };

function renderAdminSessions() {
  $("adminSessionsTable").innerHTML = state.adminSessions.map(session => `<tr><td><strong>${escapeHtml(session.username)}</strong><div class="muted-line"><code>${escapeHtml(session.session_id)}</code></div></td><td>${formatDate(new Date(session.created_at * 1000).toISOString())}</td><td>${formatDate(new Date(session.last_used_at * 1000).toISOString())}</td><td>${escapeHtml(formatDuration(session.idle_seconds))}</td><td><button class="icon-action danger" onclick="revokeSshSession('${escapeHtml(session.session_id)}')">${escapeHtml(t("common.revoke", {}, "Revoke"))}</button></td></tr>`).join("") || `<tr><td colspan="5"><div class="empty-state">${escapeHtml(t("admin.noSessions", {}, "No active SSH sessions."))}</div></td></tr>`;
}
function renderAdminUsers() {
  const rows = state.adminUsers || [];
  $("adminUsersTable").innerHTML = rows.map(user => {
    const scope = user.scope || {};
    const scopeClass = scope.mode === "none" ? "none" : "";
    return `<tr>
      <td><div class="admin-user-identity"><span class="admin-user-avatar"><svg><use href="#i-user"></use></svg></span><div><strong>${escapeHtml(user.username)}</strong><span>${escapeHtml(user.enabled ? t("access.rememberedIdentity", {}, "Remembered SSH identity") : t("access.accessDisabled", {}, "Access disabled"))}</span></div></div></td>
      <td><strong>${formatDate(user.last_login)}</strong><div class="muted-line">${escapeHtml(t("admin.loginCount", { count: user.login_count }, `${user.login_count} logins`))}</div></td>
      <td><div class="platform-cell"><strong>${escapeHtml(user.last_auth_device_name || t("common.unknown", {}, "Unknown"))}</strong><span>${escapeHtml(user.last_auth_device_host || "")}</span></div></td>
      <td><div class="access-user-role"><strong>${escapeHtml(user.role_id ? accessRoleName(accessRoleById(user.role_id)) : (user.role_name || user.role))}</strong><span>${escapeHtml(user.scope?.global ? t("access.globalRole", {}, "Global role") : t("access.scopedRole", {}, "Scoped role"))}</span></div></td>
      <td><span class="access-scope-badge ${scopeClass}">${escapeHtml(accessScopeText(scope))}</span></td>
      <td>${`<span class="status ${user.enabled ? "online" : "offline"}">${escapeHtml(user.enabled ? t("access.enabled", {}, "Enabled") : t("access.disabled", {}, "Disabled"))}</span>`}</td>
      <td><button class="btn secondary compact" type="button" onclick="openUserAccessDialog(${Number(user.id)})"><svg><use href="#i-admin"></use></svg><span>${escapeHtml(t("access.configure", {}, "Configure"))}</span></button></td>
    </tr>`;
  }).join("") || `<tr><td colspan="7"><div class="empty-state">${escapeHtml(t("admin.noKnownUsers", {}, "No SSH users have signed in yet."))}</div></td></tr>`;
}
function selectedValues(select) { return [...(select?.selectedOptions || [])].map(option => option.value).filter(Boolean); }
function userAccessScopeMode() { return document.querySelector('input[name="userAccessScopeMode"]:checked')?.value || "selected"; }
function userAccessSelectedCountText(count) {
  return t("access.selectedCount", { count }, `${count} selected`);
}
function renderUserAccessScopePicker(selectId, pickerId, countId) {
  const select = $(selectId);
  const picker = $(pickerId);
  const count = $(countId);
  if (!select || !picker) return;
  const options = [...select.options];
  const selectedCount = options.filter(option => option.selected).length;
  if (count) count.textContent = userAccessSelectedCountText(selectedCount);
  if (!options.length) {
    picker.innerHTML = `<div class="access-scope-picker-empty"><svg><use href="#i-info"></use></svg><span>${escapeHtml(t("access.noScopeOptions", {}, "No options available for the current selection."))}</span></div>`;
    return;
  }
  picker.innerHTML = options.map((option, index) => {
    const selected = Boolean(option.selected);
    return `<button class="access-scope-option${selected ? " selected" : ""}" type="button" role="option" aria-selected="${selected ? "true" : "false"}" data-option-index="${index}" ${select.disabled ? "disabled" : ""}><span class="access-scope-option-label">${escapeHtml(option.textContent || option.value)}</span><span class="access-scope-option-state" aria-hidden="true"><svg><use href="#i-check"></use></svg></span></button>`;
  }).join("");
}
function renderUserAccessScopePickers() {
  renderUserAccessScopePicker("userAccessSites", "userAccessSitesPicker", "userAccessSitesCount");
  renderUserAccessScopePicker("userAccessGroups", "userAccessGroupsPicker", "userAccessGroupsCount");
}
function handleUserAccessScopePickerClick(event, selectId) {
  const button = event.target.closest(".access-scope-option[data-option-index]");
  if (!button || button.disabled) return;
  const select = $(selectId);
  const index = Number(button.dataset.optionIndex);
  const option = select?.options?.[index];
  if (!select || !option || select.disabled) return;
  option.selected = !option.selected;
  select.dispatchEvent(new Event("change", { bubbles: true }));
}
function populateUserAccessGroups(selected = null) {
  const select = $("userAccessGroups");
  const siteValues = new Set(selectedValues($("userAccessSites")));
  const groups = (state.adminAccessControl?.groups || []).filter(item => siteValues.has(item.site));
  const selectedValuesBefore = selected === null
    ? new Set(selectedValues(select))
    : new Set(selected.map(item => `${item.site}\u0000${item.group}`));
  select.innerHTML = groups.map(item => {
    const value = `${item.site}\u0000${item.group}`;
    return `<option value="${escapeHtml(value)}" ${selectedValuesBefore.has(value) ? "selected" : ""}>${escapeHtml(item.site)} · ${escapeHtml(item.group)}</option>`;
  }).join("");
  renderUserAccessScopePicker("userAccessGroups", "userAccessGroupsPicker", "userAccessGroupsCount");
}
function renderUserAccessPolicy(role) {
  const caps = new Set(role?.capabilities || []);
  const actions = new Set(role?.allowed_actions || []);
  const allCaps = caps.has("*");
  const allActions = actions.has("*");
  const operationText = allActions ? t("access.allCatalogActions", {}, "All catalog actions") : t("access.explicitChangeCount", { count: actions.size }, `${actions.size} explicit change actions`);
  const capabilityText = allCaps ? t("access.allPlatformCapabilities", {}, "All platform capabilities") : t("access.capabilityCount", { count: caps.size }, `${caps.size} capabilities`);
  $("userAccessPolicyPreview").innerHTML = `<article><span class="access-policy-icon"><svg><use href="#i-admin"></use></svg></span><div><strong>${escapeHtml(t("access.policyApplication", {}, "Application access"))}</strong><span>${escapeHtml(capabilityText)}</span></div></article><article><span class="access-policy-icon"><svg><use href="#i-settings"></use></svg></span><div><strong>${escapeHtml(t("access.policyOperations", {}, "Operations"))}</strong><span>${escapeHtml(operationText)}</span></div></article><article><span class="access-policy-icon"><svg><use href="#i-terminal"></use></svg></span><div><strong>${escapeHtml(t("access.advancedCli", {}, "Advanced CLI"))}</strong><span>${escapeHtml(allCaps || caps.has("terminal.use") || caps.has("custom_cli.use") ? t("access.allowedByRole", {}, "Allowed by role policy") : t("access.hiddenBlocked", {}, "Hidden and blocked"))}</span></div></article>`;
}
function syncUserAccessScopeUi() {
  const role = accessRoleById(Number($("userAccessRole").value || 0));
  if (!role) return;
  $("userAccessRoleHelp").textContent = accessRoleDescription(role);
  const editor = $("userAccessScopeEditor");
  const globalRole = Boolean(role.global_role);
  editor.classList.toggle("scope-locked", globalRole);
  editor.querySelectorAll("input,select").forEach(control => { control.disabled = globalRole; });
  if (globalRole) {
    const all = editor.querySelector('input[value="all"]'); if (all) all.checked = true;
    $("userAccessScopeStatus").textContent = t("access.globalAllSites", {}, "Global · All Sites");
  } else {
    const mode = userAccessScopeMode();
    $("userAccessScopeStatus").textContent = mode === "all" ? t("access.explicitAllSites", {}, "Explicit All Sites") : t("access.scopedStatus", {}, "Scoped access");
    $("userAccessScopeSelectors").classList.toggle("hidden", mode !== "selected");
  }
  renderUserAccessPolicy(role);
  renderUserAccessScopePickers();
}
window.openUserAccessDialog = function(userId) {
  const user = (state.adminUsers || []).find(item => Number(item.id) === Number(userId));
  if (!user) return;
  $("userAccessId").value = String(user.id);
  $("userAccessDialogTitle").textContent = `${t("access.access", {}, "Access")} · ${user.username}`;
  const authSource = user.last_auth_device_name || user.last_auth_device_host || t("access.unknownSource", {}, "unknown source");
  $("userAccessIdentity").innerHTML = `<span class="admin-user-avatar"><svg><use href="#i-user"></use></svg></span><div class="access-user-identity-copy"><strong>${escapeHtml(user.username)}</strong><span>${escapeHtml(t("access.lastAuthenticatedVia", { source: authSource }, `Last authenticated via ${authSource}`))}</span></div>`;
  $("userAccessRole").innerHTML = (state.adminAccessControl?.roles || []).map(role => `<option value="${Number(role.id)}">${escapeHtml(accessRoleName(role))}${role.built_in ? "" : ` · ${escapeHtml(t("access.customRole", {}, "Custom"))}`}</option>`).join("");
  $("userAccessRole").value = String(user.role_id || "");
  $("userAccessEnabled").checked = Boolean(user.enabled);
  $("userAccessSites").innerHTML = (state.adminAccessControl?.sites || []).map(site => `<option value="${escapeHtml(site)}" ${(user.scope?.sites || []).includes(site) ? "selected" : ""}>${escapeHtml(site)}</option>`).join("");
  const mode = user.scope?.mode === "all" ? "all" : "selected";
  const radio = document.querySelector(`input[name="userAccessScopeMode"][value="${mode}"]`); if (radio) radio.checked = true;
  populateUserAccessGroups(user.scope?.groups || []);
  syncUserAccessScopeUi();
  $("userAccessDialog").showModal();
};
async function saveUserAccess(event) {
  event.preventDefault();
  const userId = Number($("userAccessId").value || 0);
  const role = accessRoleById(Number($("userAccessRole").value || 0));
  if (!userId || !role) return;
  let scopeMode = role.global_role ? "all" : userAccessScopeMode();
  const sites = scopeMode === "selected" ? selectedValues($("userAccessSites")) : [];
  const groups = scopeMode === "selected" ? selectedValues($("userAccessGroups")).map(value => { const [site, group] = value.split("\u0000"); return { site, group }; }) : [];
  if (!role.global_role && scopeMode === "selected" && !sites.length) { toast(t("access.selectSiteError", {}, "Select at least one Site or choose All Sites."), "error"); return; }
  try {
    await api(`/api/admin/ssh-users/${userId}/access`, { method: "PUT", body: { role_id: Number(role.id), enabled: $("userAccessEnabled").checked, scope_mode: scopeMode, sites, groups } });
    $("userAccessDialog").close();
    toast(t("access.updated", {}, "User access updated"), "success");
    await loadAdminPanel();
  } catch (error) { toast(error.message, "error"); }
}
function currentRoleEditorRole() { return state.adminRoleEditorDraft ? null : accessRoleById(state.adminSelectedRoleId); }
function selectAccessRoleEditor(roleId) {
  state.adminRoleEditorDraft = false;
  state.adminSelectedRoleId = Number(roleId);
  renderAccessRoleEditor();
}
function renderAccessRoleList() {
  const roles = state.adminAccessControl?.roles || [];
  $("accessRoleList").innerHTML = roles.map(role => `<button class="access-role-list-item ${!state.adminRoleEditorDraft && Number(role.id) === Number(state.adminSelectedRoleId) ? "active" : ""}" type="button" onclick="selectAccessRoleEditor(${Number(role.id)})"><strong>${escapeHtml(accessRoleName(role))}</strong><span>${escapeHtml(accessRoleDescription(role))}</span><em>${escapeHtml(role.built_in ? t("access.builtIn", {}, "Built-in") : t("access.customRole", {}, "Custom"))} · ${escapeHtml(role.global_role ? t("access.global", {}, "Global") : t("access.scoped", {}, "Scoped"))}</em></button>`).join("");
}
function permissionChecked(role, capability) { return Boolean(role && ((role.capabilities || []).includes("*") || (role.capabilities || []).includes(capability))); }
function actionChecked(role, action) { return Boolean(role && ((role.allowed_actions || []).includes("*") || (role.allowed_actions || []).includes(action))); }
function renderAccessRoleEditor() {
  const role = currentRoleEditorRole();
  const isDraft = state.adminRoleEditorDraft;
  const editable = isDraft || (role && !role.built_in);
  $("accessRoleEditorKicker").textContent = isDraft ? t("access.newCustomRoleKicker", {}, "NEW CUSTOM ROLE") : (role?.built_in ? t("access.builtInRoleKicker", {}, "BUILT-IN ROLE") : t("access.customRoleKicker", {}, "CUSTOM ROLE"));
  $("accessRoleEditorTitle").textContent = isDraft ? t("access.newCustomRole", {}, "New Custom Role") : accessRoleName(role);
  $("accessRoleEditorDescription").textContent = isDraft ? t("access.roleLibraryHelp", {}, "Choose exactly which application capabilities and command actions this scoped role may use.") : accessRoleDescription(role);
  $("accessRoleEditorType").textContent = isDraft ? t("access.scopedCustom", {}, "Scoped custom") : (role?.built_in ? (role.global_role ? t("access.builtInGlobal", {}, "Built-in · Global") : t("access.builtInScoped", {}, "Built-in · Scoped")) : t("access.customScoped", {}, "Custom · Scoped"));
  $("accessRoleIdentityFields").classList.toggle("hidden", !editable);
  if (editable) { $("accessRoleName").value = isDraft ? "" : role.name; $("accessRoleDescription").value = isDraft ? "" : (role.description || ""); }
  const caps = state.adminAccessControl?.capabilities || [];
  const grouped = new Map();
  for (const item of caps) { if (!grouped.has(item.category)) grouped.set(item.category, []); grouped.get(item.category).push(item); }
  const categoryHelp = {
    "Core access": "Primary Portivo workspaces visible to the role.",
    "Operations": "Live diagnostics, controlled execution and Fleet Audit access.",
    "Observability": "Notification and execution history visible inside the assigned scope.",
    "Tools": "Secondary reference tools surfaced through More.",
    "Administration": "Governed inventory and power-infrastructure changes.",
    "Advanced access": "High-trust interactive CLI interfaces.",
  };
  $("accessCapabilityGrid").innerHTML = [...grouped.entries()].map(([category, items]) => `<section class="access-capability-group"><div class="access-capability-group-head"><div><strong>${escapeHtml(category)}</strong><small>${escapeHtml(categoryHelp[category] || "Role capabilities")}</small></div><span>${items.length}</span></div><div class="access-capability-group-grid">${items.map(item => `<label class="access-permission-card ${editable ? "" : "locked"}"><input type="checkbox" data-access-capability="${escapeHtml(item.id)}" ${permissionChecked(role,item.id) ? "checked" : ""} ${editable ? "" : "disabled"}/><span><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(item.description)}</small></span></label>`).join("")}</div></section>`).join("");
  $("accessCapabilityGrid").querySelectorAll("[data-access-capability]").forEach(input => input.addEventListener("change", () => renderAccessActionGrid(role, editable)));
  renderAccessActionGrid(role, editable);
  $("saveCustomRoleButton").classList.toggle("hidden", !editable);
  $("deleteCustomRoleButton").classList.toggle("hidden", !(role && !role.built_in && !isDraft));
  renderAccessRoleList();
}
function renderAccessActionGrid(role = currentRoleEditorRole(), editable = state.adminRoleEditorDraft || Boolean(role && !role.built_in)) {
  const query = String($("accessActionSearch")?.value || "").trim().toLowerCase();
  const actions = (state.adminAccessControl?.actions || []).filter(item => !query || `${item.label} ${item.category} ${item.description} ${item.id}`.toLowerCase().includes(query));
  const allRead = editable ? Boolean(document.querySelector('[data-access-capability="operations.read"]')?.checked) : permissionChecked(role, "operations.read");
  $("accessActionGrid").innerHTML = actions.map(item => {
    const inherited = allRead && item.risk === "read";
    const checked = inherited || actionChecked(role,item.id);
    const disabled = !editable || inherited;
    return `<label class="access-action-card ${disabled ? "locked" : ""}"><input type="checkbox" data-access-action="${escapeHtml(item.id)}" ${checked ? "checked" : ""} ${disabled ? "disabled" : ""}/><span><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(inherited ? t("access.includedByRead", {}, "Included by Read-only CLI actions") : `${item.category} · ${item.description || item.id}`)}</small></span><em class="risk-pill ${escapeHtml(item.risk)}">${escapeHtml(item.risk)}</em></label>`;
  }).join("") || `<div class="empty-state">${escapeHtml(t("access.noActions", {}, "No actions match this search."))}</div>`;
}
window.selectAccessRoleEditor = selectAccessRoleEditor;
function openAccessRoleLibrary() {
  const roles = state.adminAccessControl?.roles || [];
  if (!state.adminSelectedRoleId && roles.length) state.adminSelectedRoleId = Number(roles[0].id);
  state.adminRoleEditorDraft = false;
  renderAccessRoleEditor();
  $("accessRoleDialog").showModal();
}
function startNewCustomRole() { state.adminRoleEditorDraft = true; state.adminSelectedRoleId = null; renderAccessRoleEditor(); setTimeout(() => $("accessRoleName")?.focus(), 20); }
async function saveCustomAccessRole() {
  const name = $("accessRoleName").value.trim();
  if (!name) { toast(t("access.roleNameRequired", {}, "Role name is required"), "error"); return; }
  const capabilities = [...document.querySelectorAll("[data-access-capability]:checked")].map(input => input.dataset.accessCapability);
  const allowed_actions = [...document.querySelectorAll("[data-access-action]:checked:not(:disabled)")].map(input => input.dataset.accessAction);
  const body = { name, description: $("accessRoleDescription").value.trim(), capabilities, allowed_actions };
  const existing = currentRoleEditorRole();
  try {
    const saved = await api(existing ? `/api/admin/access-roles/${existing.id}` : "/api/admin/access-roles", { method: existing ? "PUT" : "POST", body });
    state.adminAccessControl = await api("/api/admin/access-control");
    state.adminSelectedRoleId = Number(saved.id); state.adminRoleEditorDraft = false;
    renderAccessRoleStrip(); renderAccessRoleEditor(); renderAdminUsers();
    toast(existing ? t("access.roleUpdated", {}, "Custom Role updated") : t("access.roleCreated", {}, "Custom Role created"), "success");
  } catch (error) { toast(error.message, "error"); }
}
async function deleteCustomAccessRole() {
  const role = currentRoleEditorRole();
  if (!role || role.built_in) return;
  if (!confirm(`Delete Custom Role “${role.name}”?`)) return;
  try {
    await api(`/api/admin/access-roles/${role.id}`, { method: "DELETE" });
    state.adminAccessControl = await api("/api/admin/access-control");
    state.adminSelectedRoleId = Number(state.adminAccessControl.roles?.[0]?.id || 0); state.adminRoleEditorDraft = false;
    renderAccessRoleStrip(); renderAccessRoleEditor();
    toast(t("access.roleDeleted", {}, "Custom Role deleted"), "success");
  } catch (error) { toast(error.message, "error"); }
}

window.revokeSshSession = async function(sessionId) {
  try {
    await api(`/api/admin/sessions/${encodeURIComponent(sessionId)}`, { method: "DELETE" });
    toast(t("common.revoke", {}, "Session revoked"), "success");
    await loadAdminPanel();
  } catch (error) { toast(error.message, "error"); }
};
async function saveAdminSettings(event) {
  event.preventDefault();
  const payload = {
    default_language: $("adminDefaultLanguage").value,
    ssh_users_manage_inventory: $("adminSshInventory").checked,
    health_poll_interval_seconds: Number($("adminPollInterval").value || 30),
    platform_timezone: $("adminPlatformTimezone")?.value || state.platformTimezone || "UTC",
    monitoring_mode: currentAdminMonitoringMode(),
    monitoring_switch_availability: Boolean($("adminMonitorSwitchAvailability")?.checked),
    monitoring_stack_health: Boolean($("adminMonitorStackHealth")?.checked),
    monitoring_power_ups: Boolean($("adminMonitorPowerUps")?.checked),
    monitoring_incident_detection: Boolean($("adminMonitorIncidentDetection")?.checked),
    authentication_source_device_ids: selectedAuthenticationSourceIds(),
  };
  try {
    await api("/api/admin/settings", { method: "PUT", body: payload });
    setPlatformTimezone(payload.platform_timezone);
    toast(t("admin.settingsSaved", {}, "Administration settings saved"), "success");
    if (!localStorage.getItem("osc-language")) await changeLanguage(payload.default_language);
    await Promise.all([loadAdminPanel(), loadDashboard(), loadJobs()]);
    renderDevices();
    renderFinderResult(state.finderResult);
    if (state.notifications) await loadNotifications();
  } catch (error) { toast(error.message, "error"); }
}

async function saveAuthenticationSources() {
  const payload = {
    default_language: state.adminSettings?.default_language || "en",
    ssh_users_manage_inventory: Boolean(state.adminSettings?.ssh_users_manage_inventory),
    health_poll_interval_seconds: Number(state.adminSettings?.health_poll_interval_seconds || 30),
    platform_timezone: state.adminSettings?.platform_timezone || state.platformTimezone || "UTC",
    monitoring_mode: state.adminSettings?.monitoring_mode || "full",
    monitoring_switch_availability: state.adminSettings?.monitoring_switch_availability !== false,
    monitoring_stack_health: state.adminSettings?.monitoring_stack_health !== false,
    monitoring_power_ups: state.adminSettings?.monitoring_power_ups !== false,
    monitoring_incident_detection: state.adminSettings?.monitoring_incident_detection !== false,
    authentication_source_device_ids: selectedAuthenticationSourceIds(),
  };
  try {
    await api("/api/admin/settings", { method: "PUT", body: payload });
    toast(t("admin.authSourcesSaved", {}, "Authentication Sources saved"), "success");
    await loadAdminPanel();
  } catch (error) { toast(error.message, "error"); }
}

function selectedOptionValues(select) {
  if (!select) return [];
  return Array.from(select.selectedOptions || []).map(option => option.value).filter(Boolean);
}
function setSelectedOptionValues(select, values) {
  const wanted = new Set((values || []).map(String));
  Array.from(select?.options || []).forEach(option => { option.selected = wanted.has(option.value); });
}
function populateAutomationScopeOptions(selectedSites = [], selectedGroups = []) {
  const siteSelect = $("automationScheduleSites");
  const groupSelect = $("automationScheduleGroups");
  if (!siteSelect || !groupSelect) return;
  const sites = [...new Set(state.devices.map(device => String(device.site || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  siteSelect.innerHTML = sites.map(site => `<option value="${escapeHtml(site)}">${escapeHtml(site)}</option>`).join("");
  setSelectedOptionValues(siteSelect, selectedSites);
  const activeSites = new Set(selectedOptionValues(siteSelect));
  const groups = [...new Set(state.devices
    .filter(device => !activeSites.size || activeSites.has(String(device.site || "").trim()))
    .map(device => String(device.group_name || "").trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  groupSelect.innerHTML = groups.map(group => `<option value="${escapeHtml(group)}">${escapeHtml(group)}</option>`).join("");
  setSelectedOptionValues(groupSelect, selectedGroups.filter(group => groups.includes(group)));
  renderUserAccessScopePicker("automationScheduleSites", "automationScheduleSitesPicker", "automationScheduleSitesCount");
  renderUserAccessScopePicker("automationScheduleGroups", "automationScheduleGroupsPicker", "automationScheduleGroupsCount");
}
function clientRunbookCommandRisk(command) {
  const value = String(command || "").trim().toLowerCase();
  if (!value) return "read";
  if (/(^|\s)(reload|reboot|boot|erase|delete|format|factory[- ]?reset|clear\s+configuration|write\s+erase)(\s|$)/i.test(value)) return "high";
  if (/^(show(?:\s|$)|help(?:\s|$)|who(?:\s|$)|ping\s|traceroute\s|trace\s|display\s)/i.test(value)) return "read";
  return "change";
}
function refreshRunbookRiskPreview() {
  const rows = [...document.querySelectorAll("#runbookStepBuilder .runbook-step-row")];
  const rank = { read: 0, change: 1, high: 2 };
  let risk = "read";
  rows.forEach(row => {
    const type = row.querySelector("[data-step-type]")?.value || "command";
    if (type === "wait") return;
    const current = clientRunbookCommandRisk(row.querySelector("[data-step-command]")?.value || "");
    if (rank[current] > rank[risk]) risk = current;
  });
  const pill = $("runbookRiskPreview");
  if (pill) { pill.className = `runbook-risk-pill ${risk}`; pill.textContent = risk === "high" ? t("runbooks.highRisk", {}, "HIGH RISK") : risk === "change" ? t("runbooks.changeRisk", {}, "CHANGE") : t("runbooks.readRisk", {}, "READ"); }
}
function addRunbookVariableRow(spec = {}) {
  const wrap = $("runbookVariableBuilder");
  if (!wrap) return;
  const row = document.createElement("div");
  row.className = "runbook-variable-row";
  row.innerHTML = `<input data-var-name maxlength="32" placeholder="${escapeHtml(t("runbooks.variableName", {}, "Variable name"))}" value="${escapeHtml(spec.name || "")}"/><input data-var-label maxlength="80" placeholder="${escapeHtml(t("runbooks.variableLabel", {}, "Display label"))}" value="${escapeHtml(spec.label || "")}"/><input data-var-default maxlength="200" placeholder="${escapeHtml(t("runbooks.defaultValue", {}, "Default value"))}" value="${escapeHtml(spec.default || "")}"/><label class="runbook-required-check"><input data-var-required type="checkbox" ${spec.required !== false ? "checked" : ""}/><span>${escapeHtml(t("runbooks.variableRequired", {}, "Required"))}</span></label><button class="icon-action danger" type="button" data-remove-variable>${escapeHtml(t("runbooks.remove", {}, "Remove"))}</button>`;
  row.querySelector("[data-remove-variable]")?.addEventListener("click", () => row.remove());
  wrap.appendChild(row);
}
function addRunbookStepRow(step = { type: "command", command: "" }) {
  const wrap = $("runbookStepBuilder");
  if (!wrap) return;
  const row = document.createElement("div");
  row.className = "runbook-step-row";
  const type = step.type || "command";
  row.innerHTML = `<span class="runbook-step-handle">${wrap.children.length + 1}</span><select data-step-type><option value="command" ${type === "command" ? "selected" : ""}>${escapeHtml(t("runbooks.command", {}, "COMMAND"))}</option><option value="wait" ${type === "wait" ? "selected" : ""}>${escapeHtml(t("runbooks.wait", {}, "WAIT"))}</option><option value="verify" ${type === "verify" ? "selected" : ""}>${escapeHtml(t("runbooks.verify", {}, "VERIFY"))}</option></select><input data-step-command class="${type === "wait" ? "hidden" : ""}" maxlength="400" spellcheck="false" placeholder="${escapeHtml(t("runbooks.commandPlaceholder", {}, "Enter one CLI command"))}" value="${escapeHtml(step.command || "")}"/><div data-step-wait class="number-with-suffix ${type === "wait" ? "" : "hidden"}"><input type="number" min="1" max="300" value="${Number(step.seconds || 5)}"/><span>${escapeHtml(t("runbooks.waitSeconds", {}, "seconds"))}</span></div><button class="icon-action danger" type="button" data-remove-step>${escapeHtml(t("runbooks.remove", {}, "Remove"))}</button>`;
  const select = row.querySelector("[data-step-type]");
  const command = row.querySelector("[data-step-command]");
  const wait = row.querySelector("[data-step-wait]");
  select?.addEventListener("change", () => { const isWait = select.value === "wait"; command.classList.toggle("hidden", isWait); wait.classList.toggle("hidden", !isWait); refreshRunbookRiskPreview(); });
  command?.addEventListener("input", refreshRunbookRiskPreview);
  row.querySelector("[data-remove-step]")?.addEventListener("click", () => { row.remove(); [...wrap.children].forEach((child, i) => { const h=child.querySelector(".runbook-step-handle"); if(h) h.textContent=String(i+1); }); refreshRunbookRiskPreview(); });
  wrap.appendChild(row);
  refreshRunbookRiskPreview();
}
function collectRunbookForm() {
  const variables = [...document.querySelectorAll("#runbookVariableBuilder .runbook-variable-row")].map(row => ({
    name: row.querySelector("[data-var-name]").value.trim(),
    label: row.querySelector("[data-var-label]").value.trim(),
    default: row.querySelector("[data-var-default]").value,
    required: row.querySelector("[data-var-required]").checked,
  }));
  const steps = [...document.querySelectorAll("#runbookStepBuilder .runbook-step-row")].map(row => {
    const type = row.querySelector("[data-step-type]").value;
    if (type === "wait") return { type, seconds: Number(row.querySelector("[data-step-wait] input").value || 1) };
    return { type, command: row.querySelector("[data-step-command]").value.trim() };
  });
  return {
    name: $("runbookName").value.trim(), description: $("runbookDescription").value.trim(),
    allow_scheduled: $("runbookAllowScheduled").checked, max_targets: Number($("runbookMaxTargets").value || 50),
    concurrency: Number($("runbookConcurrency").value || 5), failure_policy: $("runbookFailurePolicy").value,
    variables, steps,
  };
}
function renderRunbookLibrary() {
  const list = $("runbookLibraryList");
  if (!list) return;
  $("runbookLibraryCount").textContent = t("runbooks.workflowCount", { count: (state.runbooks || []).length }, `${(state.runbooks || []).length} workflows`);
  list.innerHTML = (state.runbooks || []).map(item => {
    const risk = runbookRiskMeta(item);
    const statusLabel = item.status === "approved" ? t("runbooks.approved", {}, "Approved") : t("runbooks.draft", {}, "Draft");
    return `<button class="runbook-library-item ${Number($("runbookId")?.value || 0) === Number(item.id) ? "active" : ""}" type="button" onclick="editRunbookById(${Number(item.id)})"><div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.description || t("runbooks.noDescription", {}, "No description"))}</small></div><div class="runbook-library-badges"><span class="status ${item.status === "approved" ? "online" : "unknown"}">${escapeHtml(statusLabel)}</span><span class="runbook-risk-pill ${escapeHtml(risk.risk)}">${escapeHtml(risk.label)}</span></div></button>`;
  }).join("") || `<div class="empty-state compact-empty"><svg><use href="#i-terminal"></use></svg><strong>${escapeHtml(t("runbooks.saved", {}, "Saved runbooks"))}</strong><span>${escapeHtml(t("runbooks.emptyLibrary", {}, "No runbooks yet. Create the first controlled CLI workflow."))}</span></div>`;
}
function editRunbook(runbook) {
  $("runbookId").value = runbook ? String(runbook.id) : "";
  $("runbookName").value = runbook?.name || "";
  $("runbookDescription").value = runbook?.description || "";
  $("runbookAllowScheduled").checked = Boolean(runbook?.allow_scheduled);
  $("runbookMaxTargets").value = Number(runbook?.max_targets || 50);
  $("runbookConcurrency").value = Number(runbook?.concurrency || 5);
  $("runbookFailurePolicy").value = runbook?.failure_policy || "continue";
  $("runbookVariableBuilder").innerHTML = "";
  (runbook?.variables || []).forEach(addRunbookVariableRow);
  $("runbookStepBuilder").innerHTML = "";
  (runbook?.steps || [{type:"command",command:"show system"}]).forEach(addRunbookStepRow);
  const status = $("runbookEditorStatus");
  status.className = `status ${runbook?.status === "approved" ? "online" : "unknown"}`;
  status.textContent = runbook?.status === "approved" ? t("runbooks.approved", {}, "Approved") : t("runbooks.draft", {}, "Draft");
  $("approveRunbookButton").classList.toggle("hidden", !runbook || runbook.status === "approved");
  $("deleteRunbookButton").classList.toggle("hidden", !runbook);
  $("duplicateRunbookButton").classList.toggle("hidden", !runbook);
  renderRunbookLibrary();
  refreshRunbookRiskPreview();
}
window.editRunbookById = function(id) { const item=(state.runbooks||[]).find(x=>Number(x.id)===Number(id)); if(item) editRunbook(item); };
async function openRunbookLibrary() {
  if (!isPlatformAdmin()) return;
  await loadRunbooks();
  const current = selectedRunbook();
  editRunbook(current || state.runbooks[0] || null);
  $("runbookLibraryDialog")?.showModal();
}
async function saveRunbookForm(event) {
  event.preventDefault();
  const id = Number($("runbookId").value || 0);
  try {
    const saved = await api(id ? `/api/runbooks/${id}` : "/api/runbooks", { method: id ? "PUT" : "POST", body: collectRunbookForm() });
    toast(t("runbooks.savedDraft", { name: saved.name }, `Runbook “${saved.name}” saved as Draft`), "success");
    await loadRunbooks();
    editRunbook((state.runbooks || []).find(x => Number(x.id) === Number(saved.id)) || saved);
  } catch (error) { toast(error.message, "error"); }
}
async function approveCurrentRunbook() {
  const id = Number($("runbookId").value || 0); if (!id) return;
  try { const item = await api(`/api/runbooks/${id}/approve`, { method: "POST" }); toast(t("runbooks.approvedToast", { name: item.name }, `Runbook “${item.name}” approved`), "success"); await loadRunbooks(); editRunbook((state.runbooks||[]).find(x=>Number(x.id)===id)||item); } catch(error){ toast(error.message,"error"); }
}
async function deleteCurrentRunbook() {
  const id = Number($("runbookId").value || 0); if (!id) return;
  if (!confirm(t("runbooks.deleteConfirm", {}, "Delete this runbook?"))) return;
  try { await api(`/api/runbooks/${id}`, { method: "DELETE" }); toast(t("runbooks.deletedToast", {}, "Runbook deleted"), "success"); await loadRunbooks(); editRunbook(state.runbooks[0] || null); } catch(error){ toast(error.message,"error"); }
}
function duplicateCurrentRunbook() {
  const id = Number($("runbookId").value || 0); const item=(state.runbooks||[]).find(x=>Number(x.id)===id); if(!item) return;
  editRunbook({ ...item, id: null, name: t("runbooks.copyOf", { name: item.name }, `Copy of ${item.name}`), status: "draft", approved_at: null, approved_by: null });
}

function automationAction(actionId) {
  return (state.automation?.actions || []).find(item => String(item.id) === String(actionId)) || null;
}
function automationActionLabel(actionId) {
  const item = automationAction(actionId);
  return actionMeta(actionId).label || item?.label || String(actionId).replaceAll("_", " ");
}
function automationSafeguardSummary(policy = state.automation?.safeguards?.fix_unp || {}) {
  const ports = String(policy.protected_ports || "1/1/1").split(",").map(value => value.trim()).filter(Boolean);
  return { ports: ports.length, portText: ports.join(", ") || "1/1/1", guest: policy.guest_keywords || "GUEST", services: policy.service_keywords || "VOIP,IPTV", max: Number(policy.max_ports_per_switch || 12) };
}
function vlanMaintenanceSafeguardSummary(policy = state.automation?.safeguards?.vlan_port_maintenance || {}) {
  const ports = String(policy.protected_ports || "").split(",").map(value => value.trim()).filter(Boolean);
  return { ports: ports.length, maxSwitch: Number(policy.max_ports_per_switch || 12), maxTotal: Number(policy.max_total_ports || 100), vlanThreshold: Number(policy.trunk_vlan_threshold || 4), macThreshold: Number(policy.mac_address_threshold || 8) };
}
function renderAutomationSafeguards() {
  const fix = automationSafeguardSummary();
  const vlan = vlanMaintenanceSafeguardSummary();
  const container = $("automationSafeguardSummary");
  if (container) container.innerHTML = `
    <article class="automation-policy-row"><span class="admin-security-icon"><svg><use href="#i-admin"></use></svg></span><span><strong>${escapeHtml(t("automation.fixUnpPolicy", {}, "Fix UNP"))}</strong><small>${escapeHtml(t("automation.safeguardInlineSummary", { ports: fix.ports, max: fix.max }, `${fix.ports} protected ports · maximum ${fix.max} affected ports per switch`))}</small></span><button class="btn secondary compact" type="button" onclick="openFixUnpSafeguards()">${escapeHtml(t("automation.viewSafeguards", {}, "View safeguards"))}</button></article>
    <article class="automation-policy-row"><span class="admin-security-icon"><svg><use href="#i-network"></use></svg></span><span><strong>${escapeHtml(t("automation.vlanMaintenancePolicy", {}, "VLAN Port Maintenance"))}</strong><small>${escapeHtml(t("automation.vlanPolicySummary", { perSwitch: vlan.maxSwitch, total: vlan.maxTotal }, `Mandatory uplink protection · max ${vlan.maxSwitch}/switch · ${vlan.maxTotal}/run`))}</small></span><button class="btn secondary compact" type="button" onclick="openVlanMaintenanceSafeguards()">${escapeHtml(t("automation.viewSafeguards", {}, "View safeguards"))}</button></article>`;
  updateAutomationScheduleSafeguard();
}
function updateAutomationScheduleSafeguard() {
  const actionId = $("automationScheduleAction")?.value || "fix_unp";
  const action = automationAction(actionId) || {};
  const wrap = $("automationScheduleSafeguard");
  if (!wrap) return;
  const hasPolicy = Boolean(action.safeguard_profile);
  wrap.classList.toggle("hidden", !hasPolicy);
  if (!hasPolicy) return;
  const title = $("automationScheduleSafeguardTitle");
  const summary = $("automationScheduleSafeguardSummary");
  if (action.safeguard_profile === "vlan_port_maintenance") {
    const policy = vlanMaintenanceSafeguardSummary();
    if (title) title.textContent = t("automation.vlanSafeguardsApply", {}, "VLAN Port Maintenance safeguards will apply");
    if (summary) summary.textContent = t("automation.vlanPolicySummary", { perSwitch: policy.maxSwitch, total: policy.maxTotal }, `Mandatory uplink protection · max ${policy.maxSwitch}/switch · ${policy.maxTotal}/run`);
  } else {
    const policy = automationSafeguardSummary();
    if (title) title.textContent = t("automation.fixUnpSafeguardsApply", {}, "Fix UNP safeguards will apply");
    if (summary) summary.textContent = t("automation.safeguardInlineSummary", { ports: policy.ports, max: policy.max }, `${policy.ports} protected ports · maximum ${policy.max} affected ports per switch`);
  }
}
function openSelectedAutomationSafeguard() {
  const profile = automationAction($("automationScheduleAction")?.value || "")?.safeguard_profile;
  if (profile === "vlan_port_maintenance") window.openVlanMaintenanceSafeguards();
  else if (profile === "fix_unp") window.openFixUnpSafeguards();
}
function renderAutomationMetrics() {
  const automation = state.automation || { credential: {}, schedules: [] };
  const schedules = automation.schedules || [];
  const enabled = schedules.filter(item => item.enabled);
  $("automationMetricSchedules").textContent = schedules.length;
  $("automationMetricEnabled").textContent = enabled.length;
  const credential = automation.credential || {};
  $("automationMetricCredential").textContent = credential.configured ? t("automation.ready", {}, "Ready") : t("automation.required", {}, "Required");
  $("automationMetricCredentialHelp").textContent = credential.configured ? `${credential.username}${credential.verified_device_name ? ` · ${credential.verified_device_name}` : ""}` : t("automation.credentialRequiredHelp", {}, "Configure a dedicated SSH service account");
  const next = enabled.slice().sort((a, b) => String(a.run_time || "").localeCompare(String(b.run_time || "")))[0];
  $("automationMetricNextRun").textContent = next ? String(next.run_time || "--:--") : t("common.none", {}, "None");
  $("automationMetricNextRunHelp").textContent = next ? `${automationActionLabel(next.action)} · ${next.timezone || "UTC"}` : t("automation.noEnabledSchedules", {}, "No enabled schedules");
}
function renderAutomationActions(selectedAction = "") {
  const select = $("automationScheduleAction");
  if (!select) return;
  const actions = state.automation?.actions || [];
  select.innerHTML = actions.map(action => `<option value="${escapeHtml(action.id)}">${escapeHtml(automationActionLabel(action.id))}</option>`).join("");
  if (selectedAction && [...select.options].some(option => option.value === selectedAction)) select.value = selectedAction;
  else if ([...select.options].some(option => option.value === "fix_unp")) select.value = "fix_unp";
  renderAutomationActionSettings();
}
function renderAutomationActionSettings(settingsValues = null) {
  const actionId = $("automationScheduleAction")?.value || "fix_unp";
  const action = automationAction(actionId) || { settings: {}, safeguard_profile: null };
  const settings = action.settings || {};
  const container = $("automationActionSettings");
  if (container) {
    if (actionId === "custom_runbook") {
      const runbooks = state.automation?.runbooks || [];
      const selectedId = Number(settingsValues?.runbook_id || runbooks[0]?.id || 0);
      const runbook = runbooks.find(item => Number(item.id) === selectedId) || null;
      const variables = settingsValues?.variables && typeof settingsValues.variables === "object" ? settingsValues.variables : {};
      const scheduleSummary = runbook ? t("runbooks.scheduleSummary", { steps: Number(runbook.steps?.length || 0), targets: Number(runbook.max_targets || 1), concurrency: Number(runbook.concurrency || 1) }, `${Number(runbook.steps?.length || 0)} steps · max ${Number(runbook.max_targets || 1)} targets · ${Number(runbook.concurrency || 1)} concurrent`) : "";
      container.innerHTML = `<div class="automation-runbook-settings"><label><span>${escapeHtml(t("runbooks.runbook", {}, "Runbook"))}</span><select data-automation-setting="runbook_id" id="automationRunbookSelect"><option value="">${escapeHtml(t("runbooks.scheduleSelect", {}, "Select approved runbook"))}</option>${runbooks.map(item => `<option value="${Number(item.id)}" ${Number(item.id) === selectedId ? "selected" : ""}>${escapeHtml(item.name)} · ${escapeHtml(runbookRiskMeta(item).label)}</option>`).join("")}</select></label>${runbook ? `<div class="automation-runbook-summary"><strong>${escapeHtml(runbook.name)}</strong><small>${escapeHtml(runbook.description || t("runbooks.noDescription", {}, "No description"))}</small><span>${escapeHtml(scheduleSummary)}</span></div>` : `<div class="automation-runbook-summary warning"><strong>${escapeHtml(t("runbooks.scheduleNoneTitle", {}, "No schedulable runbook selected"))}</strong><small>${escapeHtml(t("runbooks.scheduleNoneHelp", {}, "Approve a runbook and enable scheduled execution in the Runbook Library first."))}</small></div>`}<div class="automation-runbook-variables">${(runbook?.variables || []).map(spec => `<label><span>${escapeHtml(spec.label || spec.name)}${spec.required ? " *" : ""}</span><input data-automation-runbook-variable="${escapeHtml(spec.name)}" maxlength="200" value="${escapeHtml(variables[spec.name] ?? spec.default ?? "")}"/></label>`).join("")}</div></div>`;
      container.classList.remove("hidden");
      $("automationRunbookSelect")?.addEventListener("change", event => renderAutomationActionSettings({ runbook_id: Number(event.target.value || 0), variables: {} }));
    } else {
      container.innerHTML = Object.entries(settings).map(([name, spec]) => {
        const value = settingsValues?.[name] ?? spec.default ?? "";
        const label = name === "cycle_delay_seconds" ? t("admin.scheduleDelay", {}, spec.label || name)
          : name === "target_vlan" ? t("operations.targetVlan", {}, spec.label || name)
          : name === "operation" ? t("operations.vlanMaintenanceAction", {}, spec.label || name)
          : (spec.label || name);
        const suffix = spec.suffix === "seconds" ? t("common.seconds", {}, spec.suffix) : (spec.suffix || "");
        if (spec.type === "integer") return `<label><span>${escapeHtml(label)}</span><div class="number-with-suffix"><input data-automation-setting="${escapeHtml(name)}" type="number" min="${Number(spec.min ?? 0)}" max="${Number(spec.max ?? 999999)}" value="${escapeHtml(value)}"/><span>${escapeHtml(suffix)}</span></div></label>`;
        if (spec.type === "choice") return `<label><span>${escapeHtml(label)}</span><select data-automation-setting="${escapeHtml(name)}">${(spec.choices || []).map(choice => { const choiceLabel = choice.value === "poe_cycle" ? t("operations.restartPoe", {}, choice.label || choice.value) : choice.value === "interface_cycle" ? t("operations.restartInterface", {}, choice.label || choice.value) : (choice.label || choice.value); return `<option value="${escapeHtml(choice.value)}" ${String(choice.value) === String(value) ? "selected" : ""}>${escapeHtml(choiceLabel)}</option>`; }).join("")}</select></label>`;
        return `<label><span>${escapeHtml(label)}</span><input data-automation-setting="${escapeHtml(name)}" value="${escapeHtml(value)}"/></label>`;
      }).join("");
      container.classList.toggle("hidden", !Object.keys(settings).length);
    }
  }
  updateAutomationScheduleSafeguard();
  renderAutomationSafeguards();
}
function collectAutomationActionSettings() {
  if ($("automationScheduleAction")?.value === "custom_runbook") {
    const values = {};
    document.querySelectorAll("#automationActionSettings [data-automation-runbook-variable]").forEach(input => { values[input.dataset.automationRunbookVariable] = input.value; });
    return { runbook_id: Number($("automationRunbookSelect")?.value || 0), variables: values };
  }
  const values = {};
  document.querySelectorAll("#automationActionSettings [data-automation-setting]").forEach(input => {
    const name = input.dataset.automationSetting;
    values[name] = input.type === "number" ? Number(input.value) : input.value;
  });
  return values;
}

function resetAutomationScheduleForm() {
  $("automationScheduleForm")?.reset();
  $("automationScheduleId").value = "";
  $("automationScheduleTime").value = "06:00";
  $("automationScheduleTimezone").value = state.platformTimezone || "UTC";
  $("automationScheduleEnabled").checked = true;
  populateAutomationScopeOptions([], []);
  renderAutomationActions("fix_unp");
  $("automationScheduleDialogTitle").textContent = t("automation.createSchedule", {}, "Create schedule");
}
function openAutomationScheduleDialog(schedule = null, duplicate = false) {
  resetAutomationScheduleForm();
  if (schedule) {
    $("automationScheduleId").value = duplicate ? "" : String(schedule.id);
    $("automationScheduleName").value = duplicate ? t("automation.copyName", { name: schedule.name }, `Copy of ${schedule.name}`) : (schedule.name || "");
    renderAutomationActions(schedule.action || "fix_unp");
    $("automationScheduleTime").value = schedule.run_time || "06:00";
    $("automationScheduleTimezone").value = schedule.timezone || "UTC";
    $("automationScheduleEnabled").checked = Boolean(schedule.enabled);
    populateAutomationScopeOptions(schedule.sites || [], schedule.groups || []);
    renderAutomationActionSettings(schedule.settings || { cycle_delay_seconds: schedule.cycle_delay_seconds || 5 });
    $("automationScheduleDialogTitle").textContent = duplicate ? t("automation.duplicateSchedule", {}, "Duplicate schedule") : t("automation.editSchedule", {}, "Edit schedule");
  }
  $("automationScheduleDialog")?.showModal();
  requestAnimationFrame(() => $("automationScheduleName")?.focus());
}
function renderAutomationSchedules() {
  const rows = state.automation?.schedules || [];
  const table = $("automationSchedulesTable");
  if (!table) return;
  table.innerHTML = rows.map(schedule => {
    const sites = schedule.sites?.length ? schedule.sites.join(", ") : t("automation.allSites", {}, "All sites");
    const groups = schedule.groups?.length ? schedule.groups.join(", ") : t("automation.allGroups", {}, "All groups");
    const action = automationAction(schedule.action) || {};
    const status = schedule.last_status || "never";
    const guard = action.safeguard_profile ? `<span class="automation-policy-pill"><svg><use href="#i-admin"></use></svg>${escapeHtml(t("automation.safeguards", {}, "Safeguards"))}</span>` : "";
    return `<tr>
      <td><strong>${escapeHtml(schedule.name)}</strong><div class="muted-line">${schedule.enabled ? escapeHtml(t("status.enabled", {}, "Enabled")) : escapeHtml(t("status.disabled", {}, "Disabled"))}</div></td>
      <td><strong>${escapeHtml(automationActionLabel(schedule.action))}</strong><div class="muted-line">${guard}</div></td>
      <td><strong>${escapeHtml(sites)}</strong><div class="muted-line">${escapeHtml(groups)}</div></td>
      <td><strong>${escapeHtml(schedule.run_time)}</strong><div class="muted-line">${escapeHtml(schedule.timezone || "UTC")}</div></td>
      <td>${schedule.last_run_at ? formatDate(schedule.last_run_at) : escapeHtml(t("automation.neverRun", {}, "Never"))}${schedule.last_job_id ? `<div class="muted-line">Job #${Number(schedule.last_job_id)}</div>` : ""}</td>
      <td>${statusBadge(status)}${schedule.last_error ? `<div class="scheduler-error">${escapeHtml(schedule.last_error)}</div>` : ""}</td>
      <td><div class="row-actions automation-row-actions"><button class="icon-action" onclick="editAutomationSchedule(${Number(schedule.id)})">${escapeHtml(t("common.edit", {}, "Edit"))}</button><button class="icon-action" onclick="duplicateAutomationSchedule(${Number(schedule.id)})">${escapeHtml(t("automation.duplicate", {}, "Duplicate"))}</button><button class="icon-action" onclick="runAutomationScheduleNow(${Number(schedule.id)})">${escapeHtml(t("automation.runNow", {}, "Run now"))}</button><button class="icon-action danger" onclick="deleteAutomationSchedule(${Number(schedule.id)})">${escapeHtml(t("common.delete", {}, "Delete"))}</button></div></td>
    </tr>`;
  }).join("") || `<tr><td colspan="7"><div class="empty-state">${escapeHtml(t("automation.noSchedules", {}, "No scheduled actions have been created."))}</div></td></tr>`;
}
function renderAutomationCenter() {
  const automation = state.automation || { credential: {}, schedules: [] };
  const credential = automation.credential || {};
  const badge = $("automationCredentialBadge");
  if (badge) {
    badge.className = `status ${credential.configured ? "online" : "unknown"}`;
    badge.textContent = credential.configured ? t("automation.credentialReady", {}, "Credential ready") : t("automation.credentialRequired", {}, "Credential required");
  }
  $("automationUsername").value = credential.username || "";
  $("automationPassword").value = "";
  $("automationCredentialRemove").disabled = !credential.configured;
  $("automationCredentialSummary").innerHTML = credential.configured
    ? `<span class="admin-security-icon"><svg><use href="#i-check"></use></svg></span><span><strong>${escapeHtml(credential.username)}</strong><small>${escapeHtml(t("automation.verifiedOn", { device: credential.verified_device_name || "" }, `Verified on ${credential.verified_device_name || "switch"}`))} · ${escapeHtml(formatDate(credential.verified_at))}</small></span>`
    : `<span class="admin-security-icon"><svg><use href="#i-key"></use></svg></span><span><strong>${escapeHtml(t("automation.credentialRequired", {}, "Credential required"))}</strong><small>${escapeHtml(t("automation.credentialRequiredHelp", {}, "Configure a dedicated SSH service account before an enabled schedule can run."))}</small></span>`;
  renderAutomationSafeguards();
  renderAutomationMetrics();
  renderAutomationSchedules();
}
async function loadAutomationCenter() {
  if (!isPlatformAdmin()) return;
  try {
    const [automation] = await Promise.all([api("/api/automation"), loadDevices()]);
    state.automation = automation;
    renderAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
}
async function saveAutomationCredential() {
  const username = $("automationUsername").value.trim();
  const password = $("automationPassword").value;
  if (!username || !password) { toast(t("automation.enterCredential", {}, "Enter the automation SSH username and password"), "error"); return; }
  try {
    await api("/api/automation/credential", { method: "PUT", body: { username, password } });
    toast(t("automation.credentialSaved", {}, "Automation credential verified and saved"), "success");
    await loadAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
}
async function removeAutomationCredential() {
  if (!confirm(t("automation.removeCredentialConfirm", {}, "Remove the automation SSH credential? Enabled schedules will stop running until a credential is configured."))) return;
  try {
    await api("/api/automation/credential", { method: "DELETE" });
    toast(t("automation.credentialRemoved", {}, "Automation credential removed"), "success");
    await loadAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
}
async function saveAutomationSchedule(event) {
  event.preventDefault();
  const id = Number($("automationScheduleId").value || 0);
  const payload = {
    name: $("automationScheduleName").value.trim(),
    enabled: $("automationScheduleEnabled").checked,
    action: $("automationScheduleAction").value,
    run_time: $("automationScheduleTime").value,
    timezone: $("automationScheduleTimezone").value.trim() || "UTC",
    sites: selectedOptionValues($("automationScheduleSites")),
    groups: selectedOptionValues($("automationScheduleGroups")),
    settings: collectAutomationActionSettings(),
  };
  try {
    await api(id ? `/api/automation/schedules/${id}` : "/api/automation/schedules", { method: id ? "PUT" : "POST", body: payload });
    toast(t("automation.scheduleSaved", {}, "Schedule saved"), "success");
    $("automationScheduleDialog")?.close();
    await loadAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
}
window.editAutomationSchedule = function(scheduleId) {
  const schedule = (state.automation?.schedules || []).find(item => Number(item.id) === Number(scheduleId));
  if (schedule) openAutomationScheduleDialog(schedule, false);
};
window.duplicateAutomationSchedule = function(scheduleId) {
  const schedule = (state.automation?.schedules || []).find(item => Number(item.id) === Number(scheduleId));
  if (schedule) openAutomationScheduleDialog(schedule, true);
};
window.deleteAutomationSchedule = async function(scheduleId) {
  if (!confirm(t("automation.deleteScheduleConfirm", {}, "Delete this scheduled action?"))) return;
  try {
    await api(`/api/automation/schedules/${scheduleId}`, { method: "DELETE" });
    toast(t("automation.scheduleDeleted", {}, "Schedule deleted"), "success");
    await loadAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
};
window.runAutomationScheduleNow = async function(scheduleId) {
  try {
    const result = await api(`/api/automation/schedules/${scheduleId}/run`, { method: "POST" });
    toast(t("automation.scheduleQueued", { job: result.job_id }, `Job #${result.job_id} queued`), "success");
    await loadAutomationCenter();
  } catch (error) { toast(error.message, "error"); }
};
window.openFixUnpSafeguards = async function openFixUnpSafeguards() {
  try {
    const policy = await api("/api/automation/safeguards/fix-unp");
    if (state.automation) state.automation.safeguards = { ...(state.automation.safeguards || {}), fix_unp: policy };
    $("fixUnpProtectedPorts").value = policy.protected_ports || "1/1/1";
    $("fixUnpGuestKeywords").value = policy.guest_keywords || "GUEST";
    $("fixUnpServiceKeywords").value = policy.service_keywords || "VOIP,IPTV";
    $("fixUnpMaxPorts").value = Number(policy.max_ports_per_switch || 12);
    const editable = isPlatformAdmin();
    for (const id of ["fixUnpProtectedPorts", "fixUnpGuestKeywords", "fixUnpServiceKeywords", "fixUnpMaxPorts"]) $(id).disabled = !editable;
    $("fixUnpSafeguardsSave").classList.toggle("hidden", !editable);
    $("fixUnpSafeguardsDialog")?.showModal();
    renderAutomationSafeguards();
  } catch (error) { toast(error.message, "error"); }
};
async function saveFixUnpSafeguards(event) {
  event.preventDefault();
  if (!isPlatformAdmin()) return;
  const payload = {
    protected_ports: $("fixUnpProtectedPorts").value.trim() || "1/1/1",
    guest_keywords: $("fixUnpGuestKeywords").value.trim() || "GUEST",
    service_keywords: $("fixUnpServiceKeywords").value.trim() || "VOIP,IPTV",
    max_ports_per_switch: Number($("fixUnpMaxPorts").value || 12),
  };
  try {
    const policy = await api("/api/automation/safeguards/fix-unp", { method: "PUT", body: payload });
    state.automation = state.automation || { credential: {}, actions: [], schedules: [], safeguards: {} };
    state.automation.safeguards = { ...(state.automation.safeguards || {}), fix_unp: policy };
    if (state.adminSettings) {
      state.adminSettings.unp_fix_protected_ports = policy.protected_ports;
      state.adminSettings.unp_fix_guest_keywords = policy.guest_keywords;
      state.adminSettings.unp_fix_service_keywords = policy.service_keywords;
      state.adminSettings.unp_fix_max_ports_per_switch = policy.max_ports_per_switch;
    }
    toast(t("admin.safeguardsSaved", {}, "Fix UNP safeguards saved"), "success");
    $("fixUnpSafeguardsDialog")?.close();
    renderAutomationSafeguards();
    updateActionContext();
  } catch (error) { toast(error.message, "error"); }
}


window.openVlanMaintenanceSafeguards = async function openVlanMaintenanceSafeguards() {
  try {
    const policy = await api("/api/automation/safeguards/vlan-maintenance");
    state.automation = state.automation || { credential: {}, actions: [], schedules: [], safeguards: {} };
    state.automation.safeguards = { ...(state.automation.safeguards || {}), vlan_port_maintenance: policy };
    $("vlanMaintenanceProtectedPorts").value = policy.protected_ports || "";
    $("vlanMaintenanceMaxPerSwitch").value = Number(policy.max_ports_per_switch || 12);
    $("vlanMaintenanceMaxTotal").value = Number(policy.max_total_ports || 100);
    $("vlanMaintenanceTrunkThreshold").value = Number(policy.trunk_vlan_threshold || 4);
    $("vlanMaintenanceMacThreshold").value = Number(policy.mac_address_threshold || 8);
    const editable = isPlatformAdmin();
    for (const id of ["vlanMaintenanceProtectedPorts", "vlanMaintenanceMaxPerSwitch", "vlanMaintenanceMaxTotal", "vlanMaintenanceTrunkThreshold", "vlanMaintenanceMacThreshold"]) $(id).disabled = !editable;
    $("vlanMaintenanceSafeguardsSave").classList.toggle("hidden", !editable);
    $("vlanMaintenanceSafeguardsDialog")?.showModal();
    renderAutomationSafeguards();
  } catch (error) { toast(error.message, "error"); }
};
async function saveVlanMaintenanceSafeguards(event) {
  event.preventDefault();
  if (!isPlatformAdmin()) return;
  const payload = {
    protected_ports: $("vlanMaintenanceProtectedPorts").value.trim(),
    max_ports_per_switch: Number($("vlanMaintenanceMaxPerSwitch").value || 12),
    max_total_ports: Number($("vlanMaintenanceMaxTotal").value || 100),
    trunk_vlan_threshold: Number($("vlanMaintenanceTrunkThreshold").value || 4),
    mac_address_threshold: Number($("vlanMaintenanceMacThreshold").value || 8),
  };
  try {
    const policy = await api("/api/automation/safeguards/vlan-maintenance", { method: "PUT", body: payload });
    state.automation = state.automation || { credential: {}, actions: [], schedules: [], safeguards: {} };
    state.automation.safeguards = { ...(state.automation.safeguards || {}), vlan_port_maintenance: policy };
    toast(t("automation.vlanSafeguardsSaved", {}, "VLAN Port Maintenance safeguards saved"), "success");
    $("vlanMaintenanceSafeguardsDialog")?.close();
    renderAutomationSafeguards();
    updateActionContext();
  } catch (error) { toast(error.message, "error"); }
}

async function runAdminHealthScan() {
  try {
    await api("/api/admin/health-scan", { method: "POST" });
    toast(t("admin.healthQueued", {}, "Health scan queued"), "success");
  } catch (error) { toast(error.message, "error"); }
}
async function pruneAdminData(event) {
  event.preventDefault();
  if (!confirm(t("admin.pruneConfirm", {}, "Delete old records?"))) return;
  try {
    const result = await api("/api/admin/maintenance/prune", { method: "POST", body: {
      audit_retention_days: Number($("adminAuditRetention").value || 180),
      completed_jobs_retention_days: Number($("adminJobsRetention").value || 90),
    }});
    toast(t("admin.pruneResult", { audit: result.audit_deleted, jobs: result.jobs_deleted }, "Maintenance completed"), "success");
    await loadAdminPanel();
  } catch (error) { toast(error.message, "error"); }
}

async function changePassword(event) {
  event.preventDefault();
  $("passwordFormError").textContent = "";
  const newPassword = $("newPassword").value;
  if (newPassword.length < state.passwordPolicy.min_length || newPassword.length > state.passwordPolicy.max_length) {
    $("passwordFormError").textContent = t("password.policyError", { min: state.passwordPolicy.min_length, max: state.passwordPolicy.max_length }, `Use between ${state.passwordPolicy.min_length} and ${state.passwordPolicy.max_length} characters.`);
    return;
  }
  try {
    await api("/api/auth/change-password", { method: "POST", body: { current_password: $("currentPassword").value, new_password: $("newPassword").value } });
    $("passwordDialog").close(); toast(t("password.updated", {}, "Password updated"), "success");
    state.user.must_change_password = false;
  } catch (error) { $("passwordFormError").textContent = error.message; }
}
function togglePasswordField(id) {
  const input = $(id);
  input.type = input.type === "password" ? "text" : "password";
}

init();
