// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Dimitris Galatsanos
(() => {
  const languages = [
    { code: "en", label: "English", locale: "en-GB" },
    { code: "el", label: "Ελληνικά", locale: "el-GR" },
  ];
  const supported = languages.map(item => item.code);
  const cache = new Map();
  let language = "en";
  let dictionary = {};

  function normalize(value) {
    const candidate = String(value || "").toLowerCase().split("-")[0];
    return supported.includes(candidate) ? candidate : "en";
  }

  async function load(lang) {
    const normalized = normalize(lang);
    if (!cache.has(normalized)) {
      const response = await fetch(`/static/i18n/${normalized}.json`, { cache: "no-store" });
      if (!response.ok) throw new Error(`Unable to load language: ${normalized}`);
      cache.set(normalized, await response.json());
    }
    language = normalized;
    dictionary = cache.get(normalized) || {};
    document.documentElement.lang = normalized;
    localStorage.setItem("osc-language", normalized);
    return dictionary;
  }

  function t(key, variables = {}, fallback = "") {
    let value = dictionary[key];
    if (typeof value !== "string") value = fallback || key;
    return value.replace(/\{(\w+)\}/g, (_, name) => String(variables[name] ?? `{${name}}`));
  }

  function apply(root = document) {
    root.querySelectorAll("[data-i18n]").forEach(element => {
      const translated = t(element.dataset.i18n, {}, element.textContent);
      const directText = [...element.childNodes].find(node => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim());
      if (element.children.length && directText) directText.nodeValue = translated;
      else element.textContent = translated;
    });
    root.querySelectorAll("[data-label-i18n]").forEach(element => {
      const translated = t(element.dataset.labelI18n, {}, "");
      const directText = [...element.childNodes].find(node => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim());
      if (directText) directText.nodeValue = translated;
      else element.insertBefore(document.createTextNode(translated), element.firstChild);
    });
    root.querySelectorAll("[data-i18n-html]").forEach(element => {
      element.innerHTML = t(element.dataset.i18nHtml, {}, element.innerHTML);
    });
    root.querySelectorAll("[data-i18n-placeholder]").forEach(element => {
      element.setAttribute("placeholder", t(element.dataset.i18nPlaceholder, {}, element.getAttribute("placeholder") || ""));
    });
    root.querySelectorAll("[data-i18n-title]").forEach(element => {
      element.setAttribute("title", t(element.dataset.i18nTitle, {}, element.getAttribute("title") || ""));
    });
    root.querySelectorAll("[data-i18n-aria-label]").forEach(element => {
      element.setAttribute("aria-label", t(element.dataset.i18nAriaLabel, {}, element.getAttribute("aria-label") || ""));
    });
    document.dispatchEvent(new CustomEvent("osc:language-applied", { detail: { language } }));
  }

  async function setLanguage(lang, root = document) {
    await load(lang);
    apply(root);
    return language;
  }

  window.I18n = {
    languages,
    supported,
    normalize,
    load,
    setLanguage,
    apply,
    t,
    get language() { return language; },
    get locale() { return languages.find(item => item.code === language)?.locale || "en-GB"; },
  };
})();
