# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from .db import get_app_setting, get_app_setting_int
from .profiles import render_command

PORT_RE = re.compile(r"^[0-9]+(?:/[0-9]+){1,2}$")
INTEGER_RE = re.compile(r"^[0-9]+$")


@dataclass(frozen=True)
class UnpUserEntry:
    port: str
    profile_id: str
    profile_name: str
    status: str
    raw_line: str

    @property
    def profile_label(self) -> str:
        name = self.profile_name.strip()
        if name and name != "-":
            return f"{self.profile_id} {name}".strip()
        return self.profile_id


@dataclass(frozen=True)
class UnpConflict:
    port: str
    profiles: tuple[str, ...]
    entries: tuple[UnpUserEntry, ...]


def _csv_setting(name: str, default: str) -> tuple[str, ...]:
    try:
        raw = get_app_setting(name, default)
    except Exception:
        raw = default
    values: list[str] = []
    for part in re.split(r"[,;\n]+", raw):
        value = part.strip()
        if value and value not in values:
            values.append(value)
    return tuple(values)


def protected_ports() -> set[str]:
    return {value for value in _csv_setting("unp_fix_protected_ports", "1/1/1") if PORT_RE.fullmatch(value)}


def guest_keywords() -> tuple[str, ...]:
    return tuple(value.upper() for value in _csv_setting("unp_fix_guest_keywords", "GUEST"))


def service_keywords() -> tuple[str, ...]:
    return tuple(value.upper() for value in _csv_setting("unp_fix_service_keywords", "VOIP,IPTV"))


def max_ports_per_switch() -> int:
    try:
        return get_app_setting_int("unp_fix_max_ports_per_switch", 12, 1, 48)
    except Exception:
        return 12


def parse_show_unp_user(output: str) -> list[UnpUserEntry]:
    """Parse the tabular output of ``show unp user``.

    AOS releases vary slightly in spacing and whether the User IP column is
    populated. The stable fields are the first token (physical port) and the
    four trailing fields (profile id, profile name, type, status). Parsing from
    both ends keeps the detector tolerant without accepting arbitrary data.
    """

    entries: list[UnpUserEntry] = []
    for raw_line in str(output or "").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("-") or line.lower().startswith(("port ", "total users", "show unp", "user ")):
            continue
        tokens = line.split()
        if len(tokens) < 6 or not PORT_RE.fullmatch(tokens[0]):
            continue

        # AOS normally ends each row with: <profile-id> <profile-name> <type> <status>.
        # The profile name can occasionally be absent, in which case "-" is used.
        status = tokens[-1]
        profile_name = tokens[-3] if len(tokens) >= 4 else ""
        profile_id = tokens[-4] if len(tokens) >= 5 else ""
        if not INTEGER_RE.fullmatch(profile_id):
            # Fallback for releases that omit the profile name column.
            profile_id = tokens[-3] if len(tokens) >= 4 and INTEGER_RE.fullmatch(tokens[-3]) else ""
            profile_name = ""
        if not profile_id:
            continue
        entries.append(
            UnpUserEntry(
                port=tokens[0],
                profile_id=profile_id,
                profile_name=profile_name,
                status=status,
                raw_line=raw_line.rstrip(),
            )
        )
    return entries


def _matches_any(value: str, keywords: Iterable[str]) -> bool:
    normalized = value.upper()
    return any(keyword and keyword in normalized for keyword in keywords)


def detect_conflicts(output: str) -> list[UnpConflict]:
    protected = protected_ports()
    guest = guest_keywords()
    services = service_keywords()
    grouped: dict[str, list[UnpUserEntry]] = {}
    for entry in parse_show_unp_user(output):
        if entry.port in protected:
            continue
        # Only active learned users are relevant to the repair rule.
        if entry.status.strip().lower() not in {"active", "up", "learned"}:
            continue
        grouped.setdefault(entry.port, []).append(entry)

    conflicts: list[UnpConflict] = []
    for port, entries in grouped.items():
        labels = tuple(dict.fromkeys(entry.profile_label for entry in entries))
        searchable = tuple(f"{entry.profile_id} {entry.profile_name}".strip() for entry in entries)
        has_guest = any(_matches_any(value, guest) for value in searchable)
        has_service = any(_matches_any(value, services) for value in searchable)
        if has_guest and has_service:
            conflicts.append(UnpConflict(port=port, profiles=labels, entries=tuple(entries)))
    return sorted(conflicts, key=lambda item: tuple(int(part) for part in item.port.split("/")))


def build_restart_commands(profile: str, conflicts: list[UnpConflict], delay_seconds: int) -> tuple[list[str], str]:
    commands: list[str] = []
    for conflict in conflicts:
        disable, _ = render_command(profile, "interface_disable", port=conflict.port)
        enable, _ = render_command(profile, "interface_enable", port=conflict.port)
        commands.extend([disable, f"WAIT {delay_seconds}s", enable])
    return commands, "show unp user"


def format_detection_summary(conflicts: list[UnpConflict], *, protected: set[str] | None = None) -> str:
    protected = protected if protected is not None else protected_ports()
    lines = ["SCAN: show unp user"]
    if protected:
        lines.append("PROTECTED PORTS: " + ", ".join(sorted(protected)))
    if not conflicts:
        lines.append("RESULT: No GUEST + VOIP/IPTV conflict was detected.")
        return "\n".join(lines)
    lines.append(f"RESULT: {len(conflicts)} conflicting port(s) detected")
    for conflict in conflicts:
        lines.append(f"- {conflict.port}: " + " + ".join(conflict.profiles))
    return "\n".join(lines)

UNP_CHECK_RESULT_MARKER = "UNP_CHECK_RESULT:"
UNP_AFFECTED_PORTS_MARKER = "UNP_AFFECTED_PORTS:"


def format_check_result(conflicts: list[UnpConflict], raw_output: str) -> str:
    """Build a stable, report-friendly result for the read-only UNP check."""

    lines = [
        f"{UNP_CHECK_RESULT_MARKER} {'ISSUE' if conflicts else 'CLEAR'}",
        f"{UNP_AFFECTED_PORTS_MARKER} {len(conflicts)}",
        format_detection_summary(conflicts, protected=protected_ports()),
        "",
        "RAW SCAN OUTPUT:",
        str(raw_output or "").strip(),
    ]
    return "\n".join(lines).strip()
