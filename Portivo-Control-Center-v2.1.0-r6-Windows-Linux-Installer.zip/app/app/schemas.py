# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, Field, field_validator, model_validator

from .password_policy import MAX_PASSWORD_LENGTH, validate_password


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=1, max_length=500)
    mode: Literal["ssh", "admin"] = "ssh"

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Username cannot be empty")
        return normalized


class DeviceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    host: str = Field(min_length=1, max_length=255)
    ssh_port: int = Field(default=22, ge=1, le=65535)
    site: str = Field(default="", max_length=120)
    group_name: str = Field(default="", max_length=120)
    model: str = Field(default="", max_length=120)
    aos_version: str = Field(default="", max_length=120)
    profile: Literal["AOS6", "AOS8"] = "AOS8"
    enabled: bool = True
    notes: str = Field(default="", max_length=2000)
    health_probe_mode: Literal["auto", "ping", "snmp"] = "auto"
    health_monitor_profile_id: int | None = Field(default=None, ge=1)
    stack_monitor_enabled: bool = False
    stack_expected_members: int = Field(default=0, ge=0, le=8)  # compatibility; auto baseline is authoritative
    stack_monitor_method: Literal["ssh", "snmpv3"] = "ssh"
    stack_monitor_profile_id: int | None = Field(default=None, ge=1)
    power_source_ups_id: int | None = Field(default=None, ge=1)
    verification_username: str = Field(default="", max_length=120)
    verification_password: str = Field(default="", max_length=500)

    @field_validator("host")
    @classmethod
    def normalize_host(cls, value: str) -> str:
        return value.strip()


class DeviceUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    host: str | None = Field(default=None, min_length=1, max_length=255)
    ssh_port: int | None = Field(default=None, ge=1, le=65535)
    site: str | None = Field(default=None, max_length=120)
    group_name: str | None = Field(default=None, max_length=120)
    model: str | None = Field(default=None, max_length=120)
    aos_version: str | None = Field(default=None, max_length=120)
    profile: Literal["AOS6", "AOS8"] | None = None
    enabled: bool | None = None
    notes: str | None = Field(default=None, max_length=2000)
    health_probe_mode: Literal["auto", "ping", "snmp"] | None = None
    health_monitor_profile_id: int | None = Field(default=None, ge=1)
    stack_monitor_enabled: bool | None = None
    stack_expected_members: int | None = Field(default=None, ge=0, le=8)  # compatibility
    stack_monitor_method: Literal["ssh", "snmpv3"] | None = None
    stack_monitor_profile_id: int | None = Field(default=None, ge=1)
    power_source_ups_id: int | None = Field(default=None, ge=1)
    verification_username: str | None = Field(default=None, max_length=120)
    verification_password: str | None = Field(default=None, max_length=500)




class UpsDeviceRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    host: str = Field(min_length=1, max_length=255)
    site: str = Field(default="", max_length=120)
    group_name: str = Field(default="", max_length=120)
    location: str = Field(default="", max_length=200)
    monitoring_profile_id: int = Field(ge=1)
    driver_mode: Literal["auto", "generic", "apc", "eaton", "vertiv", "socomec", "acculine", "xppc", "cyberpower", "riello"] = "auto"
    enabled: bool = True

    @field_validator("name", "host", "site", "group_name", "location")
    @classmethod
    def normalize_ups_text(cls, value: str) -> str:
        return value.strip()


class UpsVerifyRequest(BaseModel):
    host: str = Field(min_length=1, max_length=255)
    monitoring_profile_id: int = Field(ge=1)
    driver_mode: Literal["auto", "generic", "apc", "eaton", "vertiv", "socomec", "acculine", "xppc", "cyberpower", "riello"] = "auto"

    @field_validator("host")
    @classmethod
    def normalize_ups_host(cls, value: str) -> str:
        return value.strip()


class UpsAssignmentRequest(BaseModel):
    device_ids: list[int] = Field(default_factory=list, max_length=2000)

    @field_validator("device_ids")
    @classmethod
    def normalize_ups_devices(cls, value: list[int]) -> list[int]:
        return list(dict.fromkeys(int(item) for item in value if int(item) > 0))


class MonitoringCredentialProfileRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    method: Literal["ssh", "snmpv3"]
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(default="", max_length=500)
    snmp_port: int = Field(default=161, ge=1, le=65535)
    snmp_auth_protocol: Literal["SHA", "SHA256"] = "SHA256"
    snmp_auth_password: str = Field(default="", max_length=500)
    snmp_priv_protocol: Literal["AES", "AES128", "DES"] = "AES"
    snmp_priv_password: str = Field(default="", max_length=500)
    # verify_device_id is retained for backwards compatibility with clients
    # that can verify only against switches. New clients use the generic
    # verify_target_* fields so SNMPv3 profiles can also be checked against
    # managed UPS assets.
    verify_device_id: int | None = Field(default=None, ge=1)
    verify_target_type: Literal["switch", "ups"] | None = None
    verify_target_id: int | None = Field(default=None, ge=1)

    @field_validator("name", "username")
    @classmethod
    def normalize_monitoring_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be empty")
        return value


class MonitoringCredentialVerifyRequest(BaseModel):
    device_id: int = Field(ge=1)



class DraftConnectionTestRequest(BaseModel):
    device_id: int | None = None
    host: str = Field(min_length=1, max_length=255)
    ssh_port: int = Field(default=22, ge=1, le=65535)
    profile: Literal["AOS6", "AOS8"] = "AOS8"
    verification_username: str = Field(default="", max_length=120)
    verification_password: str = Field(default="", max_length=500)

    @field_validator("host")
    @classmethod
    def normalize_host(cls, value: str) -> str:
        return value.strip()


class ConnectionTestRequest(BaseModel):
    device_id: int


class BulkTarget(BaseModel):
    device_id: int
    port: str = Field(default="", max_length=80)
    slot: str = Field(default="", max_length=80)


def _supported_actions() -> set[str]:
    from .profiles import supported_actions
    return supported_actions()



class BulkExecuteRequest(BaseModel):
    action: str = Field(min_length=1, max_length=80)
    targets: list[BulkTarget] = Field(min_length=1, max_length=1000)
    dry_run: bool = False
    cycle_delay_seconds: int = Field(default=5, ge=1, le=300)
    port_alias: str = Field(default="", max_length=80)
    confirmation_text: str = ""
    custom_command: str = Field(default="", max_length=4000)
    target_vlan: int = Field(default=1, ge=1, le=4094)
    vlan_maintenance_operation: Literal["poe_cycle", "interface_cycle"] = "poe_cycle"
    runbook_id: int = Field(default=0, ge=0)
    runbook_variables: dict[str, object] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_action(self) -> "BulkExecuteRequest":
        if self.action not in _supported_actions():
            raise ValueError(f"Unsupported action: {self.action}")
        if self.action == "custom_command" and not self.custom_command.strip():
            raise ValueError("A custom CLI command is required")
        if self.action == "custom_runbook" and self.runbook_id <= 0:
            raise ValueError("Select a Custom Runbook")
        if self.action == "interface_alias" and not self.port_alias.strip():
            raise ValueError("A port alias is required")
        return self


class PreviewRequest(BaseModel):
    action: str = Field(min_length=1, max_length=80)
    targets: list[BulkTarget] = Field(min_length=1, max_length=1000)
    cycle_delay_seconds: int = Field(default=5, ge=1, le=300)
    port_alias: str = Field(default="", max_length=80)
    custom_command: str = Field(default="", max_length=4000)
    target_vlan: int = Field(default=1, ge=1, le=4094)
    vlan_maintenance_operation: Literal["poe_cycle", "interface_cycle"] = "poe_cycle"
    runbook_id: int = Field(default=0, ge=0)
    runbook_variables: dict[str, object] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_action(self) -> "PreviewRequest":
        if self.action not in _supported_actions():
            raise ValueError(f"Unsupported action: {self.action}")
        if self.action == "custom_command" and not self.custom_command.strip():
            raise ValueError("A custom CLI command is required")
        if self.action == "custom_runbook" and self.runbook_id <= 0:
            raise ValueError("Select a Custom Runbook")
        if self.action == "interface_alias" and not self.port_alias.strip():
            raise ValueError("A port alias is required")
        return self


class PasswordChangeRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=500)
    new_password: str = Field(min_length=1, max_length=MAX_PASSWORD_LENGTH)

    @field_validator("new_password")
    @classmethod
    def enforce_password_policy(cls, value: str) -> str:
        return validate_password(value)


class AdminSettingsRequest(BaseModel):
    default_language: Literal["en", "el"] = "en"
    ssh_users_manage_inventory: bool = True
    health_poll_interval_seconds: int = Field(default=30, ge=10, le=3600)
    platform_timezone: str | None = Field(default=None, min_length=1, max_length=120)
    monitoring_mode: Literal["full", "management_only"] | None = None
    monitoring_switch_availability: bool | None = None
    monitoring_stack_health: bool | None = None
    monitoring_power_ups: bool | None = None
    monitoring_incident_detection: bool | None = None
    authentication_source_device_ids: list[int] | None = Field(default=None, max_length=5)
    # Legacy v1.6.2 compatibility. The v1.6.3 UI manages these through /api/automation/safeguards/fix-unp.
    unp_fix_protected_ports: str | None = Field(default=None, max_length=500)
    unp_fix_guest_keywords: str | None = Field(default=None, max_length=500)
    unp_fix_service_keywords: str | None = Field(default=None, max_length=500)
    unp_fix_max_ports_per_switch: int | None = Field(default=None, ge=1, le=48)

    @field_validator("platform_timezone")
    @classmethod
    def validate_platform_timezone(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("Platform timezone cannot be empty")
        try:
            ZoneInfo(normalized)
        except (ZoneInfoNotFoundError, ValueError) as exc:
            raise ValueError(f"Unknown IANA timezone: {normalized}") from exc
        return normalized

    @field_validator("authentication_source_device_ids")
    @classmethod
    def normalize_authentication_sources(cls, values: list[int] | None) -> list[int] | None:
        if values is None:
            return None
        result: list[int] = []
        seen: set[int] = set()
        for value in values:
            device_id = int(value)
            if device_id <= 0 or device_id in seen:
                continue
            seen.add(device_id)
            result.append(device_id)
        return result[:5]


class NotificationPolicyRequest(BaseModel):
    enabled: bool = False
    scope_mode: Literal["all", "selected"] = "all"
    sites: list[str] = Field(default_factory=list, max_length=500)
    groups: list[str] = Field(default_factory=list, max_length=500)
    notify_offline: bool = True
    notify_recovery: bool = True
    failure_threshold: int = Field(default=3, ge=2, le=10)
    reminder_minutes: int = Field(default=0, ge=0, le=1440)

    @field_validator("sites", "groups")
    @classmethod
    def normalize_notification_scope(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            normalized = str(value).strip()
            if not normalized or normalized.casefold() in seen:
                continue
            seen.add(normalized.casefold())
            result.append(normalized[:120])
        return result


class NotificationDestinationRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    provider: Literal["microsoft", "slack", "discord", "generic"] = "generic"
    enabled: bool = True
    webhook_url: str | None = Field(default=None, max_length=4000)
    scope_mode: Literal["all", "selected"] = "all"
    sites: list[str] = Field(default_factory=list, max_length=500)
    groups: list[str] = Field(default_factory=list, max_length=500)
    notify_offline: bool = True
    notify_recovery: bool = True
    notify_reminder: bool = True
    notify_stack_degraded: bool = True
    notify_stack_recovery: bool = True
    notify_ups_on_battery: bool = True
    notify_ups_power_restored: bool = True
    notify_ups_low_battery: bool = True
    notify_ups_unreachable: bool = False

    @field_validator("sites", "groups")
    @classmethod
    def normalize_destination_scope(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            normalized = str(value).strip()
            if not normalized or normalized.casefold() in seen:
                continue
            seen.add(normalized.casefold())
            result.append(normalized[:120])
        return result

    @field_validator("name")
    @classmethod
    def normalize_destination_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Destination name is required")
        return normalized


class SshUserRoleUpdateRequest(BaseModel):
    role: Literal["admin", "power_user", "user"]
    enabled: bool = True


class AccessScopeGroup(BaseModel):
    site: str = Field(min_length=1, max_length=120)
    group: str = Field(min_length=1, max_length=120)

    @field_validator("site", "group")
    @classmethod
    def normalize_scope_value(cls, value: str) -> str:
        return value.strip()


class SshUserAccessUpdateRequest(BaseModel):
    role_id: int = Field(gt=0)
    enabled: bool = True
    scope_mode: Literal["none", "selected", "all"] = "none"
    sites: list[str] = Field(default_factory=list, max_length=500)
    groups: list[AccessScopeGroup] = Field(default_factory=list, max_length=2000)

    @field_validator("sites")
    @classmethod
    def normalize_scope_sites(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        seen: set[str] = set()
        for value in values:
            normalized = str(value or "").strip()[:120]
            key = normalized.casefold()
            if normalized and key not in seen:
                seen.add(key)
                result.append(normalized)
        return result


class AccessRoleUpsertRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=500)
    capabilities: list[str] = Field(default_factory=list, max_length=100)
    allowed_actions: list[str] = Field(default_factory=list, max_length=500)

    @field_validator("name")
    @classmethod
    def normalize_role_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Role name is required")
        return normalized


class AdminMaintenanceRequest(BaseModel):
    audit_retention_days: int = Field(default=180, ge=1, le=3650)
    completed_jobs_retention_days: int = Field(default=90, ge=1, le=3650)

class DeviceFinderRequest(BaseModel):
    query: str = Field(min_length=1, max_length=255)
    search_type: Literal["auto", "ip", "mac", "hostname", "username", "vlan", "profile"] = "auto"
    device_ids: list[int] = Field(default_factory=list, max_length=1000)

    @field_validator("query")
    @classmethod
    def normalize_query(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("A search value is required")
        return normalized


class PortDiagnosticRequest(BaseModel):
    port: str = Field(min_length=3, max_length=32)

    @field_validator("port")
    @classmethod
    def validate_port(cls, value: str) -> str:
        import re
        normalized = value.strip()
        if not re.fullmatch(r"\d+(?:/\d+){1,2}[A-Za-z]?", normalized):
            raise ValueError("Invalid switch port")
        return normalized


class SchedulerCredentialRequest(BaseModel):
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=1, max_length=500)

    @field_validator("username")
    @classmethod
    def normalize_scheduler_username(cls, value: str) -> str:
        return value.strip()


class UnpScheduleRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    enabled: bool = True
    action: Literal["check_unp", "fix_unp"] = "fix_unp"
    run_time: str = Field(default="06:00", min_length=5, max_length=5)
    timezone: str = Field(default="UTC", min_length=1, max_length=120)
    sites: list[str] = Field(default_factory=list, max_length=200)
    groups: list[str] = Field(default_factory=list, max_length=500)
    cycle_delay_seconds: int = Field(default=5, ge=1, le=300)

    @field_validator("name", "timezone")
    @classmethod
    def strip_schedule_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("sites", "groups")
    @classmethod
    def normalize_schedule_scope(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        for value in values:
            item = str(value).strip()
            if item and item not in result:
                result.append(item)
        return result

    @field_validator("run_time")
    @classmethod
    def validate_schedule_time(cls, value: str) -> str:
        import re
        normalized = value.strip()
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", normalized):
            raise ValueError("Run time must use 24-hour HH:MM format")
        return normalized


class FleetAuditRequest(BaseModel):
    audit_type: Literal[
        "thermal_health",
        "fan_cooling",
        "power_supply",
        "poe_capacity",
        "interface_errors",
        "port_flapping",
        "uplink_health",
        "configuration_save",
        "full_switch_health",
    ]
    device_ids: list[int] = Field(min_length=1, max_length=1000)

    @field_validator("device_ids")
    @classmethod
    def normalize_device_ids(cls, values: list[int]) -> list[int]:
        result: list[int] = []
        for value in values:
            item = int(value)
            if item > 0 and item not in result:
                result.append(item)
        if not result:
            raise ValueError("At least one switch is required")
        return result


class AutomationScheduleRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    enabled: bool = True
    action: str = Field(default="fix_unp", min_length=1, max_length=80)
    run_time: str = Field(default="06:00", min_length=5, max_length=5)
    timezone: str = Field(default="UTC", min_length=1, max_length=120)
    sites: list[str] = Field(default_factory=list, max_length=200)
    groups: list[str] = Field(default_factory=list, max_length=500)
    settings: dict[str, object] = Field(default_factory=dict)

    @field_validator("name", "timezone", "action")
    @classmethod
    def strip_automation_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("sites", "groups")
    @classmethod
    def normalize_automation_scope(cls, values: list[str]) -> list[str]:
        result: list[str] = []
        for value in values:
            item = str(value).strip()
            if item and item not in result:
                result.append(item)
        return result

    @field_validator("run_time")
    @classmethod
    def validate_automation_time(cls, value: str) -> str:
        import re
        normalized = value.strip()
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", normalized):
            raise ValueError("Run time must use 24-hour HH:MM format")
        return normalized


class RunbookUpsertRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=1000)
    allow_scheduled: bool = False
    max_targets: int = Field(default=50, ge=1, le=500)
    concurrency: int = Field(default=5, ge=1, le=16)
    failure_policy: Literal["continue", "stop_all"] = "continue"
    steps: list[dict[str, object]] = Field(min_length=1, max_length=40)
    variables: list[dict[str, object]] = Field(default_factory=list, max_length=16)


class FixUnpSafeguardsRequest(BaseModel):
    protected_ports: str = Field(default="1/1/1", max_length=500)
    guest_keywords: str = Field(default="GUEST", max_length=500)
    service_keywords: str = Field(default="VOIP,IPTV", max_length=500)
    max_ports_per_switch: int = Field(default=12, ge=1, le=48)

    @field_validator("protected_ports", "guest_keywords", "service_keywords")
    @classmethod
    def normalize_safeguard_text(cls, value: str) -> str:
        return value.strip()


class VlanMaintenanceSafeguardsRequest(BaseModel):
    protected_ports: str = Field(default="", max_length=1000)
    max_ports_per_switch: int = Field(default=12, ge=1, le=48)
    max_total_ports: int = Field(default=100, ge=1, le=2000)
    trunk_vlan_threshold: int = Field(default=4, ge=2, le=128)
    mac_address_threshold: int = Field(default=8, ge=2, le=2048)

    @field_validator("protected_ports")
    @classmethod
    def normalize_vlan_safeguard_text(cls, value: str) -> str:
        return value.strip()
