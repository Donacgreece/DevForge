# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
from collections import OrderedDict
from typing import Any

from .db import db, utc_now
from .device_finder import parse_lldp, parse_mac_table, parse_unp_users, display_mac
from .port_inventory import (
    merge_port_records,
    parse_interface_alias,
    parse_interface_status,
    parse_lanpower,
)

PORT_PATTERN = re.compile(r"^\d+(?:/\d+){1,2}[A-Za-z]?$", re.I)
COUNTER_NUMBER_RE = re.compile(r"(?<![A-Za-z])(-?\d[\d,]*)")


def validate_port(value: str) -> str:
    port = str(value or "").strip()
    if not PORT_PATTERN.fullmatch(port):
        raise ValueError("Invalid switch port")
    return port


def _slot_for_port(port: str, profile: str) -> str:
    parts = port.split("/")
    if str(profile or "").upper() == "AOS8" and len(parts) >= 3:
        return "/".join(parts[:-1])
    return parts[0] if parts else ""


def _normalize_label(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().strip(":|- ")).lower()


def _last_number(line: str) -> int | None:
    values = COUNTER_NUMBER_RE.findall(line)
    if not values:
        return None
    try:
        return int(values[-1].replace(",", ""))
    except ValueError:
        return None


def parse_error_counters(output: str) -> dict[str, Any]:
    """Extract only diagnostic/error signals from a port counter response.

    OmniSwitch releases format interface counters differently. This parser is
    intentionally conservative. It reports a counter only when the line has a
    recognised error/drop/collision label and a numeric value. Unknown formats
    remain unreported instead of being guessed.
    """
    signals: OrderedDict[str, int] = OrderedDict()
    raw_lines: list[str] = []
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue
        lower = _normalize_label(line)
        diagnostic = any(token in lower for token in (
            "crc", "fcs", "alignment", "input error", "rx error", "receive error",
            "output error", "tx error", "transmit error", "discard", "drop",
            "collision", "undersize", "oversize", "jabber", "fragment",
        ))
        if not diagnostic:
            continue
        value = _last_number(line)
        if value is None:
            continue
        # Keep a compact, human-readable label while preventing duplicate keys.
        label = re.sub(r"\s+", " ", re.sub(r"\s+[-=:|]\s*[-\d, ]+$", "", line)).strip(" |:-")
        label = label[:96] or "Counter"
        key = label
        suffix = 2
        while key in signals:
            key = f"{label} ({suffix})"
            suffix += 1
        signals[key] = value
        raw_lines.append(raw_line.rstrip())

    crc_total = 0
    error_total = 0
    discard_total = 0
    collision_total = 0
    for label, value in signals.items():
        lower = label.lower()
        if any(token in lower for token in ("crc", "fcs", "alignment")):
            crc_total += max(0, value)
        if "error" in lower:
            error_total += max(0, value)
        if any(token in lower for token in ("discard", "drop")):
            discard_total += max(0, value)
        if "collision" in lower:
            collision_total += max(0, value)

    return {
        "signals": [{"name": name, "value": value} for name, value in signals.items()],
        "crc_total": crc_total,
        "error_total": error_total,
        "discard_total": discard_total,
        "collision_total": collision_total,
        "reported": bool(signals),
        "raw_lines": raw_lines[:24],
    }


def _cached_port(device_id: int, port: str) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute(
            "SELECT payload_json FROM port_inventory_snapshots WHERE device_id = ?",
            (device_id,),
        ).fetchone()
    if not row:
        return {}
    try:
        payload = json.loads(row["payload_json"] or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    for item in payload.get("ports") or []:
        if str(item.get("port") or "") == port:
            return dict(item)
    return {}


def _live_port_record(port: str, interface_detail: str, interface_status: str) -> dict[str, Any]:
    detail = parse_interface_alias(interface_detail, source="show interfaces <port>")
    status = parse_interface_status(interface_status, source="show interfaces <port> status")
    merged = merge_port_records(detail, status)
    record = merged.get(port)
    return record.to_dict() if record else {}


def _merge_port_state(cached: dict[str, Any], live: dict[str, Any], poe: dict[str, Any]) -> dict[str, Any]:
    merged = dict(cached or {})
    for key, value in (live or {}).items():
        if value not in (None, "", "unknown", [], {}):
            merged[key] = value
    for key, value in (poe or {}).items():
        if value not in (None, "", "unknown"):
            merged[key] = value
    return merged


def _recent_port_activity(device_id: int, port: str, limit: int = 5) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT j.id AS job_id, j.action, j.requested_by, j.created_at,
                   ji.status, ji.command, ji.started_at, ji.finished_at
            FROM job_items ji
            JOIN jobs j ON j.id = ji.job_id
            WHERE ji.device_id = ? AND ji.port = ? AND j.dry_run = 0
            ORDER BY COALESCE(ji.finished_at, ji.started_at, j.created_at) DESC, ji.id DESC
            LIMIT ?
            """,
            (device_id, port, max(1, min(int(limit), 20))),
        ).fetchall()
    return [
        {
            "job_id": int(row["job_id"]),
            "action": str(row["action"] or ""),
            "requested_by": str(row["requested_by"] or ""),
            "status": str(row["status"] or ""),
            "command": str(row["command"] or ""),
            "created_at": str(row["finished_at"] or row["started_at"] or row["created_at"] or ""),
        }
        for row in rows
    ]


def build_diagnosis(
    *,
    device_id: int,
    port: str,
    profile: str,
    outputs: dict[str, str],
    command_errors: dict[str, str],
) -> dict[str, Any]:
    port = validate_port(port)
    cached = _cached_port(device_id, port)
    live = _live_port_record(
        port,
        outputs.get("interface_detail", ""),
        outputs.get("interface_status", ""),
    )
    slot = _slot_for_port(port, profile)
    poe_rows = parse_lanpower(outputs.get("poe", ""), slot, [port]) if outputs.get("poe") else {}
    state = _merge_port_state(cached, live, poe_rows.get(port, {}))

    mac_records = [record for record in parse_mac_table(outputs.get("mac", "")) if record.get("port") == port]
    unp_records = [record for record in parse_unp_users(outputs.get("unp", "")) if record.get("port") == port]
    lldp_records = [record for record in parse_lldp(outputs.get("lldp", "")) if record.get("port") == port]
    counters = parse_error_counters(outputs.get("counters", ""))

    macs = []
    for record in mac_records + unp_records:
        value = display_mac(record.get("mac", ""))
        if value and value not in macs:
            macs.append(value)
    unp_users = []
    for record in unp_records:
        value = str(record.get("username") or "").strip()
        if value and value not in unp_users:
            unp_users.append(value)
    profiles = []
    for record in unp_records:
        value = str(record.get("profile_name") or record.get("profile") or "").strip()
        if value and value not in profiles:
            profiles.append(value)
    neighbors = []
    for record in lldp_records:
        identity = str(record.get("hostname") or "").strip() or display_mac(record.get("mac", ""))
        if identity and identity not in neighbors:
            neighbors.append(identity)

    admin = str(state.get("admin_state") or "unknown")
    link = str(state.get("link_state") or "unknown")
    poe_state = str(state.get("poe_state") or "unknown")
    poe_power = state.get("poe_power_mw")
    findings: list[dict[str, Any]] = []

    def finding(code: str, severity: str, **params: Any) -> None:
        findings.append({"code": code, "severity": severity, "params": params})

    if admin == "disabled":
        finding("admin_disabled", "info")
    elif admin == "enabled" and link == "down":
        finding("no_physical_link", "attention")
    elif link == "up":
        finding("physical_link_up", "good")

    if counters["crc_total"] > 0:
        finding("crc_errors", "attention", count=counters["crc_total"])
    elif counters["error_total"] > 0:
        finding("interface_errors", "attention", count=counters["error_total"])
    if counters["discard_total"] > 0:
        finding("packet_discards", "attention", count=counters["discard_total"])
    if counters["collision_total"] > 0:
        finding("collisions", "attention", count=counters["collision_total"])

    try:
        poe_power_numeric = int(poe_power) if poe_power is not None else None
    except (TypeError, ValueError):
        poe_power_numeric = None

    if poe_state == "fault":
        finding("poe_fault", "attention")
    elif poe_state == "on" and poe_power_numeric is not None and poe_power_numeric <= 0:
        finding("poe_no_draw", "attention")
    elif poe_state == "on":
        finding("poe_delivering", "good", power=poe_power if poe_power is not None else "")

    if len(macs) > 1:
        finding("multiple_macs", "attention", count=len(macs))
    elif len(macs) == 1:
        finding("endpoint_learned", "good", mac=macs[0])
    elif link == "up" and not neighbors:
        finding("no_endpoint_learned", "info")

    if neighbors:
        finding("lldp_neighbor", "info", count=len(neighbors), neighbor=neighbors[0])
    if unp_users or profiles:
        finding("unp_detected", "info", user=unp_users[0] if unp_users else "", profile=profiles[0] if profiles else "")

    attention_count = sum(1 for item in findings if item["severity"] == "attention")
    if attention_count:
        health = "attention"
    elif link == "up":
        # Optional AOS capabilities may be unavailable on an otherwise healthy
        # port. Keep the health assessment separate from evidence coverage.
        health = "healthy"
    elif command_errors and not any(value not in (None, "", "unknown") for value in (state.get("link_state"), state.get("admin_state"))):
        health = "limited"
    else:
        health = "normal"

    vlans = [str(value) for value in (state.get("vlans") or []) if str(value).strip()]
    return {
        "device_id": device_id,
        "port": port,
        "profile": profile,
        "diagnosed_at": utc_now(),
        "health": health,
        "state": {
            "admin_state": admin,
            "link_state": link,
            "speed": str(state.get("speed") or state.get("detected_speed") or state.get("configured_speed") or ""),
            "duplex": str(state.get("duplex") or state.get("detected_duplex") or state.get("configured_duplex") or ""),
            "vlans": vlans,
            "poe_state": poe_state,
            "poe_oper_status": str(state.get("poe_oper_status") or ""),
            "poe_power_mw": poe_power,
            "poe_max_mw": state.get("poe_max_mw"),
            "alias": str(state.get("alias") or ""),
            "last_link_change_at": str(state.get("last_link_change_at") or ""),
            "observed_link_seconds": state.get("observed_link_seconds"),
        },
        "endpoint": {
            "mac_count": len(macs),
            "mac_addresses": macs[:32],
            "unp_users": unp_users[:16],
            "unp_profiles": profiles[:16],
            "lldp_neighbors": neighbors[:16],
            "mac_records": [record.get("raw", "") for record in mac_records[:24] if record.get("raw")],
            "unp_records": [record.get("raw", "") for record in unp_records[:24] if record.get("raw")],
            "lldp_records": [record.get("raw", "") for record in lldp_records[:24] if record.get("raw")],
        },
        "counters": counters,
        "findings": findings,
        "command_errors": dict(command_errors),
        "recent_activity": _recent_port_activity(device_id, port),
    }
