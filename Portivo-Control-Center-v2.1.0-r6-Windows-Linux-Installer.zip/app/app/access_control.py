# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Iterable

from .db import db
from .profiles import is_read_only_action, public_action_catalog


CAPABILITY_CATALOG: dict[str, dict[str, str]] = {
    # Core access follows the primary Portivo navigation.
    "dashboard.view": {"category": "Core access", "label": "Dashboard", "description": "View fleet health and scoped summary metrics."},
    "devices.view": {"category": "Core access", "label": "Switches", "description": "View switch inventory within the assigned Site/Group scope."},
    "power.view": {"category": "Core access", "label": "Power", "description": "View UPS health, power incidents and switch power-source correlation within scope."},
    "finder.use": {"category": "Core access", "label": "Find Device", "description": "Run live endpoint discovery against scoped switches."},

    # Operational workspaces and read-only diagnostics.
    "devices.live_ports": {"category": "Operations", "label": "Live port data", "description": "Read live interface, VLAN and PoE data from scoped switches."},
    "operations.view": {"category": "Operations", "label": "Operations workspace", "description": "Open Operations and select switches inside the assigned scope."},
    "operations.read": {"category": "Operations", "label": "Read-only CLI actions", "description": "Execute catalog actions classified as read-only."},
    "operations.runbook": {"category": "Operations", "label": "Approved Runbooks", "description": "Execute approved Custom Runbooks within scope."},
    "audits.view": {"category": "Operations", "label": "Fleet Audit history", "description": "View Fleet Audit results that are entirely within scope."},
    "audits.run": {"category": "Operations", "label": "Run Fleet Audits", "description": "Launch read-only Fleet Audits against scoped switches."},

    # Observability is intentionally separate from configuration rights.
    "notifications.view": {"category": "Observability", "label": "Notifications", "description": "View switch, stack and power notification state inside the assigned scope."},
    "activity.jobs": {"category": "Observability", "label": "Jobs", "description": "View Jobs whose targets are within the assigned scope."},
    "activity.audit": {"category": "Observability", "label": "Audit Log", "description": "View authorization and activity evidence permitted for the role."},

    # Secondary tools exposed through More.
    "command_library.view": {"category": "Tools", "label": "Command Library", "description": "View only the command templates that the role may execute."},
    "drivers.view": {"category": "Tools", "label": "Drivers", "description": "View the built-in switch, UPS and future infrastructure driver reference."},

    # Governed inventory and power administration. Power changes are split so
    # a role can, for example, verify telemetry or assign switches without
    # receiving authority to delete a UPS asset.
    "inventory.manage": {"category": "Administration", "label": "Manage switches", "description": "Add, edit, import and remove switch records inside scope."},
    "power.create": {"category": "Administration", "label": "Add UPS", "description": "Create new UPS assets inside the assigned scope."},
    "power.edit": {"category": "Administration", "label": "Edit UPS", "description": "Edit UPS identity, monitoring profile and driver settings inside scope."},
    "power.delete": {"category": "Administration", "label": "Delete UPS", "description": "Delete UPS assets inside scope and unassign their protected switches."},
    "power.verify": {"category": "Administration", "label": "Verify UPS telemetry", "description": "Run read-only SNMPv3 UPS telemetry verification."},
    "power.assign": {"category": "Administration", "label": "Assign power sources", "description": "Assign or remove scoped switches from a monitored UPS power source."},

    # Explicit high-trust interfaces stay isolated from normal operations.
    "terminal.use": {"category": "Advanced access", "label": "Interactive terminal", "description": "Use the unrestricted interactive SSH terminal on scoped switches."},
    "custom_cli.use": {"category": "Advanced access", "label": "Custom CLI", "description": "Submit manually authored CLI commands to scoped switches."},
}


# Change actions are deliberately explicit for constrained presets. Read-only
# actions are governed by operations.read and therefore do not need to be
# duplicated in these lists.
HELPDESK_CHANGE_ACTIONS = {
    "interface_alias",
    "interface_cycle",
    "poe_cycle",
}

OPERATOR_CHANGE_ACTIONS = {
    *HELPDESK_CHANGE_ACTIONS,
    "poe_enable",
    "poe_disable",
    "fix_unp",
    "vlan_port_maintenance",
    "save_config",
}

BUILTIN_ROLE_DEFINITIONS: dict[str, dict[str, Any]] = {
    "admin": {
        "name": "Administrator",
        "description": "Full platform, inventory and network access everywhere.",
        "capabilities": {"*"},
        "allowed_actions": {"*"},
        "scope_required": False,
        "global_role": True,
    },
    "power_user": {
        "name": "Power User",
        "description": "Full switch operations and raw CLI access across the fleet, without platform administration.",
        "capabilities": {
            "dashboard.view", "devices.view", "devices.live_ports", "finder.use",
            "operations.view", "operations.read", "operations.runbook",
            "audits.view", "audits.run", "activity.jobs", "activity.audit",
            "notifications.view", "power.view", "command_library.view", "drivers.view", "inventory.manage",
            "power.create", "power.edit", "power.delete", "power.verify", "power.assign",
            "terminal.use", "custom_cli.use",
        },
        "allowed_actions": {"*"},
        "scope_required": False,
        "global_role": True,
    },
    "site_admin": {
        "name": "Site Administrator",
        "description": "Full governed operational access, restricted to assigned Sites and Groups.",
        "capabilities": {
            "dashboard.view", "devices.view", "devices.live_ports", "finder.use",
            "operations.view", "operations.read", "operations.runbook",
            "audits.view", "audits.run", "activity.jobs", "activity.audit",
            "notifications.view", "power.view", "command_library.view", "drivers.view", "inventory.manage",
            "power.create", "power.edit", "power.delete", "power.verify", "power.assign",
            "terminal.use", "custom_cli.use",
        },
        "allowed_actions": {"*"},
        "scope_required": True,
        "global_role": False,
    },
    "operator": {
        "name": "Operator",
        "description": "Operational troubleshooting, governed changes and approved Runbooks inside assigned scope.",
        "capabilities": {
            "dashboard.view", "devices.view", "devices.live_ports", "finder.use",
            "operations.view", "operations.read", "operations.runbook",
            "audits.view", "audits.run", "activity.jobs", "notifications.view", "power.view",
            "command_library.view", "drivers.view",
        },
        "allowed_actions": OPERATOR_CHANGE_ACTIONS,
        "scope_required": True,
        "global_role": False,
    },
    "helpdesk": {
        "name": "Helpdesk",
        "description": "Scoped visibility and basic port support: alias, interface restart and PoE restart.",
        "capabilities": {
            "dashboard.view", "devices.view", "devices.live_ports", "finder.use",
            "operations.view", "operations.read", "activity.jobs", "command_library.view", "drivers.view", "power.view",
        },
        "allowed_actions": HELPDESK_CHANGE_ACTIONS,
        "scope_required": True,
        "global_role": False,
    },
    "read_only": {
        "name": "Read Only",
        "description": "Scoped inventory and activity visibility only. No live CLI execution or console access.",
        "capabilities": {"dashboard.view", "devices.view", "audits.view", "activity.jobs", "notifications.view", "power.view", "drivers.view"},
        "allowed_actions": set(),
        "scope_required": True,
        "global_role": False,
    },
}


@dataclass(frozen=True)
class AccessContext:
    role_id: int | None
    role_key: str
    role_name: str
    built_in: bool
    capabilities: frozenset[str]
    allowed_actions: frozenset[str]
    scope_mode: str
    sites: tuple[str, ...]
    groups: tuple[tuple[str, str], ...]
    scope_required: bool
    global_role: bool

    def has(self, capability: str) -> bool:
        return "*" in self.capabilities or capability in self.capabilities

    def can_action(self, action: str) -> bool:
        if action == "custom_command":
            return self.has("custom_cli.use") and ("*" in self.allowed_actions or action in self.allowed_actions)
        if is_read_only_action(action):
            return self.has("operations.read") or action in self.allowed_actions or "*" in self.allowed_actions
        return "*" in self.allowed_actions or action in self.allowed_actions

    def scope_payload(self) -> dict[str, Any]:
        return {
            "mode": self.scope_mode,
            "sites": list(self.sites),
            "groups": [{"site": site, "group": group} for site, group in self.groups],
            "required": self.scope_required,
            "global": self.global_role,
        }


def _decode_json(value: Any, fallback: Any) -> Any:
    try:
        decoded = json.loads(str(value or ""))
        return decoded
    except (TypeError, ValueError, json.JSONDecodeError):
        return fallback


def normalize_scope(value: Any, *, default_mode: str = "none") -> dict[str, Any]:
    raw = value if isinstance(value, dict) else _decode_json(value, {})
    mode = str(raw.get("mode") or default_mode).strip().lower()
    if mode not in {"none", "selected", "all"}:
        mode = default_mode
    sites: list[str] = []
    seen_sites: set[str] = set()
    for item in raw.get("sites") or []:
        site = str(item or "").strip()
        key = site.casefold()
        if site and key not in seen_sites:
            seen_sites.add(key)
            sites.append(site[:120])
    groups: list[dict[str, str]] = []
    seen_groups: set[tuple[str, str]] = set()
    for item in raw.get("groups") or []:
        if isinstance(item, dict):
            site = str(item.get("site") or "").strip()
            group = str(item.get("group") or "").strip()
        else:
            # Compatibility with an early internal representation where only
            # the group label was stored. Bind it only when exactly one site is
            # selected so the scope cannot silently expand across Sites.
            site = sites[0] if len(sites) == 1 else ""
            group = str(item or "").strip()
        if not site or not group:
            continue
        key = (site.casefold(), group.casefold())
        if key in seen_groups:
            continue
        seen_groups.add(key)
        groups.append({"site": site[:120], "group": group[:120]})
    if mode == "all":
        sites, groups = [], []
    if mode == "selected" and not sites:
        mode = "none"
        groups = []
    return {"mode": mode, "sites": sites, "groups": groups}


def _role_from_row(row: Any) -> tuple[dict[str, Any], bool]:
    key = str(row["role_key"] or "read_only")
    built_in = bool(row["built_in"])
    if built_in and key in BUILTIN_ROLE_DEFINITIONS:
        definition = BUILTIN_ROLE_DEFINITIONS[key]
        return {
            "id": int(row["id"]), "key": key, "name": definition["name"],
            "description": definition["description"],
            "capabilities": set(definition["capabilities"]),
            "allowed_actions": set(definition["allowed_actions"]),
            "scope_required": bool(definition["scope_required"]),
            "global_role": bool(definition["global_role"]),
        }, True
    raw_capabilities = {str(item) for item in (_decode_json(row["capabilities_json"], []) or []) if str(item)}
    # v1.9.0-r7 compatibility: early Power Infrastructure builds used one
    # coarse power.manage permission. Expand it in-memory into the new granular
    # rights so existing Custom Roles never lose access during an update.
    if "power.manage" in raw_capabilities:
        raw_capabilities.update({"power.create", "power.edit", "power.delete", "power.verify", "power.assign"})
        raw_capabilities.discard("power.manage")
    capabilities = {item for item in raw_capabilities if item in CAPABILITY_CATALOG}
    allowed_actions = {
        str(item) for item in (_decode_json(row["allowed_actions_json"], []) or [])
        if str(item)
    }
    return {
        "id": int(row["id"]), "key": key, "name": str(row["name"] or key),
        "description": str(row["description"] or ""), "capabilities": capabilities,
        "allowed_actions": allowed_actions, "scope_required": True, "global_role": False,
    }, False


def _role_row_by_id(role_id: int | None) -> Any | None:
    if not role_id:
        return None
    with db() as conn:
        return conn.execute("SELECT * FROM access_roles WHERE id = ?", (int(role_id),)).fetchone()


def _fallback_role_key(legacy_role: str) -> str:
    normalized = str(legacy_role or "user")
    if normalized == "admin":
        return "admin"
    if normalized == "power_user":
        return "power_user"
    return "read_only"


def _role_row_by_key(role_key: str) -> Any | None:
    with db() as conn:
        return conn.execute("SELECT * FROM access_roles WHERE role_key = ?", (role_key,)).fetchone()


def access_context_for_profile(profile: dict[str, Any]) -> AccessContext:
    row = _role_row_by_id(int(profile.get("access_role_id") or 0))
    if row is None:
        row = _role_row_by_key(_fallback_role_key(str(profile.get("role") or "user")))
    if row is None:
        # init_db seeds built-ins, but fail safely if a damaged database is
        # opened before repair.
        definition = BUILTIN_ROLE_DEFINITIONS["read_only"]
        role = {
            "id": None, "key": "read_only", "name": definition["name"],
            "description": definition["description"], "capabilities": set(definition["capabilities"]),
            "allowed_actions": set(), "scope_required": True, "global_role": False,
        }
        built_in = True
    else:
        role, built_in = _role_from_row(row)
    scope = normalize_scope(profile.get("scope_json"), default_mode="all" if role["global_role"] else "none")
    if role["global_role"]:
        scope = {"mode": "all", "sites": [], "groups": []}
    return AccessContext(
        role_id=role["id"], role_key=role["key"], role_name=role["name"], built_in=built_in,
        capabilities=frozenset(role["capabilities"]), allowed_actions=frozenset(role["allowed_actions"]),
        scope_mode=scope["mode"], sites=tuple(scope["sites"]),
        groups=tuple((str(item["site"]), str(item["group"])) for item in scope["groups"]),
        scope_required=bool(role["scope_required"]), global_role=bool(role["global_role"]),
    )


def access_context_for_user(user: dict[str, Any]) -> AccessContext:
    if str(user.get("auth_type") or "") == "admin":
        definition = BUILTIN_ROLE_DEFINITIONS["admin"]
        return AccessContext(
            role_id=None, role_key="admin", role_name=definition["name"], built_in=True,
            capabilities=frozenset({"*"}), allowed_actions=frozenset({"*"}), scope_mode="all",
            sites=(), groups=(), scope_required=False, global_role=True,
        )
    return access_context_for_profile(user)


def device_in_scope(access: AccessContext, device: dict[str, Any] | Any) -> bool:
    if access.scope_mode == "all" or access.global_role:
        return True
    if access.scope_mode != "selected":
        return False
    site = str(device["site"] if hasattr(device, "keys") and "site" in device.keys() else device.get("site", "")).strip()
    group = str(device["group_name"] if hasattr(device, "keys") and "group_name" in device.keys() else device.get("group_name", "")).strip()
    selected_sites = {value.casefold() for value in access.sites}
    if site.casefold() not in selected_sites:
        return False
    if not access.groups:
        return True
    # Group restrictions are evaluated per Site. This allows a grant such as
    # "Site A / Access Layer" together with "Site B / all groups" in one assignment:
    # a selected Site that has no explicit group pairs remains fully visible.
    site_groups = {g.casefold() for s, g in access.groups if s.casefold() == site.casefold()}
    if not site_groups:
        return True
    return group.casefold() in site_groups


def filter_devices(access: AccessContext, rows: Iterable[Any]) -> list[Any]:
    return [row for row in rows if device_in_scope(access, row)]


def scoped_device_ids(access: AccessContext, *, enabled_only: bool = False) -> set[int]:
    where = " WHERE enabled = 1" if enabled_only else ""
    with db() as conn:
        rows = conn.execute(f"SELECT id, site, group_name FROM devices{where}").fetchall()
    return {int(row["id"]) for row in rows if device_in_scope(access, row)}


def role_public_payload(row: Any) -> dict[str, Any]:
    role, built_in = _role_from_row(row)
    return {
        "id": role["id"], "key": role["key"], "name": role["name"], "description": role["description"],
        "built_in": built_in, "scope_required": role["scope_required"], "global_role": role["global_role"],
        "capabilities": sorted(role["capabilities"]), "allowed_actions": sorted(role["allowed_actions"]),
    }


def list_roles() -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT * FROM access_roles ORDER BY built_in DESC, id ASC, name COLLATE NOCASE").fetchall()
    return [role_public_payload(row) for row in rows]


def role_by_id(role_id: int) -> dict[str, Any] | None:
    row = _role_row_by_id(role_id)
    return role_public_payload(row) if row else None


def save_custom_role(*, role_id: int | None, name: str, description: str, capabilities: list[str], allowed_actions: list[str], actor: str) -> dict[str, Any]:
    normalized_name = str(name or "").strip()
    if not normalized_name:
        raise ValueError("Role name is required")
    if len(normalized_name) > 80:
        raise ValueError("Role name is too long")
    normalized_caps_set = {str(item) for item in capabilities if str(item) in CAPABILITY_CATALOG}
    catalog = public_action_catalog()
    valid_actions = set(catalog.keys())
    normalized_actions_set = {str(item) for item in allowed_actions if str(item) in valid_actions}

    # Normalize capability dependencies so a Custom Role cannot be saved in a
    # contradictory state where an execution permission exists but its parent
    # workspace is hidden. These are additive safety dependencies only.
    if "devices.live_ports" in normalized_caps_set or "finder.use" in normalized_caps_set or "inventory.manage" in normalized_caps_set:
        normalized_caps_set.add("devices.view")
    if "operations.read" in normalized_caps_set or "operations.runbook" in normalized_caps_set or "custom_cli.use" in normalized_caps_set or normalized_actions_set:
        normalized_caps_set.add("operations.view")
    if "audits.run" in normalized_caps_set:
        normalized_caps_set.add("audits.view")
    if normalized_caps_set.intersection({"power.create", "power.edit", "power.delete", "power.verify", "power.assign"}):
        normalized_caps_set.add("power.view")
    if "terminal.use" in normalized_caps_set:
        normalized_caps_set.update({"devices.view", "devices.live_ports"})
    if "activity.audit" in normalized_caps_set:
        normalized_caps_set.add("activity.jobs")

    # Raw CLI has a dedicated capability gate and must not be smuggled in merely
    # by selecting the Custom CLI catalog row.
    if "custom_cli.use" not in normalized_caps_set:
        normalized_actions_set.discard("custom_command")

    normalized_caps = sorted(normalized_caps_set)
    normalized_actions = sorted(normalized_actions_set)
    now_sql = "CURRENT_TIMESTAMP"
    with db() as conn:
        if role_id:
            existing = conn.execute("SELECT * FROM access_roles WHERE id = ?", (int(role_id),)).fetchone()
            if not existing:
                raise LookupError("Role not found")
            if bool(existing["built_in"]):
                raise ValueError("Built-in roles cannot be modified")
            conn.execute(
                f"""UPDATE access_roles SET name=?, description=?, capabilities_json=?, allowed_actions_json=?, updated_at={now_sql}, updated_by=? WHERE id=?""",
                (normalized_name, str(description or "").strip()[:500], json.dumps(normalized_caps), json.dumps(normalized_actions), actor, int(role_id)),
            )
            target_id = int(role_id)
        else:
            key_seed = "custom"
            index = 1
            while conn.execute("SELECT 1 FROM access_roles WHERE role_key = ?", (f"{key_seed}_{index}",)).fetchone():
                index += 1
            cursor = conn.execute(
                f"""INSERT INTO access_roles(role_key,name,description,built_in,capabilities_json,allowed_actions_json,created_at,updated_at,updated_by)
                VALUES(?,?,?,0,?,?,{now_sql},{now_sql},?)""",
                (f"{key_seed}_{index}", normalized_name, str(description or "").strip()[:500], json.dumps(normalized_caps), json.dumps(normalized_actions), actor),
            )
            target_id = int(cursor.lastrowid)
        row = conn.execute("SELECT * FROM access_roles WHERE id = ?", (target_id,)).fetchone()
    return role_public_payload(row)


def delete_custom_role(role_id: int) -> None:
    with db() as conn:
        row = conn.execute("SELECT * FROM access_roles WHERE id = ?", (int(role_id),)).fetchone()
        if not row:
            raise LookupError("Role not found")
        if bool(row["built_in"]):
            raise ValueError("Built-in roles cannot be deleted")
        count = int(conn.execute("SELECT COUNT(*) AS count FROM ssh_user_profiles WHERE access_role_id = ?", (int(role_id),)).fetchone()["count"])
        if count:
            raise ValueError(f"Role is assigned to {count} SSH user(s)")
        conn.execute("DELETE FROM access_roles WHERE id = ?", (int(role_id),))


def action_catalog_for_access(access: AccessContext) -> dict[str, Any]:
    catalog = public_action_catalog()
    return {key: value for key, value in catalog.items() if access.can_action(key) or key == "custom_runbook" and access.has("operations.runbook")}


def capability_catalog_payload() -> list[dict[str, str]]:
    return [{"id": key, **value} for key, value in CAPABILITY_CATALOG.items()]
