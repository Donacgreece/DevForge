# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
import threading
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from .db import db, utc_now
from .device_finder import parse_lldp
from .port_inventory import infer_slots, load_inventory_snapshot, merge_port_records, parse_interface_alias, parse_interface_status
from .port_troubleshooter import parse_error_counters
from .ssh_runner import (
    SSHAuthenticationFailure,
    SSHConnectionFailure,
    SSHTimeoutFailure,
    command_session,
)
from .ssh_coordinator import SSHDeviceBusyError
from .ale_cli import poe_status_command, poe_status_commands, power_status_commands


# Fleet Audits are intentionally read-only. Each audit uses one serialized SSH
# session per switch and only the commands needed for that audit.
AUDIT_DEFINITIONS: dict[str, dict[str, Any]] = {
    "thermal_health": {
        "label": "Thermal Health Audit",
        "category": "Hardware health",
        "description": "Evaluate reported temperatures and device-reported thermal thresholds/status.",
        "commands": {"temperature": "show temperature"},
        "policy": "Vendor/device-reported thresholds take priority. Numeric temperatures without a verified threshold are reported, not guessed.",
        "weight": 1,
    },
    "fan_cooling": {
        "label": "Fan & Cooling Audit",
        "category": "Hardware health",
        "description": "Check fans and correlate cooling faults with thermal state.",
        "commands": {"fans": "show fan", "temperature": "show temperature"},
        "policy": "Explicit fan fault/down states are findings. Optional or absent fan bays are not treated as failures without a fault state.",
        "weight": 2,
    },
    "power_supply": {
        "label": "Power Supply Health Audit",
        "category": "Hardware health",
        "description": "Check PSU state and identify failed or degraded power redundancy.",
        "commands": {"power": "show powersupply"},
        "policy": "Only explicit failed/fault/down power-supply states are escalated. Empty optional bays are informational.",
        "weight": 1,
    },
    "poe_capacity": {
        "label": "PoE Capacity Audit",
        "category": "Power over Ethernet",
        "description": "Review PoE delivery, per-port fault state, PSU context, Ethernet link state and available power budget.",
        "commands": {
            "poe": "ALE slot-qualified PoE status",
            "power": "show powersupply",
            "status": "show interfaces status",
            "interfaces": "show interfaces",
        },
        "policy": "Portivo operational policy: warning at >=80% budget utilization, critical at >=90%, plus explicit deny/fault conditions. PoE faults are correlated with Ethernet link and PSU evidence when reported.",
        "weight": 4,
    },
    "interface_errors": {
        "label": "Interface Error Audit",
        "category": "Interfaces",
        "description": "Find CRC/FCS, interface errors, drops, discards and collisions and correlate them with live port state and alias.",
        "commands": {
            "errors": "show interfaces counters errors",
            "status": "show interfaces status",
            "interfaces": "show interfaces",
        },
        "policy": "Non-zero physical/error counters are surfaced conservatively. The report separates CRC/FCS, errors, drops/discards and collisions and correlates them with current port state when reported.",
        "weight": 3,
    },
    "port_flapping": {
        "label": "Port Stability Audit",
        "category": "Interfaces",
        "description": "Detect repeated link-state transitions and correlate unstable ports with their current state and alias.",
        "commands": {
            "log": "show log swlog",
            "status": "show interfaces status",
            "interfaces": "show interfaces",
        },
        "policy": "Portivo operational policy over the available log window: warning at >=4 observed link transitions, critical at >=10. Current port state is reported separately from historical log evidence.",
        "weight": 3,
    },
    "uplink_health": {
        "label": "Uplink Health Audit",
        "category": "Connectivity",
        "description": "Check managed-switch LLDP uplinks for state, media degradation and error evidence.",
        "commands": {
            "interfaces": "show interfaces",
            "status": "show interfaces status",
            "errors": "show interfaces counters errors",
            "lldp": "show lldp remote-system",
        },
        "policy": "Only LLDP neighbors matching managed Portivo switches are treated as infrastructure uplinks.",
        "weight": 4,
    },
    "configuration_save": {
        "label": "Configuration Save Audit",
        "category": "Configuration safety",
        "description": "Identify working/certified or running/persistent configuration that is not synchronized.",
        "commands": {
            "status": "show configuration status",
            "running": "show running-directory",
            "working": "show working-directory",
            "certified": "show certified-directory",
        },
        "policy": "Explicit NOT SYNCHRONIZED / unsaved / working-only evidence is treated as pending persistent configuration.",
        "weight": 4,
    },
    "full_switch_health": {
        "label": "Full Switch Health Audit",
        "category": "Executive health",
        "description": "Correlate hardware, environment, power, interfaces, PoE, configuration and control-plane health into one score.",
        "commands": {
            "health": "show health",
            "temperature": "show temperature",
            "fans": "show fan",
            "power": "show powersupply",
            "poe": "ALE slot-qualified PoE status",
            "cpu": "show cpu",
            "memory": "show memory",
            "errors": "show interfaces counters errors",
            "status": "show interfaces status",
            "interfaces": "show interfaces",
            "config": "show configuration status",
        },
        "policy": "Health score is evidence-based. Unknown/unsupported metrics reduce coverage, not the score. Critical findings cap the score.",
        "weight": 11,
    },
}

SEVERITY_RANK = {"healthy": 0, "info": 1, "warning": 2, "critical": 3, "unavailable": 4}
SEVERITY_ORDER = ("critical", "warning", "healthy", "info", "unavailable")
PORT_RE = re.compile(r"\b\d+(?:/\d+){1,2}[A-Za-z]?\b", re.I)
NUMBER_RE = re.compile(r"-?\d+(?:\.\d+)?")
TEMP_RE = re.compile(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[cC]\b")
PERCENT_RE = re.compile(r"(\d+(?:\.\d+)?)\s*%")
POWER_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(mW|W|kW)\b", re.I)

# Global guard across all simultaneous audit runs. Per-run pools remain bounded,
# while this semaphore prevents multiple users from multiplying SSH load on a
# large fleet. It intentionally applies only while a worker is actively
# collecting one switch.
_AUDIT_WORKER_LIMIT = 8
_AUDIT_WORKER_SEMAPHORE = threading.BoundedSemaphore(_AUDIT_WORKER_LIMIT)


def public_audit_catalog() -> list[dict[str, Any]]:
    return [
        {
            "id": key,
            "label": value["label"],
            "category": value["category"],
            "description": value["description"],
            "policy": value["policy"],
            "command_count": len(value["commands"]),
            "weight": value["weight"],
        }
        for key, value in AUDIT_DEFINITIONS.items()
    ]


def _worst(*values: str) -> str:
    candidates = [value for value in values if value]
    return max(candidates, key=lambda value: SEVERITY_RANK.get(value, 0), default="healthy")


def _line_status(line: str) -> str:
    value = line.casefold()
    if any(token in value for token in ("critical", "shutdown", "overheat", "failed", "failure", "fault", "alarm", "error")):
        return "critical"
    if any(token in value for token in ("warning", "warn", "degraded", "high", "down", "denied")):
        return "warning"
    if any(token in value for token in ("normal", "healthy", "ok", "operational", "up", "good", "active")):
        return "healthy"
    return "info"


def _temperature_analysis(output: str) -> dict[str, Any]:
    """Parse AOS thermal output without inventing vendor thresholds.

    Modern OmniSwitch releases commonly expose a table with Current, Range,
    Danger, Thresh and Status columns. Older/variant releases may instead
    expose temperatures with units or free-form threshold lines. The parser
    accepts both forms and treats the switch-reported status as authoritative.
    """
    sensors: list[dict[str, Any]] = []
    global_warning: float | None = None
    global_critical: float | None = None
    explicit = ""
    raw_lines = [line.strip() for line in str(output or "").replace("\r", "").split("\n") if line.strip()]

    # AOS table rows. Range can itself contain spaces/numbers, therefore the
    # last two numeric columns before the textual status are captured as
    # Danger and Thresh respectively.
    table_row = re.compile(
        r"^(?P<sensor>\S+)\s+"
        r"(?P<current>-?\d+(?:\.\d+)?)\s+"
        r"(?P<range>.+?)\s+"
        r"(?P<danger>-?\d+(?:\.\d+)?)\s+"
        r"(?P<thresh>-?\d+(?:\.\d+)?)\s+"
        r"(?P<status>(?:UNDER|OVER|ABOVE|AT|NORMAL|OK|WARNING|WARN|DANGER|CRITICAL|SHUTDOWN|ALARM|HIGH|LOW).*)$",
        re.I,
    )

    for line in raw_lines:
        lower = line.casefold()
        if lower.startswith("show temperature"):
            continue
        if "chassis/device" in lower and "current" in lower and "status" in lower:
            continue
        if set(line) <= set("- =+|"):
            continue

        table_match = table_row.match(line)
        if table_match:
            current = float(table_match.group("current"))
            danger = float(table_match.group("danger"))
            thresh = float(table_match.group("thresh"))
            status_text = table_match.group("status").strip()
            status_lower = status_text.casefold()

            # The CLI status remains the primary signal. Numeric comparisons
            # supplement it using the switch-reported Danger/Thresh columns.
            if any(token in status_lower for token in ("danger", "critical", "shutdown", "alarm")) or current >= danger:
                zone = "critical"
            elif any(token in status_lower for token in ("over", "above", "warning", "warn", "high")) or current >= thresh:
                zone = "warning"
            else:
                zone = "normal"

            sensors.append({
                "name": table_match.group("sensor")[:120],
                "celsius": current,
                "reported_range": table_match.group("range").strip()[:80],
                "warning_threshold_c": thresh,
                "danger_threshold_c": danger,
                "status": status_text[:100],
                "zone": zone,
                "threshold_source": "device",
            })
            explicit = _worst(explicit or "healthy", zone)
            continue

        temps = [float(value) for value in TEMP_RE.findall(line)]
        if not temps:
            # Preserve an explicit thermal alarm/status even when the release
            # does not print a numeric value on the same line.
            if any(token in lower for token in ("overheat", "thermal alarm", "temperature alarm")):
                explicit = _worst(explicit or "healthy", "critical")
            continue
        if "warning" in lower or "warn" in lower:
            global_warning = temps[-1]
            continue
        if any(token in lower for token in ("critical", "shutdown", "danger threshold", "max threshold", "high threshold")):
            global_critical = temps[-1]
            continue
        label = re.sub(TEMP_RE, "", line).strip(" :-|\t") or f"Sensor {len(sensors)+1}"
        sensors.append({"name": label[:120], "celsius": temps[0], "threshold_source": "global" if (global_warning is not None or global_critical is not None) else "none"})
        line_severity = _line_status(line)
        if line_severity in {"warning", "critical"}:
            explicit = _worst(explicit or "healthy", line_severity)

    severity = explicit or "healthy"
    above_warning = 0
    above_critical = 0
    threshold_verified = False
    for sensor in sensors:
        current = float(sensor["celsius"])
        warning_threshold = sensor.get("warning_threshold_c", global_warning)
        danger_threshold = sensor.get("danger_threshold_c", global_critical)
        if warning_threshold is not None or danger_threshold is not None:
            threshold_verified = True
        if sensor.get("zone") not in {"warning", "critical", "normal"}:
            if danger_threshold is not None and current >= float(danger_threshold):
                sensor["zone"] = "critical"
            elif warning_threshold is not None and current >= float(warning_threshold):
                sensor["zone"] = "warning"
            elif warning_threshold is not None or danger_threshold is not None:
                sensor["zone"] = "normal"
            else:
                sensor["zone"] = "observed"
        if sensor["zone"] == "critical":
            above_critical += 1
            severity = _worst(severity, "critical")
        elif sensor["zone"] == "warning":
            above_warning += 1
            severity = _worst(severity, "warning")

    if sensors:
        coverage = "verified" if (threshold_verified or explicit) else "observed_only"
    else:
        coverage = "not_reported"
        severity = explicit or "info"
    return {
        "severity": severity,
        "sensors": sensors[:32],
        "warning_threshold_c": global_warning,
        "critical_threshold_c": global_critical,
        "above_warning": above_warning,
        "above_critical": above_critical,
        "coverage": coverage,
        "max_celsius": max((sensor["celsius"] for sensor in sensors), default=None),
    }

def _fan_analysis(output: str) -> dict[str, Any]:
    rows: list[dict[str, str]] = []
    failed = 0
    warning = 0
    in_fan_table = False
    for line in str(output or "").replace("\r", "").split("\n"):
        clean = line.strip()
        lower = clean.casefold()
        if not clean or lower.startswith("show fan"):
            continue
        if "fan" in lower and any(token in lower for token in ("status", "state", "tray", "slot", "speed")):
            in_fan_table = True
            # Header-only lines are not evidence rows.
            if not any(token in lower for token in ("failed", "fault", "error", "stopped", "normal", "ok", "up", "running", "degraded", "slow")):
                continue
        if set(clean) <= set("- =+|"):
            continue
        if "fan" not in lower and not in_fan_table:
            continue
        # In a detected table, only accept rows that contain a recognizable
        # operational state so unrelated trailing CLI text is not classified.
        if "fan" not in lower and not any(token in lower for token in ("failed", "failure", "fault", "error", "stopped", "slow", "degraded", "warning", "normal", "ok", "up", "running", "active", "not present", "absent", "empty")):
            continue
        status = _line_status(clean)
        if any(token in lower for token in ("failed", "failure", "fault", "error", "stopped")):
            failed += 1
            status = "critical"
        elif any(token in lower for token in ("slow", "degraded", "warning", "warn")):
            warning += 1
            status = "warning"
        elif any(token in lower for token in ("not present", "absent", "empty")):
            status = "info"
        elif any(token in lower for token in ("normal", "ok", "up", "running", "active", "operational")):
            status = "healthy"
        rows.append({"line": clean[:180], "status": status})
    severity = "critical" if failed else "warning" if warning else "healthy" if rows and any(row["status"] == "healthy" for row in rows) else "info"
    return {"severity": severity, "failed": failed, "warning": warning, "fans": rows[:32], "reported": bool(rows)}

def _power_supply_analysis(output: str) -> dict[str, Any]:
    """Parse AOS power-supply tables into operator-readable component rows.

    Known AOS formats include columns similar to ``Chassis/PS Power Type Status
    Location``. Unknown variants are retained as raw switch evidence instead of
    being guessed.
    """
    rows: list[dict[str, Any]] = []
    failed = 0
    healthy = 0
    present = 0
    total_power_w = 0.0
    in_power_table = False
    structured = re.compile(
        r"^(?P<chassis>\d+(?:/\d+)?)\s+"
        r"(?P<power>\d+(?:\.\d+)?)\s+"
        r"(?P<type>AC|DC|N/A|NA|-)\s+"
        r"(?P<state>\S+)"
        r"(?:\s+(?P<location>.+))?$", re.I
    )
    for line in str(output or "").replace("\r", "").split("\n"):
        clean = line.strip()
        lower = clean.casefold()
        if not clean or lower.startswith("show power"):
            continue
        if set(clean) <= set("- =+|"):
            continue
        if "chassis/ps" in lower and "status" in lower:
            in_power_table = True
            continue
        if lower.startswith("total ps") or lower.startswith("total "):
            continue

        match = structured.match(clean) if in_power_table else None
        if match:
            state_text = match.group("state").strip()
            state_lower = state_text.casefold()
            location = (match.group("location") or "").strip()
            power_w = float(match.group("power"))
            total_power_w += max(0.0, power_w)
            if any(token in state_lower for token in ("failed", "failure", "fault", "error", "down", "unplug", "unplugged", "degraded")):
                status = "critical"
                failed += 1
            elif any(token in state_lower for token in ("ok", "up", "normal", "good", "operational")):
                status = "healthy"
                healthy += 1
            elif any(token in state_lower for token in ("absent", "empty", "not-present", "notpresent")):
                status = "info"
            else:
                status = _line_status(state_text)
            if status != "info":
                present += 1
            rows.append({
                "id": match.group("chassis"),
                "power_w": power_w,
                "type": match.group("type"),
                "switch_state": state_text,
                "location": location or "-",
                "status": status,
                "line": clean[:220],
            })
            continue

        if not any(token in lower for token in ("power", "supply", "psu")) and not in_power_table:
            continue
        if any(token in lower for token in ("not present", "absent", "empty")):
            rows.append({"id": "-", "power_w": None, "type": "-", "switch_state": clean, "location": "-", "status": "info", "line": clean[:220]})
            continue
        if any(token in lower for token in ("failed", "failure", "fault", "error", "down", "unplug", "unplugged", "degraded")):
            status = "critical"
            failed += 1
            present += 1
        elif re.search(r"\b(?:ok|up|normal|good|operational|present)\b", lower):
            status = "healthy"
            healthy += 1
            present += 1
        else:
            status = "info"
        rows.append({"id": "-", "power_w": None, "type": "-", "switch_state": clean, "location": "-", "status": status, "line": clean[:220]})

    if failed and healthy == 0 and present:
        severity = "critical"
    elif failed:
        severity = "warning"
    elif healthy:
        severity = "healthy"
    else:
        severity = "info"
    return {
        "severity": severity,
        "failed": failed,
        "healthy": healthy,
        "present": present,
        "total_reported_power_w": round(total_power_w, 2) if total_power_w else None,
        "reported": bool(rows),
        "supplies": rows[:32],
    }

def _to_watts(value: float, unit: str) -> float:
    unit = unit.casefold()
    if unit == "mw":
        return value / 1000.0
    if unit == "kw":
        return value * 1000.0
    return value


def _poe_analysis(
    output: str,
    *,
    interface_status: str = "",
    interface_detail: str = "",
    power_output: str = "",
) -> dict[str, Any]:
    """Summarize PoE budget and preserve per-port switch evidence.

    Supports both slot-local port numbers (``2``) and full AOS interface names
    (``1/1/2``). This distinction matters because some OS6560/AOS builds print
    the full interface in ``show lanpower`` while other families print only the
    port number for a slot-qualified command.
    """
    budget_values: list[float] = []
    used_from_ports_w = 0.0
    port_rows = 0
    available_values: list[float] = []
    explicit_used_values: list[float] = []
    raw = str(output or "")
    ports: list[dict[str, Any]] = []
    generic_fault_evidence: list[str] = []
    source_commands: list[str] = []
    current_slot = ""

    # First column may be ``2`` or ``1/1/2``. The next two columns are mW.
    table_row = re.compile(r"^\s*(?P<port>\d+(?:/\d+){0,2})\s+(?P<max>\d+)\s+(?P<used>\d+)\s+(?P<rest>.+)$")
    total_budget_available = re.compile(r"(?i)(\d+(?:\.\d+)?)\s*(?:watts?|w)\s+total\s+power\s+budget\s+available")
    total_budget_used = re.compile(r"(?i)(\d+(?:\.\d+)?)\s*(?:watts?|w)\s+total\s+power\s+budget\s+used")
    actual_consumed = re.compile(r"(?i)(\d+(?:\.\d+)?)\s*(?:watts?|w)\s+actual\s+power\s+consumed")
    slot_budget = re.compile(r"(?i)slot\s+\S+\s+max\s+watts?\s+(\d+(?:\.\d+)?)")
    explicit_remaining = re.compile(r"(?i)(\d+(?:\.\d+)?)\s*(?:watts?|w)\s+(?:power\s+)?(?:remaining|free)")
    marker_re = re.compile(r"^###\s+(show\s+lanpower(?:\s+slot)?\s+\S+|show\s+lanpower)\s*$", re.I)
    slot_from_command = re.compile(r"(?i)^show\s+lanpower(?:\s+slot)?\s+(\S+)\s*$")

    interface_records = merge_port_records(
        parse_interface_alias(interface_detail or "", source="show interfaces"),
        parse_interface_status(interface_status or "", source="show interfaces status"),
    )

    for line in raw.replace("\r", "").split("\n"):
        clean = line.strip()
        lower = clean.casefold()
        if not clean:
            continue
        marker = marker_re.match(clean)
        if marker:
            command = marker.group(1).strip()
            if command not in source_commands:
                source_commands.append(command)
            slot_match = slot_from_command.match(command)
            current_slot = slot_match.group(1) if slot_match else ""
            continue
        if set(clean) <= set("- =+|"):
            continue
        if "port" in lower and "maximum" in lower and "actual" in lower and "status" in lower:
            continue

        row = table_row.match(clean)
        if row and not any(token in lower for token in ("total", "budget", "supply")):
            printed_port = row.group("port")
            maximum_mw = int(row.group("max"))
            actual_mw = int(row.group("used"))
            rest = row.group("rest").strip()
            tokens = rest.split()
            status_text = tokens[0] if tokens else rest
            consumed = 1 if tokens else 0
            if len(tokens) >= 2 and f"{tokens[0]} {tokens[1]}".casefold() in {"powered on", "powered off", "power on", "power off", "not present"}:
                status_text = f"{tokens[0]} {tokens[1]}"
                consumed = 2
            status_lower = status_text.casefold()
            priority = tokens[consumed] if len(tokens) > consumed else ""
            admin_state = tokens[consumed + 1] if len(tokens) > consumed + 1 else ""
            extra = " ".join(tokens[consumed + 2:]) if len(tokens) > consumed + 2 else ""

            if "/" in printed_port:
                interface = printed_port
                port_number = printed_port.split("/")[-1]
                slot_value = "/".join(printed_port.split("/")[:-1])
            else:
                port_number = printed_port
                slot_value = current_slot
                interface = f"{current_slot}/{printed_port}" if current_slot else printed_port

            used_from_ports_w += max(0, actual_mw) / 1000.0
            port_rows += 1
            is_fault = any(token in status_lower for token in ("fault", "error", "short", "overload"))
            is_denied = any(token in status_lower for token in ("deny", "denied"))
            is_powered = ("powered" in status_lower and "off" not in status_lower) or actual_mw > 0
            if is_fault:
                port_severity, state = "critical", "fault"
            elif is_denied:
                port_severity, state = "warning", "denied"
            elif is_powered:
                port_severity, state = "healthy", "powered"
            elif any(token in status_lower for token in ("off", "undefined", "disabled")):
                port_severity, state = "info", "not_powering"
            else:
                port_severity, state = "info", "reported"

            record = interface_records.get(interface)
            current = record.to_dict() if record else {}
            location = interface or (f"Slot {slot_value} / Port {port_number}" if slot_value else f"Port {port_number}")
            ports.append({
                "location": location,
                "interface": interface,
                "slot": slot_value,
                "port": port_number,
                "maximum_mw": maximum_mw,
                "used_mw": actual_mw,
                "maximum_w": round(maximum_mw / 1000.0, 2),
                "used_w": round(actual_mw / 1000.0, 2),
                "status": status_text[:80],
                "raw_status": rest[:180],
                "priority": priority,
                "poe_admin": admin_state,
                "extra": extra[:80],
                "state": state,
                "severity": port_severity,
                "link_state": str(current.get("link_state") or "unknown"),
                "admin_state": str(current.get("admin_state") or "unknown"),
                "alias": str(current.get("alias") or ""),
                "detected_speed": str(current.get("detected_speed") or ""),
            })
            continue

        match = total_budget_available.search(clean)
        if match:
            available_values.append(float(match.group(1))); continue
        match = total_budget_used.search(clean)
        if match:
            explicit_used_values.append(float(match.group(1))); continue
        match = actual_consumed.search(clean)
        if match:
            explicit_used_values.append(float(match.group(1))); continue
        match = slot_budget.search(clean)
        if match:
            budget_values.append(float(match.group(1))); continue
        match = explicit_remaining.search(clean)
        if match:
            available_values.append(float(match.group(1)))

        power_values = [(_to_watts(float(value), unit), unit) for value, unit in POWER_RE.findall(clean)]
        if power_values:
            watts = power_values[0][0]
            if any(token in lower for token in ("maximum power", "max power", "total power budget")) and not any(token in lower for token in ("used", "consumed", "available")):
                budget_values.append(watts)
            elif any(token in lower for token in ("available", "remaining", "free")) and "total power budget available" not in lower:
                available_values.append(watts)

        if any(token in lower for token in ("fault", "error", "denied", "deny")) and not any(token in lower for token in ("status", "header", "fault count")):
            generic_fault_evidence.append(clean[:220])

    budget = sum(budget_values) if budget_values else None
    used = used_from_ports_w if port_rows else (sum(explicit_used_values) if explicit_used_values else None)
    available = sum(available_values) if available_values else None
    if budget is None and used is not None and available is not None:
        budget = used + available
    if used is None and budget is not None and available is not None:
        used = max(0.0, budget - available)
    if available is None and budget is not None and used is not None:
        available = max(0.0, budget - used)

    fault_ports = [item for item in ports if item.get("state") == "fault"]
    denied_ports = [item for item in ports if item.get("state") == "denied"]
    powered_ports = [item for item in ports if item.get("state") == "powered"]
    faults = len(fault_ports) + len(generic_fault_evidence)
    denied = len(denied_ports)
    utilization = (used / budget * 100.0) if budget and used is not None and budget > 0 else None
    severity = "critical" if faults else "warning" if denied else "healthy"
    if utilization is not None:
        severity = _worst(severity, "critical" if utilization >= 90 else "warning" if utilization >= 80 else "healthy")
    if utilization is None and not (faults or denied or ports):
        severity = "info"

    ethernet_up_with_poe_fault = sum(1 for item in fault_ports if item.get("link_state") == "up")
    psu = _power_supply_analysis(power_output) if power_output else {"severity": "info", "supplies": [], "reported": False}
    return {
        "severity": severity,
        "budget_w": round(budget, 2) if budget is not None else None,
        "used_w": round(used, 2) if used is not None else None,
        "available_w": round(available, 2) if available is not None else None,
        "utilization_percent": round(utilization, 1) if utilization is not None else None,
        "faults": faults,
        "denied": denied,
        "fault_ports": fault_ports,
        "denied_ports": denied_ports,
        "powered_ports": powered_ports,
        "ports": ports[:256],
        "generic_fault_evidence": generic_fault_evidence[:32],
        "powered_ports_observed": len(powered_ports),
        "port_rows_observed": port_rows,
        "ethernet_up_with_poe_fault": ethernet_up_with_poe_fault,
        "psu_context": psu,
        "source_commands": source_commands,
        "reported": bool(port_rows or budget_values or available_values or faults or denied),
    }


def _counter_category(label: str) -> str:
    lower = label.casefold()
    if any(token in lower for token in ("crc", "fcs", "alignment")):
        return "crc_fcs"
    if any(token in lower for token in ("discard", "drop")):
        return "drops_discards"
    if "collision" in lower:
        return "collisions"
    if any(token in lower for token in ("error", "jabber", "fragment", "undersize", "oversize")):
        return "errors"
    return "other"


def _extract_counter_pairs(line: str) -> list[tuple[str, int]]:
    # Supports lines such as ``CRC Error Frames: 12, Alignments Err: 0``.
    pairs: list[tuple[str, int]] = []
    for match in re.finditer(r"([A-Za-z][A-Za-z0-9 /_.()-]{2,}?)\s*[:=]\s*([0-9][0-9,]*)", line):
        label = re.sub(r"\s+", " ", match.group(1)).strip(" ,|:-")
        if not any(token in label.casefold() for token in ("crc", "fcs", "align", "error", "discard", "drop", "collision", "jabber", "fragment", "undersize", "oversize")):
            continue
        pairs.append((label[:96], int(match.group(2).replace(",", ""))))
    return pairs


def _interface_error_analysis(output: str, *, interface_status: str = "", interface_detail: str = "") -> dict[str, Any]:
    aggregate = parse_error_counters(output)
    records = merge_port_records(
        parse_interface_alias(interface_detail or "", source="show interfaces"),
        parse_interface_status(interface_status or "", source="show interfaces status"),
    )
    port_metrics: dict[str, dict[str, Any]] = {}
    current_port = ""
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        match = PORT_RE.search(line)
        if match:
            current_port = match.group(0)
        lower = line.casefold()
        if not current_port or not any(token in lower for token in ("crc", "fcs", "align", "error", "discard", "drop", "collision", "jabber", "fragment", "undersize", "oversize")):
            continue
        item = port_metrics.setdefault(current_port, {
            "port": current_port, "crc_fcs": 0, "errors": 0, "drops_discards": 0, "collisions": 0, "other": 0, "signals": [], "evidence": []
        })
        pairs = _extract_counter_pairs(PORT_RE.sub(" ", line, count=1))
        if not pairs:
            value_match = re.findall(r"\b[0-9][0-9,]*\b", PORT_RE.sub(" ", line, count=1))
            if value_match:
                label = re.sub(r"\b[0-9][0-9,]*\b", " ", PORT_RE.sub(" ", line, count=1))
                pairs = [(re.sub(r"\s+", " ", label).strip(" ,|:-")[:96] or "Counter", int(value_match[-1].replace(",", "")))]
        for label, value in pairs:
            category = _counter_category(label)
            item[category] += max(0, value)
            item["signals"].append({"name": label, "value": value, "category": category})
        if pairs:
            item["evidence"].append(line[:220])

    affected: list[dict[str, Any]] = []
    category_totals = {"crc_fcs": 0, "errors": 0, "drops_discards": 0, "collisions": 0, "other": 0}
    for port, item in port_metrics.items():
        total = sum(int(item[key]) for key in category_totals)
        if total <= 0:
            continue
        record = records.get(port)
        state = record.to_dict() if record else {}
        item.update({
            "count": total,
            "alias": str(state.get("alias") or ""),
            "link_state": str(state.get("link_state") or "unknown"),
            "admin_state": str(state.get("admin_state") or "unknown"),
            "detected_speed": str(state.get("detected_speed") or ""),
        })
        for key in category_totals:
            category_totals[key] += int(item[key])
        affected.append(item)
    affected.sort(key=lambda item: int(item["count"]), reverse=True)
    total = sum(category_totals.values())
    if total <= 0:
        total = int(aggregate["crc_total"] + aggregate["error_total"] + aggregate["discard_total"] + aggregate["collision_total"])
    severity = "critical" if total >= 1000 or any(int(item["count"]) >= 500 for item in affected) else "warning" if total > 0 else "healthy" if aggregate["reported"] else "info"
    return {
        "severity": severity,
        "crc_total": category_totals["crc_fcs"] or aggregate["crc_total"],
        "error_total": category_totals["errors"] or aggregate["error_total"],
        "discard_total": category_totals["drops_discards"] or aggregate["discard_total"],
        "collision_total": category_totals["collisions"] or aggregate["collision_total"],
        "other_error_total": category_totals["other"],
        "affected_ports": affected[:80],
        "reported": aggregate["reported"] or bool(port_metrics),
    }

def _flap_analysis(output: str, *, interface_status: str = "", interface_detail: str = "") -> dict[str, Any]:
    events: dict[str, list[str]] = defaultdict(list)
    records = merge_port_records(
        parse_interface_alias(interface_detail or "", source="show interfaces"),
        parse_interface_status(interface_status or "", source="show interfaces status"),
    )
    for line in str(output or "").replace("\r", "").split("\n"):
        lower = line.casefold()
        if not any(token in lower for token in ("link", "interface", "port")):
            continue
        if not any(token in lower for token in (" up", " down", "up ", "down ", "state")):
            continue
        match = PORT_RE.search(line)
        if not match:
            continue
        events[match.group(0)].append(line.strip()[:220])
    flapping = []
    for port, lines in events.items():
        count = len(lines)
        if count >= 4:
            record = records.get(port)
            state = record.to_dict() if record else {}
            flapping.append({
                "port": port,
                "events": count,
                "samples": lines[-8:],
                "alias": str(state.get("alias") or ""),
                "link_state": str(state.get("link_state") or "unknown"),
                "admin_state": str(state.get("admin_state") or "unknown"),
                "detected_speed": str(state.get("detected_speed") or ""),
            })
    flapping.sort(key=lambda item: item["events"], reverse=True)
    max_events = max((item["events"] for item in flapping), default=0)
    severity = "critical" if max_events >= 10 else "warning" if flapping else "healthy" if events else "info"
    return {
        "severity": severity,
        "flapping_ports": flapping[:60],
        "ports_with_link_events": len(events),
        "total_link_events": sum(len(lines) for lines in events.values()),
        "log_window_note": "Available switch software-log window",
    }

def _parse_interface_error_ports(output: str) -> dict[str, int]:
    analysis = _interface_error_analysis(output)
    return {str(item.get("port") or ""): int(item.get("count") or 0) for item in analysis.get("affected_ports") or [] if str(item.get("port") or "")}


def _uplink_analysis(outputs: dict[str, str], managed_names: set[str]) -> dict[str, Any]:
    lldp = parse_lldp(outputs.get("lldp", ""))
    interface_records = merge_port_records(
        parse_interface_alias(outputs.get("interfaces", ""), source="show interfaces"),
        parse_interface_status(outputs.get("status", ""), source="show interfaces status"),
    )
    error_analysis = _interface_error_analysis(outputs.get("errors", ""), interface_status=outputs.get("status", ""), interface_detail=outputs.get("interfaces", ""))
    error_by_port = {str(item.get("port") or ""): item for item in error_analysis.get("affected_ports") or []}
    uplinks = []
    for record in lldp:
        hostname = str(record.get("hostname") or "").strip()
        normalized = hostname.casefold()
        candidate_aliases = {normalized, normalized.split(".")[0]}
        if managed_names and not any(alias in managed_names for alias in candidate_aliases if alias):
            continue
        port = str(record.get("port") or "")
        interface = interface_records.get(port)
        data = interface.to_dict() if interface else {}
        link = str(data.get("link_state") or "unknown")
        admin = str(data.get("admin_state") or "unknown")
        detected_speed = str(data.get("detected_speed") or "")
        configured_speed = str(data.get("configured_speed") or "")
        error_item = error_by_port.get(port) or {}
        errors = int(error_item.get("count") or 0)
        severity = "healthy"
        reasons: list[str] = []
        if admin == "disabled" or link == "down":
            severity = "critical"
            reasons.append("Uplink is administratively disabled or physical link is down")
        if errors > 0:
            severity = _worst(severity, "warning")
            reasons.append(f"{errors} error/drop counter evidence")
        if detected_speed and configured_speed and detected_speed.isdigit() and configured_speed.isdigit() and int(detected_speed) < int(configured_speed):
            severity = _worst(severity, "warning")
            reasons.append(f"Detected media {detected_speed} below configured {configured_speed}")
        uplinks.append({
            "port": port,
            "neighbor": hostname or str(record.get("mac") or "Unknown"),
            "neighbor_mac": str(record.get("mac") or ""),
            "alias": str(data.get("alias") or ""),
            "admin": admin,
            "link": link,
            "detected_speed": detected_speed,
            "configured_speed": configured_speed,
            "error_evidence": errors,
            "crc_fcs": int(error_item.get("crc_fcs") or 0),
            "errors": int(error_item.get("errors") or 0),
            "drops_discards": int(error_item.get("drops_discards") or 0),
            "collisions": int(error_item.get("collisions") or 0),
            "severity": severity,
            "reasons": reasons,
        })
    severity = "healthy" if uplinks else "info"
    for item in uplinks:
        severity = _worst(severity, item["severity"])
    return {
        "severity": severity,
        "uplinks": uplinks[:96],
        "managed_uplink_count": len(uplinks),
        "lldp_neighbors_observed": len(lldp),
        "reported": bool(lldp),
    }

def _configuration_analysis(outputs: dict[str, str]) -> dict[str, Any]:
    joined = "\n".join(str(outputs.get(key, "")) for key in ("status", "running", "working", "certified"))
    lower = joined.casefold()
    unsaved_tokens = (
        "not synchronized", "not synchronised", "unsynchronized", "unsynchronised",
        "configuration modified", "unsaved", "working directory", "working configuration",
    )
    synchronized_tokens = ("synchronized", "synchronised", "certified", "running directory")
    evidence = [line.strip()[:220] for line in joined.replace("\r", "").split("\n") if line.strip() and any(token in line.casefold() for token in unsaved_tokens + synchronized_tokens)]
    explicit_unsaved = any(token in lower for token in unsaved_tokens[:5])
    # "working directory" alone is not enough to prove unsaved state; only use it as evidence.
    if explicit_unsaved:
        severity = "warning"
        synchronized = False
    elif "synchronized" in lower or "synchronised" in lower:
        severity = "healthy"
        synchronized = True
    else:
        severity = "info"
        synchronized = None
    return {"severity": severity, "synchronized": synchronized, "evidence": evidence[:20], "reported": bool(joined.strip())}


def _parse_percent_metric(output: str) -> float | None:
    values = []
    for line in str(output or "").splitlines():
        lower = line.casefold()
        if any(token in lower for token in ("cpu", "memory", "utilization", "usage", "used")):
            values.extend(float(value) for value in PERCENT_RE.findall(line))
    return max(values) if values else None


def _full_health_analysis(outputs: dict[str, str]) -> dict[str, Any]:
    thermal = _temperature_analysis(outputs.get("temperature", ""))
    fans = _fan_analysis(outputs.get("fans", ""))
    power = _power_supply_analysis(outputs.get("power", ""))
    poe = _poe_analysis(
        outputs.get("poe", ""),
        interface_status=outputs.get("status", ""),
        interface_detail=outputs.get("interfaces", ""),
        power_output=outputs.get("power", ""),
    )
    errors = _interface_error_analysis(outputs.get("errors", ""), interface_status=outputs.get("status", ""), interface_detail=outputs.get("interfaces", ""))
    config = _configuration_analysis({"status": outputs.get("config", "")})
    cpu = _parse_percent_metric(outputs.get("cpu", ""))
    memory = _parse_percent_metric(outputs.get("memory", ""))
    health_text = str(outputs.get("health", ""))
    health_severity = "critical" if any(token in health_text.casefold() for token in ("critical", "fault", "failed", "alarm")) else "warning" if any(token in health_text.casefold() for token in ("warning", "degraded")) else "healthy" if health_text.strip() else "info"
    if cpu is not None:
        health_severity = _worst(health_severity, "critical" if cpu >= 95 else "warning" if cpu >= 85 else "healthy")
    if memory is not None:
        health_severity = _worst(health_severity, "critical" if memory >= 95 else "warning" if memory >= 90 else "healthy")

    components = {
        "health": health_severity,
        "thermal": thermal["severity"],
        "fans": fans["severity"],
        "power": power["severity"],
        "poe": poe["severity"],
        "interfaces": errors["severity"],
        "configuration": config["severity"],
    }
    component_reported = {
        "health": bool(health_text.strip()),
        "thermal": thermal.get("coverage") != "not_reported",
        "fans": bool(fans.get("reported")),
        "power": bool(power.get("reported")),
        "poe": bool(poe.get("reported")),
        "interfaces": bool(errors.get("reported")),
        "configuration": bool(config.get("reported")),
        "cpu": cpu is not None,
        "memory": memory is not None,
    }
    reported_count = sum(1 for value in component_reported.values() if value)
    coverage_percent = round(reported_count / max(1, len(component_reported)) * 100.0, 1)
    score = 100
    for severity in components.values():
        score -= {"critical": 28, "warning": 10, "info": 0, "healthy": 0}.get(severity, 0)
    if cpu is not None and cpu >= 85:
        score -= 8 if cpu < 95 else 18
    if memory is not None and memory >= 90:
        score -= 8 if memory < 95 else 18
    score = max(0, min(100, score))
    overall = max(components.values(), key=lambda value: SEVERITY_RANK.get(value, 0))
    if overall == "critical":
        score = min(score, 59)
    elif overall == "warning":
        score = min(score, 84)
    return {
        "severity": overall,
        "score": score,
        "cpu_percent": cpu,
        "memory_percent": memory,
        "components": components,
        "component_reported": component_reported,
        "coverage_percent": coverage_percent,
        "thermal": thermal,
        "fans": fans,
        "power": power,
        "poe": poe,
        "interfaces": errors,
        "configuration": config,
    }


def analyze_audit(audit_type: str, outputs: dict[str, str], managed_names: set[str]) -> dict[str, Any]:
    if audit_type == "thermal_health":
        return _temperature_analysis(outputs.get("temperature", ""))
    if audit_type == "fan_cooling":
        fan = _fan_analysis(outputs.get("fans", ""))
        thermal = _temperature_analysis(outputs.get("temperature", ""))
        severity = _worst(fan["severity"], thermal["severity"])
        if fan["failed"] and thermal["severity"] in {"warning", "critical"}:
            severity = "critical"
        return {"severity": severity, "fans": fan, "thermal": thermal}
    if audit_type == "power_supply":
        return _power_supply_analysis(outputs.get("power", ""))
    if audit_type == "poe_capacity":
        return _poe_analysis(
            outputs.get("poe", ""),
            interface_status=outputs.get("status", ""),
            interface_detail=outputs.get("interfaces", ""),
            power_output=outputs.get("power", ""),
        )
    if audit_type == "interface_errors":
        return _interface_error_analysis(outputs.get("errors", ""), interface_status=outputs.get("status", ""), interface_detail=outputs.get("interfaces", ""))
    if audit_type == "port_flapping":
        return _flap_analysis(outputs.get("log", ""), interface_status=outputs.get("status", ""), interface_detail=outputs.get("interfaces", ""))
    if audit_type == "uplink_health":
        return _uplink_analysis(outputs, managed_names)
    if audit_type == "configuration_save":
        return _configuration_analysis(outputs)
    if audit_type == "full_switch_health":
        return _full_health_analysis(outputs)
    raise ValueError(f"Unsupported fleet audit: {audit_type}")


def _summary_for(audit_type: str, analysis: dict[str, Any]) -> str:
    severity = str(analysis.get("severity") or "info")
    if audit_type == "thermal_health":
        max_c = analysis.get("max_celsius")
        if max_c is not None:
            return f"Max {max_c:.1f} C · {analysis.get('coverage', 'observed')}"
        return "Temperature not reported"
    if audit_type == "fan_cooling":
        return f"{analysis.get('fans', {}).get('failed', 0)} fan fault(s) · thermal {analysis.get('thermal', {}).get('severity', 'unknown')}"
    if audit_type == "power_supply":
        return f"{analysis.get('failed', 0)} PSU fault(s) · {analysis.get('healthy', 0)} healthy"
    if audit_type == "poe_capacity":
        util = analysis.get("utilization_percent")
        faults = int(analysis.get("faults") or 0)
        denied = int(analysis.get("denied") or 0)
        budget = analysis.get("budget_w")
        if faults:
            suffix = f" · denied {denied}"
            if budget is not None:
                suffix += f" · budget {float(budget):.1f} W"
            return f"{faults} PoE port fault(s) reported by the switch{suffix}"
        if denied:
            return f"{denied} PoE port(s) denied power" + (f" · utilization {float(util):.1f}%" if util is not None else "")
        if util is not None:
            return f"PoE budget utilization {float(util):.1f}%"
        return "PoE state reported without calculable budget utilization"
    if audit_type == "interface_errors":
        return f"{len(analysis.get('affected_ports') or [])} affected port(s) · CRC {analysis.get('crc_total', 0)}"
    if audit_type == "port_flapping":
        return f"{len(analysis.get('flapping_ports') or [])} unstable port(s) in available log window"
    if audit_type == "uplink_health":
        affected = sum(1 for item in analysis.get("uplinks") or [] if item.get("severity") in {"warning", "critical"})
        return f"{analysis.get('managed_uplink_count', 0)} managed uplink(s) · {affected} require attention"
    if audit_type == "configuration_save":
        sync = analysis.get("synchronized")
        return "Persistent configuration synchronized" if sync is True else "Unsaved/persistent mismatch detected" if sync is False else "Synchronization state not reported"
    if audit_type == "full_switch_health":
        return f"Health score {analysis.get('score', 0)}/100 · {severity}"
    return severity.title()


def create_audit_run(audit_type: str, devices: list[dict[str, Any]], requested_by: str) -> int:
    if audit_type not in AUDIT_DEFINITIONS:
        raise ValueError("Unsupported fleet audit")
    now = utc_now()
    scope = [{"id": int(device["id"]), "name": str(device.get("name") or ""), "host": str(device.get("host") or "")} for device in devices]
    with db() as conn:
        cur = conn.execute(
            """
            INSERT INTO fleet_audit_runs(
                audit_type, status, target_count, requested_by, scope_json, created_at
            ) VALUES(?, 'queued', ?, ?, ?, ?)
            """,
            (audit_type, len(devices), requested_by, json.dumps(scope, ensure_ascii=False), now),
        )
        return int(cur.lastrowid)


def _save_item(run_id: int, device: dict[str, Any], *, severity: str, score: int | None, summary: str, details: dict[str, Any], command_errors: dict[str, str], error: str = "") -> None:
    now = utc_now()
    with db() as conn:
        conn.execute(
            """
            INSERT INTO fleet_audit_items(
                run_id, device_id, device_name, host, site, group_name, model, profile,
                severity, score, summary, details_json, command_errors_json, error, finished_at
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id, int(device["id"]), str(device.get("name") or ""), str(device.get("host") or ""),
                str(device.get("site") or ""), str(device.get("group_name") or ""), str(device.get("model") or ""),
                str(device.get("profile") or ""), severity, score, summary,
                json.dumps(details, ensure_ascii=False), json.dumps(command_errors, ensure_ascii=False), error, now,
            ),
        )


def _execute_first_supported(session: Any, commands: list[str], *, read_timeout: float | None = None) -> tuple[str, str, str]:
    """Run read-only command alternatives until one succeeds with useful output.

    Returns ``(output, command_used, error)``. A rejected compatibility alias is
    not surfaced when a later supported command succeeds.
    """
    failures: list[str] = []
    for command in commands:
        result = session.execute(command, read_timeout=read_timeout)
        if result.ok and str(result.output or "").strip():
            return str(result.output or ""), command, ""
        if not result.ok:
            failures.append(f"{command}: {result.error or 'rejected'}")
        elif not str(result.output or "").strip():
            failures.append(f"{command}: no output")
    return "", "", " | ".join(failures)[:800]


def _power_commands(profile: str) -> list[str]:
    return list(power_status_commands(profile))


def _log_commands(profile: str) -> list[str]:
    # ``show log swlog`` is the preferred software-log view. Some older AOS
    # releases expose the same evidence through the broader ``show log`` form.
    return ["show log swlog", "show log"] if profile == "AOS6" else ["show log swlog", "show log"]


def _poe_slots_from_cache(device: dict[str, Any]) -> list[str]:
    try:
        snapshot = load_inventory_snapshot(int(device["id"]))
    except Exception:
        snapshot = None
    if not snapshot:
        return []
    ports = [str(item.get("port") or "") for item in (snapshot.get("ports") or []) if str(item.get("port") or "").strip()]
    return infer_slots(ports, str(device.get("profile") or "AOS8")) if ports else []


def _collect_poe_output(session: Any, device: dict[str, Any]) -> tuple[str, str]:
    """Collect per-slot PoE tables without opening extra SSH sessions.

    AOS requires a slot-qualified ``show lanpower`` form on many platforms.
    Prefer the existing live-inventory cache to discover slots. If no cache is
    available, perform one read-only interface-status query and infer slots.
    """
    profile = str(device.get("profile") or "AOS8")
    slots = _poe_slots_from_cache(device)
    discovery_error = ""
    if not slots:
        status = session.execute("show interfaces status")
        if status.ok and status.output:
            parsed = parse_interface_status(status.output, source="show interfaces status")
            slots = infer_slots(parsed.keys(), profile)
        elif not status.ok:
            discovery_error = status.error or "Unable to discover PoE slots"

    outputs: list[str] = []
    failures: list[str] = []
    for slot in slots:
        accepted = False
        variant_failures: list[str] = []
        for command in poe_status_commands(profile, slot):
            result = session.execute(command)
            if result.ok and str(result.output or "").strip():
                outputs.append(f"### {command}\n{result.output}")
                accepted = True
                break
            variant_failures.append(f"{command}: {result.error or 'rejected'}")
        if not accepted:
            failures.extend(variant_failures)

    if outputs:
        return "\n\n".join(outputs), ""

    # ALE documents PoE monitoring as a slot-qualified query. Do not fall back
    # to the bare `show lanpower` form because AOS 6/8 platforms can reject it
    # as incomplete.
    messages = [message for message in (discovery_error, *failures) if message]
    return "", " | ".join(messages)[:800] or "PoE information was not reported"


def _collect_audit_outputs(session: Any, audit_type: str, device: dict[str, Any]) -> tuple[dict[str, str], dict[str, str], list[str]]:
    outputs: dict[str, str] = {}
    errors: dict[str, str] = {}
    used_commands: list[str] = []
    profile = str(device.get("profile") or "AOS8")
    commands = AUDIT_DEFINITIONS[audit_type]["commands"]
    for key, command in commands.items():
        timeout = 35 if audit_type in {"port_flapping", "full_switch_health"} else None
        if key == "poe":
            output, error = _collect_poe_output(session, device)
            if output:
                outputs[key] = output
                for marker in re.findall(r"(?m)^###\s+(show\s+lanpower[^\r\n]*)$", output):
                    command_used = marker.strip()
                    if command_used and command_used not in used_commands:
                        used_commands.append(command_used)
                if not used_commands:
                    used_commands.append("ALE slot-qualified PoE status query")
            if error:
                errors[key] = error
            continue
        if key == "power":
            output, _used, error = _execute_first_supported(session, _power_commands(profile), read_timeout=timeout)
            if output:
                outputs[key] = output
            if _used and _used not in used_commands:
                used_commands.append(_used)
            if error:
                errors[key] = error
            continue
        if key == "log":
            output, _used, error = _execute_first_supported(session, _log_commands(profile), read_timeout=timeout)
            if output:
                outputs[key] = output
            if _used and _used not in used_commands:
                used_commands.append(_used)
            if error:
                errors[key] = error
            continue
        result = session.execute(command, read_timeout=timeout)
        if result.output:
            outputs[key] = result.output
        if result.ok and command not in used_commands:
            used_commands.append(command)
        if not result.ok:
            errors[key] = result.error or "Command not supported or rejected"
    return outputs, errors, used_commands


def _audit_device(run_id: int, audit_type: str, device: dict[str, Any], credentials: dict[str, str], managed_names: set[str]) -> None:
    target = dict(device)
    target.update(credentials)
    outputs: dict[str, str] = {}
    command_errors: dict[str, str] = {}
    used_commands: list[str] = []
    try:
        with _AUDIT_WORKER_SEMAPHORE:
            with command_session(target, operation=f"fleet audit {audit_type}", lock_timeout=20.0) as session:
                outputs, command_errors, used_commands = _collect_audit_outputs(session, audit_type, device)
        analysis = analyze_audit(audit_type, outputs, managed_names)
        if used_commands:
            existing = [str(value) for value in (analysis.get("source_commands") or []) if str(value).strip()]
            analysis["source_commands"] = list(dict.fromkeys(existing + used_commands))
        severity = str(analysis.get("severity") or "info")
        if not outputs and command_errors:
            severity = "unavailable"
        score = analysis.get("score")
        score = int(score) if isinstance(score, (int, float)) else None
        _save_item(
            run_id, device,
            severity=severity,
            score=score,
            summary=_summary_for(audit_type, analysis),
            details=analysis,
            command_errors=command_errors,
        )
    except (SSHDeviceBusyError, SSHAuthenticationFailure, SSHTimeoutFailure, SSHConnectionFailure) as exc:
        _save_item(run_id, device, severity="unavailable", score=None, summary=str(exc), details={}, command_errors={}, error=str(exc))
    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        _save_item(run_id, device, severity="unavailable", score=None, summary=message, details={}, command_errors={}, error=message)


def _update_run_counts(run_id: int, *, status: str | None = None, finished: bool = False) -> None:
    with db() as conn:
        rows = conn.execute("SELECT severity FROM fleet_audit_items WHERE run_id = ?", (run_id,)).fetchall()
        counts = Counter(str(row["severity"] or "unavailable") for row in rows)
        values: list[Any] = [
            len(rows), counts.get("healthy", 0), counts.get("info", 0), counts.get("warning", 0),
            counts.get("critical", 0), counts.get("unavailable", 0),
        ]
        assignments = "completed_count=?, healthy_count=?, info_count=?, warning_count=?, critical_count=?, unavailable_count=?"
        if status is not None:
            assignments += ", status=?"
            values.append(status)
        if finished:
            assignments += ", finished_at=?"
            values.append(utc_now())
        values.append(run_id)
        conn.execute(f"UPDATE fleet_audit_runs SET {assignments} WHERE id=?", values)


def run_fleet_audit(run_id: int, audit_type: str, devices: list[dict[str, Any]], credentials: dict[str, str]) -> None:
    with db() as conn:
        conn.execute("UPDATE fleet_audit_runs SET status='running', started_at=? WHERE id=?", (utc_now(), run_id))
        all_rows = conn.execute("SELECT name, host FROM devices WHERE enabled=1").fetchall()
    managed_names: set[str] = set()
    for row in all_rows:
        for value in (str(row["name"] or ""), str(row["host"] or "")):
            normalized = value.casefold().strip()
            if normalized:
                managed_names.add(normalized)
                managed_names.add(normalized.split(".")[0])

    max_workers = 6 if audit_type == "full_switch_health" else 8
    try:
        with ThreadPoolExecutor(max_workers=min(max_workers, max(1, len(devices))), thread_name_prefix="portivo-audit") as pool:
            futures = [pool.submit(_audit_device, run_id, audit_type, device, credentials, managed_names) for device in devices]
            for _future in as_completed(futures):
                try:
                    _future.result()
                except Exception:
                    # _audit_device is defensive and persists its own errors. Keep the run alive if an unexpected worker error escapes.
                    pass
                _update_run_counts(run_id)
        _update_run_counts(run_id, status="completed", finished=True)
    except Exception as exc:
        with db() as conn:
            conn.execute(
                "UPDATE fleet_audit_runs SET status='failed', error=?, finished_at=? WHERE id=?",
                (f"{type(exc).__name__}: {exc}", utc_now(), run_id),
            )


def _decode_json(value: Any, fallback: Any) -> Any:
    try:
        return json.loads(str(value or ""))
    except (TypeError, ValueError, json.JSONDecodeError):
        return fallback


def get_audit_run(run_id: int) -> dict[str, Any] | None:
    with db() as conn:
        run = conn.execute("SELECT * FROM fleet_audit_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            return None
        rows = conn.execute(
            "SELECT * FROM fleet_audit_items WHERE run_id=? ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 WHEN 'unavailable' THEN 2 WHEN 'info' THEN 3 ELSE 4 END, device_name COLLATE NOCASE",
            (run_id,),
        ).fetchall()
    result = {key: run[key] for key in run.keys()}
    result["scope"] = _decode_json(result.pop("scope_json", "[]"), [])
    definition = AUDIT_DEFINITIONS.get(str(result.get("audit_type") or ""), {})
    result["definition"] = {key: definition.get(key) for key in ("label", "category", "description", "policy")}
    result["definition"]["command_count"] = len(definition.get("commands") or {})
    items = []
    for row in rows:
        item = {key: row[key] for key in row.keys()}
        item["details"] = _decode_json(item.pop("details_json", "{}"), {})
        item["command_errors"] = _decode_json(item.pop("command_errors_json", "{}"), {})
        items.append(item)
    result["items"] = items
    result["progress_percent"] = round((int(result.get("completed_count") or 0) / max(1, int(result.get("target_count") or 0))) * 100, 1)
    return result


def list_audit_runs(limit: int = 50) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM fleet_audit_runs ORDER BY id DESC LIMIT ?",
            (max(1, min(int(limit), 200)),),
        ).fetchall()
    result = []
    for row in rows:
        item = {key: row[key] for key in row.keys()}
        definition = AUDIT_DEFINITIONS.get(str(item.get("audit_type") or ""), {})
        item["label"] = definition.get("label", item.get("audit_type"))
        item.pop("scope_json", None)
        result.append(item)
    return result
