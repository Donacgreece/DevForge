# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 128


def validate_password(password: str) -> str:
    """Validate a newly created local Portivo password.

    Existing password hashes remain valid after upgrades. The policy is applied
    only when a local bootstrap administrator password is created or changed.
    """
    if not isinstance(password, str):
        raise ValueError("Password must be text")
    if len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Password must contain at least {MIN_PASSWORD_LENGTH} characters")
    if len(password) > MAX_PASSWORD_LENGTH:
        raise ValueError(f"Password must contain no more than {MAX_PASSWORD_LENGTH} characters")
    return password
