# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any


class SSHDeviceBusyError(RuntimeError):
    """Raised when another incompatible SSH operation owns the switch."""

    def __init__(self, message: str, *, operation: str = "", terminal_active: bool = False) -> None:
        super().__init__(message)
        self.operation = operation
        self.terminal_active = terminal_active


@dataclass
class _DeviceState:
    condition: threading.Condition = field(default_factory=threading.Condition)
    operation: str = ""
    operation_started_at: float = 0.0
    terminal_active: bool = False
    automation_queue: deque[tuple[object, str]] = field(default_factory=deque)
    not_before: float = 0.0
    last_credential_fingerprint: str = ""
    last_credential_success_at: float = 0.0


class SSHLease:
    def __init__(self, coordinator: "SSHCoordinator", device_id: int, state: _DeviceState, *, terminal: bool) -> None:
        self._coordinator = coordinator
        self.device_id = device_id
        self._state = state
        self.terminal = terminal
        self._released = False
        self._cooldown_seconds = 0.0

    def set_cooldown(self, seconds: float) -> None:
        self._cooldown_seconds = max(self._cooldown_seconds, max(0.0, float(seconds)))

    def release(self) -> None:
        if self._released:
            return
        self._released = True
        with self._state.condition:
            self._state.operation = ""
            self._state.operation_started_at = 0.0
            if self.terminal:
                self._state.terminal_active = False
            if self._cooldown_seconds:
                self._state.not_before = max(
                    self._state.not_before,
                    time.monotonic() + self._cooldown_seconds,
                )
            self._state.condition.notify_all()

    def __enter__(self) -> "SSHLease":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.release()


class SSHCoordinator:
    """Compatibility-first, FIFO SSH coordination per switch.

    Every switch owns one independent automation lane. Automated operations are
    admitted in request order, so two different Jobs targeting the same switch
    cannot overtake each other. A persistent interactive terminal owns the same
    lane exclusively. A release cooldown can keep the lane unavailable for a
    short settle window after flash writes or other heavy switch operations.
    """

    def __init__(self) -> None:
        self._states: dict[int, _DeviceState] = {}
        self._states_lock = threading.Lock()

    def _state(self, device_id: int) -> _DeviceState:
        with self._states_lock:
            return self._states.setdefault(int(device_id), _DeviceState())

    @staticmethod
    def _remove_ticket(state: _DeviceState, ticket: object) -> None:
        for index, (queued_ticket, _operation) in enumerate(state.automation_queue):
            if queued_ticket is ticket:
                del state.automation_queue[index]
                return

    def acquire_automation(self, device_id: int, operation: str, timeout: float) -> SSHLease:
        state = self._state(device_id)
        timeout = max(0.0, float(timeout))
        deadline = time.monotonic() + timeout
        ticket = object()

        with state.condition:
            if state.terminal_active:
                raise SSHDeviceBusyError(
                    "An interactive terminal is active for this switch. Disconnect it before running live operations.",
                    operation=state.operation or "interactive terminal",
                    terminal_active=True,
                )

            state.automation_queue.append((ticket, operation))
            while True:
                now = time.monotonic()
                is_first = bool(state.automation_queue) and state.automation_queue[0][0] is ticket
                cooldown_remaining = max(0.0, state.not_before - now)
                if (
                    is_first
                    and not state.operation
                    and not state.terminal_active
                    and cooldown_remaining <= 0.0
                ):
                    state.automation_queue.popleft()
                    state.operation = operation
                    state.operation_started_at = now
                    return SSHLease(self, device_id, state, terminal=False)

                remaining = deadline - now
                if remaining <= 0.0:
                    self._remove_ticket(state, ticket)
                    current = state.operation
                    if not current and cooldown_remaining > 0.0:
                        current = "post-save SSH cooldown"
                    if not current and state.automation_queue:
                        current = "an earlier queued SSH operation"
                    current = current or "another SSH operation"
                    state.condition.notify_all()
                    raise SSHDeviceBusyError(
                        f"The switch is busy with {current}.",
                        operation=current,
                        terminal_active=state.terminal_active,
                    )

                wait_for = remaining
                if is_first and not state.operation and cooldown_remaining > 0.0:
                    wait_for = min(wait_for, cooldown_remaining)
                state.condition.wait(timeout=max(0.001, wait_for))

    def acquire_terminal(self, device_id: int, timeout: float = 0.25) -> SSHLease:
        state = self._state(device_id)
        timeout = max(0.0, float(timeout))
        deadline = time.monotonic() + timeout

        with state.condition:
            while True:
                now = time.monotonic()
                cooldown_remaining = max(0.0, state.not_before - now)
                if (
                    not state.operation
                    and not state.terminal_active
                    and not state.automation_queue
                    and cooldown_remaining <= 0.0
                ):
                    state.terminal_active = True
                    state.operation = "interactive terminal"
                    state.operation_started_at = now
                    return SSHLease(self, device_id, state, terminal=True)

                remaining = deadline - now
                if remaining <= 0.0:
                    current = state.operation
                    if not current and state.automation_queue:
                        current = "queued switch operations"
                    if not current and cooldown_remaining > 0.0:
                        current = "post-save SSH cooldown"
                    current = current or "another SSH operation"
                    raise SSHDeviceBusyError(
                        f"The switch is busy with {current}. Wait for it to finish before connecting the terminal.",
                        operation=current,
                        terminal_active=state.terminal_active,
                    )

                wait_for = remaining
                if not state.operation and not state.automation_queue and cooldown_remaining > 0.0:
                    wait_for = min(wait_for, cooldown_remaining)
                state.condition.wait(timeout=max(0.001, wait_for))

    def mark_connection_success(self, device_id: int, credential_fingerprint: str) -> None:
        if not credential_fingerprint:
            return
        state = self._state(device_id)
        with state.condition:
            state.last_credential_fingerprint = credential_fingerprint
            state.last_credential_success_at = time.monotonic()

    def credentials_succeeded_recently(
        self,
        device_id: int,
        credential_fingerprint: str,
        *,
        within_seconds: float,
    ) -> bool:
        if not credential_fingerprint:
            return False
        state = self._state(device_id)
        with state.condition:
            return bool(
                state.last_credential_fingerprint == credential_fingerprint
                and state.last_credential_success_at > 0.0
                and (time.monotonic() - state.last_credential_success_at) <= max(0.0, float(within_seconds))
            )

    def status(self, device_id: int) -> dict[str, Any]:
        state = self._state(device_id)
        with state.condition:
            cooldown_remaining = max(0.0, state.not_before - time.monotonic())
            return {
                "operation": state.operation,
                "terminal_active": state.terminal_active,
                "busy": bool(state.operation or state.automation_queue or cooldown_remaining > 0.0),
                "queue_depth": len(state.automation_queue),
                "cooldown_remaining": round(cooldown_remaining, 3),
            }


ssh_coordinator = SSHCoordinator()
