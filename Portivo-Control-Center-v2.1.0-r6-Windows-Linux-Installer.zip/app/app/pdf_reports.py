# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import html
import io
import json
import re
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
    XPreformatted,
)


_PDF_FONT_REGULAR = "Helvetica"
_PDF_FONT_BOLD = "Helvetica-Bold"
_PDF_FONT_MONO = "Courier"
_FONTS_REGISTERED = False


from .time_service import format_platform_datetime, platform_now, platform_timezone_name

_LABELS = {
    "en": {
        "report_title": "Job execution report",
        "job": "Job",
        "operation": "Operation",
        "status": "Status",
        "mode": "Mode",
        "live": "Live execution",
        "simulation": "Simulation",
        "requested_by": "Requested by",
        "created": "Created",
        "started": "Started",
        "finished": "Finished",
        "targets": "Targets",
        "successful": "Successful",
        "failed": "Failed",
        "device_results": "Switch results",
        "device": "Switch",
        "address": "Management address",
        "port": "Port",
        "slot": "Slot",
        "command": "Command",
        "verification_command": "Verification command",
        "output": "Output",
        "verification": "Verification output",
        "error": "Error",
        "generated": "Generated",
        "page": "Page",
        "confidential": "Portivo Control Center - operational report",
        "not_available": "Not available",
        "no_output": "No output was returned.",
        "status_completed": "Completed",
        "status_success": "Successful",
        "status_failed": "Failed",
        "status_partial": "Partially completed",
        "status_running": "Running",
        "status_queued": "Queued",
        "status_unknown": "Unknown",
        "unp_assessment": "UNP assessment",
        "unp_problem_rate": "Switches with detected UNP conflict",
        "unp_affected": "Affected switches",
        "unp_clear": "No conflict detected",
        "unp_checked": "Successfully checked",
        "unp_scan_failed": "Scan failures",
    },
    "el": {
        "report_title": "Αναφορά εκτέλεσης εργασίας",
        "job": "Εργασία",
        "operation": "Ενέργεια",
        "status": "Κατάσταση",
        "mode": "Λειτουργία",
        "live": "Πραγματική εκτέλεση",
        "simulation": "Προσομοίωση",
        "requested_by": "Ζητήθηκε από",
        "created": "Δημιουργήθηκε",
        "started": "Ξεκίνησε",
        "finished": "Ολοκληρώθηκε",
        "targets": "Συσκευές",
        "successful": "Επιτυχείς",
        "failed": "Αποτυχημένες",
        "device_results": "Αποτελέσματα ανά switch",
        "device": "Switch",
        "address": "Διεύθυνση διαχείρισης",
        "port": "Θύρα",
        "slot": "Slot",
        "command": "Εντολή",
        "verification_command": "Εντολή επαλήθευσης",
        "output": "Αποτέλεσμα",
        "verification": "Αποτέλεσμα επαλήθευσης",
        "error": "Σφάλμα",
        "generated": "Δημιουργήθηκε",
        "page": "Σελίδα",
        "confidential": "Portivo Control Center - λειτουργική αναφορά",
        "not_available": "Δεν υπάρχει",
        "no_output": "Δεν επιστράφηκε αποτέλεσμα.",
        "status_completed": "Ολοκληρώθηκε",
        "status_success": "Επιτυχής",
        "status_failed": "Απέτυχε",
        "status_partial": "Μερικώς ολοκληρωμένη",
        "status_running": "Σε εξέλιξη",
        "status_queued": "Σε αναμονή",
        "status_unknown": "Άγνωστη",
        "unp_assessment": "Αξιολόγηση UNP",
        "unp_problem_rate": "Switches με εντοπισμένο πρόβλημα UNP",
        "unp_affected": "Switches με πρόβλημα",
        "unp_clear": "Χωρίς εντοπισμένο πρόβλημα",
        "unp_checked": "Επιτυχώς ελεγμένα",
        "unp_scan_failed": "Αποτυχίες ελέγχου",
    },
}


_STATUS_COLORS = {
    "success": colors.HexColor("#0F8A61"),
    "successful": colors.HexColor("#0F8A61"),
    "completed": colors.HexColor("#0F8A61"),
    "failed": colors.HexColor("#D13F62"),
    "partial": colors.HexColor("#D28B22"),
    "running": colors.HexColor("#3467D6"),
    "queued": colors.HexColor("#6D49D8"),
}


def _register_fonts() -> None:
    global _FONTS_REGISTERED, _PDF_FONT_REGULAR, _PDF_FONT_BOLD, _PDF_FONT_MONO
    if _FONTS_REGISTERED:
        return

    candidates = [
        (
            Path("C:/Windows/Fonts/arial.ttf"),
            Path("C:/Windows/Fonts/arialbd.ttf"),
            Path("C:/Windows/Fonts/consola.ttf"),
        ),
        (
            Path("C:/Windows/Fonts/calibri.ttf"),
            Path("C:/Windows/Fonts/calibrib.ttf"),
            Path("C:/Windows/Fonts/consola.ttf"),
        ),
        (
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"),
        ),
    ]
    for regular, bold, mono in candidates:
        if regular.exists() and bold.exists() and mono.exists():
            pdfmetrics.registerFont(TTFont("OSC-Regular", str(regular)))
            pdfmetrics.registerFont(TTFont("OSC-Bold", str(bold)))
            pdfmetrics.registerFont(TTFont("OSC-Mono", str(mono)))
            _PDF_FONT_REGULAR = "OSC-Regular"
            _PDF_FONT_BOLD = "OSC-Bold"
            _PDF_FONT_MONO = "OSC-Mono"
            break
    _FONTS_REGISTERED = True


def _safe_text(value: Any) -> str:
    text = str(value or "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = "".join(ch for ch in text if ch in "\n\t" or ord(ch) >= 32)
    return text


def _fmt_datetime(value: Any, lang: str) -> str:
    if not value:
        return _LABELS[lang]["not_available"]
    return format_platform_datetime(value, fallback=str(value))


def _load_action_label(action: str, lang: str, static_dir: Path) -> str:
    try:
        dictionary_path = static_dir / "i18n" / f"{lang}.json"
        dictionary = json.loads(dictionary_path.read_text(encoding="utf-8"))
        label = dictionary.get(f"actions.{action}.label")
        if isinstance(label, str) and label.strip():
            return label.strip()
    except (OSError, ValueError, TypeError):
        pass
    acronyms = {"aos", "arp", "cli", "cpu", "ip", "lldp", "mac", "ntp", "poe", "qos", "ssh", "unp", "vlan"}
    words = []
    for token in action.replace("_", " ").strip().split():
        words.append(token.upper() if token.lower() in acronyms else token.capitalize())
    return " ".join(words)


def _status_label(status: Any, lang: str) -> str:
    normalized = str(status or "unknown").lower()
    if normalized == "successful":
        normalized = "success"
    return _LABELS[lang].get(f"status_{normalized}", str(status or "Unknown").title())


def _wrap_cli_lines(text: str, width: int = 185) -> list[str]:
    lines: list[str] = []
    for original in _safe_text(text).split("\n"):
        expanded = original.expandtabs(4)
        if len(expanded) <= width:
            lines.append(expanded)
            continue
        wrapped = textwrap.wrap(
            expanded,
            width=width,
            replace_whitespace=False,
            drop_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
            subsequent_indent="  ",
        )
        lines.extend(wrapped or [""])
    return lines or [""]


def _code_blocks(text: str, style: ParagraphStyle, *, empty_text: str) -> list[Any]:
    normalized = _safe_text(text).strip("\n")
    if not normalized:
        normalized = empty_text
    lines = _wrap_cli_lines(normalized)
    blocks: list[Any] = []
    chunk_size = 24
    for index in range(0, len(lines), chunk_size):
        chunk = "\n".join(lines[index : index + chunk_size])
        pre = XPreformatted(html.escape(chunk), style)
        table = Table([[pre]], colWidths=[260 * mm])
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0E172A")),
                    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#24314A")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                    ("TOPPADDING", (0, 0), (-1, -1), 7),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                ]
            )
        )
        blocks.append(table)
        if index + chunk_size < len(lines):
            blocks.append(Spacer(1, 1.5 * mm))
    return blocks


def _unp_check_statistics(items: list[dict[str, Any]]) -> dict[str, int | float]:
    total = len(items)
    affected = 0
    clear = 0
    failed = 0
    checked = 0
    for item in items:
        output = _safe_text(item.get("output"))
        status = str(item.get("status") or "").lower()
        if "UNP_CHECK_RESULT: ISSUE" in output:
            affected += 1
            checked += 1
        elif "UNP_CHECK_RESULT: CLEAR" in output:
            clear += 1
            checked += 1
        elif status in {"failed", "partial"} or _safe_text(item.get("error")).strip():
            failed += 1
        else:
            failed += 1
    percentage = (affected / total * 100.0) if total else 0.0
    return {
        "total": total,
        "affected": affected,
        "clear": clear,
        "checked": checked,
        "failed": failed,
        "percentage": percentage,
    }


def build_job_pdf(
    job: dict[str, Any],
    items: Iterable[dict[str, Any]],
    *,
    language: str = "en",
    static_dir: Path,
) -> bytes:
    _register_fonts()
    lang = language if language in _LABELS else "en"
    labels = _LABELS[lang]
    action = str(job.get("action") or "")
    action_label = _load_action_label(action, lang, static_dir)
    generated_at = platform_now()

    output = io.BytesIO()
    page_width, page_height = landscape(A4)
    doc = SimpleDocTemplate(
        output,
        pagesize=(page_width, page_height),
        leftMargin=14 * mm,
        rightMargin=14 * mm,
        topMargin=20 * mm,
        bottomMargin=16 * mm,
        title=f"Portivo Control Center - Job {job.get('id')}",
        author="Portivo Control Center",
        subject=action_label,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "OSC-Title",
        parent=styles["Title"],
        fontName=_PDF_FONT_BOLD,
        fontSize=22,
        leading=26,
        textColor=colors.HexColor("#111827"),
        alignment=TA_LEFT,
        spaceAfter=3 * mm,
    )
    subtitle_style = ParagraphStyle(
        "OSC-Subtitle",
        parent=styles["Normal"],
        fontName=_PDF_FONT_REGULAR,
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#64748B"),
    )
    section_style = ParagraphStyle(
        "OSC-Section",
        parent=styles["Heading2"],
        fontName=_PDF_FONT_BOLD,
        fontSize=14,
        leading=18,
        textColor=colors.HexColor("#191A2F"),
        spaceBefore=2 * mm,
        spaceAfter=3 * mm,
    )
    label_style = ParagraphStyle(
        "OSC-Label",
        parent=styles["Normal"],
        fontName=_PDF_FONT_BOLD,
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor("#64748B"),
    )
    value_style = ParagraphStyle(
        "OSC-Value",
        parent=styles["Normal"],
        fontName=_PDF_FONT_BOLD,
        fontSize=9.5,
        leading=12,
        textColor=colors.HexColor("#111827"),
    )
    body_style = ParagraphStyle(
        "OSC-Body",
        parent=styles["Normal"],
        fontName=_PDF_FONT_REGULAR,
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#334155"),
    )
    code_style = ParagraphStyle(
        "OSC-Code",
        parent=styles["Code"],
        fontName=_PDF_FONT_MONO,
        fontSize=6.7,
        leading=8.2,
        textColor=colors.HexColor("#E8EEF9"),
        leftIndent=0,
        rightIndent=0,
        spaceBefore=0,
        spaceAfter=0,
    )

    logo_path = static_dir / "assets" / "portivo-logo-color.png"

    def footer(canvas: Any, _: Any) -> None:
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#E2E8F0"))
        canvas.setLineWidth(0.5)
        canvas.line(14 * mm, 11 * mm, page_width - 14 * mm, 11 * mm)
        canvas.setFillColor(colors.HexColor("#64748B"))
        canvas.setFont(_PDF_FONT_REGULAR, 7)
        canvas.drawString(14 * mm, 7 * mm, labels["confidential"])
        canvas.drawRightString(
            page_width - 14 * mm,
            7 * mm,
            f"{labels['page']} {canvas.getPageNumber()}  |  {labels['generated']}: {generated_at.strftime('%d/%m/%Y %H:%M:%S')} ({platform_timezone_name()})",
        )
        canvas.restoreState()

    story: list[Any] = []
    if logo_path.exists():
        logo = Image(str(logo_path), width=36 * mm, height=13.75 * mm)
        header = Table(
            [[logo, Paragraph(f"<b>Portivo Control Center</b><br/><font size='8' color='#64748B'>{html.escape(labels['report_title'])}</font>", value_style)]],
            colWidths=[42 * mm, 218 * mm],
        )
        header.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        story.extend([header, Spacer(1, 5 * mm)])

    story.append(Paragraph(f"{html.escape(labels['job'])} #{job.get('id')} - {html.escape(action_label)}", title_style))
    story.append(Paragraph(html.escape(labels["report_title"]), subtitle_style))
    story.append(Spacer(1, 5 * mm))

    item_list = list(items)
    status = str(job.get("status") or "unknown")
    mode = labels["simulation"] if bool(job.get("dry_run")) else labels["live"]
    summary_data = [
        [labels["status"], labels["mode"], labels["requested_by"], labels["created"]],
        [_status_label(status, lang), mode, str(job.get("requested_by") or ""), _fmt_datetime(job.get("created_at"), lang)],
        [labels["targets"], labels["successful"], labels["failed"], labels["finished"]],
        [str(job.get("target_count") or 0), str(job.get("success_count") or 0), str(job.get("failure_count") or 0), _fmt_datetime(job.get("finished_at"), lang)],
    ]
    summary_table = Table(summary_data, colWidths=[65 * mm] * 4)
    summary_style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F1F5F9")),
        ("BACKGROUND", (0, 2), (-1, 2), colors.HexColor("#F1F5F9")),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#111827")),
        ("FONTNAME", (0, 0), (-1, -1), _PDF_FONT_REGULAR),
        ("FONTNAME", (0, 0), (-1, 0), _PDF_FONT_BOLD),
        ("FONTNAME", (0, 2), (-1, 2), _PDF_FONT_BOLD),
        ("FONTNAME", (0, 1), (-1, 1), _PDF_FONT_BOLD),
        ("FONTNAME", (0, 3), (-1, 3), _PDF_FONT_BOLD),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D7DFEA")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]
    summary_style.append(("TEXTCOLOR", (0, 1), (0, 1), _STATUS_COLORS.get(status.lower(), colors.HexColor("#475569"))))
    summary_table.setStyle(TableStyle(summary_style))
    story.append(summary_table)

    if action == "check_unp":
        stats = _unp_check_statistics(item_list)
        percentage_text = f"{float(stats['percentage']):.1f}%"
        affected_text = f"{int(stats['affected'])} / {int(stats['total'])}"
        unp_card = Table(
            [
                [
                    Paragraph(percentage_text, ParagraphStyle(
                        "OSC-UNP-Percentage", parent=title_style, fontSize=34, leading=38,
                        textColor=colors.HexColor("#C72E52" if int(stats["affected"]) else "#0B8A67"),
                        alignment=TA_LEFT, spaceAfter=0,
                    )),
                    Paragraph(
                        f"<b>{html.escape(labels['unp_problem_rate'])}</b><br/>"
                        f"<font size='15'>{html.escape(affected_text)}</font>",
                        value_style,
                    ),
                ],
                [
                    Paragraph(f"<b>{labels['unp_affected']}:</b> {int(stats['affected'])}", body_style),
                    Paragraph(
                        f"<b>{labels['unp_clear']}:</b> {int(stats['clear'])} &nbsp;&nbsp; "
                        f"<b>{labels['unp_checked']}:</b> {int(stats['checked'])} &nbsp;&nbsp; "
                        f"<b>{labels['unp_scan_failed']}:</b> {int(stats['failed'])}",
                        body_style,
                    ),
                ],
            ],
            colWidths=[70 * mm, 190 * mm],
        )
        unp_card.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8F5FF")),
            ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#C9B8F5")),
            ("INNERGRID", (0, 1), (-1, 1), 0.4, colors.HexColor("#DED5F3")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.extend([Spacer(1, 6 * mm), Paragraph(labels["unp_assessment"], section_style), unp_card])

    story.extend([Spacer(1, 8 * mm), Paragraph(labels["device_results"], section_style)])

    if not item_list:
        story.append(Paragraph(labels["not_available"], body_style))

    for index, item in enumerate(item_list):
        story.append(PageBreak())
        device_name = str(item.get("device_name") or item.get("host") or f"Device {item.get('device_id')}")
        item_status = str(item.get("status") or "unknown")
        status_color = _STATUS_COLORS.get(item_status.lower(), colors.HexColor("#475569"))
        device_header = Table(
            [
                [
                    Paragraph(html.escape(device_name), section_style),
                    Paragraph(f"<font color='{status_color.hexval()}'><b>{html.escape(_status_label(item_status, lang))}</b></font>", value_style),
                ],
                [
                    Paragraph(f"{html.escape(labels['address'])}: <b>{html.escape(str(item.get('host') or ''))}</b>", body_style),
                    Paragraph(
                        " &nbsp; ".join(
                            part
                            for part in [
                                f"{html.escape(labels['port'])}: <b>{html.escape(str(item.get('port') or '-'))}</b>" if item.get("port") else "",
                                f"{html.escape(labels['slot'])}: <b>{html.escape(str(item.get('slot') or '-'))}</b>" if item.get("slot") else "",
                            ]
                            if part
                        ),
                        body_style,
                    ),
                ],
            ],
            colWidths=[195 * mm, 65 * mm],
        )
        device_header.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                    ("LINEBELOW", (0, 1), (-1, 1), 0.7, colors.HexColor("#D7DFEA")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                    ("BOTTOMPADDING", (0, 1), (-1, 1), 6),
                ]
            )
        )
        story.extend([device_header, Spacer(1, 4 * mm)])

        sections = [
            (labels["command"], item.get("command")),
            (labels["verification_command"], item.get("verification_command")),
            (labels["output"], item.get("output")),
            (labels["verification"], item.get("verification_output")),
        ]
        for heading, content in sections:
            if not _safe_text(content).strip():
                continue
            story.append(Paragraph(html.escape(heading), label_style))
            story.extend(_code_blocks(_safe_text(content), code_style, empty_text=labels["no_output"]))
            story.append(Spacer(1, 3 * mm))
        if _safe_text(item.get("error")).strip():
            error_table = Table(
                [[Paragraph(f"<b>{html.escape(labels['error'])}:</b> {html.escape(_safe_text(item.get('error')))}", body_style)]],
                colWidths=[260 * mm],
            )
            error_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF1F3")),
                        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#A61B3C")),
                        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#F4A8B8")),
                        ("LEFTPADDING", (0, 0), (-1, -1), 8),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                        ("TOPPADDING", (0, 0), (-1, -1), 8),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                    ]
                )
            )
            story.append(error_table)

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()


def safe_report_filename(job: dict[str, Any]) -> str:
    action = re.sub(r"[^A-Za-z0-9_-]+", "_", str(job.get("action") or "job")).strip("_") or "job"
    created = str(job.get("created_at") or "")[:10].replace("-", "")
    suffix = f"_{created}" if created else ""
    return f"Portivo_Job_{int(job.get('id') or 0)}_{action}{suffix}.pdf"
