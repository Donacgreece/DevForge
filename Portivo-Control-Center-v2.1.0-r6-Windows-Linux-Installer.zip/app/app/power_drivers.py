# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

SYS_DESCR = "1.3.6.1.2.1.1.1.0"
SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"
UPS_IDENT_MANUFACTURER = "1.3.6.1.2.1.33.1.1.1.0"
UPS_IDENT_MODEL = "1.3.6.1.2.1.33.1.1.2.0"

# Schneider Electric / APC PowerNet MIB enterprise root: 1.3.6.1.4.1.318
APC_ENTERPRISE = "1.3.6.1.4.1.318"
APC_MODEL = "1.3.6.1.4.1.318.1.1.1.1.1.1.0"
APC_FIRMWARE = "1.3.6.1.4.1.318.1.1.1.1.2.1.0"
APC_BATTERY_STATUS = "1.3.6.1.4.1.318.1.1.1.2.1.1.0"
APC_BATTERY_CAPACITY = "1.3.6.1.4.1.318.1.1.1.2.2.1.0"
# High-precision PowerNet battery capacity. The value is reported in tenths of
# a percent (e.g. 987 => 98.7%). Some Easy UPS/NMC combinations expose this
# scalar even when upsAdvBatteryCapacity and RFC1628 charge remaining are absent.
APC_HIGH_PREC_BATTERY_CAPACITY = "1.3.6.1.4.1.318.1.1.1.2.3.1.0"
APC_BATTERY_RUNTIME = "1.3.6.1.4.1.318.1.1.1.2.2.3.0"
APC_OUTPUT_STATUS = "1.3.6.1.4.1.318.1.1.1.4.1.1.0"
APC_OUTPUT_LOAD = "1.3.6.1.4.1.318.1.1.1.4.2.3.0"


# Additional read-only APC PowerNet telemetry. These OIDs are queried only for
# details/normal polling and ignored when the connected model does not expose
# them. The set intentionally stays read-only.
APC_MODEL_TYPE = "1.3.6.1.4.1.318.1.1.1.1.1.4.0"
APC_MANUFACTURE_DATE = "1.3.6.1.4.1.318.1.1.1.1.2.2.0"
APC_SERIAL_NUMBER = "1.3.6.1.4.1.318.1.1.1.1.2.3.0"
APC_BATTERY_LAST_REPLACE = "1.3.6.1.4.1.318.1.1.1.2.1.3.0"
APC_BATTERY_TEMPERATURE = "1.3.6.1.4.1.318.1.1.1.2.2.2.0"
APC_BATTERY_VOLTAGE = "1.3.6.1.4.1.318.1.1.1.2.2.8.0"
APC_BATTERY_CURRENT = "1.3.6.1.4.1.318.1.1.1.2.2.9.0"
APC_BATTERY_BREAKER = "1.3.6.1.4.1.318.1.1.1.2.2.27.0"
APC_HIGH_PREC_BATTERY_TEMPERATURE = "1.3.6.1.4.1.318.1.1.1.2.3.2.0"
APC_HIGH_PREC_BATTERY_CURRENT = "1.3.6.1.4.1.318.1.1.1.2.3.5.0"
APC_HIGH_PREC_BATTERY_VOLTAGE = "1.3.6.1.4.1.318.1.1.1.2.3.7.0"
APC_INPUT_FREQUENCY = "1.3.6.1.4.1.318.1.1.1.3.2.4.0"
APC_INPUT_ACTIVE_POWER = "1.3.6.1.4.1.318.1.1.1.3.2.12.0"
APC_OUTPUT_ACTIVE_POWER = "1.3.6.1.4.1.318.1.1.1.4.2.8.0"
APC_BATTERY_CABINET_AH = "1.3.6.1.4.1.318.1.1.1.5.2.17.0"
APC_BATTERY_TEST_LAST_DATE = "1.3.6.1.4.1.318.1.1.1.7.2.13.0"
APC_BATTERY_TEST_PROCESS = "1.3.6.1.4.1.318.1.1.1.7.2.14.0"
APC_BATTERY_TEST_CONDITION = "1.3.6.1.4.1.318.1.1.1.7.2.15.0"
APC_COMM_STATUS = "1.3.6.1.4.1.318.1.1.1.8.1.0"
APC_NMC_DIAG_TABLE = "1.3.6.1.4.1.318.1.1.1.13.4.26.1"
APC_UIO_SENSOR_TABLE = "1.3.6.1.4.1.318.1.1.25.1.2.1"


# Phoenixtec / XPPC enterprise MIB root used by a number of white-label UPS
# network cards. Portivo treats this as its own telemetry driver because many
# implementations expose richer and more reliable vendor scalars than their
# partial RFC 1628 facade.
XPPC_ENTERPRISE = "1.3.6.1.4.1.935.1"
XPPC_UPS_ROOT = "1.3.6.1.4.1.935.1.1.1"
XPPC_MODEL = "1.3.6.1.4.1.935.1.1.1.1.1.1.0"
XPPC_NAME = "1.3.6.1.4.1.935.1.1.1.1.1.2.0"
XPPC_FIRMWARE = "1.3.6.1.4.1.935.1.1.1.1.2.1.0"
XPPC_MANUFACTURE_DATE = "1.3.6.1.4.1.935.1.1.1.1.2.2.0"
XPPC_SERIAL_NUMBER = "1.3.6.1.4.1.935.1.1.1.1.2.3.0"
XPPC_AGENT_FIRMWARE = "1.3.6.1.4.1.935.1.1.1.1.2.4.0"
XPPC_BATTERY_STATUS = "1.3.6.1.4.1.935.1.1.1.2.1.1.0"
XPPC_SECONDS_ON_BATTERY = "1.3.6.1.4.1.935.1.1.1.2.1.2.0"
XPPC_BATTERY_LAST_REPLACE = "1.3.6.1.4.1.935.1.1.1.2.1.3.0"
XPPC_BATTERY_CAPACITY = "1.3.6.1.4.1.935.1.1.1.2.2.1.0"
XPPC_BATTERY_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.2.2.2.0"
XPPC_BATTERY_TEMPERATURE = "1.3.6.1.4.1.935.1.1.1.2.2.3.0"
XPPC_RUNTIME_SECONDS = "1.3.6.1.4.1.935.1.1.1.2.2.4.0"
XPPC_BATTERY_REPLACE = "1.3.6.1.4.1.935.1.1.1.2.2.5.0"
XPPC_FULL_CHARGE_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.2.2.6.0"
XPPC_BATTERY_CURRENT_PERCENT = "1.3.6.1.4.1.935.1.1.1.2.2.7.0"
XPPC_INPUT_PHASES = "1.3.6.1.4.1.935.1.1.1.3.1.1.0"
XPPC_INPUT_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.3.2.1.0"
XPPC_INPUT_MAX_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.3.2.2.0"
XPPC_INPUT_MIN_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.3.2.3.0"
XPPC_INPUT_FREQUENCY = "1.3.6.1.4.1.935.1.1.1.3.2.4.0"
XPPC_INPUT_FAIL_CAUSE = "1.3.6.1.4.1.935.1.1.1.3.2.5.0"
XPPC_OUTPUT_STATUS = "1.3.6.1.4.1.935.1.1.1.4.1.1.0"
XPPC_OUTPUT_PHASES = "1.3.6.1.4.1.935.1.1.1.4.1.2.0"
XPPC_OUTPUT_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.4.2.1.0"
XPPC_OUTPUT_FREQUENCY = "1.3.6.1.4.1.935.1.1.1.4.2.2.0"
XPPC_OUTPUT_LOAD = "1.3.6.1.4.1.935.1.1.1.4.2.3.0"
XPPC_NUM_ATTACHED_DEVICES = "1.3.6.1.4.1.935.1.1.1.5.1.1.0"
XPPC_RATED_OUTPUT_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.5.2.1.0"
XPPC_HIGH_TRANSFER_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.5.2.2.0"
XPPC_LOW_TRANSFER_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.5.2.3.0"
XPPC_MIN_RETURN_CAPACITY = "1.3.6.1.4.1.935.1.1.1.5.2.6.0"
XPPC_LOW_BATTERY_RUNTIME = "1.3.6.1.4.1.935.1.1.1.5.2.8.0"
# Alternate XPPC three-phase telemetry. A number of Phoenixtec-compatible
# cards expose the classic smart scalars but leave runtime/load/frequency at
# zero while publishing the live values in the three-phase branch. These are
# safe read-only fallbacks even for devices that report a single active phase.
XPPC_3P_BATTERY_VOLTAGE = "1.3.6.1.4.1.935.1.1.1.8.1.1.0"
XPPC_3P_BATTERY_CAPACITY = "1.3.6.1.4.1.935.1.1.1.8.1.2.0"
XPPC_3P_RUNTIME_MINUTES = "1.3.6.1.4.1.935.1.1.1.8.1.3.0"
XPPC_3P_BATTERY_CURRENT = "1.3.6.1.4.1.935.1.1.1.8.1.4.0"
XPPC_3P_BATTERY_TEMPERATURE = "1.3.6.1.4.1.935.1.1.1.8.1.5.0"
XPPC_3P_INPUT_FREQUENCY = "1.3.6.1.4.1.935.1.1.1.8.2.1.0"
XPPC_3P_INPUT_VOLTAGE_R = "1.3.6.1.4.1.935.1.1.1.8.2.2.0"
XPPC_3P_INPUT_VOLTAGE_S = "1.3.6.1.4.1.935.1.1.1.8.2.3.0"
XPPC_3P_INPUT_VOLTAGE_T = "1.3.6.1.4.1.935.1.1.1.8.2.4.0"
XPPC_3P_OUTPUT_FREQUENCY = "1.3.6.1.4.1.935.1.1.1.8.3.1.0"
XPPC_3P_OUTPUT_VOLTAGE_R = "1.3.6.1.4.1.935.1.1.1.8.3.2.0"
XPPC_3P_OUTPUT_VOLTAGE_S = "1.3.6.1.4.1.935.1.1.1.8.3.3.0"
XPPC_3P_OUTPUT_VOLTAGE_T = "1.3.6.1.4.1.935.1.1.1.8.3.4.0"
XPPC_3P_OUTPUT_LOAD_R = "1.3.6.1.4.1.935.1.1.1.8.3.5.0"
XPPC_3P_OUTPUT_LOAD_S = "1.3.6.1.4.1.935.1.1.1.8.3.6.0"
XPPC_3P_OUTPUT_LOAD_T = "1.3.6.1.4.1.935.1.1.1.8.3.7.0"
XPPC_3P_BYPASS_FREQUENCY = "1.3.6.1.4.1.935.1.1.1.8.4.1.0"
XPPC_ENV_TEMPERATURE = "1.3.6.1.4.1.935.1.1.1.9.1.1.0"
XPPC_ENV_HUMIDITY = "1.3.6.1.4.1.935.1.1.1.9.1.2.0"

# Cyber Power System Inc. IANA PEN 3808. Modern RMCARD products expose
# RFC 1628 and CyberPower MIB data; Portivo uses enterprise identity for
# deterministic driver resolution and the standards telemetry path by default.
CYBERPOWER_ENTERPRISE = "1.3.6.1.4.1.3808"

# Riello S.p.A. IANA PEN 7783. NetMan cards expose RFC 1628 plus optional
# private MIBs. Portivo resolves the vendor identity while keeping RFC 1628
# as the portable read-only telemetry baseline.
RIELLO_ENTERPRISE = "1.3.6.1.4.1.7783"

# Eaton PowerMIB / xUPS enterprise root: 1.3.6.1.4.1.534
EATON_ENTERPRISE = "1.3.6.1.4.1.534"
EATON_MANUFACTURER = "1.3.6.1.4.1.534.1.1.1.0"
EATON_MODEL = "1.3.6.1.4.1.534.1.1.2.0"
EATON_SOFTWARE = "1.3.6.1.4.1.534.1.1.3.0"
EATON_RUNTIME_SECONDS = "1.3.6.1.4.1.534.1.2.1.0"
EATON_BATTERY_CAPACITY = "1.3.6.1.4.1.534.1.2.4.0"
EATON_BATTERY_ABM_STATUS = "1.3.6.1.4.1.534.1.2.5.0"
EATON_OUTPUT_LOAD = "1.3.6.1.4.1.534.1.4.1.0"
EATON_OUTPUT_SOURCE = "1.3.6.1.4.1.534.1.4.5.0"
EATON_ALARMS = "1.3.6.1.4.1.534.1.7.1.0"
EATON_ALARM_DESCR_TABLE = "1.3.6.1.4.1.534.1.7.2.1.2"

# Additional Eaton PowerMIB/xUPS telemetry.
EATON_BATTERY_VOLTAGE = "1.3.6.1.4.1.534.1.2.2.0"
EATON_BATTERY_CURRENT = "1.3.6.1.4.1.534.1.2.3.0"
EATON_BATTERY_LAST_REPLACED = "1.3.6.1.4.1.534.1.2.6.0"
EATON_INPUT_FREQUENCY = "1.3.6.1.4.1.534.1.3.1.0"
EATON_INPUT_LINE_BADS = "1.3.6.1.4.1.534.1.3.2.0"
EATON_INPUT_NUM_PHASES = "1.3.6.1.4.1.534.1.3.3.0"
EATON_INPUT_TABLE = "1.3.6.1.4.1.534.1.3.4.1"
EATON_INPUT_SOURCE = "1.3.6.1.4.1.534.1.3.5.0"
EATON_DUAL_INPUT_STATUS = "1.3.6.1.4.1.534.1.3.6.0"
EATON_OUTPUT_FREQUENCY = "1.3.6.1.4.1.534.1.4.2.0"
EATON_OUTPUT_NUM_PHASES = "1.3.6.1.4.1.534.1.4.3.0"
EATON_OUTPUT_TABLE = "1.3.6.1.4.1.534.1.4.4.1"
EATON_BYPASS_FREQUENCY = "1.3.6.1.4.1.534.1.5.1.0"
EATON_BYPASS_NUM_PHASES = "1.3.6.1.4.1.534.1.5.2.0"
EATON_BYPASS_TABLE = "1.3.6.1.4.1.534.1.5.3.1"
EATON_AMBIENT_TEMPERATURE = "1.3.6.1.4.1.534.1.6.1.0"
EATON_AMBIENT_HUMIDITY = "1.3.6.1.4.1.534.1.6.4.0"
EATON_REMOTE_TEMPERATURE = "1.3.6.1.4.1.534.1.6.5.0"
EATON_REMOTE_HUMIDITY = "1.3.6.1.4.1.534.1.6.6.0"
EATON_BATTERY_TEST_STATUS = "1.3.6.1.4.1.534.1.8.2.0"
EATON_LAST_GENERAL_TEST = "1.3.6.1.4.1.534.1.8.3.0"
EATON_LAST_GENERAL_TEST_RESULT = "1.3.6.1.4.1.534.1.8.4.0"
EATON_CONFIG_OUTPUT_VOLTAGE = "1.3.6.1.4.1.534.1.10.1.0"
EATON_CONFIG_INPUT_VOLTAGE = "1.3.6.1.4.1.534.1.10.2.0"
EATON_CONFIG_OUTPUT_WATTS = "1.3.6.1.4.1.534.1.10.3.0"
EATON_CONFIG_OUTPUT_FREQUENCY = "1.3.6.1.4.1.534.1.10.4.0"
EATON_CONFIG_INSTALL_DATE = "1.3.6.1.4.1.534.1.10.8.0"
EATON_TOPOLOGY_TYPE = "1.3.6.1.4.1.534.1.13.1.0"
EATON_POWER_STRATEGY = "1.3.6.1.4.1.534.1.13.4.0"

# Vertiv / Liebert Global Products MIB enterprise root. Modern Vertiv network
# cards commonly expose the flexible LGP measurement points below. Portivo
# always keeps RFC 1628 as the standards fallback, so older Liebert cards and
# models with partial enterprise-MIB support remain usable.
VERTIV_ENTERPRISE = "1.3.6.1.4.1.476"
VERTIV_LGP_MEASUREMENT_ROOT = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1"
VERTIV_SYSTEM_STATUS = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4123"
VERTIV_OUTPUT_SOURCE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4872"
VERTIV_ECO_MODE_STATE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.5454"
VERTIV_ECO_MODE_STATUS = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.6198"
VERTIV_BATTERY_CAPACITY = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4153"
VERTIV_BATTERY_VOLTAGE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4148"
VERTIV_BATTERY_CURRENT = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4149"
VERTIV_BATTERY_TEMPERATURE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4156"
VERTIV_BATTERY_RUNTIME = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4150"
VERTIV_BATTERY_REPLACEMENT_DATE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4160"
VERTIV_INPUT_VOLTAGE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4096"
VERTIV_INPUT_FREQUENCY = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4105"
VERTIV_INPUT_CURRENT = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4113"
VERTIV_INPUT_POWER_FACTOR = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4116"
VERTIV_INPUT_VOLTAGE_MAX = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4106"
VERTIV_INPUT_VOLTAGE_MIN = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4107"
VERTIV_INPUT_BLACKOUT_COUNT = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4120"
VERTIV_OUTPUT_CURRENT = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4204"
VERTIV_OUTPUT_POWER = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4208"
VERTIV_OUTPUT_LOAD = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4223"
VERTIV_OUTPUT_FREQUENCY = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4207"
VERTIV_OUTPUT_APPARENT_POWER = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4209"
VERTIV_OUTPUT_POWER_FACTOR = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4210"
VERTIV_OUTPUT_APPARENT_POWER_RATING = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4264"
VERTIV_AMBIENT_TEMPERATURE = "1.3.6.1.4.1.476.1.42.3.9.20.1.20.1.2.1.4291"
VERTIV_ALARM_BATTERY_LOW = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4162"
VERTIV_ALARM_INPUT_PROBLEM = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4122"
VERTIV_ALARM_OVERLOAD = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.5806"
VERTIV_ALARM_BATTERY_TEMP = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4219"
VERTIV_ALARM_BYPASS_UNAVAILABLE = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4135"
VERTIV_ALARM_BATTERY_DISCHARGING = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4168"
VERTIV_ALARM_OUTPUT_OFF = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4215"
VERTIV_ALARM_INVERTER_FAILURE = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.4233"
VERTIV_ALARM_REPLACE_BATTERY = "1.3.6.1.4.1.476.1.42.3.9.20.1.10.1.2.100.6182"

VERTIV_ALARM_OIDS = {
    VERTIV_ALARM_BATTERY_LOW: "Low battery",
    VERTIV_ALARM_INPUT_PROBLEM: "Input power problem",
    VERTIV_ALARM_OVERLOAD: "Output overload",
    VERTIV_ALARM_BATTERY_TEMP: "Battery temperature alarm",
    VERTIV_ALARM_BYPASS_UNAVAILABLE: "Bypass unavailable",
    VERTIV_ALARM_BATTERY_DISCHARGING: "Battery discharging",
    VERTIV_ALARM_OUTPUT_OFF: "Output off",
    VERTIV_ALARM_INVERTER_FAILURE: "Inverter failure",
    VERTIV_ALARM_REPLACE_BATTERY: "Battery replacement required",
}

EATON_ALARM_LABELS = {
    "1.3.6.1.4.1.534.1.7.3": "On battery",
    "1.3.6.1.4.1.534.1.7.4": "Low battery",
    "1.3.6.1.4.1.534.1.7.5": "Utility power restored",
    "1.3.6.1.4.1.534.1.7.6": "Returned from low battery",
    "1.3.6.1.4.1.534.1.7.7": "Output overload",
    "1.3.6.1.4.1.534.1.7.8": "Internal failure",
    "1.3.6.1.4.1.534.1.7.9": "Battery discharged",
    "1.3.6.1.4.1.534.1.7.10": "Inverter failure",
    "1.3.6.1.4.1.534.1.7.11": "On bypass",
    "1.3.6.1.4.1.534.1.7.12": "Bypass unavailable",
    "1.3.6.1.4.1.534.1.7.13": "Output off",
    "1.3.6.1.4.1.534.1.7.14": "Input failure",
    "1.3.6.1.4.1.534.1.7.15": "Building alarm",
    "1.3.6.1.4.1.534.1.7.16": "Shutdown imminent",
    "1.3.6.1.4.1.534.1.7.17": "On inverter",
}

NO_VALUE_MARKERS = (
    "no such object",
    "no such instance",
    "end of mib",
    "nosuchobject",
    "nosuchinstance",
)


@dataclass(frozen=True)
class PowerDriver:
    key: str
    name: str
    protocol: str
    enterprise_root: str = ""
    aliases: tuple[str, ...] = ()
    extra_oids: tuple[str, ...] = ()
    alarm_table_oid: str = ""


DRIVERS: dict[str, PowerDriver] = {
    "generic": PowerDriver(
        key="generic",
        name="Generic UPS-MIB",
        protocol="IETF RFC 1628 UPS-MIB",
        aliases=("generic", "ups-mib", "rfc1628"),
    ),
    "apc": PowerDriver(
        key="apc",
        name="APC PowerNet",
        protocol="APC PowerNet + RFC 1628",
        enterprise_root=APC_ENTERPRISE,
        aliases=("apc", "schneider", "schneider electric", "smart-ups", "symmetra", "galaxy"),
        extra_oids=(
            APC_MODEL, APC_FIRMWARE, APC_BATTERY_STATUS, APC_BATTERY_CAPACITY,
            APC_HIGH_PREC_BATTERY_CAPACITY, APC_BATTERY_RUNTIME, APC_OUTPUT_STATUS, APC_OUTPUT_LOAD,
        ),
    ),
    "xppc": PowerDriver(
        key="xppc",
        name="Phoenixtec / XPPC",
        protocol="Phoenixtec XPPC-MIB + RFC 1628",
        enterprise_root=XPPC_ENTERPRISE,
        aliases=("phoenixtec", "xppc", "ppc ups", "intelligent ups"),
        extra_oids=(
            XPPC_MODEL, XPPC_NAME, XPPC_FIRMWARE, XPPC_BATTERY_STATUS, XPPC_SECONDS_ON_BATTERY,
            XPPC_BATTERY_CAPACITY, XPPC_RUNTIME_SECONDS, XPPC_BATTERY_REPLACE, XPPC_OUTPUT_STATUS, XPPC_OUTPUT_LOAD,
            XPPC_3P_RUNTIME_MINUTES, XPPC_3P_OUTPUT_FREQUENCY, XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S,
            XPPC_3P_OUTPUT_LOAD_T, XPPC_3P_BATTERY_CAPACITY, XPPC_3P_BATTERY_VOLTAGE,
        ),
    ),
    "eaton": PowerDriver(
        key="eaton",
        name="Eaton xUPS",
        protocol="Eaton PowerMIB xUPS + RFC 1628",
        enterprise_root=EATON_ENTERPRISE,
        aliases=("eaton", "powerware", "xups"),
        extra_oids=(
            EATON_MANUFACTURER, EATON_MODEL, EATON_SOFTWARE, EATON_RUNTIME_SECONDS,
            EATON_BATTERY_CAPACITY, EATON_BATTERY_ABM_STATUS, EATON_OUTPUT_LOAD,
            EATON_OUTPUT_SOURCE, EATON_ALARMS,
        ),
        alarm_table_oid=EATON_ALARM_DESCR_TABLE,
    ),
    "vertiv": PowerDriver(
        key="vertiv",
        name="Vertiv / Liebert",
        protocol="Liebert Global Products MIB + RFC 1628",
        enterprise_root=VERTIV_ENTERPRISE,
        aliases=(
            "vertiv", "liebert", "emerson network power", "gxt3", "gxt4", "gxt5", "gxe",
            "ita2", "ita", "mtp", "apm", "apm2", "aps", "exl", "exm", "exm2", "exs", "nxc",
            "trinergy", "power ups 9000", "psa",
        ),
        extra_oids=(
            VERTIV_SYSTEM_STATUS, VERTIV_OUTPUT_SOURCE, VERTIV_BATTERY_CAPACITY,
            VERTIV_BATTERY_RUNTIME, VERTIV_OUTPUT_LOAD, VERTIV_ALARM_BATTERY_LOW,
            VERTIV_ALARM_INPUT_PROBLEM, VERTIV_ALARM_OVERLOAD, VERTIV_ALARM_BATTERY_TEMP,
            VERTIV_ALARM_BYPASS_UNAVAILABLE, VERTIV_ALARM_BATTERY_DISCHARGING, VERTIV_ALARM_OUTPUT_OFF,
            VERTIV_ALARM_INVERTER_FAILURE, VERTIV_ALARM_REPLACE_BATTERY,
        ),
    ),
    "socomec": PowerDriver(
        key="socomec",
        name="Socomec / NET VISION / OFYS-RT",
        protocol="Socomec WEB/SNMP (NET VISION / RT VISION) + RFC 1628",
        aliases=(
            "socomec", "net vision", "netvision", "rt vision", "rtvision",
            "netys", "itys", "masterys", "delphys", "modulys",
            "ofys", "ofys-rt", "ofys rt",
        ),
    ),
    "acculine": PowerDriver(
        key="acculine",
        name="AccuLine TNmax",
        protocol="AccuLine SNMP card + RFC 1628",
        aliases=("acculine", "accu line", "tnmax", "tn max"),
    ),
    "cyberpower": PowerDriver(
        key="cyberpower",
        name="CyberPower / RMCARD",
        protocol="CyberPower RMCARD SNMP + RFC 1628",
        enterprise_root=CYBERPOWER_ENTERPRISE,
        aliases=(
            "cyberpower", "cyber power", "cyber power systems", "cyber power system",
            "rmcard", "smart app online", "smart app sinewave",
        ),
    ),
    "riello": PowerDriver(
        key="riello",
        name="Riello UPS / NetMan",
        protocol="Riello NetMan SNMP + RFC 1628",
        enterprise_root=RIELLO_ENTERPRISE,
        aliases=(
            "riello", "riello ups", "netman 204", "netman204", "netman 208", "netman208",
            "rps s.p.a", "rps spa",
        ),
    ),
}

# Operator-facing model/family coverage shown by the Drivers registry. This is
# metadata only. Live SNMP identity and MIB evidence remain authoritative.
DRIVER_MODELS: dict[str, str] = {
    "generic": "Any RFC 1628 UPS-MIB device",
    "xppc": "Phoenixtec / XPPC-compatible cards and white-label UPS",
    "vertiv": "GXT5, GXE, ITA2, EXM2, EXS, APM2, Trinergy, MTP and Liebert families",
    "socomec": "OFYS-RT, NETYS, ITYS, MASTERYS, MODULYS, DELPHYS with WEB/SNMP interfaces",
    "acculine": "TNmax series with SNMP network card",
    "apc": "Smart-UPS, Easy UPS, Symmetra, Galaxy and PowerNet families",
    "eaton": "Powerware / Eaton xUPS-compatible families",
    "cyberpower": "RMCARD-managed Smart App Online, Smart App Sinewave and compatible CyberPower UPS",
    "riello": "NetMan 204 / NetMan 208 managed Riello UPS families",
}

DRIVER_MODES = {"auto", *DRIVERS.keys()}


def power_driver_catalog() -> list[dict[str, str]]:
    ordered = (
        DRIVERS["generic"], DRIVERS["xppc"], DRIVERS["vertiv"], DRIVERS["socomec"],
        DRIVERS["acculine"], DRIVERS["apc"], DRIVERS["eaton"],
        DRIVERS["cyberpower"], DRIVERS["riello"],
    )
    return [
        {
            "key": "auto",
            "name": "Auto detect",
            "protocol": "Identity-first SNMPv3 resolver with vendor MIB enrichment and RFC 1628 fallback",
            "models": "Phoenixtec/XPPC, Vertiv/Liebert, Socomec, AccuLine, APC, Eaton, CyberPower and Riello",
        },
        *[
            {
                "key": driver.key,
                "name": driver.name,
                "protocol": driver.protocol,
                "models": DRIVER_MODELS.get(driver.key, ""),
            }
            for driver in ordered
        ],
    ]


def driver_name(key: str) -> str:
    return DRIVERS.get(str(key or "").strip().lower(), DRIVERS["generic"]).name


def normalize_driver_mode(value: str | None) -> str:
    mode = str(value or "auto").strip().lower()
    return mode if mode in DRIVER_MODES else "auto"


def _normalize_oid(value: Any) -> str:
    return str(value or "").strip().lstrip(".")


def normalize_sys_object_id(value: Any) -> str:
    """Normalize numeric or symbolic sysObjectID renderings to dotted numeric form.

    Some older SNMP agents and PySNMP render an OBJECT IDENTIFIER as
    ``SNMPv2-SMI::enterprises.935.1`` or ``iso.3.6.1.4.1.935.1`` even when
    lookupMib is disabled. Driver detection must not depend on one rendering.
    """
    text = clean_snmp_value(value)
    if not text:
        return ""
    text = text.strip().lstrip(".")
    # Already numeric dotted OID, possibly surrounded by type text.
    match = re.search(r"(?:^|\s|OID:\s*)(1(?:\.\d+){4,})", text, re.I)
    if match:
        return match.group(1).strip(".")
    lower = text.casefold()
    # Common PySNMP symbolic enterprise rendering.
    match = re.search(r"(?:enterprises?|enterprises\()\.?([0-9]+(?:\.[0-9]+)*)", lower)
    if match:
        return "1.3.6.1.4.1." + match.group(1).strip(".")
    # iso.3.6.1.4.1.935.1 style.
    match = re.search(r"(?:^|::)iso\.([0-9]+(?:\.[0-9]+)*)", lower)
    if match:
        return "1." + match.group(1).strip(".")
    return text


def clean_snmp_value(value: Any) -> str:
    text = str(value or "").strip()
    lower = text.casefold()
    if not text or any(marker in lower for marker in NO_VALUE_MARKERS):
        return ""
    return text


def int_value(value: Any, default: int | None = None) -> int | None:
    text = clean_snmp_value(value)
    match = re.search(r"-?\d+", text)
    if not match:
        return default
    try:
        return int(match.group(0))
    except ValueError:
        return default


def apc_battery_capacity_percent(values: dict[str, str]) -> int | None:
    """Return the best APC battery state-of-charge percentage available.

    Prefer the PowerNet high-precision scalar when present, then fall back to
    the classic advanced-capacity scalar. The high-precision object is tenths
    of a percent, so normalize it to the integer percentage stored by Portivo.
    Invalid/out-of-range values are ignored rather than creating misleading
    battery telemetry.
    """
    high_precision = int_value(values.get(APC_HIGH_PREC_BATTERY_CAPACITY))
    if high_precision is not None and 0 <= high_precision <= 1000:
        return max(0, min(100, int(round(high_precision / 10.0))))
    advanced = int_value(values.get(APC_BATTERY_CAPACITY))
    if advanced is not None and 0 <= advanced <= 100:
        return advanced
    return None


def timeticks_to_minutes(value: Any) -> int | None:
    """Best-effort conversion for APC TimeTicks runtime values.

    PySNMP may render TimeTicks as a raw hundredths-of-a-second integer or as a
    human-readable day/hour/minute/second form. We support both without relying
    on local MIB compilation.
    """
    text = clean_snmp_value(value)
    if not text:
        return None
    if re.fullmatch(r"\d+", text):
        ticks = int(text)
        return max(0, int(round(ticks / 6000.0)))
    normalized = text.replace("days", "").replace("day", "").strip()
    # Common PySNMP form: D:HH:MM:SS.hh, with a 3-part HH:MM:SS fallback.
    match = re.search(r"(?:(\d+)\s*:\s*)?(\d{1,2})\s*:\s*(\d{1,2})\s*:\s*(\d{1,2})(?:\.\d+)?", normalized)
    if match:
        days = int(match.group(1) or 0)
        hours = int(match.group(2) or 0)
        minutes = int(match.group(3) or 0)
        seconds = int(match.group(4) or 0)
        total_seconds = days * 86400 + hours * 3600 + minutes * 60 + seconds
        return max(0, int(round(total_seconds / 60.0)))
    match = re.search(r"(\d{1,3})\s*:\s*(\d{1,2})\s*:\s*(\d{1,2})(?:\.\d+)?", normalized)
    if match:
        hours, minutes, seconds = (int(match.group(i)) for i in range(1, 4))
        return max(0, int(round((hours * 3600 + minutes * 60 + seconds) / 60.0)))
    return None


def detect_driver(values: dict[str, str], *, requested: str = "auto") -> PowerDriver:
    mode = normalize_driver_mode(requested)
    if mode != "auto":
        return DRIVERS[mode]
    object_id = normalize_sys_object_id(values.get(SYS_OBJECT_ID))
    identity_text = " ".join(
        clean_snmp_value(values.get(oid))
        for oid in (SYS_DESCR, UPS_IDENT_MANUFACTURER, UPS_IDENT_MODEL)
    ).casefold()

    # Enterprise identity is the strongest signal. Match both canonical roots
    # and embedded numeric renderings so unusual agent formatting cannot send a
    # known UPS back to the Generic RFC1628 path.
    enterprise_markers = (
        (XPPC_ENTERPRISE, "935", "xppc"),
        (APC_ENTERPRISE, "318", "apc"),
        (EATON_ENTERPRISE, "534", "eaton"),
        (VERTIV_ENTERPRISE, "476", "vertiv"),
        (CYBERPOWER_ENTERPRISE, "3808", "cyberpower"),
        (RIELLO_ENTERPRISE, "7783", "riello"),
    )
    for root, enterprise_id, key in enterprise_markers:
        if object_id.startswith(root) or re.search(rf"(?:^|\.){re.escape(enterprise_id)}(?:\.|$)", object_id):
            return DRIVERS[key]

    # Model/manufacturer text is authoritative for families whose network card
    # commonly exposes a generic enterprise identity, especially Socomec.
    if any(alias in identity_text for alias in DRIVERS["socomec"].aliases):
        return DRIVERS["socomec"]
    if any(alias in identity_text for alias in DRIVERS["acculine"].aliases):
        return DRIVERS["acculine"]
    if any(alias in identity_text for alias in DRIVERS["xppc"].aliases):
        return DRIVERS["xppc"]
    if any(alias in identity_text for alias in DRIVERS["apc"].aliases):
        return DRIVERS["apc"]
    if any(alias in identity_text for alias in DRIVERS["eaton"].aliases):
        return DRIVERS["eaton"]
    if any(alias in identity_text for alias in DRIVERS["vertiv"].aliases):
        return DRIVERS["vertiv"]
    if any(alias in identity_text for alias in DRIVERS["cyberpower"].aliases):
        return DRIVERS["cyberpower"]
    if any(alias in identity_text for alias in DRIVERS["riello"].aliases):
        return DRIVERS["riello"]
    return DRIVERS["generic"]


def apc_output_source(value: Any) -> str:
    code = int_value(value, 1) or 1
    return {
        1: "other",
        2: "normal",
        3: "battery",
        4: "booster",
        5: "none",
        6: "bypass",
        7: "none",
        8: "other",
        9: "bypass",
        10: "other",
        11: "none",
        12: "reducer",
    }.get(code, "other")


def eaton_output_source(value: Any) -> str:
    code = int_value(value, 1) or 1
    return {
        1: "other",
        2: "none",
        3: "normal",
        4: "bypass",
        5: "battery",
        6: "booster",
        7: "reducer",
        8: "normal",   # parallel for capacity
        9: "normal",   # parallel redundant
        10: "normal",  # high efficiency mode
        11: "bypass",  # maintenance bypass
    }.get(code, "other")


def xppc_output_source(value: Any) -> str:
    code = int_value(value, 1) or 1
    return {
        1: "unknown", 2: "normal", 3: "battery", 4: "booster", 5: "none",
        6: "bypass", 7: "other", 8: "none", 9: "reducer",
    }.get(code, "unknown")


def xppc_battery_status(value: Any) -> str:
    code = int_value(value, 1) or 1
    return {1: "unknown", 2: "normal", 3: "low"}.get(code, "unknown")


def vertiv_output_source(value: Any) -> str:
    text = clean_snmp_value(value).strip().casefold()
    if text:
        for marker, state in (("battery", "battery"), ("bypass", "bypass"), ("normal", "normal"), ("booster", "booster"), ("reducer", "reducer")):
            if marker in text and not re.fullmatch(r"-?\d+", text):
                return state
    code = int_value(value, 0) or 0
    return {0: "unknown", 1: "normal", 2: "bypass", 3: "battery", 4: "booster", 5: "reducer"}.get(code, "unknown")


def vertiv_system_status(value: Any) -> int:
    text = clean_snmp_value(value).strip().casefold()
    if text and not re.fullmatch(r"-?\d+", text):
        if "on battery" in text or text == "battery":
            return 3
        if "bypass" in text:
            return 4
        if "normal" in text:
            return 2
        if "startup" in text or "starting" in text:
            return 1
        if "shutdown" in text or "output off" in text:
            return 5
        return 0
    return int_value(value, 0) or 0


def _vertiv_alarm_active(value: Any) -> bool:
    text = clean_snmp_value(value).strip().casefold()
    if not text:
        return False
    if text in {"0", "false", "off", "normal", "inactive", "no"}:
        return False
    numeric = int_value(text)
    if numeric is not None:
        return numeric != 0
    return text in {"true", "on", "active", "yes", "alarm", "warning", "critical"}


def enrich_snapshot(driver: PowerDriver, snapshot: dict[str, Any], values: dict[str, str]) -> dict[str, Any]:
    result = dict(snapshot)
    alarms = list(result.get("alarms") or [])

    if driver.key == "xppc":
        model = clean_snmp_value(values.get(XPPC_MODEL))
        firmware = clean_snmp_value(values.get(XPPC_FIRMWARE))
        name = clean_snmp_value(values.get(XPPC_NAME))
        if model:
            result["model"] = model
        if firmware:
            result["software_version"] = firmware
        if name and not str(result.get("reported_name") or "").strip():
            result["reported_name"] = name
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "Phoenixtec / XPPC"
        capacity = int_value(values.get(XPPC_BATTERY_CAPACITY))
        if capacity is None or not (0 <= capacity <= 100):
            capacity = int_value(values.get(XPPC_3P_BATTERY_CAPACITY))
        runtime_seconds = int_value(values.get(XPPC_RUNTIME_SECONDS))
        runtime_3p_minutes = int_value(values.get(XPPC_3P_RUNTIME_MINUTES))
        load = int_value(values.get(XPPC_OUTPUT_LOAD))
        alt_loads = [value for oid in (XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S, XPPC_3P_OUTPUT_LOAD_T)
                     if (value := int_value(values.get(oid))) is not None and 0 <= value <= 200]
        seconds_on_battery = int_value(values.get(XPPC_SECONDS_ON_BATTERY))
        if capacity is not None and 0 <= capacity <= 100:
            result["battery_charge_percent"] = capacity
        # Zero is a common 'not implemented' placeholder on older XPPC cards.
        # Prefer a positive three-phase runtime fallback, then a positive RFC
        # value already present in the normalized snapshot. Never invent time.
        if runtime_seconds is not None and runtime_seconds > 0:
            result["runtime_minutes"] = max(1, int(round(runtime_seconds / 60.0)))
        elif runtime_3p_minutes is not None and runtime_3p_minutes > 0:
            result["runtime_minutes"] = runtime_3p_minutes
        elif int_value(result.get("runtime_minutes")) in (None, 0):
            result["runtime_minutes"] = None
        # Do the same for load. A genuine zero cannot be distinguished from an
        # unsupported placeholder on this MIB, so only publish zero when another
        # source already supplied an authoritative value.
        if load is not None and load > 0 and load <= 200:
            result["load_percent"] = load
        elif any(value > 0 for value in alt_loads):
            result["load_percent"] = max(alt_loads)
        elif int_value(result.get("load_percent")) in (None, 0):
            result["load_percent"] = None
        if seconds_on_battery is not None and seconds_on_battery >= 0:
            result["seconds_on_battery"] = seconds_on_battery
        vendor_source = clean_snmp_value(values.get(XPPC_OUTPUT_STATUS))
        if vendor_source:
            result["output_source"] = xppc_output_source(vendor_source)
        vendor_battery = clean_snmp_value(values.get(XPPC_BATTERY_STATUS))
        if vendor_battery:
            result["battery_status"] = xppc_battery_status(vendor_battery)
        if int_value(values.get(XPPC_BATTERY_REPLACE)) == 2:
            result["battery_status"] = "fault"
            if "Battery replacement required" not in alarms:
                alarms.append("Battery replacement required")

    elif driver.key == "apc":
        model = clean_snmp_value(values.get(APC_MODEL))
        firmware = clean_snmp_value(values.get(APC_FIRMWARE))
        if model:
            result["model"] = model
        if firmware:
            result["software_version"] = firmware
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "APC by Schneider Electric"
        capacity = apc_battery_capacity_percent(values)
        load = int_value(values.get(APC_OUTPUT_LOAD))
        runtime = timeticks_to_minutes(values.get(APC_BATTERY_RUNTIME))
        if capacity is not None:
            result["battery_charge_percent"] = capacity
        if load is not None:
            result["load_percent"] = load
        if runtime is not None and result.get("runtime_minutes") is None:
            result["runtime_minutes"] = runtime
        vendor_source = clean_snmp_value(values.get(APC_OUTPUT_STATUS))
        if vendor_source:
            result["output_source"] = apc_output_source(vendor_source)
        battery_code = int_value(values.get(APC_BATTERY_STATUS))
        if battery_code == 2:
            result["battery_status"] = "normal"
        elif battery_code == 3:
            result["battery_status"] = "low"
        elif battery_code == 4:
            result["battery_status"] = "fault"
            if "Battery fault" not in alarms:
                alarms.append("Battery fault")
        elif battery_code == 1 and not result.get("battery_status"):
            result["battery_status"] = "unknown"
        output_code = int_value(values.get(APC_OUTPUT_STATUS))
        if output_code == 10 and "UPS hardware failure" not in alarms:
            alarms.append("UPS hardware failure")

    elif driver.key == "eaton":
        manufacturer = clean_snmp_value(values.get(EATON_MANUFACTURER))
        model = clean_snmp_value(values.get(EATON_MODEL))
        software = clean_snmp_value(values.get(EATON_SOFTWARE))
        if manufacturer:
            result["manufacturer"] = manufacturer
        elif not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "Eaton"
        if model:
            result["model"] = model
        if software:
            result["software_version"] = software
        runtime_seconds = int_value(values.get(EATON_RUNTIME_SECONDS))
        capacity = int_value(values.get(EATON_BATTERY_CAPACITY))
        load = int_value(values.get(EATON_OUTPUT_LOAD))
        if runtime_seconds is not None:
            result["runtime_minutes"] = max(0, int(round(runtime_seconds / 60.0)))
        if capacity is not None:
            result["battery_charge_percent"] = capacity
        if load is not None:
            result["load_percent"] = load
        vendor_source = clean_snmp_value(values.get(EATON_OUTPUT_SOURCE))
        if vendor_source:
            result["output_source"] = eaton_output_source(vendor_source)
        abm = int_value(values.get(EATON_BATTERY_ABM_STATUS))
        if abm == 2:
            result["battery_status"] = "discharging"
        elif abm in {1, 3, 4, 7}:
            result["battery_status"] = "normal"
        elif abm == 6:
            result["battery_status"] = "fault"
            if "Battery disconnected" not in alarms:
                alarms.append("Battery disconnected")
        elif abm == 8:
            result["battery_status"] = "fault"
            if "Check battery" not in alarms:
                alarms.append("Check battery")

    elif driver.key == "vertiv":
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "Vertiv / Liebert"
        capacity = _float_value(values.get(VERTIV_BATTERY_CAPACITY))
        runtime = _float_value(values.get(VERTIV_BATTERY_RUNTIME))
        load = _float_value(values.get(VERTIV_OUTPUT_LOAD))
        if capacity is not None and 0 <= capacity <= 100:
            result["battery_charge_percent"] = max(0, min(100, int(round(capacity))))
        if runtime is not None and runtime >= 0:
            result["runtime_minutes"] = max(0, int(round(runtime)))
        if load is not None and 0 <= load <= 200:
            result["load_percent"] = max(0, int(round(load)))
        vendor_source = clean_snmp_value(values.get(VERTIV_OUTPUT_SOURCE))
        if vendor_source:
            result["output_source"] = vertiv_output_source(vendor_source)
        system_status = vertiv_system_status(values.get(VERTIV_SYSTEM_STATUS))
        if system_status == 3:
            result["output_source"] = "battery"
            result["battery_status"] = "discharging"
        elif system_status == 4 and str(result.get("output_source") or "") in {"", "unknown", "other"}:
            result["output_source"] = "bypass"
        elif system_status == 2 and str(result.get("output_source") or "") in {"", "unknown", "other"}:
            result["output_source"] = "normal"
        for oid, label in VERTIV_ALARM_OIDS.items():
            if _vertiv_alarm_active(values.get(oid)) and label not in alarms:
                alarms.append(label)
        if _vertiv_alarm_active(values.get(VERTIV_ALARM_BATTERY_LOW)):
            result["battery_status"] = "low"
        elif _vertiv_alarm_active(values.get(VERTIV_ALARM_REPLACE_BATTERY)) or _vertiv_alarm_active(values.get(VERTIV_ALARM_BATTERY_TEMP)):
            result["battery_status"] = "fault"
        elif _vertiv_alarm_active(values.get(VERTIV_ALARM_BATTERY_DISCHARGING)):
            result["battery_status"] = "discharging"
        elif result.get("battery_status") in {None, "", "unknown"} and result.get("battery_charge_percent") is not None:
            result["battery_status"] = "normal"

    elif driver.key == "socomec":
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "Socomec"

    elif driver.key == "acculine":
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "AccuLine"

    elif driver.key == "cyberpower":
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "CyberPower"

    elif driver.key == "riello":
        if not str(result.get("manufacturer") or "").strip():
            result["manufacturer"] = "Riello UPS"

    result["alarms"] = list(dict.fromkeys(str(item) for item in alarms if str(item).strip()))[:24]
    result["alarm_count"] = max(int(result.get("alarm_count") or 0), len(result["alarms"]))
    result["driver_key"] = driver.key
    result["driver_name"] = driver.name
    result["driver_protocol"] = driver.protocol
    result["sys_object_id"] = normalize_sys_object_id(values.get(SYS_OBJECT_ID))
    return result


def vendor_alarm_label(driver: PowerDriver, value: Any) -> str:
    oid = _normalize_oid(clean_snmp_value(value))
    if not oid:
        return ""
    if driver.key == "eaton":
        return EATON_ALARM_LABELS.get(oid, oid)
    return oid


def driver_has_vendor_evidence(driver: PowerDriver, values: dict[str, str]) -> bool:
    if driver.key == "xppc":
        return any(clean_snmp_value(values.get(oid)) for oid in (XPPC_MODEL, XPPC_BATTERY_STATUS, XPPC_OUTPUT_STATUS, XPPC_BATTERY_CAPACITY))
    if driver.key == "apc":
        return any(clean_snmp_value(values.get(oid)) for oid in (APC_MODEL, APC_BATTERY_STATUS, APC_OUTPUT_STATUS))
    if driver.key == "eaton":
        return any(clean_snmp_value(values.get(oid)) for oid in (EATON_MODEL, EATON_BATTERY_CAPACITY, EATON_OUTPUT_SOURCE))
    if driver.key == "vertiv":
        return any(clean_snmp_value(values.get(oid)) for oid in (VERTIV_SYSTEM_STATUS, VERTIV_BATTERY_CAPACITY, VERTIV_OUTPUT_SOURCE, VERTIV_OUTPUT_LOAD))
    return False


def _float_value(value: Any, scale: float = 1.0) -> float | None:
    text = clean_snmp_value(value)
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return round(float(match.group(0)) * float(scale), 3)
    except (TypeError, ValueError):
        return None


def _metric(key: str, label: str, value: Any, unit: str = "", source: str = "") -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, str) and not clean_snmp_value(value):
        return None
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


def vendor_detail_scalar_oids(driver: PowerDriver) -> list[str]:
    if driver.key == "xppc":
        return [
            XPPC_MODEL, XPPC_NAME, XPPC_FIRMWARE, XPPC_MANUFACTURE_DATE, XPPC_SERIAL_NUMBER, XPPC_AGENT_FIRMWARE,
            XPPC_BATTERY_STATUS, XPPC_SECONDS_ON_BATTERY, XPPC_BATTERY_LAST_REPLACE, XPPC_BATTERY_CAPACITY,
            XPPC_BATTERY_VOLTAGE, XPPC_BATTERY_TEMPERATURE, XPPC_RUNTIME_SECONDS, XPPC_BATTERY_REPLACE,
            XPPC_FULL_CHARGE_VOLTAGE, XPPC_BATTERY_CURRENT_PERCENT, XPPC_INPUT_PHASES, XPPC_INPUT_VOLTAGE,
            XPPC_INPUT_MAX_VOLTAGE, XPPC_INPUT_MIN_VOLTAGE, XPPC_INPUT_FREQUENCY, XPPC_INPUT_FAIL_CAUSE,
            XPPC_OUTPUT_STATUS, XPPC_OUTPUT_PHASES, XPPC_OUTPUT_VOLTAGE, XPPC_OUTPUT_FREQUENCY, XPPC_OUTPUT_LOAD,
            XPPC_NUM_ATTACHED_DEVICES, XPPC_RATED_OUTPUT_VOLTAGE, XPPC_HIGH_TRANSFER_VOLTAGE, XPPC_LOW_TRANSFER_VOLTAGE,
            XPPC_MIN_RETURN_CAPACITY, XPPC_LOW_BATTERY_RUNTIME,
            XPPC_3P_BATTERY_VOLTAGE, XPPC_3P_BATTERY_CAPACITY, XPPC_3P_RUNTIME_MINUTES,
            XPPC_3P_BATTERY_CURRENT, XPPC_3P_BATTERY_TEMPERATURE, XPPC_3P_INPUT_FREQUENCY,
            XPPC_3P_INPUT_VOLTAGE_R, XPPC_3P_INPUT_VOLTAGE_S, XPPC_3P_INPUT_VOLTAGE_T,
            XPPC_3P_OUTPUT_FREQUENCY, XPPC_3P_OUTPUT_VOLTAGE_R, XPPC_3P_OUTPUT_VOLTAGE_S,
            XPPC_3P_OUTPUT_VOLTAGE_T, XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S,
            XPPC_3P_OUTPUT_LOAD_T, XPPC_3P_BYPASS_FREQUENCY, XPPC_ENV_TEMPERATURE, XPPC_ENV_HUMIDITY,
        ]
    if driver.key == "apc":
        return [
            APC_MODEL_TYPE, APC_MANUFACTURE_DATE, APC_SERIAL_NUMBER, APC_BATTERY_LAST_REPLACE,
            APC_BATTERY_TEMPERATURE, APC_BATTERY_VOLTAGE, APC_BATTERY_CURRENT, APC_BATTERY_BREAKER,
            APC_HIGH_PREC_BATTERY_TEMPERATURE, APC_HIGH_PREC_BATTERY_CURRENT, APC_HIGH_PREC_BATTERY_VOLTAGE,
            APC_INPUT_FREQUENCY, APC_INPUT_ACTIVE_POWER, APC_OUTPUT_ACTIVE_POWER, APC_BATTERY_CABINET_AH,
            APC_BATTERY_TEST_LAST_DATE, APC_BATTERY_TEST_PROCESS, APC_BATTERY_TEST_CONDITION, APC_COMM_STATUS,
        ]
    if driver.key == "eaton":
        return [
            EATON_BATTERY_VOLTAGE, EATON_BATTERY_CURRENT, EATON_BATTERY_LAST_REPLACED,
            EATON_INPUT_FREQUENCY, EATON_INPUT_LINE_BADS, EATON_INPUT_NUM_PHASES, EATON_INPUT_SOURCE, EATON_DUAL_INPUT_STATUS,
            EATON_OUTPUT_FREQUENCY, EATON_OUTPUT_NUM_PHASES, EATON_BYPASS_FREQUENCY, EATON_BYPASS_NUM_PHASES,
            EATON_AMBIENT_TEMPERATURE, EATON_AMBIENT_HUMIDITY, EATON_REMOTE_TEMPERATURE, EATON_REMOTE_HUMIDITY,
            EATON_BATTERY_TEST_STATUS, EATON_LAST_GENERAL_TEST, EATON_LAST_GENERAL_TEST_RESULT,
            EATON_CONFIG_OUTPUT_VOLTAGE, EATON_CONFIG_INPUT_VOLTAGE, EATON_CONFIG_OUTPUT_WATTS,
            EATON_CONFIG_OUTPUT_FREQUENCY, EATON_CONFIG_INSTALL_DATE, EATON_TOPOLOGY_TYPE, EATON_POWER_STRATEGY,
        ]
    if driver.key == "vertiv":
        return [
            VERTIV_ECO_MODE_STATE, VERTIV_ECO_MODE_STATUS, VERTIV_BATTERY_VOLTAGE, VERTIV_BATTERY_CURRENT,
            VERTIV_BATTERY_TEMPERATURE, VERTIV_BATTERY_REPLACEMENT_DATE, VERTIV_INPUT_VOLTAGE,
            VERTIV_INPUT_FREQUENCY, VERTIV_INPUT_CURRENT, VERTIV_INPUT_POWER_FACTOR, VERTIV_INPUT_VOLTAGE_MAX,
            VERTIV_INPUT_VOLTAGE_MIN, VERTIV_INPUT_BLACKOUT_COUNT, VERTIV_OUTPUT_CURRENT, VERTIV_OUTPUT_POWER,
            VERTIV_OUTPUT_FREQUENCY, VERTIV_OUTPUT_APPARENT_POWER, VERTIV_OUTPUT_POWER_FACTOR,
            VERTIV_OUTPUT_APPARENT_POWER_RATING, VERTIV_AMBIENT_TEMPERATURE, VERTIV_ALARM_BATTERY_TEMP,
            VERTIV_ALARM_BYPASS_UNAVAILABLE,
        ]
    return []


def vendor_detail_walk_oids(driver: PowerDriver) -> dict[str, str]:
    if driver.key == "apc":
        return {"nmc": APC_NMC_DIAG_TABLE, "environment": APC_UIO_SENSOR_TABLE}
    if driver.key == "eaton":
        return {"input": EATON_INPUT_TABLE, "output": EATON_OUTPUT_TABLE, "bypass": EATON_BYPASS_TABLE}
    return {}


def _table_by_index(rows: list[tuple[str, str]], base_oid: str) -> dict[str, dict[int, str]]:
    base = _normalize_oid(base_oid)
    grouped: dict[str, dict[int, str]] = {}
    for oid, raw in rows or []:
        normalized = _normalize_oid(oid)
        if not normalized.startswith(base + "."):
            continue
        suffix = normalized[len(base) + 1:].split(".")
        if len(suffix) < 2:
            continue
        try:
            column = int(suffix[0])
        except ValueError:
            continue
        index = ".".join(suffix[1:])
        value = clean_snmp_value(raw)
        if value:
            grouped.setdefault(index, {})[column] = value
    return grouped


def build_vendor_detail_metrics(driver: PowerDriver, values: dict[str, str], walks: dict[str, list[tuple[str, str]]] | None = None) -> dict[str, list[dict[str, Any]]]:
    walks = walks or {}
    sections: dict[str, list[dict[str, Any]]] = {"identity": [], "battery": [], "input": [], "output": [], "bypass": [], "diagnostics": [], "environment": []}
    add = lambda section, item: sections[section].append(item) if item else None

    if driver.key == "xppc":
        src = "Phoenixtec XPPC-MIB"
        add("identity", _metric("model", "Model", clean_snmp_value(values.get(XPPC_MODEL)), source=src))
        add("identity", _metric("reported_name", "UPS name", clean_snmp_value(values.get(XPPC_NAME)), source=src))
        add("identity", _metric("ups_software", "UPS firmware", clean_snmp_value(values.get(XPPC_FIRMWARE)), source=src))
        add("identity", _metric("manufacture_date", "Manufacture date", clean_snmp_value(values.get(XPPC_MANUFACTURE_DATE)), source=src))
        add("identity", _metric("serial_number", "UPS serial number", clean_snmp_value(values.get(XPPC_SERIAL_NUMBER)), source=src))
        add("identity", _metric("agent_software", "SNMP agent firmware", clean_snmp_value(values.get(XPPC_AGENT_FIRMWARE)), source=src))

        status = xppc_battery_status(values.get(XPPC_BATTERY_STATUS))
        add("battery", _metric("battery_status", "Battery status", status.replace("_", " ").title() if status != "unknown" else None, source=src))
        capacity = int_value(values.get(XPPC_BATTERY_CAPACITY))
        if capacity is None or not (0 <= capacity <= 100):
            capacity = int_value(values.get(XPPC_3P_BATTERY_CAPACITY))
        add("battery", _metric("battery_charge", "Battery capacity remaining", capacity, "%", src))
        runtime_seconds = int_value(values.get(XPPC_RUNTIME_SECONDS))
        runtime_3p = int_value(values.get(XPPC_3P_RUNTIME_MINUTES))
        runtime_minutes = (round(runtime_seconds / 60.0, 1) if runtime_seconds is not None and runtime_seconds > 0
                           else runtime_3p if runtime_3p is not None and runtime_3p > 0 else None)
        add("battery", _metric("battery_runtime", "Battery time remaining", runtime_minutes, "min", src))
        add("battery", _metric("seconds_on_battery", "Time running on battery", int_value(values.get(XPPC_SECONDS_ON_BATTERY)), "s", src))
        battery_voltage = _float_value(values.get(XPPC_BATTERY_VOLTAGE), 0.1)
        if battery_voltage in (None, 0):
            battery_voltage = _float_value(values.get(XPPC_3P_BATTERY_VOLTAGE), 0.1)
        battery_temp = _float_value(values.get(XPPC_BATTERY_TEMPERATURE), 0.1)
        if battery_temp in (None, 0):
            battery_temp = _float_value(values.get(XPPC_3P_BATTERY_TEMPERATURE), 0.1)
        add("battery", _metric("battery_voltage", "Battery voltage", battery_voltage if battery_voltage not in (None, 0) else None, "V", src))
        add("battery", _metric("battery_temperature", "Battery temperature", battery_temp if battery_temp not in (None, 0) else None, "°C", src))
        add("battery", _metric("battery_current", "Battery current utilization", _float_value(values.get(XPPC_BATTERY_CURRENT_PERCENT)), "% max", src))
        add("battery", _metric("battery_full_charge_voltage", "Full-charge battery voltage", _float_value(values.get(XPPC_FULL_CHARGE_VOLTAGE), 0.1), "V", src))
        replace_code = int_value(values.get(XPPC_BATTERY_REPLACE))
        add("battery", _metric("battery_replace", "Battery replacement", {1:"Not required",2:"Required"}.get(replace_code), source=src))
        add("battery", _metric("battery_last_replaced", "Last battery replacement", clean_snmp_value(values.get(XPPC_BATTERY_LAST_REPLACE)), source=src))

        add("input", _metric("input_lines", "Input phases", int_value(values.get(XPPC_INPUT_PHASES)), source=src))
        add("input", _metric("input_voltage_1", "Input voltage L1", _float_value(values.get(XPPC_INPUT_VOLTAGE), 0.1), "V", src))
        add("input", _metric("input_voltage_max", "Maximum input voltage", _float_value(values.get(XPPC_INPUT_MAX_VOLTAGE), 0.1), "V", src))
        add("input", _metric("input_voltage_min", "Minimum input voltage", _float_value(values.get(XPPC_INPUT_MIN_VOLTAGE), 0.1), "V", src))
        add("input", _metric("input_frequency_1", "Input frequency L1", _float_value(values.get(XPPC_INPUT_FREQUENCY), 0.1), "Hz", src))
        add("diagnostics", _metric("input_fail_cause", "Last input transfer cause", int_value(values.get(XPPC_INPUT_FAIL_CAUSE)), source=src))

        source_code = int_value(values.get(XPPC_OUTPUT_STATUS))
        source_label = xppc_output_source(values.get(XPPC_OUTPUT_STATUS)).replace("_", " ").title() if source_code is not None else None
        add("output", _metric("output_source", "UPS operation mode", source_label, source=src))
        add("output", _metric("output_lines", "Output phases", int_value(values.get(XPPC_OUTPUT_PHASES)), source=src))
        output_voltage = _float_value(values.get(XPPC_OUTPUT_VOLTAGE), 0.1)
        if output_voltage in (None, 0):
            output_voltage = next((v for oid in (XPPC_3P_OUTPUT_VOLTAGE_R, XPPC_3P_OUTPUT_VOLTAGE_S, XPPC_3P_OUTPUT_VOLTAGE_T)
                                   if (v := _float_value(values.get(oid), 0.1)) not in (None, 0)), None)
        output_frequency = _float_value(values.get(XPPC_OUTPUT_FREQUENCY), 0.1)
        if output_frequency in (None, 0):
            output_frequency = _float_value(values.get(XPPC_3P_OUTPUT_FREQUENCY), 0.1)
        output_load = _float_value(values.get(XPPC_OUTPUT_LOAD))
        alt_loads = [v for oid in (XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S, XPPC_3P_OUTPUT_LOAD_T)
                     if (v := _float_value(values.get(oid))) is not None and 0 < v <= 200]
        if output_load in (None, 0) and alt_loads:
            output_load = max(alt_loads)
        add("output", _metric("output_voltage_1", "Output voltage L1", output_voltage if output_voltage not in (None, 0) else None, "V", src))
        add("output", _metric("output_frequency", "Output frequency", output_frequency if output_frequency not in (None, 0) else None, "Hz", src))
        add("output", _metric("output_load_1", "Output load L1", output_load if output_load not in (None, 0) else None, "%", src))
        for phase, oid in ((1, XPPC_3P_OUTPUT_LOAD_R), (2, XPPC_3P_OUTPUT_LOAD_S), (3, XPPC_3P_OUTPUT_LOAD_T)):
            phase_load = _float_value(values.get(oid))
            if phase > 1 and phase_load not in (None, 0):
                add("output", _metric(f"output_load_{phase}", f"Output load L{phase}", phase_load, "%", src))
        add("output", _metric("nominal_output_voltage", "Nominal output voltage", _float_value(values.get(XPPC_RATED_OUTPUT_VOLTAGE), 0.1), "V", src))
        add("input", _metric("high_transfer_voltage", "High voltage transfer point", _float_value(values.get(XPPC_HIGH_TRANSFER_VOLTAGE), 0.1), "V", src))
        add("input", _metric("low_transfer_voltage", "Low voltage transfer point", _float_value(values.get(XPPC_LOW_TRANSFER_VOLTAGE), 0.1), "V", src))
        add("battery", _metric("min_return_capacity", "Minimum return capacity", int_value(values.get(XPPC_MIN_RETURN_CAPACITY)), "%", src))
        add("battery", _metric("low_battery_threshold", "Low battery runtime threshold", int_value(values.get(XPPC_LOW_BATTERY_RUNTIME)), "s", src))
        add("diagnostics", _metric("attached_device_count", "Attached device count", int_value(values.get(XPPC_NUM_ATTACHED_DEVICES)), source=src))
        env_temp = _float_value(values.get(XPPC_ENV_TEMPERATURE), 0.1)
        env_humidity = _float_value(values.get(XPPC_ENV_HUMIDITY))
        add("environment", _metric("ambient_temperature", "Ambient temperature", env_temp if env_temp not in (None, 0) else None, "°C", src))
        add("environment", _metric("ambient_humidity", "Ambient humidity", env_humidity if env_humidity not in (None, 0) else None, "%", src))

    elif driver.key == "apc":
        src = "APC PowerNet"
        add("identity", _metric("apc_model_type", "Model type", clean_snmp_value(values.get(APC_MODEL_TYPE)), source=src))
        add("identity", _metric("manufacture_date", "Manufacture date", clean_snmp_value(values.get(APC_MANUFACTURE_DATE)), source=src))
        add("identity", _metric("serial_number", "Serial number", clean_snmp_value(values.get(APC_SERIAL_NUMBER)), source=src))
        add("identity", _metric("firmware", "UPS firmware", clean_snmp_value(values.get(APC_FIRMWARE)), source=src))

        last_replace = clean_snmp_value(values.get(APC_BATTERY_LAST_REPLACE))
        add("battery", _metric("battery_last_replaced", "Last battery replacement", last_replace, source=src))
        hp_temp = _float_value(values.get(APC_HIGH_PREC_BATTERY_TEMPERATURE), 0.1)
        temp = hp_temp if hp_temp is not None else _float_value(values.get(APC_BATTERY_TEMPERATURE))
        add("battery", _metric("battery_temperature", "Battery temperature", temp, "° (NMC unit)", src))
        hp_voltage = _float_value(values.get(APC_HIGH_PREC_BATTERY_VOLTAGE), 0.1)
        voltage = hp_voltage if hp_voltage is not None else _float_value(values.get(APC_BATTERY_VOLTAGE))
        add("battery", _metric("battery_voltage", "Battery voltage", voltage, "V", src))
        hp_current = _float_value(values.get(APC_HIGH_PREC_BATTERY_CURRENT), 0.1)
        current = hp_current if hp_current is not None else _float_value(values.get(APC_BATTERY_CURRENT))
        add("battery", _metric("battery_current", "Battery current", current, "A", src))
        breaker = int_value(values.get(APC_BATTERY_BREAKER))
        breaker_label = {1: "Open", 2: "Closed", 3: "Not present"}.get(breaker)
        add("battery", _metric("battery_breaker", "Battery breaker", breaker_label, source=src))
        add("battery", _metric("battery_capacity_ah", "Configured battery capacity", _float_value(values.get(APC_BATTERY_CABINET_AH)), "Ah", src))

        add("input", _metric("input_frequency", "Input frequency", _float_value(values.get(APC_INPUT_FREQUENCY)), "Hz", src))
        add("input", _metric("input_active_power", "Input active power", _float_value(values.get(APC_INPUT_ACTIVE_POWER)), "kW", src))
        add("output", _metric("output_active_power", "Output active power", _float_value(values.get(APC_OUTPUT_ACTIVE_POWER)), "W", src))

        add("diagnostics", _metric("last_battery_test", "Last battery test", clean_snmp_value(values.get(APC_BATTERY_TEST_LAST_DATE)), source=src))
        test_process = int_value(values.get(APC_BATTERY_TEST_PROCESS))
        add("diagnostics", _metric("battery_test_process", "Battery test process", {1:"Successful",2:"Precondition not met",3:"In progress",4:"Refused",5:"Cancelled",6:"Pending",7:"Unknown"}.get(test_process), source=src))
        test_condition = int_value(values.get(APC_BATTERY_TEST_CONDITION))
        add("diagnostics", _metric("battery_test_condition", "Battery test condition", {1:"Unknown",2:"Battery OK",3:"Battery capacity lower",4:"Battery defect"}.get(test_condition), source=src))
        comm = int_value(values.get(APC_COMM_STATUS))
        add("diagnostics", _metric("ups_communication", "UPS communication", {1:"Unknown",2:"Communication OK",3:"Communication lost"}.get(comm, clean_snmp_value(values.get(APC_COMM_STATUS))), source=src))

        nmc_rows = _table_by_index(walks.get("nmc", []), APC_NMC_DIAG_TABLE)
        if nmc_rows:
            first = nmc_rows[sorted(nmc_rows.keys())[0]]
            for key, label, col in [
                ("nmc_model", "Network card model", 2), ("nmc_serial", "Network card serial", 3),
                ("nmc_manufacture_date", "Network card manufacture date", 4), ("nmc_hardware", "Network card hardware", 5),
                ("nmc_firmware", "Network card firmware", 6),
            ]:
                add("identity", _metric(key, label, first.get(col), source=src))

        sensor_rows = _table_by_index(walks.get("environment", []), APC_UIO_SENSOR_TABLE)
        for index in sorted(sensor_rows.keys()):
            row = sensor_rows[index]
            name = row.get(3) or f"Sensor {index}"
            location = row.get(4) or ""
            prefix = f"{name} · " if name else ""
            temp_c = _float_value(row.get(6))
            humidity = _float_value(row.get(7))
            alarm_code = int_value(row.get(9))
            comm_code = int_value(row.get(10))
            add("environment", _metric(f"sensor_{index}_temperature", f"{prefix}Temperature", temp_c, "°C", src))
            add("environment", _metric(f"sensor_{index}_humidity", f"{prefix}Humidity", humidity, "%", src))
            add("environment", _metric(f"sensor_{index}_location", f"{prefix}Location", location, source=src))
            add("environment", _metric(f"sensor_{index}_alarm", f"{prefix}Status", {1:"Normal",2:"Warning",3:"Critical",4:"N/A"}.get(alarm_code), source=src))
            add("environment", _metric(f"sensor_{index}_comm", f"{prefix}Communication", {1:"Not installed",2:"Communication OK",3:"Communication lost"}.get(comm_code), source=src))

    elif driver.key == "vertiv":
        src = "Vertiv Liebert Global Products MIB"
        add("battery", _metric("battery_voltage", "Battery voltage", _float_value(values.get(VERTIV_BATTERY_VOLTAGE)), "V", src))
        add("battery", _metric("battery_current", "Battery current", _float_value(values.get(VERTIV_BATTERY_CURRENT)), "A", src))
        add("battery", _metric("battery_temperature", "Battery temperature", _float_value(values.get(VERTIV_BATTERY_TEMPERATURE)), "°C", src))
        add("battery", _metric("battery_last_replaced", "Last battery replacement", clean_snmp_value(values.get(VERTIV_BATTERY_REPLACEMENT_DATE)), source=src))
        add("input", _metric("input_voltage", "Input voltage L1-N", _float_value(values.get(VERTIV_INPUT_VOLTAGE)), "V", src))
        add("input", _metric("input_frequency", "Input frequency", _float_value(values.get(VERTIV_INPUT_FREQUENCY)), "Hz", src))
        add("input", _metric("input_current", "Input current L1", _float_value(values.get(VERTIV_INPUT_CURRENT)), "A", src))
        add("input", _metric("input_power_factor", "Input power factor L1", _float_value(values.get(VERTIV_INPUT_POWER_FACTOR)), "", src))
        add("input", _metric("input_voltage_max", "Maximum input voltage L1-N", _float_value(values.get(VERTIV_INPUT_VOLTAGE_MAX)), "V", src))
        add("input", _metric("input_voltage_min", "Minimum input voltage L1-N", _float_value(values.get(VERTIV_INPUT_VOLTAGE_MIN)), "V", src))
        add("diagnostics", _metric("input_blackout_count", "Input blackout count", int_value(values.get(VERTIV_INPUT_BLACKOUT_COUNT)), source=src))
        add("output", _metric("output_current", "Output current", _float_value(values.get(VERTIV_OUTPUT_CURRENT)), "A", src))
        add("output", _metric("output_power", "Output active power", _float_value(values.get(VERTIV_OUTPUT_POWER)), "W", src))
        add("output", _metric("output_frequency", "Output frequency", _float_value(values.get(VERTIV_OUTPUT_FREQUENCY)), "Hz", src))
        add("output", _metric("output_apparent_power", "Output apparent power", _float_value(values.get(VERTIV_OUTPUT_APPARENT_POWER)), "VA", src))
        add("output", _metric("output_power_factor", "Output power factor L1", _float_value(values.get(VERTIV_OUTPUT_POWER_FACTOR)), "", src))
        add("output", _metric("rated_output_va", "Rated output apparent power", _float_value(values.get(VERTIV_OUTPUT_APPARENT_POWER_RATING)), "VA", src))
        add("environment", _metric("ambient_temperature", "Inlet air temperature", _float_value(values.get(VERTIV_AMBIENT_TEMPERATURE)), "°C", src))
        system_status = vertiv_system_status(values.get(VERTIV_SYSTEM_STATUS))
        add("diagnostics", _metric("system_status", "System status", {0:"Unknown",1:"Startup",2:"Normal",3:"On battery",4:"On bypass",5:"Shutdown"}.get(system_status), source=src))
        eco_state = int_value(values.get(VERTIV_ECO_MODE_STATE))
        eco_status = int_value(values.get(VERTIV_ECO_MODE_STATUS))
        add("diagnostics", _metric("eco_mode_state", "ECO operation state", eco_state, source=src))
        add("diagnostics", _metric("eco_mode_status", "ECO mode status", eco_status, source=src))
        for oid, label in VERTIV_ALARM_OIDS.items():
            if _vertiv_alarm_active(values.get(oid)):
                add("diagnostics", _metric(f"alarm_{oid.rsplit('.', 1)[-1]}", label, "Active", source=src))

    elif driver.key == "eaton":
        src = "Eaton xUPS"
        add("identity", _metric("firmware", "UPS software", clean_snmp_value(values.get(EATON_SOFTWARE)), source=src))
        add("battery", _metric("battery_voltage", "Battery voltage", _float_value(values.get(EATON_BATTERY_VOLTAGE)), "V", src))
        add("battery", _metric("battery_current", "Battery current", _float_value(values.get(EATON_BATTERY_CURRENT)), "A", src))
        add("battery", _metric("battery_last_replaced", "Last battery replacement", clean_snmp_value(values.get(EATON_BATTERY_LAST_REPLACED)), source=src))
        add("input", _metric("input_frequency", "Input frequency", _float_value(values.get(EATON_INPUT_FREQUENCY), 0.1), "Hz", src))
        add("input", _metric("input_line_bads", "Input out-of-tolerance count", int_value(values.get(EATON_INPUT_LINE_BADS)), source=src))
        add("input", _metric("input_phases", "Input phases", int_value(values.get(EATON_INPUT_NUM_PHASES)), source=src))
        input_source = int_value(values.get(EATON_INPUT_SOURCE))
        add("input", _metric("input_source", "Input source", {1:"Other",2:"None",3:"Primary utility",4:"Bypass feed",5:"Secondary utility",6:"Generator",7:"Flywheel",8:"Fuel cell"}.get(input_source), source=src))
        dual = int_value(values.get(EATON_DUAL_INPUT_STATUS))
        add("input", _metric("dual_input_status", "Dual input status", {1:"Both sources bad",2:"Primary source good",3:"Secondary source good",4:"Both sources good"}.get(dual), source=src))
        add("output", _metric("output_frequency", "Output frequency", _float_value(values.get(EATON_OUTPUT_FREQUENCY), 0.1), "Hz", src))
        add("output", _metric("output_phases", "Output phases", int_value(values.get(EATON_OUTPUT_NUM_PHASES)), source=src))
        add("bypass", _metric("bypass_frequency", "Bypass frequency", _float_value(values.get(EATON_BYPASS_FREQUENCY), 0.1), "Hz", src))
        add("bypass", _metric("bypass_phases", "Bypass phases", int_value(values.get(EATON_BYPASS_NUM_PHASES)), source=src))
        add("environment", _metric("ambient_temperature", "Ambient temperature", _float_value(values.get(EATON_AMBIENT_TEMPERATURE)), "°C", src))
        add("environment", _metric("ambient_humidity", "Ambient humidity", _float_value(values.get(EATON_AMBIENT_HUMIDITY)), "%", src))
        add("environment", _metric("remote_temperature", "Remote temperature", _float_value(values.get(EATON_REMOTE_TEMPERATURE)), "°C", src))
        add("environment", _metric("remote_humidity", "Remote humidity", _float_value(values.get(EATON_REMOTE_HUMIDITY)), "%", src))
        add("diagnostics", _metric("battery_test_status", "Battery test status", clean_snmp_value(values.get(EATON_BATTERY_TEST_STATUS)), source=src))
        add("diagnostics", _metric("last_general_test", "Last general test", clean_snmp_value(values.get(EATON_LAST_GENERAL_TEST)), source=src))
        add("diagnostics", _metric("last_general_test_result", "Last general test result", clean_snmp_value(values.get(EATON_LAST_GENERAL_TEST_RESULT)), source=src))
        add("diagnostics", _metric("install_date", "UPS install date", clean_snmp_value(values.get(EATON_CONFIG_INSTALL_DATE)), source=src))
        add("output", _metric("nominal_output_voltage", "Nominal output voltage", _float_value(values.get(EATON_CONFIG_OUTPUT_VOLTAGE)), "V", src))
        add("input", _metric("nominal_input_voltage", "Nominal input voltage", _float_value(values.get(EATON_CONFIG_INPUT_VOLTAGE)), "V", src))
        add("output", _metric("rated_output_power", "Rated output power", _float_value(values.get(EATON_CONFIG_OUTPUT_WATTS)), "W", src))
        add("output", _metric("nominal_output_frequency", "Nominal output frequency", _float_value(values.get(EATON_CONFIG_OUTPUT_FREQUENCY), 0.1), "Hz", src))
        add("identity", _metric("topology_type", "UPS topology type", clean_snmp_value(values.get(EATON_TOPOLOGY_TYPE)), source=src))
        add("diagnostics", _metric("power_strategy", "Power strategy", clean_snmp_value(values.get(EATON_POWER_STRATEGY)), source=src))

        for section, base in [("input", EATON_INPUT_TABLE), ("output", EATON_OUTPUT_TABLE), ("bypass", EATON_BYPASS_TABLE)]:
            grouped = _table_by_index(walks.get(section, []), base)
            for index in sorted(grouped.keys()):
                row = grouped[index]
                phase = int_value(row.get(1)) or index
                if section == "input":
                    add(section, _metric(f"input_voltage_{phase}", f"Input voltage L{phase}", _float_value(row.get(2)), "V", src))
                    add(section, _metric(f"input_current_{phase}", f"Input current L{phase}", _float_value(row.get(3)), "A", src))
                    add(section, _metric(f"input_watts_{phase}", f"Input power L{phase}", _float_value(row.get(4)), "W", src))
                elif section == "output":
                    add(section, _metric(f"output_voltage_{phase}", f"Output voltage L{phase}", _float_value(row.get(2)), "V", src))
                    add(section, _metric(f"output_current_{phase}", f"Output current L{phase}", _float_value(row.get(3)), "A", src))
                    add(section, _metric(f"output_watts_{phase}", f"Output power L{phase}", _float_value(row.get(4)), "W", src))
                else:
                    add(section, _metric(f"bypass_voltage_{phase}", f"Bypass voltage L{phase}", _float_value(row.get(2)), "V", src))

    return {key: values for key, values in sections.items() if values}
