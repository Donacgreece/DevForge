# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import io
import html
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

from .time_service import format_platform_datetime, platform_timezone_name

_FONT_REGULAR = "Helvetica"
_FONT_BOLD = "Helvetica-Bold"
_FONTS_READY = False

COLORS = {
    "purple": colors.HexColor("#6D3EE7"),
    "navy": colors.HexColor("#111827"),
    "slate": colors.HexColor("#64748B"),
    "line": colors.HexColor("#D8DEEA"),
    "panel": colors.HexColor("#F4F6FB"),
    "healthy": colors.HexColor("#15966F"),
    "warning": colors.HexColor("#D58B16"),
    "critical": colors.HexColor("#D23D5A"),
    "unavailable": colors.HexColor("#64748B"),
    "info": colors.HexColor("#4B6CB7"),
}

AUDIT_TRANSLATIONS = {
    "el": {
        "thermal_health": ("Έλεγχος Θερμικής Κατάστασης", "Προτεραιότητα έχουν η κατάσταση και τα θερμικά όρια που αναφέρει η ίδια η συσκευή. Τιμές χωρίς επιβεβαιωμένο όριο εμφανίζονται χωρίς αυθαίρετη εκτίμηση."),
        "fan_cooling": ("Έλεγχος Ανεμιστήρων & Ψύξης", "Ρητές ενδείξεις βλάβης ή υποβάθμισης ανεμιστήρα καταγράφονται ως ευρήματα. Προαιρετικές κενές θέσεις δεν θεωρούνται βλάβη χωρίς σχετική ένδειξη."),
        "power_supply": ("Έλεγχος Τροφοδοτικών", "Κλιμακώνονται μόνο ρητές καταστάσεις failed, fault ή down. Οι προαιρετικές κενές θέσεις παραμένουν πληροφοριακές."),
        "poe_capacity": ("Έλεγχος Χωρητικότητας PoE", "Η λειτουργική πολιτική του Portivo προειδοποιεί από 80% χρήση PoE budget και χαρακτηρίζει 90% ή περισσότερο ως κρίσιμο. Ρητές καταστάσεις fault ή deny εμφανίζονται πάντα και συσχετίζονται με Ethernet link state και PSU evidence όταν αυτά αναφέρονται."),
        "interface_errors": ("Έλεγχος Σφαλμάτων Interfaces", "Μη μηδενικοί counters εμφανίζονται ανά θύρα και χωρίζονται σε CRC/FCS, errors, drops/discards και collisions. Η τρέχουσα κατάσταση link και το alias εμφανίζονται όταν αναφέρονται από το switch."),
        "port_flapping": ("Έλεγχος Σταθερότητας Θυρών", "Η λειτουργική πολιτική του Portivo προειδοποιεί από 4 παρατηρημένες μεταβάσεις link και χαρακτηρίζει 10 ή περισσότερες ως κρίσιμες μέσα στο διαθέσιμο παράθυρο log. Η τρέχουσα κατάσταση της θύρας εμφανίζεται ξεχωριστά από το ιστορικό."),
        "uplink_health": ("Έλεγχος Υγείας Uplinks", "Μόνο LLDP γείτονες που αντιστοιχούν σε managed switches του Portivo θεωρούνται infrastructure uplinks. Μη υποστηριζόμενα στοιχεία δηλώνονται ως μη διαθέσιμα και δεν μαντεύονται."),
        "lag_health": ("Έλεγχος Υγείας LAG", "Ρητές καταστάσεις down, detached ή fault σε members κλιμακώνονται. Μη υποστηριζόμενα formats παραμένουν ως Not reported."),
        "configuration_save": ("Έλεγχος Αποθήκευσης Configuration", "Ρητές ενδείξεις not synchronized, unsaved ή working-only αντιμετωπίζονται ως εκκρεμής μόνιμη αποθήκευση configuration."),
        "vlan_unp_consistency": ("Έλεγχος Συνέπειας VLAN / UNP", "Χρησιμοποιεί τους κανόνες προστατευμένων ports και τις δικλείδες GUEST, VOIP και IPTV του Portivo. Ο έλεγχος είναι read-only και δεν αλλάζει configuration."),
        "full_switch_health": ("Πλήρης Έλεγχος Υγείας Switch", "Το health score βασίζεται μόνο σε πραγματικά στοιχεία. Μη υποστηριζόμενα metrics μειώνουν την κάλυψη και όχι το score, ενώ κρίσιμα ευρήματα περιορίζουν το τελικό score."),
    }
}

LABELS = {
    "en": {
        "fleet_audit": "Fleet Audit Report",
        "executive": "Executive summary",
        "generated": "Generated",
        "requested": "Requested by",
        "targets": "Switches assessed",
        "completed": "Completed",
        "healthy": "Healthy",
        "warning": "Warning",
        "critical": "Critical",
        "unavailable": "Unavailable",
        "info": "Informational",
        "policy": "Assessment policy",
        "top_findings": "Priority findings",
        "details": "Detailed switch results",
        "switch": "Switch",
        "address": "Management IP",
        "site": "Site",
        "model": "Model",
        "severity": "Assessment",
        "score": "Score",
        "summary": "Summary",
        "threshold_coverage": "Thermal threshold coverage",
        "verified_threshold": "Vendor/device threshold verified",
        "observed_only": "Temperature observed, threshold unavailable",
        "above_warning": "Sensors above warning threshold",
        "above_critical": "Sensors in critical zone",
        "not_reported": "Temperature not reported",
        "hottest": "Highest observed temperatures",
        "page": "Page",
        "confidential": "Portivo Control Center - operational audit",
        "diagnostics": "Diagnostic findings",
        "interpretation": "What this means",
        "recommended": "Recommended checks",
        "collection": "Data collection",
        "commands": "Read-only command(s)",
        "collection_notes": "Collection notes",
        "affected_components": "Affected components",
        "reported_status": "Switch-reported status",
        "location": "Location",
        "maximum_power": "Maximum power",
        "used_power": "Power used",
        "assessment": "Assessment",
        "metric": "Metric",
        "value": "Value",
        "component": "Component",
        "evidence": "Evidence",
        "recent_evidence": "Recent evidence",
        "evidence_scope": "Evidence detail",
        "evidence_scope_note": "For scopes up to 25 switches, a detailed evidence section is included for every assessed switch. For larger fleet scopes, full evidence sections are included for Warning, Critical and Unavailable results while healthy switches remain in the detailed fleet table.",
        "evidence_scope_note_small": "A detailed evidence section is included for every assessed switch in this report.",
    },
    "el": {
        "fleet_audit": "Αναφορά Ελέγχου Fleet",
        "executive": "Σύνοψη ελέγχου",
        "generated": "Δημιουργήθηκε",
        "requested": "Ζητήθηκε από",
        "targets": "Switches που ελέγχθηκαν",
        "completed": "Ολοκληρώθηκαν",
        "healthy": "Υγιή",
        "warning": "Προειδοποίηση",
        "critical": "Κρίσιμα",
        "unavailable": "Μη διαθέσιμα",
        "info": "Πληροφοριακά",
        "policy": "Πολιτική αξιολόγησης",
        "top_findings": "Ευρήματα προτεραιότητας",
        "details": "Αναλυτικά αποτελέσματα ανά switch",
        "switch": "Switch",
        "address": "Management IP",
        "site": "Site",
        "model": "Μοντέλο",
        "severity": "Αξιολόγηση",
        "score": "Βαθμός",
        "summary": "Σύνοψη",
        "threshold_coverage": "Κάλυψη θερμικών ορίων",
        "verified_threshold": "Επιβεβαιωμένο όριο από τη συσκευή",
        "observed_only": "Θερμοκρασία διαθέσιμη χωρίς επιβεβαιωμένο όριο",
        "above_warning": "Αισθητήρες πάνω από το όριο προειδοποίησης",
        "above_critical": "Αισθητήρες σε κρίσιμη ζώνη",
        "not_reported": "Δεν αναφέρθηκε θερμοκρασία",
        "hottest": "Υψηλότερες θερμοκρασίες",
        "page": "Σελίδα",
        "confidential": "Portivo Control Center - λειτουργικός έλεγχος",
        "diagnostics": "Αναλυτικά διαγνωστικά ευρήματα",
        "interpretation": "Τι σημαίνει το αποτέλεσμα",
        "recommended": "Προτεινόμενοι έλεγχοι",
        "collection": "Συλλογή δεδομένων",
        "commands": "Read-only εντολή/εντολές",
        "collection_notes": "Σημειώσεις συλλογής",
        "affected_components": "Επηρεαζόμενα στοιχεία",
        "reported_status": "Κατάσταση που αναφέρει το switch",
        "location": "Θέση",
        "maximum_power": "Μέγιστη ισχύς",
        "used_power": "Χρησιμοποιούμενη ισχύς",
        "assessment": "Αξιολόγηση",
        "metric": "Μέτρηση",
        "value": "Τιμή",
        "component": "Στοιχείο",
        "evidence": "Στοιχεία",
        "recent_evidence": "Πρόσφατα στοιχεία",
        "evidence_scope": "Ανάλυση στοιχείων",
        "evidence_scope_note": "Για scope έως 25 switches, περιλαμβάνεται αναλυτική ενότητα στοιχείων για κάθε switch. Σε μεγαλύτερα fleet scopes, πλήρεις διαγνωστικές ενότητες περιλαμβάνονται για Warning, Critical και Unavailable αποτελέσματα, ενώ τα υγιή switches παραμένουν στον αναλυτικό fleet πίνακα.",
        "evidence_scope_note_small": "Περιλαμβάνεται αναλυτική ενότητα στοιχείων για κάθε switch που ελέγχθηκε σε αυτή την αναφορά.",
    },
}


def _register_fonts() -> None:
    global _FONTS_READY, _FONT_REGULAR, _FONT_BOLD
    if _FONTS_READY:
        return
    candidates = [
        (Path("C:/Windows/Fonts/arial.ttf"), Path("C:/Windows/Fonts/arialbd.ttf")),
        (Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")),
    ]
    for regular, bold in candidates:
        if regular.exists() and bold.exists():
            pdfmetrics.registerFont(TTFont("Portivo-Regular", str(regular)))
            pdfmetrics.registerFont(TTFont("Portivo-Bold", str(bold)))
            _FONT_REGULAR = "Portivo-Regular"
            _FONT_BOLD = "Portivo-Bold"
            break
    _FONTS_READY = True


def _fmt(value: Any) -> str:
    if not value:
        return "-"
    return format_platform_datetime(value, fallback=str(value))


def _p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(html.escape(str(text if text is not None else "")), style)


def _severity_label(value: str, labels: dict[str, str]) -> str:
    return labels.get(value, value.replace("_", " ").title())


def _localized_definition(run: dict[str, Any], language: str) -> tuple[str, str]:
    definition = run.get("definition") or {}
    audit_type = str(run.get("audit_type") or "")
    translated = AUDIT_TRANSLATIONS.get(language, {}).get(audit_type)
    if translated:
        return translated
    return (str(definition.get("label") or audit_type or "Audit"), str(definition.get("policy") or ""))


def _audit_item_summary(item: dict[str, Any], audit_type: str, language: str) -> str:
    if language != "el":
        return str(item.get("summary") or item.get("error") or "-")
    d = item.get("details") or {}
    if item.get("error"):
        return str(item.get("error"))
    if audit_type == "thermal_health":
        max_c = d.get("max_celsius")
        return f"Μέγιστη θερμοκρασία {float(max_c):.1f} C · {d.get('coverage', 'observed')}" if max_c is not None else "Δεν αναφέρθηκε θερμοκρασία"
    if audit_type == "fan_cooling":
        return f"{int((d.get('fans') or {}).get('failed') or 0)} βλάβες ανεμιστήρων · θερμική κατάσταση {(d.get('thermal') or {}).get('severity', 'unknown')}"
    if audit_type == "power_supply":
        return f"{int(d.get('failed') or 0)} βλάβες PSU · {int(d.get('healthy') or 0)} υγιή"
    if audit_type == "poe_capacity":
        util = d.get("utilization_percent")
        return f"Χρήση PoE {float(util):.1f}%" if util is not None else f"PoE faults {int(d.get('faults') or 0)} · denied {int(d.get('denied') or 0)}"
    if audit_type == "interface_errors":
        return f"{len(d.get('affected_ports') or [])} θύρες με ευρήματα · CRC {int(d.get('crc_total') or 0)}"
    if audit_type == "port_flapping":
        return f"{len(d.get('flapping_ports') or [])} ασταθείς θύρες στο διαθέσιμο log"
    if audit_type == "uplink_health":
        affected = sum(1 for value in d.get("uplinks") or [] if value.get("severity") in {"warning", "critical"})
        return f"{int(d.get('managed_uplink_count') or 0)} managed uplinks · {affected} χρειάζονται προσοχή"
    if audit_type == "lag_health":
        return f"{len(d.get('groups') or [])} LAGs · {int(d.get('degraded_groups') or 0)} υποβαθμισμένα"
    if audit_type == "configuration_save":
        sync = d.get("synchronized")
        return "Το persistent configuration είναι συγχρονισμένο" if sync is True else "Εντοπίστηκε μη αποθηκευμένη ή μη συγχρονισμένη configuration" if sync is False else "Δεν αναφέρθηκε κατάσταση συγχρονισμού"
    if audit_type == "vlan_unp_consistency":
        return f"{int(d.get('conflict_count') or 0)} συγκρούσεις προστατευμένης πολιτικής"
    if audit_type == "full_switch_health":
        return f"Health score {int(d.get('score') or 0)}/100 · {str(d.get('severity') or 'info')}"
    return str(item.get("summary") or "-")


def _audit_item_evidence(item: dict[str, Any], audit_type: str, language: str) -> str:
    d = item.get("details") or {}
    sep = " · "
    if audit_type == "thermal_health":
        values = []
        for sensor in (d.get("sensors") or [])[:3]:
            text = f"{sensor.get('name') or 'Sensor'} {float(sensor.get('celsius') or 0):.1f} C"
            if sensor.get("status"):
                text += f" [{sensor.get('status')}]"
            values.append(text)
        return sep.join(values)
    if audit_type == "fan_cooling":
        thermal = d.get("thermal") or {}
        fans = d.get("fans") or {}
        parts = [f"Fan faults {int(fans.get('failed') or 0)}", f"Warnings {int(fans.get('warning') or 0)}"]
        if thermal.get("max_celsius") is not None:
            parts.append(f"Max {float(thermal['max_celsius']):.1f} C")
        return sep.join(parts)
    if audit_type == "power_supply":
        parts = [f"PSU faults {int(d.get('failed') or 0)}", f"healthy {int(d.get('healthy') or 0)}"]
        if d.get("total_reported_power_w") is not None:
            parts.append(f"reported power {float(d['total_reported_power_w']):.1f} W")
        return sep.join(parts)
    if audit_type == "poe_capacity":
        parts=[]
        if d.get("used_w") is not None: parts.append(f"Used {float(d['used_w']):.1f} W")
        if d.get("budget_w") is not None: parts.append(f"Budget {float(d['budget_w']):.1f} W")
        if d.get("utilization_percent") is not None: parts.append(f"{float(d['utilization_percent']):.1f}%")
        if d.get("faults"): parts.append(f"Faults {int(d['faults'])}")
        if d.get("denied"): parts.append(f"Denied {int(d['denied'])}")
        if d.get("ethernet_up_with_poe_fault"): parts.append(f"Fault + Ethernet Up {int(d['ethernet_up_with_poe_fault'])}")
        return sep.join(parts)
    if audit_type == "interface_errors":
        parts=[f"CRC/FCS {int(d.get('crc_total') or 0)}", f"Errors {int(d.get('error_total') or 0)}", f"Drops/Discards {int(d.get('discard_total') or 0)}", f"Collisions {int(d.get('collision_total') or 0)}"]
        top=(d.get("affected_ports") or [])[:3]
        if top: parts.append(", ".join(f"{x.get('port')} ({x.get('count')})" for x in top))
        return sep.join(parts)
    if audit_type == "port_flapping":
        parts = [f"Link events {int(d.get('total_link_events') or 0)}"]
        parts.extend(f"{x.get('port')}: {x.get('events')}" for x in (d.get("flapping_ports") or [])[:3])
        return sep.join(parts)
    if audit_type == "uplink_health":
        affected=[x for x in d.get("uplinks") or [] if x.get("severity") in {"warning","critical"}]
        parts=[f"Managed uplinks {int(d.get('managed_uplink_count') or 0)}", f"LLDP neighbors {int(d.get('lldp_neighbors_observed') or 0)}"]
        if affected:
            parts.append(", ".join(f"{x.get('port')} -> {x.get('neighbor')}" for x in affected[:3]))
        return sep.join(parts)
    if audit_type == "configuration_save":
        return sep.join(str(x) for x in (d.get("evidence") or [])[:3])
    if audit_type == "full_switch_health":
        parts=[]
        if d.get("cpu_percent") is not None: parts.append(f"CPU {float(d['cpu_percent']):.1f}%")
        if d.get("memory_percent") is not None: parts.append(f"Memory {float(d['memory_percent']):.1f}%")
        thermal=d.get("thermal") or {}
        if thermal.get("max_celsius") is not None: parts.append(f"Max {float(thermal['max_celsius']):.1f} C")
        if d.get("coverage_percent") is not None: parts.append(f"Coverage {float(d['coverage_percent']):.1f}%")
        return sep.join(parts)
    return ""

def _audit_kpis(run: dict[str, Any], language: str) -> list[tuple[str, str]]:
    items = list(run.get("items") or [])
    audit_type = str(run.get("audit_type") or "")
    el = language == "el"

    def label(en: str, gr: str) -> str:
        return gr if el else en

    if audit_type == "thermal_health":
        warning_sensors = sum(int((item.get("details") or {}).get("above_warning") or 0) for item in items)
        critical_sensors = sum(int((item.get("details") or {}).get("above_critical") or 0) for item in items)
        verified = sum(1 for item in items if (item.get("details") or {}).get("coverage") == "verified")
        hottest = max((float((item.get("details") or {}).get("max_celsius")) for item in items if (item.get("details") or {}).get("max_celsius") is not None), default=None)
        return [
            (label("Threshold-verified switches", "Switches με επιβεβαιωμένα όρια"), str(verified)),
            (label("Sensors above warning", "Αισθητήρες πάνω από προειδοποίηση"), str(warning_sensors)),
            (label("Sensors in danger zone", "Αισθητήρες σε ζώνη κινδύνου"), str(critical_sensors)),
            (label("Highest observed", "Υψηλότερη μέτρηση"), f"{hottest:.1f} C" if hottest is not None else "-"),
        ]
    if audit_type == "fan_cooling":
        faults = sum(int(((item.get("details") or {}).get("fans") or {}).get("failed") or 0) for item in items)
        affected = sum(1 for item in items if item.get("severity") in {"warning", "critical"})
        thermal = sum(1 for item in items if ((item.get("details") or {}).get("thermal") or {}).get("severity") in {"warning", "critical"})
        return [(label("Fan faults", "Βλάβες ανεμιστήρων"), str(faults)), (label("Affected switches", "Switches με εύρημα"), str(affected)), (label("Thermal findings", "Θερμικά ευρήματα"), str(thermal))]
    if audit_type == "power_supply":
        faults = sum(int((item.get("details") or {}).get("failed") or 0) for item in items)
        affected = sum(1 for item in items if item.get("severity") in {"warning", "critical"})
        return [(label("PSU faults", "Βλάβες PSU"), str(faults)), (label("Affected switches", "Switches με εύρημα"), str(affected))]
    if audit_type == "poe_capacity":
        warn = sum(1 for item in items if (item.get("details") or {}).get("utilization_percent") is not None and 80 <= float((item.get("details") or {}).get("utilization_percent")) < 90)
        critical = sum(1 for item in items if (item.get("details") or {}).get("utilization_percent") is not None and float((item.get("details") or {}).get("utilization_percent")) >= 90)
        denied = sum(int((item.get("details") or {}).get("denied") or 0) for item in items)
        faults = sum(int((item.get("details") or {}).get("faults") or 0) for item in items)
        return [(label("80-89.9% utilization", "Χρήση 80-89,9%"), str(warn)), (label("90%+ utilization", "Χρήση 90%+"), str(critical)), (label("Denied ports", "Θύρες denied"), str(denied)), (label("PoE faults", "Βλάβες PoE"), str(faults))]
    if audit_type == "interface_errors":
        ports = sum(len((item.get("details") or {}).get("affected_ports") or []) for item in items)
        crc = sum(int((item.get("details") or {}).get("crc_total") or 0) for item in items)
        drops = sum(int((item.get("details") or {}).get("discard_total") or 0) for item in items)
        affected = sum(1 for item in items if item.get("severity") in {"warning", "critical"})
        return [(label("Affected ports", "Θύρες με ευρήματα"), str(ports)), ("CRC/FCS", str(crc)), (label("Drops/discards", "Drops/discards"), str(drops)), (label("Affected switches", "Switches με εύρημα"), str(affected))]
    if audit_type == "port_flapping":
        ports = sum(len((item.get("details") or {}).get("flapping_ports") or []) for item in items)
        critical = sum(1 for item in items if item.get("severity") == "critical")
        return [(label("Unstable ports", "Ασταθείς θύρες"), str(ports)), (label("Critical switches", "Κρίσιμα switches"), str(critical))]
    if audit_type == "uplink_health":
        total = sum(int((item.get("details") or {}).get("managed_uplink_count") or 0) for item in items)
        affected = sum(sum(1 for uplink in ((item.get("details") or {}).get("uplinks") or []) if uplink.get("severity") in {"warning", "critical"}) for item in items)
        return [(label("Managed uplinks", "Managed uplinks"), str(total)), (label("Uplinks requiring attention", "Uplinks που χρειάζονται έλεγχο"), str(affected))]
    if audit_type == "lag_health":
        total = sum(len((item.get("details") or {}).get("groups") or []) for item in items)
        degraded = sum(int((item.get("details") or {}).get("degraded_groups") or 0) for item in items)
        return [("LAGs", str(total)), (label("Degraded LAGs", "Υποβαθμισμένα LAGs"), str(degraded))]
    if audit_type == "configuration_save":
        unsaved = sum(1 for item in items if (item.get("details") or {}).get("synchronized") is False)
        synced = sum(1 for item in items if (item.get("details") or {}).get("synchronized") is True)
        return [(label("Unsaved / not synchronized", "Μη αποθηκευμένα / μη συγχρονισμένα"), str(unsaved)), (label("Synchronized", "Συγχρονισμένα"), str(synced))]
    if audit_type == "vlan_unp_consistency":
        conflicts = sum(int((item.get("details") or {}).get("conflict_count") or 0) for item in items)
        affected = sum(1 for item in items if int((item.get("details") or {}).get("conflict_count") or 0) > 0)
        return [(label("Conflicting ports", "Θύρες με σύγκρουση"), str(conflicts)), (label("Affected switches", "Switches με εύρημα"), str(affected))]
    if audit_type == "full_switch_health":
        scores = [int(item.get("score")) for item in items if item.get("score") is not None]
        coverages = [float((item.get("details") or {}).get("coverage_percent")) for item in items if (item.get("details") or {}).get("coverage_percent") is not None]
        avg_score = sum(scores) / len(scores) if scores else None
        avg_coverage = sum(coverages) / len(coverages) if coverages else None
        attention = sum(1 for score in scores if score < 85)
        return [(label("Average health score", "Μέσο Health Score"), f"{avg_score:.1f}/100" if avg_score is not None else "-"), (label("Below 85/100", "Κάτω από 85/100"), str(attention)), (label("Average evidence coverage", "Μέση κάλυψη στοιχείων"), f"{avg_coverage:.1f}%" if avg_coverage is not None else "-")]
    return []



def _diagnostic_interpretation(item: dict[str, Any], audit_type: str, language: str) -> str:
    d = item.get("details") or {}
    el = language == "el"
    if item.get("error"):
        return ("Το switch δεν μπόρεσε να ελεγχθεί. Αυτό είναι αποτυχία συλλογής δεδομένων και όχι ένδειξη ότι το hardware είναι ελαττωματικό." if el else
                "The switch could not be assessed. This is a data-collection failure, not evidence that the hardware itself is faulty.")
    if audit_type == "thermal_health":
        warn = int(d.get("above_warning") or 0); crit = int(d.get("above_critical") or 0); max_c = d.get("max_celsius")
        if crit:
            return (f"{crit} αισθητήρας/ες βρίσκονται σε κρίσιμη θερμική ζώνη βάσει των ορίων ή του status που αναφέρει το ίδιο το switch. Υψηλότερη μέτρηση: {float(max_c):.1f} C." if el else
                    f"{crit} sensor(s) are in a critical thermal zone based on thresholds or status reported by the switch. Highest observed value: {float(max_c):.1f} C.")
        if warn:
            return (f"{warn} αισθητήρας/ες βρίσκονται σε warning zone. Δεν αναφέρθηκε critical thermal state." if el else f"{warn} sensor(s) are in the warning zone. No critical thermal state was reported.")
        return ("Οι θερμοκρασίες που αναφέρθηκαν δεν παραβιάζουν επιβεβαιωμένο warning/critical όριο. Όπου δεν υπάρχει όριο, η τιμή εμφανίζεται ως παρατήρηση και δεν χαρακτηρίζεται αυθαίρετα." if el else
                "Reported temperatures do not violate a verified warning/critical threshold. Where no threshold is available, the value is shown as an observation and is not arbitrarily classified.")
    if audit_type == "fan_cooling":
        fan = d.get("fans") or {}; faults = int(fan.get("failed") or 0); warnings = int(fan.get("warning") or 0); thermal = d.get("thermal") or {}
        return ((f"Το switch αναφέρει {faults} fan fault(s) και {warnings} degraded/warning fan state(s). Η θερμική αξιολόγηση είναι {thermal.get('severity','info')}." if el else
                 f"The switch reports {faults} fan fault(s) and {warnings} degraded/warning fan state(s). Thermal assessment is {thermal.get('severity','info')}.") if faults or warnings else
                ("Δεν αναφέρθηκε ρητή βλάβη ανεμιστήρα. Η αναφορά εμφανίζει παράλληλα τη θερμική κατάσταση ώστε να φαίνεται αν υπάρχει cooling impact." if el else
                 "No explicit fan fault was reported. Thermal evidence is shown alongside fan state so any cooling impact is visible."))
    if audit_type == "power_supply":
        faults = int(d.get("failed") or 0); healthy = int(d.get("healthy") or 0); present = int(d.get("present") or 0)
        if faults:
            return (f"Το switch αναφέρει {faults} PSU σε failed/fault/down/degraded κατάσταση. Αναφέρονται {healthy} healthy PSU από {present} παρόντα/αξιολογήσιμα. Αυτό μπορεί να σημαίνει απώλεια εφεδρείας ή πραγματική απώλεια τροφοδοσίας ανάλογα με το μοντέλο και τον αριθμό PSU." if el else
                    f"The switch reports {faults} PSU(s) in failed/fault/down/degraded state. {healthy} PSU(s) are healthy out of {present} present/assessable units. Depending on model and PSU count, this may represent lost redundancy or an active power-feed failure.")
        return (f"Δεν αναφέρθηκε ρητή βλάβη PSU. Healthy PSU: {healthy}." if el else f"No explicit PSU failure was reported. Healthy PSU count: {healthy}.")
    if audit_type == "poe_capacity":
        faults = int(d.get("faults") or 0); denied = int(d.get("denied") or 0); util = d.get("utilization_percent"); budget = d.get("budget_w"); linked = int(d.get("ethernet_up_with_poe_fault") or 0); psu = d.get("psu_context") or {}
        if faults:
            text = (f"Το switch αναφέρει {faults} PoE fault(s) και {denied} denied port(s)." if el else f"The switch reports {faults} PoE fault(s) and {denied} denied port(s).")
            if linked:
                text += (f" Σε {linked} fault port(s) το Ethernet link αναφέρεται Up, κάτι που δείχνει ότι το data path μπορεί να λειτουργεί ενώ η παροχή PoE έχει πρόβλημα." if el else
                         f" On {linked} fault port(s), Ethernet link is reported Up, showing that the data path may remain operational while PoE delivery is faulty.")
            if util is not None and float(util) < 80:
                text += (" Το συνολικό PoE budget δεν είναι υψηλά χρησιμοποιημένο, άρα τα συγκεκριμένα faults δεν εξηγούνται από εξάντληση του συνολικού budget." if el else
                         " Total PoE budget is not highly utilized, so these fault states are not explained by exhaustion of the overall budget.")
            if psu.get("reported"):
                text += (f" PSU assessment: {psu.get('severity','info')}." if el else f" PSU assessment: {psu.get('severity','info')}.")
            return text
        if denied:
            return (f"Δεν εντοπίστηκε explicit PoE fault, αλλά {denied} port(s) αναφέρουν denied power. Ελέγξτε budget, priority και PD requirement." if el else
                    f"No explicit PoE fault was detected, but {denied} port(s) report denied power. Check budget, priority and PD power requirements.")
        if util is not None:
            return (f"Η χρήση του PoE budget είναι {float(util):.1f}%" + (f" από {float(budget):.1f} W." if budget is not None else ".") if el else
                    f"PoE budget utilization is {float(util):.1f}%" + (f" of {float(budget):.1f} W." if budget is not None else "."))
        return ("Υπάρχουν PoE στοιχεία, αλλά το συνολικό budget δεν μπόρεσε να υπολογιστεί αξιόπιστα από το συγκεκριμένο CLI format." if el else
                "PoE evidence is available, but total budget utilization could not be calculated reliably from this CLI format.")
    if audit_type == "interface_errors":
        affected = len(d.get("affected_ports") or []); crc = int(d.get("crc_total") or 0); errors = int(d.get("error_total") or 0); drops = int(d.get("discard_total") or 0); collisions = int(d.get("collision_total") or 0)
        return (f"Μη μηδενικοί error counters εντοπίστηκαν σε {affected} port(s). CRC/FCS {crc}, λοιπά errors {errors}, drops/discards {drops}, collisions {collisions}. Η αναφορά δείχνει ανά port το current link/admin state και alias όταν είναι διαθέσιμα. Οι counters αποδεικνύουν ότι καταγράφηκαν σφάλματα, όχι από μόνοι τους την αιτία." if el else
                f"Non-zero error counters were detected on {affected} port(s). CRC/FCS {crc}, other errors {errors}, drops/discards {drops}, collisions {collisions}. Current link/admin state and alias are shown per port when available. Counters prove errors were recorded but do not by themselves prove the root cause.")
    if audit_type == "port_flapping":
        ports = d.get("flapping_ports") or []; max_events = max((int(x.get("events") or 0) for x in ports), default=0)
        return (f"{len(ports)} port(s) έχουν επαναλαμβανόμενες link transitions στο διαθέσιμο software log. Μέγιστη καταγραφή {max_events} transitions. Το current state εμφανίζεται ξεχωριστά, επειδή μία θύρα μπορεί τώρα να είναι Up παρότι είχε flapping νωρίτερα." if el else
                f"{len(ports)} port(s) show repeated link transitions in the available software log. Highest observed count: {max_events}. Current state is shown separately because a port may now be Up even after earlier flapping.")
    if audit_type == "uplink_health":
        uplinks = d.get("uplinks") or []; affected = [x for x in uplinks if x.get("severity") in {"warning","critical"}]
        return (f"Αξιολογήθηκαν {len(uplinks)} managed LLDP uplink(s). {len(affected)} έχουν Down/Disabled state, media degradation ή error counters. Για κάθε uplink εμφανίζονται neighbor, speed και counter breakdown." if el else
                f"{len(uplinks)} managed LLDP uplink(s) were assessed. {len(affected)} show Down/Disabled state, media degradation or error counters. Neighbor, speed and counter breakdown are shown per uplink.")
    if audit_type == "configuration_save":
        sync = d.get("synchronized")
        if sync is False:
            return ("Το switch αναφέρει ότι το active/working configuration δεν είναι συγχρονισμένο με το persistent/certified configuration. Μη αποθηκευμένες αλλαγές μπορεί να χαθούν μετά από reboot." if el else
                    "The switch reports that active/working configuration is not synchronized with persistent/certified configuration. Unsaved changes may be lost after reboot.")
        if sync is True:
            return ("Το switch αναφέρει συγχρονισμένο persistent configuration. Οι σχετικές CLI evidence lines εμφανίζονται παρακάτω." if el else
                    "The switch reports synchronized persistent configuration. Relevant CLI evidence lines are shown below.")
        return ("Δεν υπήρχε αρκετή ρητή πληροφορία για ασφαλές συμπέρασμα σχετικά με configuration synchronization." if el else
                "There was not enough explicit evidence to safely determine configuration synchronization state.")
    if audit_type == "full_switch_health":
        score = item.get("score"); coverage = d.get("coverage_percent"); components = d.get("components") or {}; bad = [name for name, status in components.items() if status in {"warning","critical"}]
        text = (f"Health Score {score if score is not None else '-'} / 100" if el else f"Health Score {score if score is not None else '-'} / 100")
        if coverage is not None: text += f" · evidence coverage {float(coverage):.1f}%"
        if bad: text += (f". Components που επηρεάζουν το αποτέλεσμα: {', '.join(bad)}." if el else f". Components affecting the result: {', '.join(bad)}.")
        else: text += (". Δεν υπάρχει Warning/Critical component στα στοιχεία που αναφέρθηκαν." if el else ". No Warning/Critical component is present in the reported evidence.")
        return text
    return str(item.get("summary") or "-")

def _diagnostic_recommendations(item: dict[str, Any], audit_type: str, language: str) -> list[str]:
    d = item.get("details") or {}; el = language == "el"
    if item.get("error"):
        return ["Ελέγξτε reachability, SSH credentials και αν το switch ήταν απασχολημένο κατά τη συλλογή." if el else "Check reachability, SSH credentials and whether the switch was busy during collection."]
    if audit_type == "thermal_health":
        return [
            "Επιβεβαιώστε πρώτα τους sensors και τα device-reported Warning/Danger thresholds που εμφανίζονται στον πίνακα." if el else "First verify the sensors and device-reported Warning/Danger thresholds shown in the table.",
            "Ελέγξτε room temperature, airflow, intake/exhaust obstruction και fan state αν υπάρχει θερμικό εύρημα." if el else "Check room temperature, airflow, intake/exhaust obstruction and fan state when a thermal finding is present.",
        ]
    if audit_type == "fan_cooling":
        return [
            "Ελέγξτε το ακριβές fan evidence και τη φυσική κατάσταση/LED του αντίστοιχου fan tray." if el else "Check the exact fan evidence and the physical state/LED of the corresponding fan tray.",
            "Αν υπάρχει ταυτόχρονα thermal Warning/Critical, δώστε προτεραιότητα στο cooling issue." if el else "If Thermal Warning/Critical is present at the same time, prioritize the cooling issue.",
        ]
    if audit_type == "power_supply":
        return [
            "Ελέγξτε το συγκεκριμένο PSU ID/location, AC/DC feed, καλώδιο και LED που εμφανίζονται στην αναφορά." if el else "Check the specific PSU ID/location, AC/DC feed, cable and LED represented by the report evidence.",
            "Επιβεβαιώστε αν το switch έχει χάσει μόνο redundancy ή αν λείπει ενεργή τροφοδοσία που απαιτείται για λειτουργία/PoE." if el else "Verify whether the switch has only lost redundancy or is missing an active feed required for operation/PoE.",
        ]
    if audit_type == "poe_capacity":
        rec=[]
        if int(d.get("faults") or 0):
            rec.append("Ξεκινήστε από τα Affected PoE ports. Ελέγξτε PoE state, Ethernet Link, PoE Admin, actual power και alias για κάθε port." if el else "Start with Affected PoE ports. Check PoE state, Ethernet Link, PoE Admin, actual power and alias for each port.")
            if int(d.get("ethernet_up_with_poe_fault") or 0):
                rec.append("Υπάρχουν fault ports με Ethernet link Up. Αυτό κατευθύνει τον έλεγχο στο PoE/PSE/power path αντί να θεωρηθεί αυτόματα γενική βλάβη του Ethernet interface." if el else "Some fault ports have Ethernet link Up. This directs troubleshooting toward the PoE/PSE/power path rather than automatically treating the Ethernet interface itself as failed.")
            rec.append("Ελέγξτε PD και καλωδίωση για short/overload/compatibility μόνο όπου το port state το υποστηρίζει. Πολλαπλά ταυτόχρονα faults σε πολλές θύρες δικαιολογούν έλεγχο κοινού PoE subsystem/PSU." if el else "Check the PD and cabling for short/overload/compatibility only where port evidence supports it. Many simultaneous faults across multiple ports justify checking the common PoE subsystem/PSU.")
        if int(d.get("denied") or 0) or (d.get("utilization_percent") is not None and float(d.get("utilization_percent")) >= 80):
            rec.append("Ελέγξτε συνολικό PoE budget, available power, port priority και PD requirement." if el else "Check total PoE budget, available power, port priority and PD requirements.")
        return rec or ["Δεν υποδεικνύεται ενέργεια από τα συγκεκριμένα PoE στοιχεία." if el else "No action is indicated by the reported PoE evidence."]
    if audit_type == "interface_errors":
        return [
            "Ξεκινήστε από τις ports με το μεγαλύτερο Total και δείτε ποια κατηγορία αυξάνει: CRC/FCS, errors, drops/discards ή collisions." if el else "Start with ports with the highest Total and identify which category is increasing: CRC/FCS, errors, drops/discards or collisions.",
            "Για CRC/FCS ελέγξτε physical medium/patch/optic. Για drops/discards εξετάστε congestion/queueing ή endpoint behavior. Επαναλάβετε το audit αργότερα για να δείτε αν οι counters συνεχίζουν να αυξάνονται." if el else "For CRC/FCS inspect the physical medium/patch/optic. For drops/discards investigate congestion/queueing or endpoint behavior. Repeat the audit later to see whether counters continue to increase.",
        ]
    if audit_type == "port_flapping":
        return [
            "Συσχετίστε τα πρόσφατα log lines με maintenance, endpoint power events ή φυσική παρέμβαση πριν χαρακτηρίσετε το flapping ως hardware fault." if el else "Correlate recent log lines with maintenance, endpoint power events or physical intervention before treating flapping as a hardware fault.",
            "Χρησιμοποιήστε το current Link/Admin/Alias για να εντοπίσετε γρήγορα το endpoint και ελέγξτε cable, transceiver ή endpoint power στις ports με τα περισσότερα transitions." if el else "Use current Link/Admin/Alias to identify the endpoint quickly and check cable, transceiver or endpoint power on ports with the most transitions.",
        ]
    if audit_type == "uplink_health":
        return [
            "Για Down/Disabled uplink επιβεβαιώστε και την remote LLDP πλευρά. Για error counters εξετάστε πρώτα CRC/FCS και drops/discards ανά link." if el else "For a Down/Disabled uplink verify the remote LLDP side as well. For counter findings inspect CRC/FCS and drops/discards per link first.",
            "Για speed mismatch επιβεβαιώστε optics/cabling και configured versus detected media και στις δύο πλευρές." if el else "For speed mismatch verify optics/cabling and configured versus detected media on both ends.",
        ]
    if audit_type == "configuration_save":
        return ["Επιβεβαιώστε ότι οι ενεργές αλλαγές πρέπει να διατηρηθούν και χρησιμοποιήστε το υπάρχον persistent-save workflow. Μην κάνετε αυτόματο save μόνο επειδή το audit βρήκε mismatch." if el else "Confirm that active changes should be retained and use the existing persistent-save workflow. Do not save automatically only because the audit found a mismatch."]
    if audit_type == "full_switch_health":
        return [
            "Ξεκινήστε από τα Critical components, μετά τα Warning, και χρησιμοποιήστε τις component-specific evidence tables για το επόμενο troubleshooting βήμα." if el else "Start with Critical components, then Warning, and use the component-specific evidence tables for the next troubleshooting step.",
            "Not reported σημαίνει έλλειψη αξιόπιστου CLI evidence, όχι αυτόματα βλάβη." if el else "Not reported means reliable CLI evidence was unavailable, not that the component is automatically faulty.",
        ]
    return []

def _diagnostic_tables(item: dict[str, Any], audit_type: str, language: str) -> list[dict[str, Any]]:
    d = item.get("details") or {}; el = language == "el"
    severity_text = {"critical": "Κρίσιμο", "warning": "Προειδοποίηση", "healthy": "Υγιές", "info": "Πληροφοριακό", "unavailable": "Μη διαθέσιμο"} if el else {}
    def sev(value: Any) -> str:
        raw=str(value or "info"); return severity_text.get(raw, raw.title() if not el else raw)
    def yn(value: Any) -> str:
        return ("Ναι" if value else "Όχι") if el else ("Yes" if value else "No")
    tables=[]
    if audit_type == "thermal_health":
        rows=[]
        for x in d.get("sensors") or []:
            rows.append([x.get("name") or "Sensor", f"{float(x.get('celsius') or 0):.1f} C", str(x.get("reported_range") or "-"), f"{x.get('warning_threshold_c')} C" if x.get("warning_threshold_c") is not None else "-", f"{x.get('danger_threshold_c')} C" if x.get("danger_threshold_c") is not None else "-", str(x.get("status") or x.get("zone") or "observed"), str(x.get("threshold_source") or "-")])
        if rows:
            tables.append({"title": "Αισθητήρες θερμοκρασίας" if el else "Temperature sensors", "headers": ["Sensor", "Current", "Reported range", "Warning", "Danger", "Switch status", "Threshold source"], "rows": rows, "widths": [42,30,48,30,30,48,27]})
    elif audit_type == "fan_cooling":
        fan=d.get("fans") or {}; rows=[[x.get("line") or "-", sev(x.get("status"))] for x in fan.get("fans") or []]
        if rows: tables.append({"title": "Κατάσταση ανεμιστήρων" if el else "Fan status", "headers": ["Switch evidence", "Assessment"], "rows": rows, "widths": [205,50]})
        thermal=d.get("thermal") or {}; sensor_rows=[[x.get("name") or "Sensor", f"{float(x.get('celsius') or 0):.1f} C", str(x.get("status") or x.get("zone") or "observed")] for x in thermal.get("sensors") or []]
        if sensor_rows: tables.append({"title": "Συσχετισμένη θερμική κατάσταση" if el else "Correlated thermal state", "headers": ["Sensor","Temperature","Switch/zone state"], "rows": sensor_rows, "widths": [100,55,100]})
    elif audit_type == "power_supply":
        rows=[]
        for x in d.get("supplies") or []:
            rows.append([x.get("id") or "-", f"{float(x.get('power_w')):.1f} W" if x.get("power_w") is not None else "-", x.get("type") or "-", x.get("switch_state") or "-", x.get("location") or "-", sev(x.get("status"))])
        if rows: tables.append({"title": "Κατάσταση τροφοδοτικών" if el else "Power supply status", "headers": ["PSU","Power","Type","Switch state","Location","Assessment"], "rows": rows, "widths": [32,34,25,55,70,39]})
    elif audit_type == "poe_capacity":
        metrics=[]
        for label,key,unit in [
            (("Συνολικό PoE budget" if el else "Total PoE budget"),"budget_w"," W"),
            (("Χρησιμοποιούμενη ισχύς" if el else "Power used"),"used_w"," W"),
            (("Διαθέσιμη ισχύς" if el else "Power available"),"available_w"," W"),
            (("Χρήση budget" if el else "Budget utilization"),"utilization_percent","%"),
            (("PoE port rows" if el else "PoE port rows reported"),"port_rows_observed",""),
            (("Powered ports" if el else "Ports delivering power"),"powered_ports_observed",""),
            (("PoE faults" if el else "PoE faults"),"faults",""),
            (("Denied ports" if el else "Denied ports"),"denied",""),
            (("Fault + Ethernet Up" if el else "Fault ports with Ethernet Up"),"ethernet_up_with_poe_fault",""),
        ]:
            v=d.get(key); metrics.append([label, "-" if v is None else f"{v}{unit}"])
        tables.append({"title":"Σύνοψη PoE" if el else "PoE capacity summary", "headers":["Metric" if not el else "Μέτρηση","Value" if not el else "Τιμή"], "rows":metrics, "widths":[170,85]})
        affected=list(d.get("fault_ports") or [])+list(d.get("denied_ports") or [])
        rows=[]
        for x in affected:
            rows.append([x.get("interface") or x.get("location") or "-", x.get("alias") or "-", x.get("link_state") or "unknown", x.get("admin_state") or "unknown", f"{float(x.get('maximum_w') or 0):.1f} W", f"{float(x.get('used_w') or 0):.1f} W", x.get("status") or "-", x.get("priority") or "-", x.get("poe_admin") or "-", x.get("extra") or "-", sev(x.get("severity"))])
        for line in d.get("generic_fault_evidence") or []:
            rows.append(["CLI","-","-","-","-","-",line,"-","-","-",sev("critical")])
        if rows: tables.append({"title":"Επηρεαζόμενες PoE θύρες" if el else "Affected PoE ports", "headers":["Port","Alias","Eth Link","Eth Admin","Max","Used","PoE state","Priority","PoE Admin","Class/Type","Assessment"], "rows":rows, "widths":[24,30,18,18,18,18,28,18,20,28,25]})
        psu=d.get("psu_context") or {}; psu_rows=[]
        for x in psu.get("supplies") or []:
            psu_rows.append([x.get("id") or "-", f"{float(x.get('power_w')):.1f} W" if x.get("power_w") is not None else "-", x.get("type") or "-", x.get("switch_state") or "-", x.get("location") or "-", sev(x.get("status"))])
        if psu_rows: tables.append({"title":"Συσχέτιση τροφοδοτικών" if el else "Power supply correlation", "headers":["PSU","Power","Type","Switch state","Location","Assessment"], "rows":psu_rows, "widths":[32,34,25,55,70,39]})
        powered=[[x.get("interface") or x.get("location") or "-", x.get("alias") or "-", x.get("link_state") or "unknown", f"{float(x.get('used_w') or 0):.1f} W", x.get("status") or "-"] for x in d.get("powered_ports") or []]
        if powered: tables.append({"title":"Θύρες που τροφοδοτούν ενεργά συσκευές" if el else "Ports actively delivering power", "headers":["Port","Alias","Ethernet link","Used","PoE state"], "rows":powered, "widths":[42,70,45,35,63]})
    elif audit_type == "interface_errors":
        summary=[["CRC/FCS",str(int(d.get("crc_total") or 0))],["Other errors",str(int(d.get("error_total") or 0))],["Drops/Discards",str(int(d.get("discard_total") or 0))],["Collisions",str(int(d.get("collision_total") or 0))],["Affected ports",str(len(d.get("affected_ports") or []))]]
        tables.append({"title":"Σύνοψη error counters" if el else "Error counter summary", "headers":["Metric","Value"], "rows":summary, "widths":[170,85]})
        rows=[]
        for x in d.get("affected_ports") or []:
            signals=", ".join(f"{sig.get('name')}: {sig.get('value')}" for sig in (x.get("signals") or [])[:5])
            rows.append([x.get("port") or "-", x.get("alias") or "-", x.get("link_state") or "unknown", x.get("admin_state") or "unknown", str(x.get("crc_fcs") or 0), str(x.get("errors") or 0), str(x.get("drops_discards") or 0), str(x.get("collisions") or 0), str(x.get("count") or 0), signals or "-"])
        if rows: tables.append({"title":"Θύρες με error evidence" if el else "Ports with error evidence", "headers":["Port","Alias","Link","Admin","CRC/FCS","Errors","Drops","Collisions","Total","Counter evidence"], "rows":rows, "widths":[22,35,18,18,22,20,20,20,22,58]})
    elif audit_type == "port_flapping":
        rows=[]
        for x in d.get("flapping_ports") or []:
            rows.append([x.get("port") or "-", x.get("alias") or "-", x.get("link_state") or "unknown", x.get("admin_state") or "unknown", str(x.get("events") or 0), " | ".join(x.get("samples") or [])])
        if rows: tables.append({"title":"Ασταθείς θύρες" if el else "Unstable ports", "headers":["Port","Alias","Current link","Admin","Transitions","Recent log evidence"], "rows":rows, "widths":[30,50,30,30,30,85]})
    elif audit_type == "uplink_health":
        rows=[]
        for x in d.get("uplinks") or []:
            rows.append([x.get("port") or "-", x.get("alias") or "-", x.get("neighbor") or "-", x.get("admin") or "-", x.get("link") or "-", f"{x.get('detected_speed') or '-'} / {x.get('configured_speed') or '-'}", str(x.get("crc_fcs") or 0), str(x.get("drops_discards") or 0), str(x.get("error_evidence") or 0), "; ".join(x.get("reasons") or []) or "-"])
        if rows: tables.append({"title":"Managed uplinks", "headers":["Port","Alias","Neighbor","Admin","Link","Detected / Configured","CRC/FCS","Drops","Total errors","Finding"], "rows":rows, "widths":[20,30,35,18,18,32,18,18,20,46]})
    elif audit_type == "configuration_save":
        rows=[[str(i+1),line] for i,line in enumerate(d.get("evidence") or [])]
        state = "Synchronized" if d.get("synchronized") is True else "Not synchronized" if d.get("synchronized") is False else "Not reported"
        tables.append({"title":"Κατάσταση persistent configuration" if el else "Persistent configuration state", "headers":["State","Reported"], "rows":[[state, yn(bool(d.get("reported")))]], "widths":[160,95]})
        if rows: tables.append({"title":"Στοιχεία συγχρονισμού configuration" if el else "Configuration synchronization evidence", "headers":["#","Switch evidence"], "rows":rows, "widths":[20,235]})
    elif audit_type == "full_switch_health":
        reported=d.get("component_reported") or {}; rows=[]
        for name,status in (d.get("components") or {}).items(): rows.append([name,sev(status),yn(bool(reported.get(name)))])
        if d.get("cpu_percent") is not None: rows.append(["CPU",f"{float(d['cpu_percent']):.1f}%",yn(True)])
        if d.get("memory_percent") is not None: rows.append(["Memory",f"{float(d['memory_percent']):.1f}%",yn(True)])
        rows.append(["Evidence coverage",f"{float(d.get('coverage_percent') or 0):.1f}%",yn(True)])
        tables.append({"title":"Component health", "headers":["Component" if not el else "Στοιχείο","State" if not el else "Κατάσταση","Reported" if not el else "Αναφέρθηκε"], "rows":rows, "widths":[100,80,75]})
        # Show component-level evidence, not only a score.
        thermal=d.get("thermal") or {}; tr=[[x.get("name") or "Sensor",f"{float(x.get('celsius') or 0):.1f} C",str(x.get("status") or x.get("zone") or "-")] for x in thermal.get("sensors") or [] if x.get("zone") in {"warning","critical"}]
        if tr: tables.append({"title":"Thermal findings","headers":["Sensor","Temperature","State"],"rows":tr,"widths":[110,60,85]})
        poe=d.get("poe") or {}; pr=[[x.get("interface") or x.get("location") or "-",x.get("alias") or "-",x.get("link_state") or "unknown",f"{float(x.get('used_w') or 0):.1f} W",x.get("status") or "-",sev(x.get("severity"))] for x in list(poe.get("fault_ports") or [])+list(poe.get("denied_ports") or [])]
        if pr: tables.append({"title":"PoE findings","headers":["Port","Alias","Eth link","Used","PoE state","Assessment"],"rows":pr,"widths":[35,55,35,30,70,30]})
        fans=(d.get("fans") or {}).get("fans") or []; fr=[[x.get("line") or "-",sev(x.get("status"))] for x in fans if x.get("status") in {"warning","critical"}]
        if fr: tables.append({"title":"Fan findings","headers":["Switch evidence","Assessment"],"rows":fr,"widths":[205,50]})
        supplies=(d.get("power") or {}).get("supplies") or []; sr=[[x.get("id") or "-",x.get("switch_state") or x.get("line") or "-",x.get("location") or "-",sev(x.get("status"))] for x in supplies if x.get("status") in {"warning","critical"}]
        if sr: tables.append({"title":"Power supply findings","headers":["PSU","Switch state","Location","Assessment"],"rows":sr,"widths":[35,120,65,35]})
        er=d.get("interfaces") or {}; rr=[[x.get("port") or "-",x.get("alias") or "-",str(x.get("crc_fcs") or 0),str(x.get("errors") or 0),str(x.get("drops_discards") or 0),str(x.get("collisions") or 0),str(x.get("count") or 0)] for x in er.get("affected_ports") or []]
        if rr: tables.append({"title":"Interface error findings","headers":["Port","Alias","CRC/FCS","Errors","Drops","Collisions","Total"],"rows":rr,"widths":[40,80,28,28,28,28,28]})
        ce=(d.get("configuration") or {}).get("evidence") or []
        if ce: tables.append({"title":"Configuration evidence","headers":["#","Switch evidence"],"rows":[[str(i+1),line] for i,line in enumerate(ce)],"widths":[20,235]})
    return tables

def build_fleet_audit_pdf(run: dict[str, Any], *, language: str = "en") -> bytes:
    _register_fonts()
    lang = language if language in LABELS else "en"
    L = LABELS[lang]
    definition = run.get("definition") or {}
    items = list(run.get("items") or [])
    audit_label, audit_policy = _localized_definition(run, lang)

    buffer = io.BytesIO()
    page_size = landscape(A4)
    left = right = 14 * mm
    top = 18 * mm
    bottom = 16 * mm
    doc = BaseDocTemplate(
        buffer,
        pagesize=page_size,
        leftMargin=left,
        rightMargin=right,
        topMargin=top,
        bottomMargin=bottom,
        title=f"Portivo - {audit_label}",
        author="Portivo Control Center",
    )
    frame = Frame(left, bottom, page_size[0] - left - right, page_size[1] - top - bottom, id="main")

    def page_decor(canvas, document):
        canvas.saveState()
        canvas.setStrokeColor(COLORS["line"])
        canvas.setLineWidth(0.5)
        canvas.line(left, 10 * mm, page_size[0] - right, 10 * mm)
        canvas.setFont(_FONT_REGULAR, 7)
        canvas.setFillColor(COLORS["slate"])
        canvas.drawString(left, 6.5 * mm, L["confidential"])
        canvas.drawRightString(page_size[0] - right, 6.5 * mm, f"{L['page']} {document.page}")
        canvas.restoreState()

    doc.addPageTemplates(PageTemplate(id="all", frames=[frame], onPage=page_decor))
    styles = getSampleStyleSheet()
    title = ParagraphStyle("title", parent=styles["Title"], fontName=_FONT_BOLD, fontSize=24, leading=28, textColor=COLORS["navy"], alignment=TA_LEFT, spaceAfter=3 * mm)
    kicker = ParagraphStyle("kicker", parent=styles["Normal"], fontName=_FONT_BOLD, fontSize=8, leading=10, textColor=COLORS["purple"], spaceAfter=1.5 * mm)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontName=_FONT_BOLD, fontSize=14, leading=18, textColor=COLORS["navy"], spaceBefore=3 * mm, spaceAfter=2 * mm)
    h3 = ParagraphStyle("h3", parent=styles["Heading3"], fontName=_FONT_BOLD, fontSize=10.5, leading=13, textColor=COLORS["navy"], spaceBefore=2 * mm, spaceAfter=1.2 * mm)
    body = ParagraphStyle("body", parent=styles["BodyText"], fontName=_FONT_REGULAR, fontSize=8.5, leading=12, textColor=COLORS["navy"])
    small = ParagraphStyle("small", parent=body, fontSize=7.2, leading=9.5, textColor=COLORS["slate"])
    metric_num = ParagraphStyle("metric_num", parent=body, fontName=_FONT_BOLD, fontSize=18, leading=20, alignment=TA_CENTER)
    metric_label = ParagraphStyle("metric_label", parent=small, fontName=_FONT_BOLD, alignment=TA_CENTER)
    table_header = ParagraphStyle("table_header", parent=small, fontName=_FONT_BOLD, textColor=colors.white)
    table_body = ParagraphStyle("table_body", parent=small, fontSize=7, leading=9)

    story: list[Any] = []
    story.append(_p(L["fleet_audit"].upper(), kicker))
    story.append(_p(audit_label, title))
    meta = Table([
        [_p(f"{L['requested']}: {run.get('requested_by') or '-'}", small), _p(f"{L['generated']}: {_fmt(datetime.now(timezone.utc).isoformat())} ({platform_timezone_name()})", small)],
        [_p(f"Run #{run.get('id')} · {L['targets']}: {run.get('target_count', 0)}", small), _p(f"{L['completed']}: {run.get('completed_count', 0)}", small)],
    ], colWidths=[130 * mm, 130 * mm])
    meta.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), COLORS["panel"]), ("BOX", (0,0), (-1,-1), 0.5, COLORS["line"]), ("INNERGRID", (0,0), (-1,-1), 0.3, COLORS["line"]), ("LEFTPADDING", (0,0), (-1,-1), 7), ("RIGHTPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 5), ("BOTTOMPADDING", (0,0), (-1,-1), 5)]))
    story.append(meta)
    story.append(Spacer(1, 4 * mm))
    story.append(_p(L["executive"], h2))

    metric_values = [
        ("healthy", int(run.get("healthy_count") or 0)),
        ("warning", int(run.get("warning_count") or 0)),
        ("critical", int(run.get("critical_count") or 0)),
        ("unavailable", int(run.get("unavailable_count") or 0)),
        ("info", int(run.get("info_count") or 0)),
    ]
    metric_cells = []
    for severity, value in metric_values:
        metric_cells.append(Table([[ _p(value, metric_num) ], [ _p(L[severity], metric_label) ]], colWidths=[49 * mm]))
    metrics = Table([metric_cells], colWidths=[51 * mm] * 5)
    metric_style = [("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("LEFTPADDING", (0,0), (-1,-1), 2), ("RIGHTPADDING", (0,0), (-1,-1), 2)]
    metrics.setStyle(TableStyle(metric_style))
    for cell, (severity, _) in zip(metric_cells, metric_values):
        cell.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), colors.Color(COLORS[severity].red, COLORS[severity].green, COLORS[severity].blue, alpha=0.08)), ("BOX", (0,0), (-1,-1), 0.6, COLORS[severity]), ("TOPPADDING", (0,0), (-1,-1), 7), ("BOTTOMPADDING", (0,0), (-1,-1), 7)]))
    story.append(metrics)
    story.append(Spacer(1, 4 * mm))

    policy = str(audit_policy or definition.get("policy") or "")
    if policy:
        policy_table = Table([[ _p(L["policy"], table_header), _p(policy, body) ]], colWidths=[48 * mm, 207 * mm])
        policy_table.setStyle(TableStyle([("BACKGROUND", (0,0), (0,0), COLORS["purple"]), ("BACKGROUND", (1,0), (1,0), COLORS["panel"]), ("BOX", (0,0), (-1,-1), 0.5, COLORS["line"]), ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 7), ("RIGHTPADDING", (0,0), (-1,-1), 7), ("TOPPADDING", (0,0), (-1,-1), 6), ("BOTTOMPADDING", (0,0), (-1,-1), 6)]))
        story.append(policy_table)

    audit_kpis = _audit_kpis(run, lang)
    if audit_kpis:
        story.append(Spacer(1, 3 * mm))
        kpi_cells = []
        for kpi_label, kpi_value in audit_kpis[:4]:
            cell = Table([[ _p(kpi_value, metric_num) ], [ _p(kpi_label, metric_label) ]], colWidths=[62 * mm])
            cell.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), COLORS["panel"]), ("BOX", (0,0), (-1,-1), 0.5, COLORS["line"]), ("TOPPADDING", (0,0), (-1,-1), 6), ("BOTTOMPADDING", (0,0), (-1,-1), 6)]))
            kpi_cells.append(cell)
        kpi_table = Table([kpi_cells], colWidths=[64 * mm] * len(kpi_cells))
        kpi_table.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("LEFTPADDING", (0,0), (-1,-1), 1), ("RIGHTPADDING", (0,0), (-1,-1), 1)]))
        story.append(kpi_table)

    if run.get("audit_type") == "thermal_health":
        verified = observed = above_warning = above_critical = not_reported = 0
        hottest = []
        for item in items:
            details = item.get("details") or {}
            coverage = details.get("coverage")
            if coverage == "verified": verified += 1
            elif coverage == "observed_only": observed += 1
            else: not_reported += 1
            above_warning += int(details.get("above_warning") or 0)
            above_critical += int(details.get("above_critical") or 0)
            if details.get("max_celsius") is not None:
                hottest.append((float(details["max_celsius"]), item.get("device_name") or item.get("host")))
        story.append(_p(L["threshold_coverage"], h2))
        coverage_data = [
            [L["verified_threshold"], str(verified)],
            [L["observed_only"], str(observed)],
            [L["above_warning"], str(above_warning)],
            [L["above_critical"], str(above_critical)],
            [L["not_reported"], str(not_reported)],
        ]
        cov = Table([[_p(row[0], body), _p(row[1], body)] for row in coverage_data], colWidths=[205*mm, 50*mm])
        cov.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), COLORS["panel"]), ("GRID", (0,0), (-1,-1), 0.35, COLORS["line"]), ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6), ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
        story.append(cov)
        if hottest:
            hottest.sort(reverse=True)
            story.append(Spacer(1, 2 * mm))
            story.append(_p(L["hottest"] + ": " + ", ".join(f"{name} {temp:.1f} C" for temp, name in hottest[:8]), small))

    story.append(Spacer(1, 3 * mm))
    story.append(_p(L["evidence_scope"], h3))
    story.append(_p(L["evidence_scope_note_small"] if len(items) <= 25 else L["evidence_scope_note"], small))

    priority = [item for item in items if item.get("severity") in {"critical", "warning"}]
    if priority:
        story.append(_p(L["top_findings"], h2))
        rows = [[_p(L["severity"], table_header), _p(L["switch"], table_header), _p(L["site"], table_header), _p(L["summary"], table_header)]]
        for item in priority[:12]:
            rows.append([
                _p(_severity_label(str(item.get("severity") or ""), L), table_body),
                _p(item.get("device_name") or item.get("host"), table_body),
                _p(item.get("site") or "-", table_body),
                _p(_audit_item_summary(item, str(run.get("audit_type") or ""), lang), table_body),
            ])
        table = Table(rows, colWidths=[30*mm, 52*mm, 45*mm, 128*mm], repeatRows=1)
        table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), COLORS["navy"]), ("GRID", (0,0), (-1,-1), 0.35, COLORS["line"]), ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 5), ("RIGHTPADDING", (0,0), (-1,-1), 5), ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
        story.append(table)

    story.append(PageBreak())
    story.append(_p(L["details"].upper(), kicker))
    story.append(_p(audit_label, h2))
    rows = [[_p(L["severity"], table_header), _p(L["switch"], table_header), _p(L["address"], table_header), _p(L["site"], table_header), _p(L["model"], table_header), _p(L["score"], table_header), _p(L["summary"], table_header)]]
    for item in items:
        rows.append([
            _p(_severity_label(str(item.get("severity") or ""), L), table_body),
            _p(item.get("device_name") or "-", table_body),
            _p(item.get("host") or "-", table_body),
            _p(item.get("site") or "-", table_body),
            _p(item.get("model") or "-", table_body),
            _p(item.get("score") if item.get("score") is not None else "-", table_body),
            _p((_audit_item_summary(item, str(run.get("audit_type") or ""), lang) + (" · " + _audit_item_evidence(item, str(run.get("audit_type") or ""), lang) if _audit_item_evidence(item, str(run.get("audit_type") or ""), lang) else "")), table_body),
        ])
    detail_table = Table(rows, colWidths=[27*mm, 45*mm, 36*mm, 34*mm, 36*mm, 18*mm, 59*mm], repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0,0), (-1,0), COLORS["navy"]),
        ("GRID", (0,0), (-1,-1), 0.3, COLORS["line"]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]
    for idx, item in enumerate(items, start=1):
        sev = str(item.get("severity") or "info")
        if sev in COLORS:
            color = COLORS[sev]
            style_cmds.append(("TEXTCOLOR", (0,idx), (0,idx), color))
            style_cmds.append(("FONTNAME", (0,idx), (0,idx), _FONT_BOLD))
    detail_table.setStyle(TableStyle(style_cmds))
    story.append(detail_table)

    if len(items) <= 25:
        diagnostic_items = list(items)
    else:
        diagnostic_items = [
            item for item in items
            if item.get("severity") in {"critical", "warning", "unavailable"}
            or item.get("error")
            or item.get("command_errors")
        ]
    if diagnostic_items:
        story.append(PageBreak())
        story.append(_p(L["diagnostics"].upper(), kicker))
        story.append(_p(audit_label, h2))
        story.append(_p(
            (("Οι παρακάτω ενότητες παρουσιάζουν αναλυτικά τα πραγματικά στοιχεία που συνέλεξε το Portivo για κάθε switch του συγκεκριμένου scope. Η αναφορά ξεχωρίζει παρατήρηση, status και συμπέρασμα και δεν αποδίδει root cause που δεν αποδεικνύεται από τα δεδομένα." if lang == "el" else
              "The following sections present the actual evidence collected by Portivo for every switch in this scope. The report separates observation, switch status and assessment and does not assign a root cause unsupported by the data.") if len(items) <= 25 else
             ("Οι παρακάτω ενότητες εξηγούν αναλυτικά κάθε Warning/Critical/Unavailable αποτέλεσμα και εμφανίζουν τα πραγματικά switch evidence. Δεν αποδίδεται root cause που δεν αποδεικνύεται από τα δεδομένα." if lang == "el" else
              "The following sections explain every Warning/Critical/Unavailable result in detail and show the actual switch evidence. The report does not assign a root cause unsupported by the data.")),
            body,
        ))
        for index, item in enumerate(diagnostic_items):
            if index:
                story.append(PageBreak())
            sev = str(item.get("severity") or "info")
            switch_name = item.get("device_name") or item.get("host") or "Switch"
            story.append(_p(f"{switch_name} - {_severity_label(sev, L)}", h2))
            identity_rows = [
                [_p(L["address"], table_header), _p(L["site"], table_header), _p(L["model"], table_header), _p(L["assessment"], table_header)],
                [_p(item.get("host") or "-", table_body), _p(item.get("site") or "-", table_body), _p(item.get("model") or "-", table_body), _p(_severity_label(sev, L), table_body)],
            ]
            identity = Table(identity_rows, colWidths=[68*mm, 60*mm, 68*mm, 59*mm])
            identity.setStyle(TableStyle([
                ("BACKGROUND", (0,0), (-1,0), COLORS["navy"]),
                ("GRID", (0,0), (-1,-1), 0.35, COLORS["line"]),
                ("VALIGN", (0,0), (-1,-1), "TOP"),
                ("LEFTPADDING", (0,0), (-1,-1), 5), ("RIGHTPADDING", (0,0), (-1,-1), 5),
                ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4),
            ]))
            story.append(identity)
            story.append(_p(L["interpretation"], h3))
            story.append(_p(_diagnostic_interpretation(item, str(run.get("audit_type") or ""), lang), body))

            commands = [str(x) for x in ((item.get("details") or {}).get("source_commands") or []) if str(x).strip()]
            errors = item.get("command_errors") or {}
            if commands or errors:
                story.append(_p(L["collection"], h3))
                collection_rows = []
                if commands:
                    collection_rows.append([L["commands"], ", ".join(commands)])
                if errors:
                    collection_rows.append([L["collection_notes"], " | ".join(f"{key}: {value}" for key, value in errors.items())])
                collection = Table([[_p(a, table_body), _p(b, table_body)] for a, b in collection_rows], colWidths=[55*mm, 200*mm])
                collection.setStyle(TableStyle([
                    ("BACKGROUND", (0,0), (0,-1), COLORS["panel"]), ("GRID", (0,0), (-1,-1), 0.3, COLORS["line"]),
                    ("VALIGN", (0,0), (-1,-1), "TOP"), ("FONTNAME", (0,0), (0,-1), _FONT_BOLD),
                    ("LEFTPADDING", (0,0), (-1,-1), 5), ("RIGHTPADDING", (0,0), (-1,-1), 5),
                    ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4),
                ]))
                story.append(collection)

            for table_def in _diagnostic_tables(item, str(run.get("audit_type") or ""), lang):
                story.append(_p(table_def["title"], h3))
                headers = table_def["headers"]
                rows = table_def["rows"]
                widths_mm = table_def.get("widths") or [255 / max(1, len(headers))] * len(headers)
                data = [[_p(value, table_header) for value in headers]] + [[_p(value, table_body) for value in row] for row in rows]
                table = Table(data, colWidths=[float(width) * mm for width in widths_mm], repeatRows=1)
                table.setStyle(TableStyle([
                    ("BACKGROUND", (0,0), (-1,0), COLORS["navy"]),
                    ("GRID", (0,0), (-1,-1), 0.3, COLORS["line"]),
                    ("VALIGN", (0,0), (-1,-1), "TOP"),
                    ("LEFTPADDING", (0,0), (-1,-1), 4), ("RIGHTPADDING", (0,0), (-1,-1), 4),
                    ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4),
                ]))
                story.append(table)

            recommendations = _diagnostic_recommendations(item, str(run.get("audit_type") or ""), lang)
            if recommendations:
                story.append(_p(L["recommended"], h3))
                for rec_index, rec in enumerate(recommendations, start=1):
                    story.append(_p(f"{rec_index}. {rec}", body))

    doc.build(story)
    return buffer.getvalue()


def safe_audit_filename(run: dict[str, Any]) -> str:
    label = str((run.get("definition") or {}).get("label") or run.get("audit_type") or "fleet-audit")
    cleaned = "-".join(part for part in "".join(ch if ch.isalnum() else " " for ch in label).split() if part)
    return f"Portivo-Audit-{run.get('id')}-{cleaned or 'Report'}.pdf"
