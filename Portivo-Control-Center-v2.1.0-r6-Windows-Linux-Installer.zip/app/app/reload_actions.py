# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
from typing import Any


class ReloadActionError(ValueError):
    pass


def _decode_members(device: dict[str, Any], key: str) -> list[dict[str, Any]]:
    value = device.get(key)
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    try:
        decoded = json.loads(str(value or "[]"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    return [item for item in decoded if isinstance(item, dict)] if isinstance(decoded, list) else []


def stack_members(device: dict[str, Any]) -> list[dict[str, Any]]:
    current = _decode_members(device, "stack_members") or _decode_members(device, "stack_members_json")
    baseline = _decode_members(device, "stack_baseline_members") or _decode_members(device, "stack_baseline_members_json")
    source = current or baseline
    unique: dict[str, dict[str, Any]] = {}
    for item in source:
        member_id = str(item.get("id") or item.get("config_id") or "").strip()
        if member_id and member_id.isdigit():
            unique[str(int(member_id))] = item
    return [unique[key] for key in sorted(unique, key=int)]


def stack_member_role(device: dict[str, Any], chassis_id: str) -> str:
    wanted = str(int(chassis_id)) if str(chassis_id).strip().isdigit() else ""
    for item in stack_members(device):
        member_id = str(item.get("id") or item.get("config_id") or "").strip()
        if member_id.isdigit() and str(int(member_id)) == wanted:
            return str(item.get("role") or "").strip()
    return ""


def stack_member_count(device: dict[str, Any]) -> int:
    members = stack_members(device)
    if members:
        return len(members)
    for key in ("stack_expected_members", "stack_current_members"):
        try:
            count = int(device.get(key) or 0)
        except (TypeError, ValueError):
            count = 0
        if count > 1:
            return count
    return 1


def normalize_chassis_id(value: str) -> str:
    raw = str(value or "").strip()
    if not re.fullmatch(r"[1-8]", raw):
        raise ReloadActionError("Chassis ID must be between 1 and 8")
    return str(int(raw))


def reload_switch_command(device: dict[str, Any]) -> str:
    profile = str(device.get("profile") or "").strip().upper()
    if stack_member_count(device) > 1:
        raise ReloadActionError(
            "This is a stacked switch. Reload a specific chassis from the front-panel card instead of rebooting the whole stack."
        )
    if profile == "AOS8":
        return "reload from working no rollback-timeout"
    if profile == "AOS6":
        return "reload working no rollback-timeout"
    raise ReloadActionError(f"Reload is not supported for profile {profile or 'Unknown'}")


def reload_stack_member_command(device: dict[str, Any], chassis_id: str) -> str:
    chassis = normalize_chassis_id(chassis_id)
    profile = str(device.get("profile") or "").strip().upper()
    if profile == "AOS8":
        return f"reload chassis-id {chassis} from working no rollback-timeout"
    if profile != "AOS6":
        raise ReloadActionError(f"Stack-member reload is not supported for profile {profile or 'Unknown'}")

    role = stack_member_role(device, chassis).lower()
    if role in {"primary", "master"}:
        return "reload primary"
    if role in {"secondary", "slave"}:
        return "reload secondary"
    if role in {"idle", "ni"}:
        return f"reload ni {chassis}"
    raise ReloadActionError(
        f"AOS6 chassis {chassis} does not have a verified stack role. Refresh or learn stack health before reloading this member."
    )


def reload_command(device: dict[str, Any], action: str, chassis_id: str = "") -> str:
    if action == "reload_switch":
        return reload_switch_command(device)
    if action == "reload_stack_member":
        return reload_stack_member_command(device, chassis_id)
    raise ReloadActionError(f"Unknown reload action: {action}")
