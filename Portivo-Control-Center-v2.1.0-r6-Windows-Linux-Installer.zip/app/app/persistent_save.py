# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
from typing import Any, Callable

from .profiles import save_command_for_profile, should_auto_save
from .ssh_runner import CommandResult, run_commands

_CERTIFIED_SAVE_ERROR = re.compile(
    r"write\s+memory.*not\s+permitted.*certified\s+mode|running\s+in\s+certified\s+mode",
    re.IGNORECASE | re.DOTALL,
)
_RUNNING_DIRECTORY = re.compile(r"running\s+configuration\s*:\s*([A-Za-z0-9_.-]+)", re.IGNORECASE)


def parse_running_directory(output: str) -> str:
    match = _RUNNING_DIRECTORY.search(str(output or ""))
    return match.group(1).strip().lower() if match else ""


def is_certified_mode_save_error(output: str, error: str = "") -> bool:
    return bool(_CERTIFIED_SAVE_ERROR.search(f"{output}\n{error}"))


def save_preview_for_profile(profile_name: str) -> str:
    save_command = save_command_for_profile(profile_name)
    if str(profile_name).upper() != "AOS8":
        return save_command
    return (
        f"{save_command}\n"
        "IF CERTIFIED MODE IS DETECTED:\n"
        "show running-directory\n"
        "copy certified working make-running-directory\n"
        f"{save_command}\n"
        "show running-directory"
    )


def execute_persistent_save(
    device: dict[str, Any],
    action: str,
    *,
    runner: Callable[..., CommandResult] = run_commands,
    read_timeout: int = 300,
    force: bool = False,
) -> tuple[str, CommandResult]:
    """Persist a successful configuration change with certified-mode recovery.

    The normal save is attempted first. AOS 8 recovery runs only when the
    switch explicitly rejects the save because it is currently running from
    the certified directory. The running directory is verified before and
    after recovery. A documented combined command is preferred, with the
    two-command sequence retained as a compatibility fallback.
    """

    if not force and not should_auto_save(action):
        return "", CommandResult(ok=True, output="Persistent save not required")

    profile = str(device.get("profile") or "")
    save_command = save_command_for_profile(profile)
    command_plan = save_preview_for_profile(profile)
    log: list[str] = [f"SAVE ATTEMPT: {save_command}"]

    initial = runner(device, [save_command], read_timeout=read_timeout)
    log.append(initial.output or initial.error or "No output")
    if initial.ok:
        return command_plan, CommandResult(ok=True, output="\n".join(log))

    if profile.upper() != "AOS8" or not is_certified_mode_save_error(initial.output, initial.error):
        return command_plan, CommandResult(
            ok=False,
            output="\n".join(log),
            error=initial.error or "Persistent configuration save failed",
        )

    status_command = "show running-directory"
    log.extend(["", f"CERTIFIED MODE CHECK: {status_command}"])
    status = runner(device, [status_command], read_timeout=read_timeout)
    log.append(status.output or status.error or "No output")
    if not status.ok:
        return command_plan, CommandResult(
            ok=False,
            output="\n".join(log),
            error="The save was rejected in certified mode and the running directory could not be verified",
        )

    running_directory = parse_running_directory(status.output)
    if running_directory != "certified":
        return command_plan, CommandResult(
            ok=False,
            output="\n".join(log),
            error=(
                "The save reported certified mode, but show running-directory did not confirm "
                f"CERTIFIED. Detected: {running_directory or 'unknown'}"
            ),
        )

    combined_command = "copy certified working make-running-directory"
    log.extend(["", f"CERTIFIED MODE RECOVERY: {combined_command}"])
    transition = runner(device, [combined_command], read_timeout=read_timeout)
    log.append(transition.output or transition.error or "No output")

    if not transition.ok:
        copy_command = "copy certified working"
        modify_command = "modify running-directory working"
        log.extend(["", "COMBINED RECOVERY WAS NOT ACCEPTED. USING COMPATIBILITY FALLBACK."])
        copy_result = runner(device, [copy_command], read_timeout=read_timeout)
        log.extend([copy_command, copy_result.output or copy_result.error or "No output"])
        if not copy_result.ok:
            return command_plan, CommandResult(
                ok=False,
                output="\n".join(log),
                error=copy_result.error or "Certified configuration could not be copied to working",
            )
        modify_result = runner(device, [modify_command], read_timeout=read_timeout)
        log.extend([modify_command, modify_result.output or modify_result.error or "No output"])
        if not modify_result.ok:
            return command_plan, CommandResult(
                ok=False,
                output="\n".join(log),
                error=modify_result.error or "The running directory could not be changed to working",
            )

    log.extend(["", f"SAVE RETRY: {save_command}"])
    retry = runner(device, [save_command], read_timeout=read_timeout)
    log.append(retry.output or retry.error or "No output")
    if not retry.ok:
        return command_plan, CommandResult(
            ok=False,
            output="\n".join(log),
            error=retry.error or "Persistent save failed after certified-mode recovery",
        )

    log.extend(["", f"FINAL DIRECTORY VERIFICATION: {status_command}"])
    final_status = runner(device, [status_command], read_timeout=read_timeout)
    log.append(final_status.output or final_status.error or "No output")
    final_directory = parse_running_directory(final_status.output) if final_status.ok else ""
    if not final_status.ok or final_directory != "working":
        return command_plan, CommandResult(
            ok=False,
            output="\n".join(log),
            error=(
                "Configuration was saved, but the final running-directory verification did not confirm WORKING"
            ),
        )

    log.extend(["", "CERTIFIED MODE RECOVERY: SUCCESSFUL"])
    return command_plan, CommandResult(ok=True, output="\n".join(log))
