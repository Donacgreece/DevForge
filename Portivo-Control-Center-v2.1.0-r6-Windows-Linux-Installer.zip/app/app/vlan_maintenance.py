# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

"""Safe VLAN-targeted transient maintenance workflows.

The workflow is intentionally fail-closed. Portivo will only touch a physical
port when the target VLAN is positively identified as untagged/access
membership and all configured uplink-safety evidence can be collected.
"""

from collections import Counter, defaultdict
import re
from typing import Any, Iterable

from .ale_cli import poe_status_commands, slot_from_port
from .db import db, get_app_setting, get_app_setting_int
from .device_finder import parse_lldp, parse_mac_table
from .port_inventory import infer_slots, parse_lanpower
from .profiles import render_command

PORT_PATTERN = re.compile(r"(?<!\d)(\d+(?:/\d+){1,2})(?!\d)")
VLAN_PATTERN = re.compile(r"(?i)\bvlan(?:\s+id)?\s*[:=]?\s*(\d{1,4})\b")
MODE_PATTERN = re.compile(r"(?i)\b(untagged|tagged)\b")


def _identity_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").casefold())


def _port_sort_key(port: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in str(port).split("/"))
    except ValueError:
        return (10**9,)


def _normalize_port(value: str) -> str:
    match = PORT_PATTERN.fullmatch(str(value or "").strip())
    return match.group(1) if match else ""


def protected_ports() -> set[str]:
    raw = get_app_setting("vlan_maintenance_protected_ports", "")
    return {
        port
        for port in (_normalize_port(item) for item in str(raw).split(","))
        if port
    }


def max_ports_per_switch() -> int:
    return get_app_setting_int("vlan_maintenance_max_ports_per_switch", 12, 1, 48)


def max_total_ports() -> int:
    return get_app_setting_int("vlan_maintenance_max_total_ports", 100, 1, 2000)


def trunk_vlan_threshold() -> int:
    return get_app_setting_int("vlan_maintenance_trunk_vlan_threshold", 4, 2, 128)


def mac_address_threshold() -> int:
    return get_app_setting_int("vlan_maintenance_mac_threshold", 8, 2, 2048)


def safeguard_policy() -> dict[str, Any]:
    return {
        "protected_ports": get_app_setting("vlan_maintenance_protected_ports", ""),
        "max_ports_per_switch": max_ports_per_switch(),
        "max_total_ports": max_total_ports(),
        "trunk_vlan_threshold": trunk_vlan_threshold(),
        "mac_address_threshold": mac_address_threshold(),
        "automatic_guards": [
            "Only confirmed untagged/access membership is eligible",
            "Tagged or unknown target-VLAN membership is always protected",
            "LAG members are always protected",
            "Ports with an LLDP neighbor matching another managed Portivo switch are always protected",
            "Trunk-like multi-VLAN ports are protected",
            "Ports exceeding the learned-MAC safety threshold are protected",
            "PoE restart requires readable PoE evidence for the target port",
            "Incomplete safety evidence blocks changes on the switch",
        ],
    }


def parse_vlan_membership_details(output: str) -> dict[str, dict[str, str]]:
    """Return port -> VLAN -> tagged/untagged/unknown from common ALE views.

    The parser accepts both configuration-style output and tabular/contextual
    ``show vlan members`` output. Ambiguous membership is retained as
    ``unknown`` so the caller can protect the port rather than guess.
    """
    result: dict[str, dict[str, str]] = defaultdict(dict)
    current_vlan = ""
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue
        lower = line.casefold()
        if lower.startswith("show "):
            continue

        # Configuration-style syntax documented by ALE, e.g.
        # vlan 120 members port 1/1/10 untagged
        config_match = re.search(
            r"(?i)\bvlan\s+(\d{1,4})\b.*?\bport\s+(\d+(?:/\d+){1,2})\b(?:.*?\b(untagged|tagged)\b)?",
            line,
        )
        if config_match and 1 <= int(config_match.group(1)) <= 4094:
            vlan, port = config_match.group(1), config_match.group(2)
            mode = (config_match.group(3) or "unknown").casefold()
            result[port][vlan] = mode
            current_vlan = vlan
            continue

        context = VLAN_PATTERN.search(line)
        if context and 1 <= int(context.group(1)) <= 4094:
            current_vlan = context.group(1)

        ports = PORT_PATTERN.findall(line)
        if not ports:
            continue
        mode_match = MODE_PATTERN.search(line)
        mode = mode_match.group(1).casefold() if mode_match else "unknown"

        # Prefer an explicit VLAN token. If the line is within a VLAN section,
        # use that context. A standalone numeric token is accepted only when it
        # is not part of a port token and is within the VLAN range.
        vlan = current_vlan
        explicit = VLAN_PATTERN.search(line)
        if explicit:
            vlan = explicit.group(1)
        if not vlan:
            scrubbed = PORT_PATTERN.sub(" ", line)
            numeric = [token for token in re.findall(r"(?<!\d)(\d{1,4})(?!\d)", scrubbed) if 1 <= int(token) <= 4094]
            if numeric:
                vlan = numeric[0]
        if not vlan:
            continue
        for port in ports:
            existing = result[port].get(vlan)
            # Never upgrade an ambiguous parse to access-safe unless the line
            # explicitly says untagged. Tagged always wins over ambiguity.
            if existing == "tagged":
                continue
            if mode == "tagged" or existing is None or mode == "untagged":
                result[port][vlan] = mode
    return {port: dict(vlans) for port, vlans in result.items()}


def parse_linkagg_member_ports(output: str) -> set[str]:
    ports: set[str] = set()
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.casefold().startswith("show "):
            continue
        for port in PORT_PATTERN.findall(line):
            ports.add(port)
    return ports


def _managed_lldp_ports(output: str, local_device_id: int) -> dict[str, str]:
    with db() as conn:
        rows = conn.execute("SELECT id, name, host FROM devices WHERE enabled = 1").fetchall()
    devices = [dict(row) for row in rows]
    result: dict[str, str] = {}
    for record in parse_lldp(output):
        port = _normalize_port(str(record.get("port") or ""))
        if not port:
            continue
        hostname = str(record.get("hostname") or "")
        raw = str(record.get("raw") or "")
        host_token = _identity_token(hostname)
        raw_folded = raw.casefold()
        for candidate in devices:
            if int(candidate.get("id") or 0) == int(local_device_id):
                continue
            candidate_name = str(candidate.get("name") or "")
            candidate_host = str(candidate.get("host") or "")
            name_token = _identity_token(candidate_name)
            host_match = bool(candidate_host and candidate_host.casefold() in raw_folded)
            name_match = bool(
                host_token and name_token and (
                    host_token == name_token
                    or (min(len(host_token), len(name_token)) >= 6 and (host_token in name_token or name_token in host_token))
                )
            )
            if host_match or name_match:
                result[port] = candidate_name or candidate_host or hostname
                break
    return result


def _mac_counts(output: str) -> dict[str, int]:
    unique: dict[str, set[str]] = defaultdict(set)
    for record in parse_mac_table(output):
        port = _normalize_port(str(record.get("port") or ""))
        mac = str(record.get("mac") or "").strip()
        if port and mac:
            unique[port].add(mac)
    return {port: len(values) for port, values in unique.items()}


def _read_required(session: Any, command: str, label: str) -> str:
    result = session.execute(command)
    if not result.ok:
        raise RuntimeError(f"Safety inspection incomplete: {label} could not be read ({result.error or 'command rejected'})")
    return str(result.output or "")


def _base_commands(profile: str) -> dict[str, str]:
    commands: dict[str, str] = {}
    for action in ("vlan_members", "linkagg_ports", "lldp_neighbors", "mac_table"):
        command, _ = render_command(profile, action)
        commands[action] = command
    return commands


def inspect_vlan_maintenance_session(
    session: Any,
    device: dict[str, Any],
    *,
    target_vlan: int,
    operation: str,
) -> dict[str, Any]:
    if not 1 <= int(target_vlan) <= 4094:
        raise ValueError("Target VLAN must be between 1 and 4094")
    if operation not in {"poe_cycle", "interface_cycle"}:
        raise ValueError("VLAN maintenance operation must be Restart PoE or Restart interface")

    profile = str(device.get("profile") or "")
    commands = _base_commands(profile)
    outputs = {
        key: _read_required(session, command, key.replace("_", " "))
        for key, command in commands.items()
    }
    vlan_map = parse_vlan_membership_details(outputs["vlan_members"])
    if not vlan_map and str(outputs["vlan_members"]).strip():
        raise RuntimeError("Safety inspection incomplete: VLAN membership output could not be parsed safely")

    lag_ports = parse_linkagg_member_ports(outputs["linkagg_ports"])
    managed_neighbors = _managed_lldp_ports(outputs["lldp_neighbors"], int(device.get("id") or 0))
    mac_counts = _mac_counts(outputs["mac_table"])
    explicit = protected_ports()
    vlan_limit = trunk_vlan_threshold()
    mac_limit = mac_address_threshold()
    target = str(int(target_vlan))

    matching = sorted((port for port, vlans in vlan_map.items() if target in vlans), key=_port_sort_key)
    candidates: list[dict[str, Any]] = []
    for port in matching:
        vlans = vlan_map.get(port, {})
        mode = str(vlans.get(target) or "unknown").casefold()
        reasons: list[str] = []
        if port in explicit:
            reasons.append("Explicitly protected by policy")
        if mode == "tagged":
            reasons.append("Target VLAN is tagged on this port")
        elif mode != "untagged":
            reasons.append("Target VLAN membership is not confirmed untagged/access")
        if port in lag_ports:
            reasons.append("LAG member")
        if port in managed_neighbors:
            reasons.append(f"LLDP neighbor is managed infrastructure: {managed_neighbors[port]}")
        vlan_count = len(vlans)
        if vlan_count >= vlan_limit:
            reasons.append(f"Trunk-like membership: {vlan_count} VLANs")
        learned_macs = int(mac_counts.get(port, 0))
        if learned_macs >= mac_limit:
            reasons.append(f"High learned-MAC count: {learned_macs}")
        candidates.append({
            "port": port,
            "membership": mode,
            "vlan_count": vlan_count,
            "mac_count": learned_macs,
            "reasons": reasons,
        })

    # PoE restart needs positive PoE evidence. A missing/failed slot view makes
    # the candidate protected rather than assuming that PoE exists.
    if operation == "poe_cycle" and candidates:
        known_ports = [item["port"] for item in candidates]
        poe_records: dict[str, dict[str, object]] = {}
        for slot in infer_slots(known_ports, profile):
            accepted_output = ""
            failures: list[str] = []
            for command in poe_status_commands(profile, slot):
                result = session.execute(command)
                if result.ok:
                    accepted_output = str(result.output or "")
                    commands[f"poe_status_{slot}"] = command
                    break
                failures.append(result.error or "command rejected")
            if not accepted_output:
                raise RuntimeError(
                    f"Safety inspection incomplete: PoE evidence for slot {slot} could not be read ({' | '.join(failures)})"
                )
            poe_records.update(parse_lanpower(accepted_output, slot, known_ports))
        for item in candidates:
            poe = poe_records.get(item["port"])
            if not poe:
                item["reasons"].append("PoE capability/state could not be verified")
                continue
            item["poe_state"] = poe.get("poe_state") or "unknown"
            item["poe_admin_state"] = poe.get("poe_admin_state") or "unknown"
            if str(poe.get("poe_admin_state") or "").casefold() == "disabled":
                item["reasons"].append("PoE is administratively disabled")

    protected = [item for item in candidates if item["reasons"]]
    eligible = [item for item in candidates if not item["reasons"]]
    per_switch_limit = max_ports_per_switch()
    safety_limit_exceeded = len(eligible) > per_switch_limit
    if safety_limit_exceeded:
        for item in eligible:
            item["reasons"] = [f"Per-switch safety limit exceeded: {len(eligible)} > {per_switch_limit}"]
        protected.extend(eligible)
        eligible = []

    return {
        "device_id": int(device.get("id") or 0),
        "device": str(device.get("name") or device.get("host") or "Switch"),
        "host": str(device.get("host") or ""),
        "profile": profile,
        "target_vlan": int(target_vlan),
        "operation": operation,
        "matching_count": len(candidates),
        "eligible_count": len(eligible),
        "protected_count": len(protected),
        "eligible_ports": [item["port"] for item in eligible],
        "protected_ports": protected,
        "ports": candidates,
        "safety_limit_exceeded": safety_limit_exceeded,
        "max_ports_per_switch": per_switch_limit,
        "commands": commands,
        "safety_complete": True,
    }


def format_assessment(assessment: dict[str, Any], *, cycle_delay_seconds: int = 5) -> str:
    operation = "Restart PoE" if assessment.get("operation") == "poe_cycle" else "Restart interface"
    lines = [
        "VLAN PORT MAINTENANCE PREVIEW",
        f"Target VLAN: {assessment.get('target_vlan')}",
        f"Operation: {operation}",
        f"Matching ports: {assessment.get('matching_count', 0)}",
        f"Eligible ports: {assessment.get('eligible_count', 0)}",
        f"Protected ports: {assessment.get('protected_count', 0)}",
        f"Cycle delay: {int(cycle_delay_seconds)}s",
    ]
    eligible = list(assessment.get("eligible_ports") or [])
    lines.append("Eligible: " + (", ".join(eligible) if eligible else "None"))
    protected = assessment.get("protected_ports") or []
    if protected:
        lines.append("")
        lines.append("PROTECTED")
        for item in protected:
            lines.append(f"{item.get('port')}: {'; '.join(item.get('reasons') or ['Protected by safety policy'])}")
    lines.extend(["", "No changes are made during Preview."])
    return "\n".join(lines)


def cycle_commands(profile: str, operation: str, port: str) -> tuple[str, str]:
    prefix = "poe" if operation == "poe_cycle" else "interface"
    disable, _ = render_command(profile, f"{prefix}_disable", port=port)
    enable, _ = render_command(profile, f"{prefix}_enable", port=port)
    return disable, enable


def stable_signature(assessment: dict[str, Any]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return the effective safety classification for a validation pass.

    The VLAN maintenance table is live evidence. Learned-MAC counts and other
    descriptive values can legitimately move between two read-only scans even
    when a port remains protected. Stability therefore means that the set of
    ports Portivo would change and the set it would protect are unchanged.

    This keeps the dual-pass guard fail-closed for any eligibility transition,
    newly matching protected port, or removed matching port, while avoiding
    false aborts caused only by volatile counters such as 161 -> 162 learned
    MAC addresses on an already protected uplink.
    """
    eligible = tuple(sorted(
        (str(port) for port in assessment.get("eligible_ports") or [] if str(port or "")),
        key=_port_sort_key,
    ))
    protected = tuple(sorted(
        (
            str(item.get("port") or "")
            for item in assessment.get("protected_ports") or []
            if str(item.get("port") or "")
        ),
        key=_port_sort_key,
    ))
    return eligible, protected
