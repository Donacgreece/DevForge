# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Iterable

from .db import db, utc_now

# AOS can expose regular ports (1/1/24), chassis ports (1/24), and breakout
# ports with a trailing letter. Keep parsing conservative and never infer an
# alias from arbitrary trailing status columns.
PORT_TOKEN = r"\d+(?:/\d+){1,2}[A-Za-z]?"
PORT_RE = re.compile(rf"^(?P<port>{PORT_TOKEN})\b", re.I)
PORT_HEADER_RE = re.compile(
    rf"(?:slot\s*/\s*port|slot/port|interface|port)\s*:?\s*(?P<port>{PORT_TOKEN})\s*:?",
    re.I,
)
VLAN_CONTEXT_RE = re.compile(r"\bvlan\s+(?P<vlan>\d+)\b", re.I)
VLAN_PORT_RE = re.compile(rf"^(?P<vlan>\d+)\s+(?P<port>{PORT_TOKEN})\b", re.I)
QUOTED_RE = re.compile(r'["“](.*?)["”]')

ADMIN_TOKENS = {"enable", "enabled", "en", "up", "on"}
ADMIN_DISABLED_TOKENS = {"disable", "disabled", "dis", "down", "off"}
LINK_UP_TOKENS = {"up", "on", "active"}
LINK_DOWN_TOKENS = {"down", "off", "inactive"}
PLACEHOLDERS = {"", "-", "--", "n/a", "na", "none", "unknown"}


@dataclass
class PortRecord:
    port: str
    admin_state: str = "unknown"
    link_state: str = "unknown"
    autoneg_state: str = "unknown"
    detected_speed: str = ""
    configured_speed: str = ""
    detected_duplex: str = ""
    configured_duplex: str = ""
    alias: str = ""
    vlans: list[str] = field(default_factory=list)
    poe_state: str = "unknown"
    poe_oper_status: str = ""
    poe_admin_state: str = "unknown"
    poe_power_mw: int | None = None
    poe_max_mw: int | None = None
    poe_priority: str = ""
    poe_class: str = ""
    poe_type: str = ""
    wtr_seconds: int | None = None
    wts_milliseconds: int | None = None
    observed_link_since: str = ""
    observed_link_seconds: int | None = None
    last_link_change_at: str = ""
    first_seen_at: str = ""
    last_seen_at: str = ""
    field_sources: dict[str, str] = field(default_factory=dict)

    @property
    def speed(self) -> str:
        return self.detected_speed or self.configured_speed

    @property
    def duplex(self) -> str:
        return self.detected_duplex or self.configured_duplex

    def set_field(self, name: str, value: object, source: str) -> None:
        if value in (None, "", "unknown"):
            return
        setattr(self, name, value)
        self.field_sources[name] = source

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["vlans"] = sorted(set(self.vlans or []), key=_natural_vlan_key)
        data["speed"] = self.speed
        data["duplex"] = self.duplex
        core = (self.admin_state, self.link_state)
        if all(value != "unknown" for value in core):
            data["data_quality"] = "complete"
        elif any(value != "unknown" for value in core):
            data["data_quality"] = "partial"
        else:
            data["data_quality"] = "unreported"
        return data


def _natural_port_key(value: str) -> tuple[object, ...]:
    parts: list[object] = []
    for part in value.split("/"):
        match = re.fullmatch(r"(\d+)([A-Za-z]?)", part)
        if not match:
            return (999999, value)
        parts.extend((int(match.group(1)), match.group(2).upper()))
    return tuple(parts)


def _natural_vlan_key(value: str) -> tuple[int, str]:
    try:
        return (int(value), value)
    except ValueError:
        return (999999, value)


def _clean_token(value: str) -> str:
    return str(value or "").strip().strip(",;:()").lower()


def _normalize_admin(value: str) -> str:
    token = _clean_token(value)
    if token in ADMIN_TOKENS:
        return "enabled"
    if token in ADMIN_DISABLED_TOKENS:
        return "disabled"
    return "unknown"


def _normalize_link(value: str) -> str:
    token = _clean_token(value)
    if token in LINK_UP_TOKENS:
        return "up"
    if token in LINK_DOWN_TOKENS:
        return "down"
    return "unknown"


def _normalize_toggle(value: str) -> str:
    token = _clean_token(value)
    if token in ADMIN_TOKENS:
        return "enabled"
    if token in ADMIN_DISABLED_TOKENS:
        return "disabled"
    return "unknown"


def _clean_value(value: str) -> str:
    token = str(value or "").strip().strip('"').strip("'")
    return "" if token.lower() in PLACEHOLDERS else token


def _parse_int(value: str) -> int | None:
    token = re.sub(r"[^0-9]", "", str(value or ""))
    return int(token) if token else None


def _record(ports: dict[str, PortRecord], port: str) -> PortRecord:
    return ports.setdefault(port, PortRecord(port=port))


def _parse_block_field(record: PortRecord, line: str, source: str) -> None:
    lower = line.lower()
    value = line.split(":", 1)[-1].strip() if ":" in line else line.split()[-1]
    if "administrative" in lower or "admin state" in lower or "admin status" in lower:
        record.set_field("admin_state", _normalize_admin(value.split()[0]), source)
    elif "operational status" in lower or "link status" in lower:
        record.set_field("link_state", _normalize_link(value.split()[0]), source)
    elif "auto" in lower and "nego" in lower:
        record.set_field("autoneg_state", _normalize_toggle(value.split()[0]), source)
    elif "detected speed" in lower or ("speed" in lower and "configured" not in lower):
        record.set_field("detected_speed", _clean_value(value.split()[0]), source)
    elif "configured speed" in lower:
        record.set_field("configured_speed", _clean_value(value.split()[0]), source)
    elif "detected duplex" in lower or ("duplex" in lower and "configured" not in lower):
        record.set_field("detected_duplex", _clean_value(value.split()[0]).title(), source)
    elif "configured duplex" in lower:
        record.set_field("configured_duplex", _clean_value(value.split()[0]).title(), source)
    elif "alias" in lower or "description" in lower:
        record.alias = _clean_value(value)
        record.field_sources["alias"] = source


def parse_interface_alias(output: str, *, source: str = "interface_alias") -> dict[str, PortRecord]:
    """Parse only authoritative admin/link/alias output.

    Supported layouts include AOS 8 ``show interfaces alias`` and AOS 6
    ``show interfaces port``. Aliases are accepted only when explicitly quoted
    or presented in an Alias/Description field. This prevents status columns
    such as ``- DIS - en dis`` from being displayed as aliases.
    """
    ports: dict[str, PortRecord] = {}
    current_port = ""
    for raw_line in (output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue

        header = PORT_HEADER_RE.search(line)
        if header and (":" in line or line.lower().startswith(("slot/port", "slot / port", "interface", "port"))):
            current_port = header.group("port")
            _record(ports, current_port)

        table = PORT_RE.match(line)
        if table:
            current_port = table.group("port")
            record = _record(ports, current_port)
            rest = line[table.end():].strip()
            tokens = rest.replace("|", " ").split()
            if tokens:
                admin = _normalize_admin(tokens[0])
                if admin != "unknown":
                    record.set_field("admin_state", admin, source)
            if len(tokens) > 1:
                link = _normalize_link(tokens[1])
                if link != "unknown":
                    record.set_field("link_state", link, source)

            # AOS 8 alias output commonly places WTR and WTS immediately after
            # link state. Parse only clearly numeric representations.
            if len(tokens) > 2 and re.fullmatch(r"\d+", tokens[2]):
                record.wtr_seconds = int(tokens[2])
                record.field_sources["wtr_seconds"] = source
            if len(tokens) > 3 and re.fullmatch(r"#?\d+", tokens[3]):
                record.wts_milliseconds = int(tokens[3].lstrip("#"))
                record.field_sources["wts_milliseconds"] = source

            quoted = QUOTED_RE.search(rest)
            if quoted:
                record.alias = _clean_value(quoted.group(1))
                record.field_sources["alias"] = source
            continue

        if current_port:
            _parse_block_field(_record(ports, current_port), line, source)
    return ports


def parse_interface_status(output: str, *, source: str = "interface_status") -> dict[str, PortRecord]:
    """Parse AOS interface capability/status output without inventing link state.

    On AOS 8, ``show interfaces status`` reports administrative status,
    auto-negotiation and detected/configured media values. It does not provide
    the physical link state, so this function intentionally leaves link_state
    untouched.
    """
    ports: dict[str, PortRecord] = {}
    current_port = ""
    for raw_line in (output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue
        table = PORT_RE.match(line)
        if table:
            current_port = table.group("port")
            record = _record(ports, current_port)
            tokens = line[table.end():].replace("|", " ").split()
            if not tokens:
                continue
            admin = _normalize_admin(tokens[0])
            if admin != "unknown":
                record.set_field("admin_state", admin, source)
            if len(tokens) > 1:
                record.set_field("autoneg_state", _normalize_toggle(tokens[1]), source)

            # Current AOS 8 status table: Admin, AutoNego, detected
            # speed/duplex/pause/FEC, configured speed/duplex/pause/FEC,
            # link-trap and EEE. Older releases may omit FEC columns.
            if len(tokens) >= 12:
                detected_speed, detected_duplex = tokens[2], tokens[3]
                configured_speed, configured_duplex = tokens[6], tokens[7]
            elif len(tokens) >= 9:
                detected_speed, detected_duplex = tokens[2], tokens[3]
                configured_speed, configured_duplex = tokens[5], tokens[6]
            else:
                detected_speed = detected_duplex = configured_speed = configured_duplex = ""

            record.set_field("detected_speed", _clean_value(detected_speed), source)
            record.set_field("detected_duplex", _clean_value(detected_duplex).title(), source)
            record.set_field("configured_speed", _clean_value(configured_speed), source)
            record.set_field("configured_duplex", _clean_value(configured_duplex).title(), source)
            continue

        header = PORT_HEADER_RE.search(line)
        if header and (":" in line or line.lower().startswith(("interface", "port"))):
            current_port = header.group("port")
            _record(ports, current_port)
        elif current_port:
            _parse_block_field(_record(ports, current_port), line, source)
    return ports


def merge_port_records(*collections: dict[str, PortRecord]) -> dict[str, PortRecord]:
    merged: dict[str, PortRecord] = {}
    for collection in collections:
        for port, incoming in collection.items():
            target = _record(merged, port)
            for name in (
                "admin_state", "link_state", "autoneg_state", "detected_speed",
                "configured_speed", "detected_duplex", "configured_duplex", "alias",
            ):
                value = getattr(incoming, name)
                if value not in (None, "", "unknown"):
                    setattr(target, name, value)
                    if name in incoming.field_sources:
                        target.field_sources[name] = incoming.field_sources[name]
            for name in ("wtr_seconds", "wts_milliseconds"):
                value = getattr(incoming, name)
                if value is not None:
                    setattr(target, name, value)
                    if name in incoming.field_sources:
                        target.field_sources[name] = incoming.field_sources[name]
    return merged


def parse_interfaces(output: str) -> dict[str, PortRecord]:
    """Backward-compatible parser combining authoritative alias and media data."""
    return merge_port_records(parse_interface_alias(output), parse_interface_status(output))


def parse_vlan_members(output: str) -> dict[str, set[str]]:
    membership: dict[str, set[str]] = {}
    current_vlan = ""
    for raw_line in (output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue
        context = VLAN_CONTEXT_RE.search(line)
        if context and not line.lower().startswith("show "):
            current_vlan = context.group("vlan")

        direct = VLAN_PORT_RE.match(line)
        if direct:
            vlan = direct.group("vlan")
            membership.setdefault(direct.group("port"), set()).add(vlan)
            continue

        port_match = PORT_RE.match(line)
        if port_match and current_vlan:
            membership.setdefault(port_match.group("port"), set()).add(current_vlan)
            continue

        tokens = line.replace("|", " ").split()
        port_tokens = [token for token in tokens if re.fullmatch(PORT_TOKEN, token, re.I)]
        vlan_tokens = [token for token in tokens if token.isdigit() and 0 < int(token) <= 4094]
        if port_tokens and vlan_tokens:
            vlan = current_vlan or vlan_tokens[0]
            for port in port_tokens:
                membership.setdefault(port, set()).add(vlan)
    return membership


def _resolve_port(first: str, slot: str, known: set[str]) -> str:
    """Resolve a PoE table row only to an interface already learned upstream.

    LANPOWER output can contain numeric summary rows (for example total/max
    wattage). Older logic treated any leading integer as a new port number,
    which could invent interfaces such as 1/1/111 or 1/1/120. PoE is
    supplementary evidence, so fail closed: a row may enrich a known physical
    interface but must never create one.
    """
    if re.fullmatch(PORT_TOKEN, first, re.I) and "/" in first:
        return first if first in known else ""
    if first.isdigit():
        candidates = [candidate for candidate in known if candidate.endswith(f"/{first}") and candidate.startswith(f"{slot}/")]
        if not candidates:
            candidates = [candidate for candidate in known if candidate.endswith(f"/{first}")]
        return sorted(candidates, key=_natural_port_key)[0] if candidates else ""
    return ""


def parse_lanpower(output: str, slot: str, known_ports: Iterable[str]) -> dict[str, dict[str, object]]:
    """Parse AOS PoE tables using the documented column meaning.

    Expected AOS 8 columns are Port, Maximum, Actual Used, Status, Priority,
    On/Off, Class and Type. Status may contain two words, for example
    ``Powered On`` or ``Powered Off``.
    """
    known = set(known_ports)
    result: dict[str, dict[str, object]] = {}
    statuses = ("powered on", "powered off", "searching", "fault", "deny", "denied", "test", "error")
    for raw_line in (output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or set(line) <= {"-", "+", "=", " ", "|"}:
            continue
        tokens = line.replace("|", " ").split()
        if not tokens:
            continue
        port = _resolve_port(tokens[0], slot, known)
        if not port:
            continue
        rest = line[len(tokens[0]):].strip()
        lower = rest.lower()
        status = next((value for value in statuses if value in lower), "")
        if status == "powered on":
            state = "on"
        elif status in {"powered off", "searching", "test"}:
            state = "off"
        elif status in {"fault", "deny", "denied", "error"}:
            state = "fault"
        else:
            state = "unknown"

        numeric_tokens = [token for token in tokens[1:] if re.fullmatch(r"\d+", token)]
        maximum = _parse_int(numeric_tokens[0]) if numeric_tokens else None
        actual = _parse_int(numeric_tokens[1]) if len(numeric_tokens) > 1 else None

        admin = "unknown"
        for token in reversed(tokens):
            normalized = _normalize_toggle(token)
            if normalized != "unknown":
                admin = normalized
                break

        priority = next((token.title() for token in tokens if token.lower() in {"low", "high", "critical"}), "")
        poe_class = ""
        poe_type = ""
        for index, token in enumerate(tokens):
            if re.fullmatch(r"[0-8]", token) and index >= 3:
                poe_class = token
            if "802.3" in token.lower() or token.lower() in {"af", "at", "bt", "poe", "poe+", "poe++"}:
                poe_type = token

        result[port] = {
            "poe_state": state,
            "poe_oper_status": status.title() if status else "",
            "poe_admin_state": admin,
            "poe_power_mw": actual,
            "poe_max_mw": maximum,
            "poe_priority": priority,
            "poe_class": poe_class,
            "poe_type": poe_type,
        }
    return result


def infer_slots(ports: Iterable[str], profile: str) -> list[str]:
    slots: set[str] = set()
    for port in ports:
        parts = port.split("/")
        if profile == "AOS8" and len(parts) >= 3:
            slots.add("/".join(parts[:-1]))
        elif len(parts) >= 2:
            slots.add(parts[0])
    return sorted(slots, key=_natural_port_key)


def merge_inventory(
    interface_ports: dict[str, PortRecord],
    vlan_membership: dict[str, set[str]],
    poe_data: dict[str, dict[str, object]],
) -> list[dict[str, object]]:
    all_ports = set(interface_ports) | set(vlan_membership) | set(poe_data)
    merged: list[dict[str, object]] = []
    for port in sorted(all_ports, key=_natural_port_key):
        record = interface_ports.get(port) or PortRecord(port=port)
        record.vlans = sorted(vlan_membership.get(port, set()), key=_natural_vlan_key)
        if record.vlans:
            record.field_sources["vlans"] = "vlan_members"
        poe = poe_data.get(port, {})
        for name in (
            "poe_state", "poe_oper_status", "poe_admin_state", "poe_power_mw",
            "poe_max_mw", "poe_priority", "poe_class", "poe_type",
        ):
            if name in poe and poe[name] not in (None, "", "unknown"):
                setattr(record, name, poe[name])
                record.field_sources[name] = "lanpower"
        merged.append(record.to_dict())
    return merged


def _parse_datetime(value: str) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def observe_port_states(device_id: int, ports: list[dict[str, object]], observed_at: str | None = None) -> list[dict[str, object]]:
    """Attach honest Portivo-observed link duration and last change time.

    This cache stores only the current state and timestamps. It is not a traffic
    or long-term time-series database. Durations begin when Portivo first sees a
    known link state and reset whenever that state changes.
    """
    now_text = observed_at or utc_now()
    now_dt = _parse_datetime(now_text) or datetime.now(timezone.utc)
    with db() as conn:
        for item in ports:
            port = str(item.get("port") or "").strip()
            if not port:
                continue
            admin = str(item.get("admin_state") or "unknown")
            link = str(item.get("link_state") or "unknown")
            alias = str(item.get("alias") or "")
            existing = conn.execute(
                "SELECT * FROM port_state_cache WHERE device_id = ? AND port = ?",
                (device_id, port),
            ).fetchone()
            if not existing:
                link_changed = now_text if link != "unknown" else None
                admin_changed = now_text if admin != "unknown" else None
                conn.execute(
                    """
                    INSERT INTO port_state_cache(
                        device_id, port, admin_state, link_state, alias, first_seen_at,
                        last_seen_at, link_changed_at, admin_changed_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (device_id, port, admin, link, alias, now_text, now_text, link_changed, admin_changed),
                )
                first_seen = now_text
            else:
                previous_link = str(existing["link_state"] or "unknown")
                previous_admin = str(existing["admin_state"] or "unknown")
                link_changed = existing["link_changed_at"]
                admin_changed = existing["admin_changed_at"]
                if link != "unknown" and link != previous_link:
                    link_changed = now_text
                if admin != "unknown" and admin != previous_admin:
                    admin_changed = now_text
                stored_link = link if link != "unknown" else previous_link
                stored_admin = admin if admin != "unknown" else previous_admin
                conn.execute(
                    """
                    UPDATE port_state_cache
                    SET admin_state = ?, link_state = ?, alias = ?, last_seen_at = ?,
                        link_changed_at = ?, admin_changed_at = ?
                    WHERE device_id = ? AND port = ?
                    """,
                    (stored_admin, stored_link, alias, now_text, link_changed, admin_changed, device_id, port),
                )
                first_seen = str(existing["first_seen_at"] or now_text)

            item["first_seen_at"] = first_seen
            item["last_seen_at"] = now_text
            item["last_link_change_at"] = str(link_changed or "")
            item["observed_link_since"] = str(link_changed or "") if link in {"up", "down"} else ""
            changed_dt = _parse_datetime(str(link_changed or ""))
            item["observed_link_seconds"] = max(0, int((now_dt - changed_dt).total_seconds())) if changed_dt and link in {"up", "down"} else None
    return ports


def summarize_ports(ports: list[dict[str, object]]) -> dict[str, int]:
    vlans = {str(vlan) for port in ports for vlan in (port.get("vlans") or [])}
    return {
        "total": len(ports),
        "link_up": sum(1 for port in ports if port.get("link_state") == "up"),
        "link_down": sum(1 for port in ports if port.get("link_state") == "down"),
        "admin_disabled": sum(1 for port in ports if port.get("admin_state") == "disabled"),
        "poe_on": sum(1 for port in ports if port.get("poe_state") == "on"),
        "vlans": len(vlans),
        "complete": sum(1 for port in ports if port.get("data_quality") == "complete"),
        "partial": sum(1 for port in ports if port.get("data_quality") == "partial"),
        "unreported": sum(1 for port in ports if port.get("data_quality") == "unreported"),
        "aliases": sum(1 for port in ports if str(port.get("alias") or "").strip()),
    }


def save_inventory_snapshot(device_id: int, payload: dict[str, object], refreshed_at: str) -> None:
    """Persist the last complete inventory response for graceful SSH failures."""
    serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    with db() as conn:
        conn.execute(
            """
            INSERT INTO port_inventory_snapshots(device_id, payload_json, refreshed_at)
            VALUES(?, ?, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                payload_json = excluded.payload_json,
                refreshed_at = excluded.refreshed_at
            """,
            (int(device_id), serialized, refreshed_at),
        )


def load_inventory_snapshot(device_id: int) -> dict[str, object] | None:
    """Return the last successful inventory payload, if one exists."""
    with db() as conn:
        row = conn.execute(
            "SELECT payload_json, refreshed_at FROM port_inventory_snapshots WHERE device_id = ?",
            (int(device_id),),
        ).fetchone()
    if not row:
        return None
    try:
        payload = json.loads(str(row["payload_json"] or "{}"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    payload["refreshed_at"] = str(payload.get("refreshed_at") or row["refreshed_at"] or "")
    return payload
