# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

"""ALE OmniSwitch CLI compatibility helpers.

The module deliberately separates *user actions* from raw CLI syntax.  AOS 6
and AOS 8 often expose the same operational concept with different syntax, and
some read-only views (notably PoE) are slot-scoped rather than port/global
commands.  Centralising those rules prevents individual Portivo features from
inventing their own command variants.
"""

from dataclasses import dataclass
import re
from typing import Iterable


AOS6 = "AOS6"
AOS8 = "AOS8"


class ALECLIError(ValueError):
    pass


@dataclass(frozen=True)
class ActionCompatibility:
    state: str
    note: str = ""
    source: str = ""


# These actions are intentionally implemented as Portivo workflows rather than
# one raw CLI string.  ALE documents PoE monitoring as a slot-qualified view.
ORCHESTRATED_ACTIONS = frozenset({"poe_global_status", "poe_port_status", "poe_status", "reload_stack_member"})

# Portivo workflows that compose multiple documented/profile actions. They are
# not raw CLI commands and therefore receive explicit compatibility handling.
PORTIVO_WORKFLOW_ACTIONS = frozenset({"interface_cycle", "poe_cycle", "check_unp", "fix_unp", "vlan_port_maintenance"})

# AOS 8 feature families that do not belong in the legacy AOS 6 command
# profile.  Keeping them out of the profile is safer than allowing a live
# switch to reject them after the user presses Execute.
AOS8_ONLY_ACTIONS = frozenset({
    "unp_users", "unp_ports", "unp_port_config", "unp_profiles",
    "unp_classification", "unp_global", "unp_port_templates",
    "unp_authentication", "unp_vlan", "unp_edge_profiles",
    "macsec_status", "vc_status", "vc_topology", "vc_consistency", "vc_vfl",
    "automatic_fabric", "spb_status", "spb_isis", "spb_adjacency",
    "service_status", "service_access", "service_sap",
})

# Documentation-backed, platform-family baseline.  Actions not listed here are
# kept available only as model/release dependent commands and are clearly
# exposed as such by the API.  This avoids claiming universal support where ALE
# documents feature/model dependencies.
DOCUMENTED_BASELINE: dict[str, set[str]] = {
    AOS8: {
        "system_info", "chassis_status", "power_supply", "temperature_status",
        "fan_status", "interface_detail_all", "interface_status_all",
        "interface_status", "interface_details", "interface_counters_all",
        "interface_errors", "interface_enable", "interface_disable",
        "interface_alias", "poe_enable", "poe_disable",
        "poe_slot_start", "poe_slot_stop", "mac_table", "arp_table",
        "lldp_neighbors", "vlan_summary", "vlan_members", "save_config",
        "running_directory", "configuration_status",
    },
    AOS6: {
        "system_info", "hardware_info", "chassis_status", "power_supply",
        "temperature_status", "fan_status", "interface_detail_all",
        "interface_status_all", "interface_status", "interface_details",
        "interface_counters_all", "interface_errors", "interface_enable",
        "interface_disable", "interface_alias",
        "mac_table", "arp_table", "lldp_neighbors",
        "vlan_summary", "vlan_members", "save_config", "running_directory",
        "configuration_status",
    },
}


def normalize_profile(profile: str) -> str:
    value = str(profile or "").strip().upper()
    if value not in {AOS6, AOS8}:
        raise ALECLIError(f"Unsupported ALE command profile: {profile!r}")
    return value


def slot_from_port(profile: str, port: str) -> str:
    profile = normalize_profile(profile)
    value = str(port or "").strip()
    parts = [part for part in value.split("/") if part != ""]
    if len(parts) < 2 or not all(part.isdigit() for part in parts):
        raise ALECLIError(f"Cannot derive a slot from port {port!r}")
    if profile == AOS8:
        # AOS 8 fixed/VC port notation is normally chassis/slot/port.  The PoE
        # command accepts the chassis/slot component (for example 1/1).
        return "/".join(parts[:-1]) if len(parts) >= 3 else parts[0]
    # AOS 6 uses slot/port notation for the classic OmniSwitch families.
    return parts[0]


def poe_status_commands(profile: str, slot: str) -> tuple[str, ...]:
    """Return documentation-backed PoE status variants in preferred order.

    Current AOS 8 hardware documentation names the view ``show lanpower slot``
    while examples on some platforms/releases show the slot directly after
    ``show lanpower``.  Portivo therefore treats both slot-qualified forms as
    documented read-only variants and learns whichever the device accepts.
    AOS 6 uses the classic ``show lanpower <slot>`` form.
    """
    profile = normalize_profile(profile)
    value = str(slot or "").strip()
    if not value or not re.fullmatch(r"\d+(?:/\d+)?", value):
        raise ALECLIError(f"Invalid PoE slot: {slot!r}")
    if profile == AOS8:
        return (f"show lanpower slot {value}", f"show lanpower {value}")
    return (f"show lanpower {value}",)


def poe_status_command(profile: str, slot: str) -> str:
    """Preferred PoE status command for previews and verification plans."""
    return poe_status_commands(profile, slot)[0]


def poe_verification_command(profile: str, port: str) -> str:
    return poe_status_command(profile, slot_from_port(profile, port))


def power_status_commands(profile: str) -> tuple[str, ...]:
    profile = normalize_profile(profile)
    # AOS 6 training material uses `show power`; AOS 8 hardware guides use
    # `show powersupply`.
    return ("show powersupply",) if profile == AOS8 else ("show power",)


def hardware_info_command(profile: str) -> str:
    profile = normalize_profile(profile)
    return "show hardware-info" if profile == AOS8 else "show hardware info"


def action_support(profile: str, action: str, configured_actions: Iterable[str] = ()) -> ActionCompatibility:
    profile = normalize_profile(profile)
    action = str(action or "").strip()
    configured = set(configured_actions)
    if action == "reload_stack_member":
        return ActionCompatibility(
            "orchestrated",
            "Portivo maps the selected physical stack member to the AOS-family reload syntax and requires explicit confirmation.",
            "ALE OmniSwitch stack reload command family",
        )
    if action in ORCHESTRATED_ACTIONS:
        return ActionCompatibility(
            "orchestrated",
            "Portivo uses ALE's slot-qualified PoE status command and extracts the requested scope.",
            "ALE OmniSwitch PoE documentation",
        )
    if action == "interface_cycle":
        required = {"interface_disable", "interface_enable"}
        if required.issubset(configured):
            return ActionCompatibility(
                "orchestrated",
                "Portivo composes the family-specific interface disable/enable commands with a controlled delay.",
                "Portivo ALE command profile",
            )
        return ActionCompatibility("unsupported", "Required interface control actions are unavailable", "Portivo ALE profile")
    if action == "poe_cycle":
        required = {"poe_disable", "poe_enable"}
        if required.issubset(configured):
            return ActionCompatibility(
                "orchestrated",
                "Portivo composes the AOS-family PoE control commands and verifies with a slot-scoped PoE readback.",
                "ALE PoE command family",
            )
        return ActionCompatibility("unsupported", "Required PoE control actions are unavailable", "Portivo ALE profile")
    if action in {"check_unp", "fix_unp"}:
        if profile == AOS8:
            return ActionCompatibility(
                "orchestrated",
                "AOS8-only UNP workflow using documented UNP operational data.",
                "ALE AOS8 UNP command family",
            )
        return ActionCompatibility("unsupported", "UNP workflows are AOS8-only", "ALE AOS family separation")
    if action == "vlan_port_maintenance":
        required = {"vlan_members", "linkagg_ports", "lldp_neighbors", "mac_table", "interface_disable", "interface_enable"}
        if required.issubset(configured):
            return ActionCompatibility(
                "orchestrated",
                "Portivo discovers target-VLAN access ports and applies mandatory uplink safeguards before transient port maintenance.",
                "ALE VLAN/LLDP/LAG/MAC operational views + Portivo safety policy",
            )
        return ActionCompatibility("unsupported", "Required VLAN/uplink safety views are unavailable", "Portivo ALE profile")
    if profile == AOS6 and action in AOS8_ONLY_ACTIONS:
        return ActionCompatibility("unsupported", "AOS 8 feature family", "ALE AOS family separation")
    if action not in configured:
        return ActionCompatibility("unsupported", "Not configured for this AOS family", "Portivo ALE profile")
    if action in DOCUMENTED_BASELINE.get(profile, set()):
        return ActionCompatibility("documented", "Documentation-backed family baseline", "ALE OmniSwitch documentation")
    return ActionCompatibility(
        "model_dependent",
        "Command availability can depend on OmniSwitch model, licenses and AOS release.",
        "ALE CLI / feature specifications",
    )
