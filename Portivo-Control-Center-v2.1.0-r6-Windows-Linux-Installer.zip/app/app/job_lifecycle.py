# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from typing import Any

from .db import db, utc_now

TERMINAL_JOB_STATUSES = {"completed", "partial", "failed", "cancelled", "interrupted"}
ACTIVE_JOB_STATUSES = {"queued", "running", "cancelling"}


def _counts(conn, job_id: int) -> tuple[int, int, int, int]:
    rows = conn.execute("SELECT status, COUNT(*) AS count FROM job_items WHERE job_id=? GROUP BY status", (job_id,)).fetchall()
    counts = {str(row["status"]): int(row["count"]) for row in rows}
    success = counts.get("success", 0) + counts.get("partial", 0)
    failure = counts.get("failed", 0)
    interrupted = counts.get("interrupted", 0)
    cancelled = counts.get("cancelled", 0)
    return success, failure, interrupted, cancelled


def reconcile_orphaned_jobs() -> list[int]:
    """Close in-memory Jobs that cannot survive a Portivo process restart.

    BackgroundTasks and worker threads are process-local. Any persisted queued,
    running or cancelling Job found during startup belongs to the previous
    process and must never continue to claim that it is live.
    """
    now = utc_now()
    reason = "Execution was interrupted because Portivo restarted before this Job completed. Automatic resume is disabled for network safety."
    reconciled: list[int] = []
    with db() as conn:
        jobs = conn.execute(
            "SELECT id, status FROM jobs WHERE status IN ('queued','running','cancelling') AND removed_at IS NULL ORDER BY id"
        ).fetchall()
        for row in jobs:
            job_id = int(row["id"])
            previous = str(row["status"] or "")
            conn.execute(
                """
                UPDATE job_items
                SET status='interrupted',
                    error=CASE WHEN COALESCE(error,'')='' THEN ? ELSE error || '\n' || ? END,
                    finished_at=COALESCE(finished_at, ?)
                WHERE job_id=? AND status IN ('queued','running')
                """,
                (reason, reason, now, job_id),
            )
            success, failure, interrupted, cancelled = _counts(conn, job_id)
            conn.execute(
                """
                UPDATE jobs
                SET status='interrupted', success_count=?, failure_count=?, interrupted_count=?, cancelled_count=?,
                    finished_at=?, heartbeat_at=?, interrupted_reason=?, cancel_requested=0
                WHERE id=?
                """,
                (success, failure, interrupted, cancelled, now, now, reason, job_id),
            )
            conn.execute(
                """INSERT INTO audit_log(actor,event,object_type,object_id,details_json,created_at)
                   VALUES('system','job_interrupted_on_startup','job',?,json_object('previous_status',?,'reason',?),?)""",
                (str(job_id), previous, reason, now),
            )
            conn.execute(
                "UPDATE automation_schedules SET last_status='interrupted', last_error=?, updated_at=? WHERE last_job_id=?",
                (reason, now, job_id),
            )
            conn.execute(
                "UPDATE unp_schedules SET last_status='interrupted', last_error=?, updated_at=? WHERE last_job_id=?",
                (reason, now, job_id),
            )
            reconciled.append(job_id)
    return reconciled


def job_cancel_requested(job_id: int) -> bool:
    with db() as conn:
        row = conn.execute("SELECT cancel_requested, status FROM jobs WHERE id=?", (int(job_id),)).fetchone()
    return bool(row and (int(row["cancel_requested"] or 0) or str(row["status"] or "") in {"cancelling", "cancelled"}))


def item_job_cancel_requested(item_id: int) -> bool:
    with db() as conn:
        row = conn.execute(
            "SELECT j.cancel_requested, j.status FROM job_items ji JOIN jobs j ON j.id=ji.job_id WHERE ji.id=?",
            (int(item_id),),
        ).fetchone()
    return bool(row and (int(row["cancel_requested"] or 0) or str(row["status"] or "") in {"cancelling", "cancelled"}))


def mark_runtime_interrupted(job_id: int, reason: str) -> None:
    now = utc_now()
    clean_reason = str(reason or "Job worker stopped unexpectedly")[:1000]
    with db() as conn:
        row = conn.execute("SELECT status FROM jobs WHERE id=?", (int(job_id),)).fetchone()
        if not row or str(row["status"] or "") in TERMINAL_JOB_STATUSES:
            return
        conn.execute(
            """UPDATE job_items SET status='interrupted',
               error=CASE WHEN COALESCE(error,'')='' THEN ? ELSE error || '\n' || ? END,
               finished_at=COALESCE(finished_at,?)
               WHERE job_id=? AND status IN ('queued','running')""",
            (clean_reason, clean_reason, now, int(job_id)),
        )
        success, failure, interrupted, cancelled = _counts(conn, int(job_id))
        conn.execute(
            """UPDATE jobs SET status='interrupted', success_count=?, failure_count=?, interrupted_count=?, cancelled_count=?,
               finished_at=?, heartbeat_at=?, interrupted_reason=? WHERE id=?""",
            (success, failure, interrupted, cancelled, now, now, clean_reason, int(job_id)),
        )
        conn.execute(
            """INSERT INTO audit_log(actor,event,object_type,object_id,details_json,created_at)
               VALUES('system','job_worker_interrupted','job',?,json_object('reason',?),?)""",
            (str(job_id), clean_reason, now),
        )
