# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any

from .db import db, utc_now
from .profiles import CONTROL_PATTERN

RUNBOOK_MAX_STEPS = 40
RUNBOOK_MAX_VARIABLES = 16
RUNBOOK_MAX_TARGETS = 500
RUNBOOK_MAX_CONCURRENCY = 16
_VARIABLE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,31}$")
_PLACEHOLDER_RE = re.compile(r"\{\{\s*([A-Za-z][A-Za-z0-9_]{0,31})\s*\}\}")

_READ_PREFIXES = (
    "show ", "show\t", "help", "who", "ping ", "traceroute ", "trace ", "display ",
)
_HIGH_RISK_RE = re.compile(
    r"(?:^|\s)(?:reload|reboot|boot|erase|delete|format|factory[- ]?reset|clear\s+configuration|"
    r"write\s+erase|copy\s+working\s+certified|copy\s+certified\s+working)(?:\s|$)", re.I,
)


def classify_command(command: str) -> str:
    value = " ".join(str(command or "").strip().split())
    lowered = value.lower()
    if not value:
        return "read"
    if _HIGH_RISK_RE.search(value):
        return "high"
    if lowered.startswith(_READ_PREFIXES) or lowered in {"show", "help", "who"}:
        return "read"
    return "change"


def classify_steps(steps: list[dict[str, Any]]) -> str:
    rank = {"read": 0, "change": 1, "high": 2}
    risk = "read"
    for step in steps:
        if str(step.get("type") or "command") == "wait":
            continue
        current = classify_command(str(step.get("command") or ""))
        if rank[current] > rank[risk]:
            risk = current
    return risk


def normalize_variables(values: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in values or []:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or "").strip()
        if not _VARIABLE_RE.fullmatch(name):
            raise ValueError("Runbook variable names must start with a letter and contain only letters, numbers or underscore")
        key = name.casefold()
        if key in seen:
            raise ValueError(f"Duplicate runbook variable: {name}")
        seen.add(key)
        label = str(raw.get("label") or name).strip()[:80]
        default = str(raw.get("default") or "")[:200]
        result.append({"name": name, "label": label or name, "default": default, "required": bool(raw.get("required", True))})
    if len(result) > RUNBOOK_MAX_VARIABLES:
        raise ValueError(f"Runbooks support at most {RUNBOOK_MAX_VARIABLES} variables")
    return result


def normalize_steps(values: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index, raw in enumerate(values or [], start=1):
        if not isinstance(raw, dict):
            continue
        step_type = str(raw.get("type") or "command").strip().lower()
        if step_type not in {"command", "wait", "verify"}:
            raise ValueError(f"Unsupported runbook step type at step {index}")
        if step_type == "wait":
            try:
                seconds = int(raw.get("seconds") or 1)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid wait duration at step {index}") from exc
            if seconds < 1 or seconds > 300:
                raise ValueError("Runbook waits must be between 1 and 300 seconds")
            result.append({"type": "wait", "seconds": seconds})
            continue
        command = str(raw.get("command") or "").strip()
        if not command:
            raise ValueError(f"Command is required at step {index}")
        if len(command) > 400:
            raise ValueError("Runbook commands must be 400 characters or fewer")
        if "\n" in command or "\r" in command or CONTROL_PATTERN.search(command):
            raise ValueError("Each runbook command must be a single CLI line without control characters")
        if step_type == "verify" and classify_command(command) != "read":
            raise ValueError("VERIFY steps must use a read-only command")
        result.append({"type": step_type, "command": command})
    if not result:
        raise ValueError("A runbook requires at least one step")
    if len(result) > RUNBOOK_MAX_STEPS:
        raise ValueError(f"Runbooks support at most {RUNBOOK_MAX_STEPS} steps")
    return result


def normalize_runbook_payload(payload: dict[str, Any]) -> dict[str, Any]:
    name = str(payload.get("name") or "").strip()
    if not name:
        raise ValueError("Runbook name is required")
    if len(name) > 120:
        raise ValueError("Runbook name is too long")
    description = str(payload.get("description") or "").strip()[:1000]
    steps = normalize_steps(payload.get("steps") if isinstance(payload.get("steps"), list) else [])
    variables = normalize_variables(payload.get("variables") if isinstance(payload.get("variables"), list) else [])
    declared = {item["name"] for item in variables}
    used: set[str] = set()
    for step in steps:
        if step["type"] != "wait":
            used.update(_PLACEHOLDER_RE.findall(step["command"]))
    unknown = sorted(used - declared)
    if unknown:
        raise ValueError(f"Undeclared runbook variable(s): {', '.join(unknown)}")
    max_targets = int(payload.get("max_targets") or 50)
    concurrency = int(payload.get("concurrency") or 5)
    if max_targets < 1 or max_targets > RUNBOOK_MAX_TARGETS:
        raise ValueError(f"Maximum targets must be between 1 and {RUNBOOK_MAX_TARGETS}")
    if concurrency < 1 or concurrency > RUNBOOK_MAX_CONCURRENCY:
        raise ValueError(f"Concurrency must be between 1 and {RUNBOOK_MAX_CONCURRENCY}")
    failure_policy = str(payload.get("failure_policy") or "continue").strip().lower()
    if failure_policy not in {"continue", "stop_all"}:
        raise ValueError("Invalid runbook failure policy")
    return {
        "name": name,
        "description": description,
        "steps": steps,
        "variables": variables,
        "allow_scheduled": bool(payload.get("allow_scheduled", False)),
        "max_targets": max_targets,
        "concurrency": concurrency,
        "failure_policy": failure_policy,
        "risk": classify_steps(steps),
    }


def _decode_json(value: str | None, fallback: Any) -> Any:
    try:
        parsed = json.loads(value or "")
    except (TypeError, ValueError, json.JSONDecodeError):
        return deepcopy(fallback)
    return parsed


def _row(row: Any) -> dict[str, Any]:
    item = {key: row[key] for key in row.keys()}
    item["steps"] = _decode_json(item.pop("steps_json", "[]"), [])
    item["variables"] = _decode_json(item.pop("variables_json", "[]"), [])
    item["allow_scheduled"] = bool(item.get("allow_scheduled"))
    return item


def get_runbook(runbook_id: int) -> dict[str, Any] | None:
    with db() as conn:
        row = conn.execute("SELECT * FROM runbooks WHERE id = ?", (int(runbook_id),)).fetchone()
    return _row(row) if row else None


def list_runbooks(*, include_drafts: bool = False) -> list[dict[str, Any]]:
    query = "SELECT * FROM runbooks"
    params: tuple[Any, ...] = ()
    if not include_drafts:
        query += " WHERE status = 'approved'"
    query += " ORDER BY CASE status WHEN 'approved' THEN 0 ELSE 1 END, name COLLATE NOCASE"
    with db() as conn:
        rows = conn.execute(query, params).fetchall()
    return [_row(row) for row in rows]


def save_runbook(payload: dict[str, Any], actor: str, runbook_id: int | None = None) -> dict[str, Any]:
    normalized = normalize_runbook_payload(payload)
    now = utc_now()
    with db() as conn:
        if runbook_id:
            existing = conn.execute("SELECT id FROM runbooks WHERE id = ?", (int(runbook_id),)).fetchone()
            if not existing:
                raise LookupError("Runbook not found")
            conn.execute(
                """
                UPDATE runbooks SET name=?, description=?, status='draft', allow_scheduled=?, max_targets=?,
                    concurrency=?, failure_policy=?, risk=?, steps_json=?, variables_json=?, approved_by=NULL,
                    approved_at=NULL, updated_at=?, updated_by=? WHERE id=?
                """,
                (
                    normalized["name"], normalized["description"], int(normalized["allow_scheduled"]),
                    normalized["max_targets"], normalized["concurrency"], normalized["failure_policy"],
                    normalized["risk"], json.dumps(normalized["steps"], ensure_ascii=False),
                    json.dumps(normalized["variables"], ensure_ascii=False), now, actor, int(runbook_id),
                ),
            )
            rid = int(runbook_id)
        else:
            cursor = conn.execute(
                """
                INSERT INTO runbooks(name, description, status, allow_scheduled, max_targets, concurrency,
                    failure_policy, risk, steps_json, variables_json, created_at, created_by, updated_at, updated_by)
                VALUES(?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    normalized["name"], normalized["description"], int(normalized["allow_scheduled"]),
                    normalized["max_targets"], normalized["concurrency"], normalized["failure_policy"],
                    normalized["risk"], json.dumps(normalized["steps"], ensure_ascii=False),
                    json.dumps(normalized["variables"], ensure_ascii=False), now, actor, now, actor,
                ),
            )
            rid = int(cursor.lastrowid)
    item = get_runbook(rid)
    if not item:
        raise RuntimeError("Unable to reload saved runbook")
    return item


def approve_runbook(runbook_id: int, actor: str) -> dict[str, Any]:
    now = utc_now()
    with db() as conn:
        cursor = conn.execute(
            "UPDATE runbooks SET status='approved', approved_by=?, approved_at=?, updated_at=?, updated_by=? WHERE id=?",
            (actor, now, now, actor, int(runbook_id)),
        )
    if not cursor.rowcount:
        raise LookupError("Runbook not found")
    item = get_runbook(runbook_id)
    if not item:
        raise LookupError("Runbook not found")
    return item


def delete_runbook(runbook_id: int) -> None:
    with db() as conn:
        schedules = conn.execute("SELECT settings_json FROM automation_schedules WHERE action='custom_runbook'").fetchall()
        for schedule in schedules:
            settings = _decode_json(schedule["settings_json"], {})
            if isinstance(settings, dict) and int(settings.get("runbook_id") or 0) == int(runbook_id):
                raise ValueError("Runbook is used by an automation schedule. Remove or change the schedule first.")
        cursor = conn.execute("DELETE FROM runbooks WHERE id = ?", (int(runbook_id),))
    if not cursor.rowcount:
        raise LookupError("Runbook not found")


def validate_variable_values(runbook: dict[str, Any], values: dict[str, Any] | None) -> dict[str, str]:
    incoming = values if isinstance(values, dict) else {}
    result: dict[str, str] = {}
    for spec in runbook.get("variables") or []:
        name = str(spec.get("name") or "")
        raw = incoming.get(name, spec.get("default", ""))
        value = str(raw if raw is not None else "")
        if len(value) > 200 or "\n" in value or "\r" in value or CONTROL_PATTERN.search(value):
            raise ValueError(f"Invalid value for variable {name}")
        if any(token in value for token in (";", "`", "&&", "||")):
            raise ValueError(f"Variable {name} contains a command separator that is not allowed")
        if bool(spec.get("required", True)) and not value.strip():
            raise ValueError(f"Variable {name} is required")
        result[name] = value
    return result


def render_runbook(runbook: dict[str, Any], variable_values: dict[str, Any] | None = None) -> dict[str, Any]:
    values = validate_variable_values(runbook, variable_values)

    def replace(text: str) -> str:
        def repl(match: re.Match[str]) -> str:
            name = match.group(1)
            if name not in values:
                raise ValueError(f"Variable {name} is not defined")
            return values[name]
        rendered = _PLACEHOLDER_RE.sub(repl, text)
        if _PLACEHOLDER_RE.search(rendered):
            raise ValueError("Unresolved runbook variable")
        return rendered

    steps: list[dict[str, Any]] = []
    for step in runbook.get("steps") or []:
        if step.get("type") == "wait":
            steps.append({"type": "wait", "seconds": int(step.get("seconds") or 1)})
        else:
            command = replace(str(step.get("command") or ""))
            if "\n" in command or "\r" in command or CONTROL_PATTERN.search(command):
                raise ValueError("Rendered runbook command contains unsupported control characters")
            if len(command) > 800:
                raise ValueError("Rendered runbook command is too long")
            step_type = str(step.get("type") or "command")
            rendered_risk = classify_command(command)
            if step_type == "verify" and rendered_risk != "read":
                raise ValueError("VERIFY steps must remain read-only after variable substitution")
            steps.append({"type": step_type, "command": command, "risk": rendered_risk})
    rank = {"read": 0, "change": 1, "high": 2}
    stored_risk = str(runbook.get("risk") or "read")
    rendered_risk = classify_steps(steps)
    effective_risk = rendered_risk if rank.get(rendered_risk, 0) > rank.get(stored_risk, 0) else stored_risk
    snapshot = {
        "id": int(runbook["id"]), "name": str(runbook.get("name") or ""),
        "description": str(runbook.get("description") or ""), "status": str(runbook.get("status") or "draft"),
        "risk": effective_risk, "allow_scheduled": bool(runbook.get("allow_scheduled")),
        "max_targets": int(runbook.get("max_targets") or 50), "concurrency": int(runbook.get("concurrency") or 5),
        "failure_policy": str(runbook.get("failure_policy") or "continue"), "steps": steps, "variables": values,
        "approved_by": runbook.get("approved_by"), "approved_at": runbook.get("approved_at"),
    }
    return snapshot


def format_runbook_plan(snapshot: dict[str, Any]) -> str:
    lines = [
        f"RUNBOOK: {snapshot.get('name') or 'Custom Runbook'}",
        f"Risk: {str(snapshot.get('risk') or 'read').upper()}",
        f"Failure policy: {'Stop remaining switches' if snapshot.get('failure_policy') == 'stop_all' else 'Stop this switch and continue'}",
        f"Concurrency: {int(snapshot.get('concurrency') or 1)} switch(es)",
        "",
        "STEPS:",
    ]
    for index, step in enumerate(snapshot.get("steps") or [], start=1):
        if step.get("type") == "wait":
            lines.append(f"{index:02d}. WAIT {int(step.get('seconds') or 1)} seconds")
        elif step.get("type") == "verify":
            lines.append(f"{index:02d}. VERIFY  {step.get('command')}")
        else:
            lines.append(f"{index:02d}. COMMAND {step.get('command')}")
    return "\n".join(lines)
