# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from dataclasses import asdict, dataclass

from .vendor_drivers import registry


@dataclass(frozen=True)
class DeviceIdentity:
    model: str = ""
    aos_version: str = ""
    system_name: str = ""
    description: str = ""
    detected_profile: str = ""
    vendor: str = ""
    os_family: str = ""
    driver_key: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def parse_show_system(output: str, profile_hint: str = "") -> DeviceIdentity:
    """Parse switch identity through the registered vendor-driver layer.

    The legacy function name is retained so existing AOS callers remain stable
    while the core no longer owns vendor-specific identity regular expressions.
    """
    identity = registry.detect_identity(output, profile_hint=profile_hint)
    if identity is None:
        return DeviceIdentity()
    return DeviceIdentity(
        model=identity.model,
        aos_version=identity.os_version,
        system_name=identity.system_name,
        description=identity.description,
        detected_profile=identity.profile,
        vendor=identity.vendor,
        os_family=identity.os_family,
        driver_key=identity.driver_key,
    )
