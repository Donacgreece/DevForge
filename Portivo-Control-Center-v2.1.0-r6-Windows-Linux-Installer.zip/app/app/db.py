# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .auth import hash_password
from .config import settings
from .password_policy import validate_password


DEFAULT_ADMIN_USERNAME = settings.admin_username.strip() or "admin"

DEFAULT_APP_SETTINGS = {
    "default_language": "en",
    "platform_timezone": "UTC",
    "monitoring_mode": "full",
    "monitoring_switch_availability": "1",
    "monitoring_stack_health": "1",
    "monitoring_power_ups": "1",
    "monitoring_incident_detection": "1",
    "ssh_users_manage_inventory": "1",
    "health_poll_interval_seconds": "30",
    "stack_poll_interval_seconds": "60",
    "ups_poll_interval_seconds": "30",
    "ups_failure_threshold": "2",
    "ups_unreachable_confirm_seconds": "30",
    "ups_power_confirm_seconds": "20",
    "ups_power_recovery_seconds": "20",
    "ups_low_charge_percent": "15",
    "ups_low_runtime_minutes": "5",
    "authentication_source_device_ids": "[]",
    "unp_fix_protected_ports": "1/1/1",
    "unp_fix_guest_keywords": "GUEST",
    "unp_fix_service_keywords": "VOIP,IPTV",
    "unp_fix_max_ports_per_switch": "12",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _connect(path: Path | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or settings.database_path), check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def _remove_legacy_shared_credentials(conn: sqlite3.Connection) -> None:
    """Purge legacy shared SSH secrets from upgraded installations.

    Switch records retain only inventory and connection metadata. Every network
    user authenticates with personal SSH credentials held only for their active
    server session.
    """
    conn.execute("UPDATE devices SET username = '', password_enc = '', credential_profile_id = NULL")
    conn.execute("DELETE FROM credential_profiles")


def _remove_non_admin_application_accounts(conn: sqlite3.Connection) -> None:
    conn.execute("DELETE FROM app_users WHERE username <> ?", (DEFAULT_ADMIN_USERNAME,))


def _seed_admin(conn: sqlite3.Connection) -> None:
    """Create the bootstrap administrator only when a password is supplied.

    Native installers create the administrator directly with
    ``scripts/set_admin_password.py`` and do not retain the clear-text password.
    ``APP_ADMIN_PASSWORD`` remains available for unattended first boot, such as
    an initial container deployment. It is ignored after the account exists.
    """
    row = conn.execute("SELECT id FROM app_users WHERE username = ?", (DEFAULT_ADMIN_USERNAME,)).fetchone()
    if row:
        return
    bootstrap_password = settings.admin_password.strip()
    if not bootstrap_password:
        return
    try:
        validate_password(bootstrap_password)
    except ValueError as exc:
        raise RuntimeError(f"APP_ADMIN_PASSWORD is invalid: {exc}") from exc
    now = utc_now()
    conn.execute(
        """
        INSERT INTO app_users(username, display_name, password_hash, role, enabled, must_change_password, created_at, updated_at)
        VALUES(?, ?, ?, 'admin', 1, 0, ?, ?)
        """,
        (
            DEFAULT_ADMIN_USERNAME,
            "Administrator",
            hash_password(bootstrap_password),
            now,
            now,
        ),
    )


def _backfill_ssh_users_from_audit(conn: sqlite3.Connection) -> None:
    rows = conn.execute(
        """
        SELECT actor, details_json, created_at
        FROM audit_log
        WHERE event = 'login'
        ORDER BY created_at ASC, id ASC
        """
    ).fetchall()
    grouped: dict[str, dict[str, object]] = {}
    for row in rows:
        try:
            details = json.loads(row["details_json"] or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            details = {}
        if str(details.get("mode") or "").lower() != "ssh":
            continue
        username = str(row["actor"] or "").strip()
        if not username:
            continue
        key = username.casefold()
        item = grouped.setdefault(
            key,
            {
                "username": username,
                "first_seen": row["created_at"],
                "last_login": row["created_at"],
                "login_count": 0,
                "last_auth_device_id": None,
                "last_auth_device_name": "",
                "last_auth_device_host": "",
            },
        )
        item["username"] = username
        item["last_login"] = row["created_at"]
        item["login_count"] = int(item["login_count"]) + 1
        item["last_auth_device_id"] = details.get("authentication_device_id")
        item["last_auth_device_name"] = str(details.get("authentication_device") or "")
    for item in grouped.values():
        existing = conn.execute(
            "SELECT id FROM ssh_user_profiles WHERE username = ? COLLATE NOCASE",
            (item["username"],),
        ).fetchone()
        if existing:
            continue
        conn.execute(
            """
            INSERT INTO ssh_user_profiles(
                username, display_name, role, enabled, first_seen, last_login, login_count,
                last_auth_device_id, last_auth_device_name, last_auth_device_host, updated_at, updated_by
            ) VALUES(?, ?, 'user', 1, ?, ?, ?, ?, ?, ?, ?, 'audit-migration')
            """,
            (
                item["username"], item["username"], item["first_seen"], item["last_login"],
                item["login_count"], item["last_auth_device_id"], item["last_auth_device_name"],
                item["last_auth_device_host"], utc_now(),
            ),
        )



def _seed_access_roles(conn: sqlite3.Connection) -> None:
    now = utc_now()
    roles = [
        ("admin", "Administrator", "Full platform, inventory and network access everywhere."),
        ("power_user", "Power User", "Full switch operations across the fleet without platform administration."),
        ("site_admin", "Site Administrator", "Full governed operational access inside assigned Sites and Groups."),
        ("operator", "Operator", "Operational troubleshooting and governed changes inside assigned scope."),
        ("helpdesk", "Helpdesk", "Scoped visibility and basic port support operations."),
        ("read_only", "Read Only", "Scoped visibility only with no command execution."),
    ]
    for key, name, description in roles:
        conn.execute(
            """
            INSERT INTO access_roles(role_key,name,description,built_in,capabilities_json,allowed_actions_json,created_at,updated_at,updated_by)
            VALUES(?,?,?,1,'[]','[]',?,?,'system')
            ON CONFLICT(role_key) DO UPDATE SET
                name=excluded.name, description=excluded.description, built_in=1
            """,
            (key, name, description, now, now),
        )


def _access_role_id(conn: sqlite3.Connection, role_key: str) -> int | None:
    row = conn.execute("SELECT id FROM access_roles WHERE role_key = ?", (role_key,)).fetchone()
    return int(row["id"]) if row else None


def _migrate_ssh_user_access(conn: sqlite3.Connection) -> None:
    """Attach legacy SSH profiles to the granular access-control model.

    Administrator and Power User are the only global presets, so existing users
    with those roles keep All Sites access. Every legacy standard user migrates
    to Read Only with no operational scope and therefore fails closed until an
    administrator explicitly assigns Selected Sites/Groups or All Sites.
    """
    rows = conn.execute("SELECT id, role, access_role_id, scope_json FROM ssh_user_profiles").fetchall()
    for row in rows:
        legacy = str(row["role"] or "user")
        role_key = "admin" if legacy == "admin" else "power_user" if legacy == "power_user" else "read_only"
        was_unmigrated = not bool(row["access_role_id"])
        role_id = int(row["access_role_id"] or 0) or (_access_role_id(conn, role_key) or 0)
        scope_raw = str(row["scope_json"] or "").strip()
        if was_unmigrated and (not scope_raw or scope_raw == '{"mode":"none","sites":[],"groups":[]}'):
            # Existing global roles stay global. Existing standard users are
            # intentionally not widened during upgrade and must be assigned a
            # scope explicitly from Access Control.
            mode = "all" if role_key in {"admin", "power_user"} else "none"
            scope_raw = json.dumps({"mode": mode, "sites": [], "groups": []}, ensure_ascii=False)
        conn.execute(
            "UPDATE ssh_user_profiles SET access_role_id=?, scope_json=? WHERE id=?",
            (role_id or None, scope_raw, int(row["id"])),
        )



def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def _migrate_legacy_notification_data(conn: sqlite3.Connection, now: str) -> None:
    """Migrate the v1.3.7 Teams-only notification model into generic webhooks.

    The legacy tables are intentionally retained for database compatibility and
    rollback safety. A durable app-setting marker makes this strictly one-time
    so later v1.3.8 policy changes are never overwritten on restart.
    """
    marker = conn.execute("SELECT value FROM app_settings WHERE name = 'notification_model_migrated_v138'").fetchone()
    if marker and str(marker["value"] or "") == "1":
        return
    if not _table_exists(conn, "teams_notification_config"):
        conn.execute(
            "INSERT OR REPLACE INTO app_settings(name,value,updated_at,updated_by) VALUES('notification_model_migrated_v138','1',?,'system')",
            (now,),
        )
        return
    legacy = conn.execute("SELECT * FROM teams_notification_config WHERE id = 1").fetchone()
    if not legacy:
        return
    destination_count = int(conn.execute("SELECT COUNT(*) AS count FROM notification_destinations").fetchone()["count"])
    incident_count = int(conn.execute("SELECT COUNT(*) AS count FROM notification_incidents").fetchone()["count"])
    outbox_count = int(conn.execute("SELECT COUNT(*) AS count FROM notification_outbox").fetchone()["count"])
    if destination_count == 0 and str(legacy["webhook_url_enc"] or ""):
        cursor = conn.execute(
            """
            INSERT INTO notification_destinations(
                name, provider, enabled, webhook_url_enc, last_test_at, last_test_status,
                last_delivery_at, last_delivery_status, last_error, created_at, updated_at, updated_by
            ) VALUES(?, 'microsoft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "Microsoft Teams / Power Automate",
                1 if bool(legacy["enabled"]) else 0,
                str(legacy["webhook_url_enc"] or ""), legacy["last_test_at"],
                str(legacy["last_test_status"] or "never"), legacy["last_delivery_at"],
                str(legacy["last_delivery_status"] or "never"), str(legacy["last_error"] or ""),
                str(legacy["updated_at"] or now), now, str(legacy["updated_by"] or "system"),
            ),
        )
        migrated_destination_id = int(cursor.lastrowid)
    else:
        row = conn.execute("SELECT id FROM notification_destinations ORDER BY id LIMIT 1").fetchone()
        migrated_destination_id = int(row["id"]) if row else None

    conn.execute(
        """
        UPDATE notification_policy SET enabled = ?, scope_mode = ?, sites_json = ?, groups_json = ?,
            notify_offline = ?, notify_recovery = ?, failure_threshold = ?, reminder_minutes = ?,
            updated_at = ?, updated_by = ? WHERE id = 1
        """,
        (
            1 if bool(legacy["enabled"]) else 0, str(legacy["scope_mode"] or "all"),
            str(legacy["sites_json"] or "[]"), str(legacy["groups_json"] or "[]"),
            1 if bool(legacy["notify_offline"]) else 0, 1 if bool(legacy["notify_recovery"]) else 0,
            int(legacy["failure_threshold"] or 3), int(legacy["reminder_minutes"] or 0),
            now, str(legacy["updated_by"] or "system"),
        ),
    )

    if incident_count == 0 and _table_exists(conn, "teams_health_incidents"):
        conn.execute(
            """
            INSERT OR IGNORE INTO notification_incidents(
                id, device_id, device_name, opened_at, confirmed_at, recovered_at, status,
                failure_threshold, last_reachable, first_delivery_at, last_reminder_at, created_at, updated_at
            )
            SELECT id, device_id, device_name, opened_at, confirmed_at, recovered_at, status,
                   failure_threshold, last_reachable, offline_delivered_at, last_reminder_at, created_at, updated_at
            FROM teams_health_incidents
            """
        )
    if outbox_count == 0 and _table_exists(conn, "teams_notification_outbox"):
        conn.execute(
            """
            INSERT OR IGNORE INTO notification_outbox(
                event_id, event_type, incident_id, destination_id, device_id, device_name, severity,
                payload_json, status, attempts, next_attempt_at, last_attempt_at, delivered_at,
                http_status, last_error, created_at
            )
            SELECT event_id, event_type, incident_id, ?, device_id, device_name, severity,
                   payload_json, status, attempts, next_attempt_at, last_attempt_at, delivered_at,
                   http_status, last_error, created_at
            FROM teams_notification_outbox
            """,
            (migrated_destination_id,),
        )
    conn.execute(
        "INSERT OR REPLACE INTO app_settings(name,value,updated_at,updated_by) VALUES('notification_model_migrated_v138','1',?,'system')",
        (now,),
    )


def _migrate_destination_routing_v140(conn: sqlite3.Connection, now: str) -> None:
    """Move the former global routing scope/event choices onto each webhook destination.

    The migration is intentionally one-shot so an upgrade preserves v1.3.x behavior:
    every existing destination initially receives the same routing rules that were
    previously global. New edits are independent per destination.
    """
    marker = conn.execute("SELECT value FROM app_settings WHERE name='notification_destination_routing_migrated_v140'").fetchone()
    if marker:
        return
    policy = conn.execute("SELECT * FROM notification_policy WHERE id=1").fetchone()
    if policy:
        conn.execute(
            """
            UPDATE notification_destinations
            SET scope_mode=?, sites_json=?, groups_json=?, notify_offline=?, notify_recovery=?, notify_reminder=1,
                updated_at=COALESCE(updated_at, ?)
            """,
            (
                str(policy["scope_mode"] or "all"), str(policy["sites_json"] or "[]"), str(policy["groups_json"] or "[]"),
                int(policy["notify_offline"] or 0), int(policy["notify_recovery"] or 0), now,
            ),
        )
    conn.execute(
        "INSERT OR REPLACE INTO app_settings(name,value,updated_at,updated_by) VALUES('notification_destination_routing_migrated_v140','1',?,'system')",
        (now,),
    )



def _migrate_unp_schedules_to_automation(conn: sqlite3.Connection, now: str) -> None:
    """Copy legacy UNP schedules into the generic automation schedule store once.

    The legacy table is intentionally retained so an older cached client or a
    rollback package does not encounter a missing table. New scheduler reads and
    writes use ``automation_schedules``.
    """
    existing = int(conn.execute("SELECT COUNT(*) AS count FROM automation_schedules").fetchone()["count"])
    if existing:
        return
    rows = conn.execute("SELECT * FROM unp_schedules ORDER BY id").fetchall()
    for row in rows:
        settings_json = json.dumps({"cycle_delay_seconds": int(row["cycle_delay_seconds"] or 5)}, ensure_ascii=False)
        conn.execute(
            """
            INSERT INTO automation_schedules(
                id, name, enabled, action, run_time, timezone, sites_json, groups_json, settings_json,
                last_run_local_date, last_run_at, last_job_id, last_status, last_error,
                created_at, updated_at, updated_by
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                int(row["id"]), str(row["name"]), int(row["enabled"]), str(row["action"]),
                str(row["run_time"]), str(row["timezone"]), str(row["sites_json"] or "[]"),
                str(row["groups_json"] or "[]"), settings_json, row["last_run_local_date"],
                row["last_run_at"], row["last_job_id"], str(row["last_status"] or "never"),
                str(row["last_error"] or ""), str(row["created_at"] or now),
                str(row["updated_at"] or now), str(row["updated_by"] or "system"),
            ),
        )

def init_db() -> None:
    schema = """
    CREATE TABLE IF NOT EXISTS app_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        display_name TEXT NOT NULL DEFAULT '',
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'operator' CHECK(role IN ('admin','operator')),
        enabled INTEGER NOT NULL DEFAULT 1,
        must_change_password INTEGER NOT NULL DEFAULT 0,
        last_login TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ssh_user_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL COLLATE NOCASE UNIQUE,
        display_name TEXT NOT NULL DEFAULT '',
        role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','power_user','user')),
        access_role_id INTEGER,
        scope_json TEXT NOT NULL DEFAULT '{"mode":"none","sites":[],"groups":[]}',
        enabled INTEGER NOT NULL DEFAULT 1,
        first_seen TEXT NOT NULL,
        last_login TEXT NOT NULL,
        login_count INTEGER NOT NULL DEFAULT 1,
        last_auth_device_id INTEGER,
        last_auth_device_name TEXT NOT NULL DEFAULT '',
        last_auth_device_host TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS access_roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_key TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        built_in INTEGER NOT NULL DEFAULT 0,
        capabilities_json TEXT NOT NULL DEFAULT '[]',
        allowed_actions_json TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS app_settings (
        name TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS credential_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL UNIQUE,
        password_enc TEXT NOT NULL,
        is_default INTEGER NOT NULL DEFAULT 0,
        verified_at TEXT,
        last_status TEXT NOT NULL DEFAULT 'unknown',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        host TEXT NOT NULL UNIQUE,
        ssh_port INTEGER NOT NULL DEFAULT 22,
        username TEXT NOT NULL DEFAULT '',
        password_enc TEXT NOT NULL DEFAULT '',
        credential_profile_id INTEGER,
        site TEXT NOT NULL DEFAULT '',
        group_name TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '',
        aos_version TEXT NOT NULL DEFAULT '',
        profile TEXT NOT NULL DEFAULT 'AOS8',
        enabled INTEGER NOT NULL DEFAULT 1,
        notes TEXT NOT NULL DEFAULT '',
        last_seen TEXT,
        last_checked TEXT,
        last_status TEXT NOT NULL DEFAULT 'unknown',
        status_changed_at TEXT,
        last_error TEXT NOT NULL DEFAULT '',
        response_ms INTEGER,
        consecutive_failures INTEGER NOT NULL DEFAULT 0,
        power_source_ups_id INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(credential_profile_id) REFERENCES credential_profiles(id)
    );

    CREATE TABLE IF NOT EXISTS monitoring_credential_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        method TEXT NOT NULL CHECK(method IN ('ssh','snmpv3')),
        username TEXT NOT NULL,
        ssh_password_enc TEXT NOT NULL DEFAULT '',
        snmp_port INTEGER NOT NULL DEFAULT 161,
        snmp_auth_protocol TEXT NOT NULL DEFAULT 'SHA',
        snmp_auth_password_enc TEXT NOT NULL DEFAULT '',
        snmp_priv_protocol TEXT NOT NULL DEFAULT 'AES',
        snmp_priv_password_enc TEXT NOT NULL DEFAULT '',
        verified_device_id INTEGER,
        verified_device_name TEXT NOT NULL DEFAULT '',
        verified_target_type TEXT NOT NULL DEFAULT '',
        verified_target_id INTEGER,
        verified_at TEXT,
        last_status TEXT NOT NULL DEFAULT 'unknown',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system',
        FOREIGN KEY(verified_device_id) REFERENCES devices(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        status TEXT NOT NULL,
        dry_run INTEGER NOT NULL DEFAULT 0,
        target_count INTEGER NOT NULL DEFAULT 0,
        success_count INTEGER NOT NULL DEFAULT 0,
        failure_count INTEGER NOT NULL DEFAULT 0,
        requested_by TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT,
        heartbeat_at TEXT,
        interrupted_reason TEXT NOT NULL DEFAULT '',
        retry_of_job_id INTEGER,
        cancel_requested INTEGER NOT NULL DEFAULT 0,
        cancel_requested_at TEXT,
        cancel_requested_by TEXT NOT NULL DEFAULT '',
        interrupted_count INTEGER NOT NULL DEFAULT 0,
        cancelled_count INTEGER NOT NULL DEFAULT 0,
        removed_at TEXT,
        removed_by TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS job_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        device_id INTEGER NOT NULL,
        device_name TEXT NOT NULL,
        host TEXT NOT NULL,
        port TEXT NOT NULL DEFAULT '',
        slot TEXT NOT NULL DEFAULT '',
        command TEXT NOT NULL DEFAULT '',
        verification_command TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL,
        output TEXT NOT NULL DEFAULT '',
        verification_output TEXT NOT NULL DEFAULT '',
        error TEXT NOT NULL DEFAULT '',
        started_at TEXT,
        finished_at TEXT,
        FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS port_state_cache (
        device_id INTEGER NOT NULL,
        port TEXT NOT NULL,
        admin_state TEXT NOT NULL DEFAULT 'unknown',
        link_state TEXT NOT NULL DEFAULT 'unknown',
        alias TEXT NOT NULL DEFAULT '',
        first_seen_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        link_changed_at TEXT,
        admin_changed_at TEXT,
        PRIMARY KEY(device_id, port),
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS port_inventory_snapshots (
        device_id INTEGER PRIMARY KEY,
        payload_json TEXT NOT NULL,
        refreshed_at TEXT NOT NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS device_action_capabilities (
        device_id INTEGER NOT NULL,
        profile TEXT NOT NULL,
        model TEXT NOT NULL DEFAULT '',
        aos_version TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        state TEXT NOT NULL CHECK(state IN ('supported','unsupported')),
        evidence TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        PRIMARY KEY(device_id, action),
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS scheduler_credentials (
        id INTEGER PRIMARY KEY CHECK(id = 1),
        username TEXT NOT NULL,
        password_enc TEXT NOT NULL,
        verified_device_id INTEGER,
        verified_device_name TEXT NOT NULL DEFAULT '',
        verified_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS unp_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        action TEXT NOT NULL DEFAULT 'fix_unp' CHECK(action IN ('check_unp','fix_unp')),
        run_time TEXT NOT NULL DEFAULT '06:00',
        timezone TEXT NOT NULL DEFAULT 'UTC',
        sites_json TEXT NOT NULL DEFAULT '[]',
        groups_json TEXT NOT NULL DEFAULT '[]',
        cycle_delay_seconds INTEGER NOT NULL DEFAULT 5,
        last_run_local_date TEXT,
        last_run_at TEXT,
        last_job_id INTEGER,
        last_status TEXT NOT NULL DEFAULT 'never',
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS automation_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        action TEXT NOT NULL,
        run_time TEXT NOT NULL DEFAULT '06:00',
        timezone TEXT NOT NULL DEFAULT 'UTC',
        sites_json TEXT NOT NULL DEFAULT '[]',
        groups_json TEXT NOT NULL DEFAULT '[]',
        settings_json TEXT NOT NULL DEFAULT '{}',
        last_run_local_date TEXT,
        last_run_at TEXT,
        last_job_id INTEGER,
        last_status TEXT NOT NULL DEFAULT 'never',
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS runbooks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','approved')),
        allow_scheduled INTEGER NOT NULL DEFAULT 0,
        max_targets INTEGER NOT NULL DEFAULT 50,
        concurrency INTEGER NOT NULL DEFAULT 5,
        failure_policy TEXT NOT NULL DEFAULT 'continue' CHECK(failure_policy IN ('continue','stop_all')),
        risk TEXT NOT NULL DEFAULT 'read' CHECK(risk IN ('read','change','high')),
        steps_json TEXT NOT NULL DEFAULT '[]',
        variables_json TEXT NOT NULL DEFAULT '[]',
        approved_by TEXT,
        approved_at TEXT,
        created_at TEXT NOT NULL,
        created_by TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS endpoint_last_seen (
        mac TEXT PRIMARY KEY,
        ip TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL DEFAULT '',
        hostname TEXT NOT NULL DEFAULT '',
        device_id INTEGER,
        switch_name TEXT NOT NULL DEFAULT '',
        switch_host TEXT NOT NULL DEFAULT '',
        site TEXT NOT NULL DEFAULT '',
        group_name TEXT NOT NULL DEFAULT '',
        port TEXT NOT NULL DEFAULT '',
        vlan TEXT NOT NULL DEFAULT '',
        profile_id TEXT NOT NULL DEFAULT '',
        profile_name TEXT NOT NULL DEFAULT '',
        confidence INTEGER NOT NULL DEFAULT 0,
        confidence_label TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT '',
        last_seen TEXT NOT NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE SET NULL
    );


    CREATE TABLE IF NOT EXISTS fleet_audit_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        audit_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'queued',
        target_count INTEGER NOT NULL DEFAULT 0,
        completed_count INTEGER NOT NULL DEFAULT 0,
        healthy_count INTEGER NOT NULL DEFAULT 0,
        info_count INTEGER NOT NULL DEFAULT 0,
        warning_count INTEGER NOT NULL DEFAULT 0,
        critical_count INTEGER NOT NULL DEFAULT 0,
        unavailable_count INTEGER NOT NULL DEFAULT 0,
        requested_by TEXT NOT NULL,
        scope_json TEXT NOT NULL DEFAULT '[]',
        error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        started_at TEXT,
        finished_at TEXT
    );

    CREATE TABLE IF NOT EXISTS fleet_audit_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL,
        device_id INTEGER,
        device_name TEXT NOT NULL,
        host TEXT NOT NULL,
        site TEXT NOT NULL DEFAULT '',
        group_name TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '',
        profile TEXT NOT NULL DEFAULT '',
        severity TEXT NOT NULL DEFAULT 'info',
        score INTEGER,
        summary TEXT NOT NULL DEFAULT '',
        details_json TEXT NOT NULL DEFAULT '{}',
        command_errors_json TEXT NOT NULL DEFAULT '{}',
        error TEXT NOT NULL DEFAULT '',
        finished_at TEXT NOT NULL,
        FOREIGN KEY(run_id) REFERENCES fleet_audit_runs(id) ON DELETE CASCADE,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS teams_notification_config (
        id INTEGER PRIMARY KEY CHECK(id = 1),
        enabled INTEGER NOT NULL DEFAULT 0,
        webhook_url_enc TEXT NOT NULL DEFAULT '',
        scope_mode TEXT NOT NULL DEFAULT 'all' CHECK(scope_mode IN ('all','selected')),
        sites_json TEXT NOT NULL DEFAULT '[]',
        groups_json TEXT NOT NULL DEFAULT '[]',
        notify_offline INTEGER NOT NULL DEFAULT 1,
        notify_recovery INTEGER NOT NULL DEFAULT 1,
        failure_threshold INTEGER NOT NULL DEFAULT 3,
        reminder_minutes INTEGER NOT NULL DEFAULT 0,
        last_test_at TEXT,
        last_test_status TEXT NOT NULL DEFAULT 'never',
        last_delivery_at TEXT,
        last_delivery_status TEXT NOT NULL DEFAULT 'never',
        last_error TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS teams_health_incidents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        device_name TEXT NOT NULL,
        opened_at TEXT NOT NULL,
        confirmed_at TEXT NOT NULL,
        recovered_at TEXT,
        status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
        failure_threshold INTEGER NOT NULL DEFAULT 3,
        last_reachable TEXT,
        offline_delivered_at TEXT,
        last_reminder_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS teams_notification_outbox (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL UNIQUE,
        event_type TEXT NOT NULL,
        incident_id INTEGER,
        device_id INTEGER,
        device_name TEXT NOT NULL DEFAULT '',
        severity TEXT NOT NULL DEFAULT 'info',
        payload_json TEXT NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','retrying','delivering','delivered','failed','cancelled')),
        attempts INTEGER NOT NULL DEFAULT 0,
        next_attempt_at TEXT NOT NULL,
        last_attempt_at TEXT,
        delivered_at TEXT,
        http_status INTEGER,
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(incident_id) REFERENCES teams_health_incidents(id) ON DELETE SET NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE SET NULL
    );


    CREATE TABLE IF NOT EXISTS ups_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        host TEXT NOT NULL UNIQUE,
        site TEXT NOT NULL DEFAULT '',
        group_name TEXT NOT NULL DEFAULT '',
        location TEXT NOT NULL DEFAULT '',
        monitoring_profile_id INTEGER NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        driver_mode TEXT NOT NULL DEFAULT 'auto',
        driver_key TEXT NOT NULL DEFAULT 'generic',
        sys_object_id TEXT NOT NULL DEFAULT '',
        manufacturer TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '',
        software_version TEXT NOT NULL DEFAULT '',
        reported_name TEXT NOT NULL DEFAULT '',
        last_status TEXT NOT NULL DEFAULT 'unknown',
        power_state TEXT NOT NULL DEFAULT 'unknown',
        power_event_started_at TEXT,
        output_source TEXT NOT NULL DEFAULT 'unknown',
        battery_status TEXT NOT NULL DEFAULT 'unknown',
        battery_charge_percent INTEGER,
        runtime_minutes INTEGER,
        seconds_on_battery INTEGER NOT NULL DEFAULT 0,
        load_percent INTEGER,
        alarm_count INTEGER NOT NULL DEFAULT 0,
        alarms_json TEXT NOT NULL DEFAULT '[]',
        telemetry_json TEXT NOT NULL DEFAULT '{}',
        telemetry_updated_at TEXT,
        consecutive_failures INTEGER NOT NULL DEFAULT 0,
        last_seen TEXT,
        last_checked TEXT,
        status_changed_at TEXT,
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system',
        FOREIGN KEY(monitoring_profile_id) REFERENCES monitoring_credential_profiles(id) ON DELETE RESTRICT
    );

    CREATE TABLE IF NOT EXISTS power_incidents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ups_id INTEGER NOT NULL,
        ups_name TEXT NOT NULL,
        incident_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
        opened_at TEXT NOT NULL,
        recovered_at TEXT,
        details_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(ups_id) REFERENCES ups_devices(id) ON DELETE CASCADE
    );


    CREATE TABLE IF NOT EXISTS notification_policy (
        id INTEGER PRIMARY KEY CHECK(id = 1),
        enabled INTEGER NOT NULL DEFAULT 0,
        scope_mode TEXT NOT NULL DEFAULT 'all' CHECK(scope_mode IN ('all','selected')),
        sites_json TEXT NOT NULL DEFAULT '[]',
        groups_json TEXT NOT NULL DEFAULT '[]',
        notify_offline INTEGER NOT NULL DEFAULT 1,
        notify_recovery INTEGER NOT NULL DEFAULT 1,
        failure_threshold INTEGER NOT NULL DEFAULT 3,
        reminder_minutes INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS notification_destinations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        provider TEXT NOT NULL DEFAULT 'generic' CHECK(provider IN ('microsoft','slack','discord','generic')),
        enabled INTEGER NOT NULL DEFAULT 1,
        webhook_url_enc TEXT NOT NULL DEFAULT '',
        last_test_at TEXT,
        last_test_status TEXT NOT NULL DEFAULT 'never',
        last_delivery_at TEXT,
        last_delivery_status TEXT NOT NULL DEFAULT 'never',
        last_error TEXT NOT NULL DEFAULT '',
        scope_mode TEXT NOT NULL DEFAULT 'all' CHECK(scope_mode IN ('all','selected')),
        sites_json TEXT NOT NULL DEFAULT '[]',
        groups_json TEXT NOT NULL DEFAULT '[]',
        notify_offline INTEGER NOT NULL DEFAULT 1,
        notify_recovery INTEGER NOT NULL DEFAULT 1,
        notify_reminder INTEGER NOT NULL DEFAULT 1,
        notify_stack_degraded INTEGER NOT NULL DEFAULT 1,
        notify_stack_recovery INTEGER NOT NULL DEFAULT 1,
        notify_ups_on_battery INTEGER NOT NULL DEFAULT 1,
        notify_ups_power_restored INTEGER NOT NULL DEFAULT 1,
        notify_ups_low_battery INTEGER NOT NULL DEFAULT 1,
        notify_ups_unreachable INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL DEFAULT 'system'
    );

    CREATE TABLE IF NOT EXISTS notification_incidents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        device_name TEXT NOT NULL,
        opened_at TEXT NOT NULL,
        confirmed_at TEXT NOT NULL,
        recovered_at TEXT,
        status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
        failure_threshold INTEGER NOT NULL DEFAULT 3,
        last_reachable TEXT,
        first_delivery_at TEXT,
        last_reminder_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        incident_type TEXT NOT NULL DEFAULT 'switch_offline',
        details_json TEXT NOT NULL DEFAULT '{}',
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notification_outbox (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        incident_id INTEGER,
        power_incident_id INTEGER,
        destination_id INTEGER,
        device_id INTEGER,
        device_name TEXT NOT NULL DEFAULT '',
        severity TEXT NOT NULL DEFAULT 'info',
        payload_json TEXT NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','retrying','delivering','delivered','failed','cancelled')),
        attempts INTEGER NOT NULL DEFAULT 0,
        next_attempt_at TEXT NOT NULL,
        last_attempt_at TEXT,
        delivered_at TEXT,
        http_status INTEGER,
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(incident_id) REFERENCES notification_incidents(id) ON DELETE SET NULL,
        FOREIGN KEY(destination_id) REFERENCES notification_destinations(id) ON DELETE SET NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE SET NULL,
        UNIQUE(event_id, destination_id)
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor TEXT NOT NULL,
        event TEXT NOT NULL,
        object_type TEXT NOT NULL,
        object_id TEXT NOT NULL,
        details_json TEXT NOT NULL,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pending_config_changes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        job_id INTEGER,
        job_item_id INTEGER,
        action TEXT NOT NULL,
        port TEXT NOT NULL DEFAULT '',
        slot TEXT NOT NULL DEFAULT '',
        command TEXT NOT NULL DEFAULT '',
        actor TEXT NOT NULL DEFAULT '',
        verification_status TEXT NOT NULL DEFAULT 'not_required',
        created_at TEXT NOT NULL,
        FOREIGN KEY(device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_users_role ON app_users(role);
    CREATE INDEX IF NOT EXISTS idx_ssh_users_role ON ssh_user_profiles(role);
    CREATE INDEX IF NOT EXISTS idx_access_roles_key ON access_roles(role_key);
    CREATE INDEX IF NOT EXISTS idx_ssh_users_last_login ON ssh_user_profiles(last_login DESC);
    CREATE INDEX IF NOT EXISTS idx_devices_site ON devices(site);
    CREATE INDEX IF NOT EXISTS idx_devices_group ON devices(group_name);
    CREATE INDEX IF NOT EXISTS idx_ups_site ON ups_devices(site);
    CREATE INDEX IF NOT EXISTS idx_ups_status ON ups_devices(enabled, last_status, power_state);
    CREATE INDEX IF NOT EXISTS idx_ups_monitor_profile ON ups_devices(monitoring_profile_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_power_incident_open_type ON power_incidents(ups_id, incident_type) WHERE status='open';
    CREATE INDEX IF NOT EXISTS idx_power_incidents_status ON power_incidents(status, opened_at DESC);
    CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
    CREATE INDEX IF NOT EXISTS idx_jobs_action ON jobs(action);
    CREATE INDEX IF NOT EXISTS idx_jobs_requested_by ON jobs(requested_by);
    CREATE INDEX IF NOT EXISTS idx_job_items_job ON job_items(job_id);
    CREATE INDEX IF NOT EXISTS idx_port_state_device ON port_state_cache(device_id);
    CREATE INDEX IF NOT EXISTS idx_port_state_link ON port_state_cache(device_id, link_state);
    CREATE INDEX IF NOT EXISTS idx_port_inventory_snapshot_refreshed ON port_inventory_snapshots(refreshed_at DESC);
    CREATE INDEX IF NOT EXISTS idx_endpoint_last_seen_ip ON endpoint_last_seen(ip);
    CREATE INDEX IF NOT EXISTS idx_endpoint_last_seen_username ON endpoint_last_seen(username);
    CREATE INDEX IF NOT EXISTS idx_endpoint_last_seen_hostname ON endpoint_last_seen(hostname);
    CREATE INDEX IF NOT EXISTS idx_endpoint_last_seen_last_seen ON endpoint_last_seen(last_seen DESC);
    CREATE INDEX IF NOT EXISTS idx_fleet_audit_runs_created ON fleet_audit_runs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_fleet_audit_runs_status ON fleet_audit_runs(status);
    CREATE INDEX IF NOT EXISTS idx_fleet_audit_items_run ON fleet_audit_items(run_id);
    CREATE INDEX IF NOT EXISTS idx_fleet_audit_items_severity ON fleet_audit_items(run_id, severity);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_fleet_audit_items_unique_device ON fleet_audit_items(run_id, device_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_teams_open_incident_device ON teams_health_incidents(device_id) WHERE status = 'open';
    CREATE INDEX IF NOT EXISTS idx_teams_incidents_status ON teams_health_incidents(status, opened_at DESC);
    CREATE INDEX IF NOT EXISTS idx_teams_outbox_status_next ON teams_notification_outbox(status, next_attempt_at);
    CREATE INDEX IF NOT EXISTS idx_teams_outbox_created ON teams_notification_outbox(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_teams_outbox_incident ON teams_notification_outbox(incident_id, event_type);
    CREATE INDEX IF NOT EXISTS idx_notification_incidents_status ON notification_incidents(status, opened_at DESC);
    CREATE INDEX IF NOT EXISTS idx_notification_destinations_enabled ON notification_destinations(enabled, provider);
    CREATE INDEX IF NOT EXISTS idx_notification_outbox_status_next ON notification_outbox(status, next_attempt_at);
    CREATE INDEX IF NOT EXISTS idx_notification_outbox_created ON notification_outbox(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_notification_outbox_incident ON notification_outbox(incident_id, event_type);
    CREATE INDEX IF NOT EXISTS idx_notification_outbox_destination ON notification_outbox(destination_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor);
    CREATE INDEX IF NOT EXISTS idx_audit_event ON audit_log(event);
    CREATE INDEX IF NOT EXISTS idx_audit_object_type ON audit_log(object_type);
    CREATE INDEX IF NOT EXISTS idx_unp_schedules_enabled_time ON unp_schedules(enabled, run_time);
    CREATE INDEX IF NOT EXISTS idx_automation_schedules_enabled_time ON automation_schedules(enabled, run_time);
    CREATE INDEX IF NOT EXISTS idx_runbooks_status_name ON runbooks(status, name);
    CREATE INDEX IF NOT EXISTS idx_pending_config_device ON pending_config_changes(device_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_pending_config_job ON pending_config_changes(job_id);
    CREATE INDEX IF NOT EXISTS idx_device_action_capability_state ON device_action_capabilities(device_id, state);
    """
    with db() as conn:
        conn.executescript(schema)
        _ensure_column(conn, "devices", "credential_profile_id", "INTEGER")
        _ensure_column(conn, "devices", "last_checked", "TEXT")
        _ensure_column(conn, "devices", "status_changed_at", "TEXT")
        _ensure_column(conn, "devices", "last_error", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "devices", "response_ms", "INTEGER")
        _ensure_column(conn, "devices", "consecutive_failures", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "power_source_ups_id", "INTEGER")
        _ensure_column(conn, "monitoring_credential_profiles", "verified_target_type", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "monitoring_credential_profiles", "verified_target_id", "INTEGER")
        conn.execute(
            "UPDATE monitoring_credential_profiles SET verified_target_type='switch' "
            "WHERE verified_device_id IS NOT NULL AND COALESCE(verified_target_type, '')=''"
        )
        conn.execute(
            "UPDATE monitoring_credential_profiles SET verified_target_id=verified_device_id "
            "WHERE verified_device_id IS NOT NULL AND verified_target_id IS NULL"
        )
        _ensure_column(conn, "ups_devices", "driver_mode", "TEXT NOT NULL DEFAULT 'auto'")
        _ensure_column(conn, "ups_devices", "driver_key", "TEXT NOT NULL DEFAULT 'generic'")
        _ensure_column(conn, "ups_devices", "sys_object_id", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "ups_devices", "telemetry_json", "TEXT NOT NULL DEFAULT '{}'")
        _ensure_column(conn, "ups_devices", "telemetry_updated_at", "TEXT")
        _ensure_column(conn, "jobs", "heartbeat_at", "TEXT")
        _ensure_column(conn, "jobs", "interrupted_reason", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "jobs", "retry_of_job_id", "INTEGER")
        _ensure_column(conn, "jobs", "cancel_requested", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "jobs", "cancel_requested_at", "TEXT")
        _ensure_column(conn, "jobs", "cancel_requested_by", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "jobs", "interrupted_count", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "jobs", "cancelled_count", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "jobs", "removed_at", "TEXT")
        _ensure_column(conn, "jobs", "removed_by", "TEXT NOT NULL DEFAULT ''")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_retry_of ON jobs(retry_of_job_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_removed_at ON jobs(removed_at, id DESC)")
        _ensure_column(conn, "devices", "health_probe_mode", "TEXT NOT NULL DEFAULT 'auto'")
        _ensure_column(conn, "devices", "health_monitor_profile_id", "INTEGER")
        conn.execute("UPDATE devices SET health_probe_mode='auto' WHERE LOWER(COALESCE(health_probe_mode, ''))='tcp22'")
        _ensure_column(conn, "devices", "last_health_probe_method", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "devices", "health_snmp_status", "TEXT NOT NULL DEFAULT 'unknown'")
        _ensure_column(conn, "devices", "health_snmp_checked_at", "TEXT")
        _ensure_column(conn, "devices", "health_snmp_error", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "devices", "health_snmp_response_ms", "INTEGER")
        _ensure_column(conn, "devices", "stack_monitor_enabled", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_monitor_method", "TEXT NOT NULL DEFAULT 'ssh'")
        _ensure_column(conn, "devices", "stack_monitor_profile_id", "INTEGER")
        _ensure_column(conn, "devices", "stack_baseline_member_ids_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "devices", "stack_baseline_members_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "devices", "stack_baseline_candidate_json", "TEXT NOT NULL DEFAULT '{}'")
        _ensure_column(conn, "devices", "stack_baseline_stable_checks", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_baseline_learned_at", "TEXT")
        _ensure_column(conn, "devices", "stack_expected_members", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_current_members", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_member_ids_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "devices", "stack_members_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "devices", "stack_last_checked", "TEXT")
        _ensure_column(conn, "devices", "stack_last_status", "TEXT NOT NULL DEFAULT 'unknown'")
        _ensure_column(conn, "devices", "stack_last_error", "TEXT NOT NULL DEFAULT ''")
        _ensure_column(conn, "devices", "stack_consecutive_failures", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_consecutive_healthy", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "devices", "stack_status_changed_at", "TEXT")
        _ensure_column(conn, "app_users", "must_change_password", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "ssh_user_profiles", "access_role_id", "INTEGER")
        _ensure_column(conn, "ssh_user_profiles", "scope_json", "TEXT NOT NULL DEFAULT '{\"mode\":\"none\",\"sites\":[],\"groups\":[]}'")
        _ensure_column(conn, "notification_destinations", "scope_mode", "TEXT NOT NULL DEFAULT 'all'")
        _ensure_column(conn, "notification_destinations", "sites_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "notification_destinations", "groups_json", "TEXT NOT NULL DEFAULT '[]'")
        _ensure_column(conn, "notification_destinations", "notify_offline", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_recovery", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_reminder", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_stack_degraded", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_stack_recovery", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_ups_on_battery", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_ups_power_restored", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_ups_low_battery", "INTEGER NOT NULL DEFAULT 1")
        _ensure_column(conn, "notification_destinations", "notify_ups_unreachable", "INTEGER NOT NULL DEFAULT 0")
        _ensure_column(conn, "notification_outbox", "power_incident_id", "INTEGER")
        _ensure_column(conn, "notification_incidents", "incident_type", "TEXT NOT NULL DEFAULT 'switch_offline'")
        _ensure_column(conn, "notification_incidents", "details_json", "TEXT NOT NULL DEFAULT '{}'")
        conn.execute("DROP INDEX IF EXISTS idx_notification_open_incident_device")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_notification_open_incident_device_type ON notification_incidents(device_id, incident_type) WHERE status='open'")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notification_incidents_status ON notification_incidents(status, opened_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_stack_monitor ON devices(stack_monitor_enabled, stack_last_status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_power_source ON devices(power_source_ups_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ups_site ON ups_devices(site)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ups_status ON ups_devices(enabled, last_status, power_state)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ups_monitor_profile ON ups_devices(monitoring_profile_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_power_incident_open_type ON power_incidents(ups_id, incident_type) WHERE status='open'")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_power_incidents_status ON power_incidents(status, opened_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notification_outbox_power_incident ON notification_outbox(power_incident_id, event_type)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_monitoring_profiles_method ON monitoring_credential_profiles(method, name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_health_monitor_profile ON devices(health_monitor_profile_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_stack_monitor_profile ON devices(stack_monitor_profile_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_credentials ON devices(credential_profile_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ssh_users_access_role ON ssh_user_profiles(access_role_id)")
        _seed_access_roles(conn)
        _backfill_ssh_users_from_audit(conn)
        _migrate_ssh_user_access(conn)
        _remove_legacy_shared_credentials(conn)
        _remove_non_admin_application_accounts(conn)
        _seed_admin(conn)
        now = utc_now()
        for name, value in DEFAULT_APP_SETTINGS.items():
            conn.execute(
                "INSERT OR IGNORE INTO app_settings(name, value, updated_at, updated_by) VALUES(?, ?, ?, 'system')",
                (name, value, now),
            )
        conn.execute(
            """
            INSERT OR IGNORE INTO teams_notification_config(
                id, enabled, webhook_url_enc, scope_mode, sites_json, groups_json, notify_offline,
                notify_recovery, failure_threshold, reminder_minutes, updated_at, updated_by
            ) VALUES(1, 0, '', 'all', '[]', '[]', 1, 1, 3, 0, ?, 'system')
            """,
            (now,),
        )
        conn.execute(
            """
            INSERT OR IGNORE INTO notification_policy(
                id, enabled, scope_mode, sites_json, groups_json, notify_offline,
                notify_recovery, failure_threshold, reminder_minutes, updated_at, updated_by
            ) VALUES(1, 0, 'all', '[]', '[]', 1, 1, 3, 0, ?, 'system')
            """,
            (now,),
        )
        _migrate_legacy_notification_data(conn, now)
        _migrate_destination_routing_v140(conn, now)
        _migrate_unp_schedules_to_automation(conn, now)


def get_app_setting(name: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE name = ?", (name,)).fetchone()
    return str(row["value"]) if row else default


def get_app_setting_bool(name: str, default: bool = False) -> bool:
    value = get_app_setting(name, "1" if default else "0")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def get_app_setting_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(get_app_setting(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


def update_app_settings(values: dict[str, str], actor: str) -> None:
    now = utc_now()
    with db() as conn:
        for name, value in values.items():
            conn.execute(
                """
                INSERT INTO app_settings(name, value, updated_at, updated_by)
                VALUES(?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    value = excluded.value,
                    updated_at = excluded.updated_at,
                    updated_by = excluded.updated_by
                """,
                (name, str(value), now, actor),
            )


def get_ssh_user_profile(username: str) -> dict[str, object] | None:
    normalized = username.strip()
    if not normalized:
        return None
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM ssh_user_profiles WHERE username = ? COLLATE NOCASE",
            (normalized,),
        ).fetchone()
    if not row:
        return None
    result = {key: row[key] for key in row.keys()}
    result["enabled"] = bool(result["enabled"])
    return result


def register_ssh_user_login(username: str, auth_device: dict[str, object]) -> dict[str, object]:
    normalized = username.strip()
    if not normalized:
        raise ValueError("SSH username is required")
    now = utc_now()
    with db() as conn:
        existing = conn.execute(
            "SELECT * FROM ssh_user_profiles WHERE username = ? COLLATE NOCASE",
            (normalized,),
        ).fetchone()
        if existing and not bool(existing["enabled"]):
            result = {key: existing[key] for key in existing.keys()}
            result["enabled"] = False
            return result
        if existing:
            conn.execute(
                """
                UPDATE ssh_user_profiles
                SET username = ?, last_login = ?, login_count = login_count + 1,
                    last_auth_device_id = ?, last_auth_device_name = ?, last_auth_device_host = ?,
                    updated_at = ?, updated_by = 'login'
                WHERE id = ?
                """,
                (
                    normalized, now, auth_device.get("id"), str(auth_device.get("name") or ""),
                    str(auth_device.get("host") or ""), now, int(existing["id"]),
                ),
            )
            user_id = int(existing["id"])
        else:
            read_only_role_id = _access_role_id(conn, "read_only")
            cursor = conn.execute(
                """
                INSERT INTO ssh_user_profiles(
                    username, display_name, role, access_role_id, scope_json, enabled, first_seen, last_login, login_count,
                    last_auth_device_id, last_auth_device_name, last_auth_device_host, updated_at, updated_by
                ) VALUES(?, ?, 'user', ?, ?, 1, ?, ?, 1, ?, ?, ?, ?, 'login')
                """,
                (
                    normalized, normalized, read_only_role_id,
                    json.dumps({"mode": "none", "sites": [], "groups": []}, ensure_ascii=False),
                    now, now, auth_device.get("id"), str(auth_device.get("name") or ""),
                    str(auth_device.get("host") or ""), now,
                ),
            )
            user_id = int(cursor.lastrowid)
        row = conn.execute("SELECT * FROM ssh_user_profiles WHERE id = ?", (user_id,)).fetchone()
    result = {key: row[key] for key in row.keys()}
    result["enabled"] = bool(result["enabled"])
    return result


def list_ssh_user_profiles() -> list[dict[str, object]]:
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM ssh_user_profiles ORDER BY last_login DESC, username COLLATE NOCASE"
        ).fetchall()
    result: list[dict[str, object]] = []
    for row in rows:
        item = {key: row[key] for key in row.keys()}
        item["enabled"] = bool(item["enabled"])
        result.append(item)
    return result


def update_ssh_user_profile(user_id: int, *, role: str, enabled: bool, actor: str) -> dict[str, object] | None:
    """Compatibility updater for cached v1.7 clients.

    Legacy ``user`` maps to the built-in Read Only role. Global legacy roles
    remain All Sites, while switching a user to Read Only through a cached
    client fails closed unless that profile already has an explicit scope.
    New clients use ``update_ssh_user_access``.
    """
    if role not in {"admin", "power_user", "user"}:
        raise ValueError("Unsupported SSH user role")
    role_key = "admin" if role == "admin" else "power_user" if role == "power_user" else "read_only"
    now = utc_now()
    with db() as conn:
        existing = conn.execute("SELECT id FROM ssh_user_profiles WHERE id = ?", (user_id,)).fetchone()
        if not existing:
            return None
        role_id = _access_role_id(conn, role_key)
        if role_key in {"admin", "power_user"}:
            scope_json = json.dumps({"mode": "all", "sites": [], "groups": []}, ensure_ascii=False)
        else:
            current = conn.execute("SELECT scope_json FROM ssh_user_profiles WHERE id = ?", (user_id,)).fetchone()
            existing_scope = str(current["scope_json"] or "") if current else ""
            try:
                parsed_scope = json.loads(existing_scope) if existing_scope else {}
            except (TypeError, ValueError, json.JSONDecodeError):
                parsed_scope = {}
            if str(parsed_scope.get("mode") or "none") not in {"all", "selected"}:
                parsed_scope = {"mode": "none", "sites": [], "groups": []}
            scope_json = json.dumps(parsed_scope, ensure_ascii=False)
        conn.execute(
            "UPDATE ssh_user_profiles SET role = ?, access_role_id = ?, scope_json = ?, enabled = ?, updated_at = ?, updated_by = ? WHERE id = ?",
            (role, role_id, scope_json, int(enabled), now, actor, user_id),
        )
        row = conn.execute("SELECT * FROM ssh_user_profiles WHERE id = ?", (user_id,)).fetchone()
    result = {key: row[key] for key in row.keys()}
    result["enabled"] = bool(result["enabled"])
    return result


def update_ssh_user_access(
    user_id: int, *, role_id: int, enabled: bool, scope_json: str, actor: str
) -> dict[str, object] | None:
    now = utc_now()
    with db() as conn:
        existing = conn.execute("SELECT id FROM ssh_user_profiles WHERE id = ?", (int(user_id),)).fetchone()
        if not existing:
            return None
        role_row = conn.execute("SELECT role_key, built_in FROM access_roles WHERE id = ?", (int(role_id),)).fetchone()
        if not role_row:
            raise ValueError("Access role does not exist")
        role_key = str(role_row["role_key"] or "read_only")
        legacy_role = "admin" if role_key == "admin" else "power_user" if role_key == "power_user" else "user"
        conn.execute(
            """UPDATE ssh_user_profiles
               SET role=?, access_role_id=?, scope_json=?, enabled=?, updated_at=?, updated_by=?
               WHERE id=?""",
            (legacy_role, int(role_id), str(scope_json), int(enabled), now, actor, int(user_id)),
        )
        row = conn.execute("SELECT * FROM ssh_user_profiles WHERE id = ?", (int(user_id),)).fetchone()
    result = {key: row[key] for key in row.keys()}
    result["enabled"] = bool(result["enabled"])
    return result

