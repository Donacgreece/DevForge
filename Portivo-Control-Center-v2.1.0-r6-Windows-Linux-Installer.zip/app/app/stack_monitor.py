# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any

from .db import db, get_app_setting_int, utc_now
from .monitoring_credentials import get_monitoring_profile, profile_matches_method
from .notification_engine import observe_stack_result
from .monitoring_policy import incident_detection_enabled, monitoring_service_enabled
from .profiles import render_command
from .snmp_monitor import snmpv3_stack_members
from .ssh_runner import run_commands

logger = logging.getLogger(__name__)
_STOP = threading.Event()
_WAKE = threading.Event()
_THREAD: threading.Thread | None = None
_STATUS_LOCK = threading.Lock()
_STATUS: dict[str, Any] = {
    "last_cycle_at": "",
    "last_cycle_seconds": 0.0,
    "last_checked": 0,
    "last_healthy": 0,
    "last_degraded": 0,
    "last_unavailable": 0,
    "last_learning": 0,
}

_MODEL_RE = re.compile(r"\b(?:OS|OmniSwitch)[- ]?[A-Z0-9][A-Z0-9.-]*\b", re.I)
_SERIAL_RE = re.compile(r"\b(?:serial(?:\s+number)?|serial\s*#)\s*[:=]\s*([A-Z0-9._/-]+)", re.I)
_MAC_RE = re.compile(r"\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b", re.I)
_MEMBER_PATTERNS = [
    re.compile(r"^\s*(?:chassis|member|slot)\s*[:#]?\s*(\d+)\b", re.I),
    re.compile(r"^\s*(\d+)\s+(?:\*\s*)?(?:primary|secondary|master|slave|idle|running|up|down|os\d|omniswitch)\b", re.I),
    re.compile(r"\b(?:chassis|member|slot)\s+(\d+)\b", re.I),
]
_TOPOLOGY_ROW = re.compile(
    r"^\s*(\d+)\s+(Master|Slave|Primary|Secondary|Idle)\s+(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+((?:[0-9a-f]{2}:){5}[0-9a-f]{2})\s*$",
    re.I,
)
_TOPOLOGY_UNAVAILABLE_ROW = re.compile(
    r"^\s*-\s+(Unassigned|Unknown|Idle)\s+(Not-Joined|Down|Unavailable|Failed|Offline)\s+(\d+)\s+-\s+-\s+-\s*$",
    re.I,
)


def _parse_ts(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def parse_stack_members(output: str) -> dict[str, Any]:
    """Parse ALE Virtual Chassis/chassis output conservatively.

    AOS8 `show virtual-chassis topology` is the preferred source because it
    exposes stable member IDs, roles, operational state and chassis MACs. Older
    chassis/status layouts remain supported as fail-closed fallbacks.
    """
    lines = [line.rstrip() for line in str(output or "").replace("\r", "").split("\n") if line.strip()]
    topology_members: list[dict[str, str]] = []
    for line in lines:
        match = _TOPOLOGY_ROW.match(line)
        if match:
            member_id, role, status, config_id, priority, group, mac = match.groups()
            topology_members.append({
                "id": str(int(member_id)),
                "role": role.title(),
                "status": status,
                "mac": mac.lower(),
                "model": "",
                "serial": "",
                "config_id": str(int(config_id)),
                "priority": str(int(priority)),
                "group": str(int(group)),
                "evidence": line.strip(),
            })
            continue
        unavailable = _TOPOLOGY_UNAVAILABLE_ROW.match(line)
        if unavailable:
            role, status, config_id = unavailable.groups()
            # When a chassis is rebooting or absent, AOS8 reports '-' in the
            # operational chassis column but preserves the configured chassis ID.
            # Use that configured ID as the stable logical member identity so an
            # already learned stack can be compared against its baseline.
            topology_members.append({
                "id": str(int(config_id)),
                "role": role.title(),
                "status": status,
                "mac": "",
                "model": "",
                "serial": "",
                "config_id": str(int(config_id)),
                "priority": "",
                "group": "",
                "evidence": line.strip(),
            })
    if topology_members:
        # Only operational/running members count as currently healthy. Keep all
        # rows in evidence so a visible Down member is still diagnostic.
        active = [item for item in topology_members if str(item.get("status") or "").lower() in {"running", "up", "ready", "ok"}]
        active_ids = [item["id"] for item in active]
        return {
            "count": len(active), "detected_count": len(topology_members), "members": topology_members,
            "member_ids": active_ids, "count_source": "vc_topology", "evidence": [item["evidence"] for item in topology_members[:24]],
            # Two topology rows are enough evidence even when only one is
            # operational. This is the normal AOS8 representation of a 2-member
            # stack while one member is rebooting: one Running row plus one
            # Unassigned/Not-Joined configured member row.
            "ok": len(topology_members) >= 2 and len(active) >= 1,
        }

    members: dict[str, dict[str, str]] = {}
    current_id = ""
    model_lines = 0
    evidence: list[str] = []
    for line in lines:
        member_id = ""
        for pattern in _MEMBER_PATTERNS:
            match = pattern.search(line)
            if match:
                member_id = str(int(match.group(1)))
                break
        model_match = _MODEL_RE.search(line)
        serial_match = _SERIAL_RE.search(line)
        mac_match = _MAC_RE.search(line)
        if model_match:
            model_lines += 1
        if member_id:
            current_id = member_id
            members.setdefault(member_id, {"id": member_id, "role": "", "status": "present", "mac": "", "model": "", "serial": "", "evidence": ""})
            lowered = line.lower()
            for role in ("primary", "secondary", "master", "slave", "idle"):
                if role in lowered:
                    members[member_id]["role"] = role.title()
                    break
            if "down" in lowered:
                members[member_id]["status"] = "down"
            elif "running" in lowered or " up " in f" {lowered} ":
                members[member_id]["status"] = "running"
            if line not in evidence:
                evidence.append(line.strip())
        target = current_id if current_id in members else ""
        if target:
            if model_match and not members[target]["model"]:
                members[target]["model"] = model_match.group(0)
            if serial_match and not members[target]["serial"]:
                members[target]["serial"] = serial_match.group(1)
            if mac_match and not members[target]["mac"]:
                members[target]["mac"] = mac_match.group(0).lower()
            if not members[target]["evidence"] and (model_match or serial_match or mac_match):
                members[target]["evidence"] = line.strip()
    if not members:
        for line in lines:
            model_match = _MODEL_RE.search(line)
            if not model_match:
                continue
            match = re.match(r"^\s*(\d+)\s+", line)
            if not match:
                continue
            member_id = str(int(match.group(1)))
            members[member_id] = {"id": member_id, "role": "", "status": "present", "mac": "", "model": model_match.group(0), "serial": "", "evidence": line.strip()}
            evidence.append(line.strip())
    count = len(members)
    count_source = "member_ids"
    if count == 0 and model_lines > 1:
        count = model_lines
        count_source = "model_rows"
    ordered = sorted(members.values(), key=lambda item: int(item["id"]) if item["id"].isdigit() else item["id"])
    active = [item for item in ordered if str(item.get("status") or "present").lower() != "down"]
    return {
        "count": len(active) if ordered else count,
        "detected_count": len(ordered) if ordered else count,
        "members": ordered,
        "member_ids": [item["id"] for item in active],
        "count_source": count_source if count else "unavailable",
        "evidence": evidence[:24],
        "ok": count >= 2,
    }


def _json(value: Any, default: Any) -> Any:
    try:
        parsed = json.loads(str(value or ""))
        return parsed
    except Exception:
        return default


def _due(row: Any, now: datetime) -> bool:
    interval = get_app_setting_int("stack_poll_interval_seconds", 60, 30, 3600)
    checked = _parse_ts(row["stack_last_checked"])
    return checked is None or (now - checked).total_seconds() >= interval


def _update_unavailable(device_id: int, error: str) -> None:
    with db() as conn:
        conn.execute(
            "UPDATE devices SET stack_last_checked=?, stack_last_error=? WHERE id=?",
            (utc_now(), str(error or "Stack status unavailable")[:1000], device_id),
        )


def _baseline_ids(device: dict[str, Any]) -> list[str]:
    value = _json(device.get("stack_baseline_member_ids_json"), [])
    return [str(item) for item in value] if isinstance(value, list) else []


def _learn_or_compare(device: dict[str, Any], parsed: dict[str, Any], checked_at: str) -> tuple[str, dict[str, Any]]:
    current_ids = [str(item) for item in (parsed.get("member_ids") or [])]
    current_ids = sorted(set(current_ids), key=lambda item: (0, int(item)) if item.isdigit() else (1, item))
    baseline = _baseline_ids(device)
    # Baseline learning must start from a genuinely healthy multi-member stack.
    # Once a baseline exists, however, a single active member is valid degraded
    # evidence for a 2-member stack and must not be downgraded to unavailable.
    if not baseline and len(current_ids) < 2:
        raise RuntimeError("Stack member evidence did not contain at least two active members for baseline learning")
    if baseline and len(current_ids) < 1:
        raise RuntimeError("Stack member evidence did not contain an active management member")
    if not baseline:
        candidate = _json(device.get("stack_baseline_candidate_json"), {})
        candidate_ids = [str(item) for item in candidate.get("member_ids", [])] if isinstance(candidate, dict) else []
        stable = int(device.get("stack_baseline_stable_checks") or 0)
        if candidate_ids == current_ids:
            stable += 1
        else:
            stable = 1
            candidate = {"member_ids": current_ids, "members": parsed.get("members") or []}
        learned = stable >= 3
        with db() as conn:
            conn.execute(
                """
                UPDATE devices SET stack_current_members=?,stack_member_ids_json=?,stack_members_json=?,stack_last_checked=?,
                    stack_last_error='',stack_baseline_candidate_json=?,stack_baseline_stable_checks=?,
                    stack_baseline_member_ids_json=CASE WHEN ? THEN ? ELSE stack_baseline_member_ids_json END,
                    stack_baseline_members_json=CASE WHEN ? THEN ? ELSE stack_baseline_members_json END,
                    stack_baseline_learned_at=CASE WHEN ? THEN ? ELSE stack_baseline_learned_at END,
                    stack_expected_members=CASE WHEN ? THEN ? ELSE stack_expected_members END,
                    stack_last_status=CASE WHEN ? THEN 'healthy' ELSE 'learning' END
                WHERE id=?
                """,
                (
                    len(current_ids), json.dumps(current_ids), json.dumps(parsed.get("members") or [], ensure_ascii=False), checked_at,
                    json.dumps(candidate, ensure_ascii=False), stable,
                    1 if learned else 0, json.dumps(current_ids), 1 if learned else 0, json.dumps(parsed.get("members") or [], ensure_ascii=False),
                    1 if learned else 0, checked_at, 1 if learned else 0, len(current_ids), 1 if learned else 0, int(device["id"]),
                ),
            )
        return ("healthy" if learned else "learning"), {"baseline_learned": learned, "expected": len(current_ids), "current": len(current_ids)}

    expected_set = set(baseline)
    current_set = set(current_ids)
    desired = "healthy" if current_set == expected_set else "degraded"
    return desired, {"baseline_learned": True, "expected": len(baseline), "current": len(current_ids)}


def _record_result(device: dict[str, Any], parsed: dict[str, Any], *, checked_at: str) -> str:
    desired, meta = _learn_or_compare(device, parsed, checked_at)
    if desired == "learning":
        return "learning"
    expected = int(meta["expected"])
    actual = int(meta["current"])
    previous = str(device.get("stack_last_status") or "unknown")
    failures = max(0, int(device.get("stack_consecutive_failures") or 0))
    healthy_checks = max(0, int(device.get("stack_consecutive_healthy") or 0))
    if desired == "degraded":
        failures += 1
        healthy_checks = 0
        new_status = "degraded" if failures >= 2 else previous
    else:
        failures = 0
        healthy_checks += 1
        new_status = "healthy" if healthy_checks >= (2 if previous == "degraded" else 1) else previous
    member_ids = parsed.get("member_ids") if isinstance(parsed.get("member_ids"), list) else []
    members = parsed.get("members") if isinstance(parsed.get("members"), list) else []
    changed = new_status in {"healthy", "degraded"} and new_status != previous
    with db() as conn:
        conn.execute(
            """
            UPDATE devices SET stack_current_members=?,stack_member_ids_json=?,stack_members_json=?,stack_last_checked=?,
                stack_last_status=?,stack_last_error='',stack_consecutive_failures=?,stack_consecutive_healthy=?,
                stack_status_changed_at=CASE WHEN ? THEN ? ELSE stack_status_changed_at END
            WHERE id=?
            """,
            (actual, json.dumps(member_ids), json.dumps(members, ensure_ascii=False), checked_at, new_status,
             failures, healthy_checks, 1 if changed else 0, checked_at, int(device["id"])),
        )
        row = conn.execute("SELECT * FROM devices WHERE id=?", (int(device["id"]),)).fetchone()
    updated = {key: row[key] for key in row.keys()} if row else dict(device)
    if changed and incident_detection_enabled():
        try:
            observe_stack_result(updated, checked_at=checked_at, expected_members=expected, current_members=actual, member_ids=member_ids, members=members)
        except Exception as exc:  # pragma: no cover
            logger.exception("Stack notification evaluation failed", exc_info=exc)
    return new_status if new_status in {"healthy", "degraded"} else desired


def _ssh_probe(device: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    candidate = dict(device)
    candidate.update({"username": str(profile.get("username") or ""), "password_enc": str(profile.get("ssh_password_enc") or "")})
    profile_name = str(device.get("profile") or "AOS8")
    action_order = ("vc_topology", "vc_status", "chassis_status") if profile_name == "AOS8" else ("chassis_status",)
    candidates: list[tuple[str, str]] = []
    for action_id in action_order:
        try:
            command, _ = render_command(profile_name, action_id)
        except Exception:
            continue
        if command and all(existing[1] != command for existing in candidates):
            candidates.append((action_id, command))
    if not candidates:
        raise RuntimeError("Command unsupported: no read-only stack command is available for this AOS profile")
    errors: list[str] = []
    for action_id, command in candidates:
        result = run_commands(candidate, [command], operation="stack member health", lock_timeout=4.0)
        if not result.ok:
            errors.append(f"{action_id}: {result.error or 'command failed'}")
            continue
        parsed = parse_stack_members(result.output)
        if parsed.get("ok"):
            parsed["source"] = f"SSH · {command}"
            return parsed
        errors.append(f"{action_id}: member evidence not identified")
    raise RuntimeError("Evidence unavailable: " + "; ".join(errors))


def _probe(device: dict[str, Any]) -> tuple[int, str]:
    method = str(device.get("stack_monitor_method") or "ssh").lower()
    profile_id = int(device.get("stack_monitor_profile_id") or 0)
    if not profile_id:
        _update_unavailable(int(device["id"]), f"Credentials required: select a {method.upper()} monitoring profile")
        return int(device["id"]), "unavailable"
    stored = get_monitoring_profile(profile_id, decrypt=False)
    if not profile_matches_method(stored, method):
        _update_unavailable(int(device["id"]), "Monitoring profile does not match the selected stack monitoring method")
        return int(device["id"]), "unavailable"
    try:
        if method == "ssh":
            # Need the encrypted SSH password, not the clear-text value.
            with db() as conn:
                row = conn.execute("SELECT * FROM monitoring_credential_profiles WHERE id=?", (profile_id,)).fetchone()
            profile = {key: row[key] for key in row.keys()} if row else {}
            parsed = _ssh_probe(device, profile)
        elif method == "snmpv3":
            profile = get_monitoring_profile(profile_id, decrypt=True) or {}
            parsed = snmpv3_stack_members(str(device.get("host") or ""), profile)
            parsed["source"] = "SNMPv3 · ENTITY-MIB"
        else:
            raise RuntimeError(f"Unsupported monitoring method: {method}")
        return int(device["id"]), _record_result(device, parsed, checked_at=utc_now())
    except Exception as exc:
        message = str(exc or "Stack status unavailable")
        lowered = message.lower()
        if any(token in lowered for token in ("authentication", "authorization", "unknown user", "wrongdigest", "decryption")):
            message = "Authentication failed: " + message
        _update_unavailable(int(device["id"]), message)
        return int(device["id"]), "unavailable"


def scan_due_stacks() -> dict[str, int]:
    started = time.perf_counter()
    summary = {"checked": 0, "healthy": 0, "degraded": 0, "unavailable": 0, "learning": 0}
    with db() as conn:
        rows = conn.execute(
            """SELECT * FROM devices WHERE enabled=1 AND stack_monitor_enabled=1 AND last_status='online' ORDER BY id"""
        ).fetchall()
    devices = [{key: row[key] for key in row.keys()} for row in rows]
    now = datetime.now(timezone.utc)
    due = [device for device in devices if _due(device, now)]
    if due:
        with ThreadPoolExecutor(max_workers=min(8, len(due)), thread_name_prefix="portivo-stack") as pool:
            futures = [pool.submit(_probe, device) for device in due]
            for future in as_completed(futures):
                try:
                    _, status = future.result()
                except Exception as exc:  # pragma: no cover
                    logger.exception("Stack health worker failed", exc_info=exc)
                    status = "unavailable"
                summary["checked"] += 1
                summary[status if status in summary else "unavailable"] += 1
    with _STATUS_LOCK:
        _STATUS.update({
            "last_cycle_at": utc_now(), "last_cycle_seconds": round(time.perf_counter() - started, 3),
            "last_checked": summary["checked"], "last_healthy": summary["healthy"],
            "last_degraded": summary["degraded"], "last_unavailable": summary["unavailable"],
            "last_learning": summary["learning"],
        })
    return summary


def reset_stack_baseline(device_id: int) -> None:
    with db() as conn:
        conn.execute(
            """UPDATE devices SET stack_expected_members=0,stack_current_members=0,stack_member_ids_json='[]',stack_members_json='[]',
                stack_baseline_member_ids_json='[]',stack_baseline_members_json='[]',stack_baseline_candidate_json='{}',
                stack_baseline_stable_checks=0,stack_baseline_learned_at=NULL,stack_last_status='unknown',stack_last_error='',
                stack_consecutive_failures=0,stack_consecutive_healthy=0,stack_last_checked=NULL,stack_status_changed_at=NULL WHERE id=?""",
            (int(device_id),),
        )
    request_stack_scan()


def stack_monitor_status() -> dict[str, Any]:
    with _STATUS_LOCK:
        result = dict(_STATUS)
    with db() as conn:
        configured = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE stack_monitor_enabled=1").fetchone()["c"])
        degraded = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE stack_monitor_enabled=1 AND stack_last_status='degraded'").fetchone()["c"])
        learning = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE stack_monitor_enabled=1 AND stack_last_status='learning'").fetchone()["c"])
    result.update({"enabled": monitoring_service_enabled("stack_health"), "running": bool(_THREAD and _THREAD.is_alive()),
                   "configured_stacks": configured, "degraded_stacks": degraded, "learning_stacks": learning,
                   "poll_interval_seconds": get_app_setting_int("stack_poll_interval_seconds", 60, 30, 3600),
                   "confirmation_checks": 2, "baseline_learning_checks": 3})
    return result


def request_stack_scan() -> None:
    _WAKE.set()


def _loop() -> None:
    while not _STOP.is_set():
        try:
            scan_due_stacks()
        except Exception as exc:  # pragma: no cover
            logger.exception("Stack monitor cycle failed", exc_info=exc)
        _WAKE.wait(10.0)
        _WAKE.clear()


def start_stack_monitor() -> None:
    global _THREAD
    if _THREAD and _THREAD.is_alive():
        return
    _STOP.clear(); _WAKE.clear()
    _THREAD = threading.Thread(target=_loop, name="portivo-stack-monitor", daemon=True)
    _THREAD.start()


def stop_stack_monitor() -> None:
    _STOP.set(); _WAKE.set()
    if _THREAD and _THREAD.is_alive():
        _THREAD.join(timeout=5)
