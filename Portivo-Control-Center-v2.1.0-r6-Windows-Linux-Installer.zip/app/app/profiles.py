# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any

from .config import settings
from .vendor_drivers import driver_for_profile, registered_driver_metadata
from .ale_cli import action_support, slot_from_port


class ProfileError(ValueError):
    pass


CONTROL_PATTERN = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def validate_custom_commands(value: str) -> list[str]:
    raw_lines = value.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    commands = [line.strip() for line in raw_lines if line.strip()]
    if not commands:
        raise ProfileError("A custom CLI command is required")
    if len(commands) > 12:
        raise ProfileError("Custom CLI is limited to 12 commands per job")
    for command in commands:
        if len(command) > 300:
            raise ProfileError("Each custom CLI command must be 300 characters or fewer")
        if CONTROL_PATTERN.search(command):
            raise ProfileError("Custom CLI contains unsupported control characters")
    return commands


def load_profiles() -> dict[str, Any]:
    with settings.command_profiles_path.open("r", encoding="utf-8") as handle:
        profiles = json.load(handle)
    # Every executable command profile must be backed by a registered OS driver.
    # This keeps vendor-specific transport/identity behavior out of the core and
    # makes adding another platform an explicit driver + profile operation.
    for profile_name in profiles:
        try:
            driver_for_profile(profile_name)
        except KeyError as exc:
            raise ProfileError(f"No vendor driver is registered for command profile {profile_name}") from exc
    return profiles


def public_profiles() -> dict[str, Any]:
    profiles = deepcopy(load_profiles())
    for profile_name, profile in profiles.items():
        configured = set(profile.get("commands", {}))
        configured.update(profile.get("orchestrated_actions", []))
        compatibility = {}
        for action in sorted(configured):
            support = action_support(profile_name, action, configured)
            compatibility[action] = {
                "state": support.state,
                "note": support.note,
                "source": support.source,
            }
        profile["compatibility"] = compatibility
    return profiles


def load_action_catalog() -> dict[str, Any]:
    with settings.action_catalog_path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def public_action_catalog() -> dict[str, Any]:
    return deepcopy(load_action_catalog())


def public_driver_catalog() -> list[dict[str, Any]]:
    """Return non-secret metadata for registered platform drivers."""
    return registered_driver_metadata(load_profiles())


def supported_actions() -> set[str]:
    profiles = load_profiles()
    actions: set[str] = {"interface_cycle", "poe_cycle", "check_unp", "fix_unp", "vlan_port_maintenance", "custom_command", "custom_runbook"}
    for profile in profiles.values():
        actions.update(profile.get("commands", {}).keys())
        actions.update(profile.get("orchestrated_actions", []))
    return actions


def render_command(
    profile_name: str,
    action: str,
    *,
    port: str = "",
    slot: str = "",
    alias: str = "",
) -> tuple[str, str]:
    profiles = load_profiles()
    if profile_name not in profiles:
        raise ProfileError(f"Unknown command profile: {profile_name}")
    try:
        driver = driver_for_profile(profile_name)
    except KeyError as exc:
        raise ProfileError(f"No vendor driver is registered for profile {profile_name}") from exc
    profile = profiles[profile_name]
    if action in set(profile.get("orchestrated_actions", [])):
        raise ProfileError(
            f"Action '{action}' is an ALE-aware Portivo workflow and does not map to one raw CLI command"
        )
    template = profile.get("commands", {}).get(action)
    if not template:
        raise ProfileError(f"Action '{action}' is not supported by profile {profile_name}")

    required: list[tuple[str, str]] = []
    if "{port}" in template:
        required.append(("port", port))
    if "{slot}" in template:
        required.append(("slot", slot))
    if "{alias}" in template:
        required.append(("alias", alias))
    missing = [name for name, value in required if not value.strip()]
    if missing:
        raise ProfileError(f"Missing required field(s): {', '.join(missing)}")

    try:
        safe_port = driver.normalize_port(port)
        safe_slot = driver.normalize_slot(slot)
        safe_alias = driver.normalize_alias(alias) if "{alias}" in template else ""
    except ValueError as exc:
        raise ProfileError(str(exc)) from exc
    safe_port_slot = ""
    if "{port_slot}" in template or "{port_slot}" in profile.get("verification", {}).get(action, ""):
        if not safe_port:
            raise ProfileError("Missing required field(s): port")
        try:
            safe_port_slot = slot_from_port(profile_name, safe_port)
        except ValueError as exc:
            raise ProfileError(str(exc)) from exc
    command = template.format(port=safe_port, slot=safe_slot, alias=safe_alias, port_slot=safe_port_slot)
    verify_template = profile.get("verification", {}).get(action, "")
    verification = (
        verify_template.format(port=safe_port, slot=safe_slot, alias=safe_alias, port_slot=safe_port_slot)
        if verify_template
        else ""
    )
    return command, verification


def action_risk(action: str) -> str:
    if action in {"interface_cycle", "poe_cycle", "fix_unp", "vlan_port_maintenance", "custom_command", "custom_runbook"}:
        return "change"
    metadata = load_action_catalog().get(action, {})
    return str(metadata.get("risk") or "read").strip().lower()



def save_command_for_profile(profile_name: str) -> str:
    """Return the profile-specific persistent configuration save command."""
    profiles = load_profiles()
    if profile_name not in profiles:
        raise ProfileError(f"Unknown command profile: {profile_name}")
    try:
        driver_for_profile(profile_name)
    except KeyError as exc:
        raise ProfileError(f"No vendor driver is registered for profile {profile_name}") from exc
    command = str(profiles[profile_name].get("commands", {}).get("save_config") or "").strip()
    if not command:
        raise ProfileError(f"No persistent save command is configured for profile {profile_name}")
    return command


def is_transient_change(action: str) -> bool:
    """Return True for live actions that intentionally do not create persistent configuration."""
    return action in {"interface_cycle", "poe_cycle", "fix_unp", "vlan_port_maintenance", "reload_switch", "reload_stack_member"}


def creates_pending_configuration(action: str) -> bool:
    """Return True when a successful operation changes running configuration that still needs saving."""
    if action == "save_config" or is_transient_change(action):
        return False
    return action_risk(action) != "read"


def should_auto_save(action: str) -> bool:
    """Compatibility helper retained for older callers. Portivo uses grouped manual saves."""
    return False

def is_read_only_action(action: str) -> bool:
    return action_risk(action) == "read"
