# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import ipaddress
import platform
import re
import secrets
import socket
import subprocess
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

from .config import settings
from .db import db
from .profiles import render_command
from .ssh_runner import run_command_collection

PORT_RE = re.compile(r"\b\d+(?:/\d+){1,2}\b")
MAC_RE = re.compile(
    r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}(?![0-9a-f])|"
    r"(?<![0-9a-f])(?:[0-9a-f]{4}[.:-]){2}[0-9a-f]{4}(?![0-9a-f])|"
    r"(?<![0-9a-f])[0-9a-f]{12}(?![0-9a-f])"
)
IP_RE = re.compile(
    r"(?<![0-9a-fA-F:.])(?:\d{1,3}\.){3}\d{1,3}(?![0-9])|"
    r"(?<![0-9a-fA-F:])(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?![0-9a-fA-F:])"
)
VLAN_RE = re.compile(r"(?i)\bvlan\s*[:#-]?\s*(\d{1,4})\b")

SOURCE_ORDER = {"MAC table": 0, "UNP": 1, "ARP": 2, "LLDP": 3}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_mac(value: str) -> str:
    return re.sub(r"[^0-9a-f]", "", str(value or "").lower())


def display_mac(value: str) -> str:
    normalized = normalize_mac(value)
    if len(normalized) != 12:
        return str(value or "")
    return ":".join(normalized[index:index + 2] for index in range(0, 12, 2))


def normalize_ip(value: str) -> str:
    try:
        return str(ipaddress.ip_address(str(value or "").strip()))
    except ValueError:
        return ""


def _valid_ip_matches(line: str) -> list[str]:
    values: list[str] = []
    for match in IP_RE.finditer(line):
        value = normalize_ip(match.group(0))
        if value and value not in values:
            values.append(value)
    return values


def _mac_matches(line: str) -> list[str]:
    values: list[str] = []
    for match in MAC_RE.finditer(line):
        value = normalize_mac(match.group(0))
        if len(value) == 12 and value not in values:
            values.append(value)
    return values


def _record(**values: Any) -> dict[str, Any]:
    record = {
        "port": "",
        "ip": "",
        "mac": "",
        "username": "",
        "hostname": "",
        "vlan": "",
        "profile_id": "",
        "profile_name": "",
        "profile": "",
        "status": "",
        "source": "",
        "raw": "",
    }
    record.update({key: str(value or "").strip() for key, value in values.items()})
    if record["mac"]:
        record["mac"] = normalize_mac(record["mac"])
    if record["ip"]:
        record["ip"] = normalize_ip(record["ip"]) or record["ip"]
    if not record["profile"]:
        record["profile"] = record["profile_name"]
    return record


def parse_unp_users(output: str) -> list[dict[str, Any]]:
    """Parse UNP users without treating Profile ID as a VLAN ID.

    AOS UNP output exposes a profile identifier and profile name. Those are kept
    separate from VLAN because a UNP Profile ID is not guaranteed to equal the
    VLAN used by the endpoint.
    """
    records: list[dict[str, Any]] = []
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("-") or line.lower().startswith(("show unp", "port ", "total users", "user ")):
            continue
        port_match = PORT_RE.match(line)
        macs = _mac_matches(line)
        if not port_match or not macs:
            continue
        tokens = line.split()
        ips = _valid_ip_matches(line)
        username = tokens[1] if len(tokens) > 1 and normalize_mac(tokens[1]) != macs[0] else ""
        profile_id = ""
        profile_name = ""
        status = tokens[-1] if tokens else ""
        # Common AOS layouts end with profile-id, profile-name, type, status.
        # Preserve these as profile metadata only. VLAN comes from MAC/ARP data.
        if len(tokens) >= 4:
            candidate = tokens[-4]
            if candidate.isdigit():
                profile_id = candidate
                profile_name = tokens[-3] if tokens[-3] != "-" else ""
            elif tokens[-3].isdigit():
                profile_id = tokens[-3]
        records.append(_record(
            port=port_match.group(0),
            username="" if username == "-" else username,
            mac=macs[0],
            ip=ips[0] if ips else "",
            profile_id=profile_id,
            profile_name=profile_name,
            profile=profile_name,
            status=status,
            source="UNP",
            raw=raw_line.rstrip(),
        ))
    return records


def parse_arp(output: str) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("-") or line.lower().startswith(("show arp", "ip address", "address ")):
            continue
        ips = _valid_ip_matches(line)
        macs = _mac_matches(line)
        if not ips or not macs:
            continue
        ports = PORT_RE.findall(line)
        vlan_match = VLAN_RE.search(line)
        records.append(_record(
            port=ports[-1] if ports else "",
            ip=ips[0],
            mac=macs[0],
            vlan=vlan_match.group(1) if vlan_match else "",
            status="learned",
            source="ARP",
            raw=raw_line.rstrip(),
        ))
    return records


def parse_mac_table(output: str) -> list[dict[str, Any]]:
    """Parse ALE source-learning output into normalized MAC records.

    Native OmniSwitch ``show mac-learning`` output uses rows such as::

        VLAN 100 02:00:00:00:00:01 dynamic bridging 1/1/1

    The parser also retains a conservative generic fallback for other tabular
    MAC-learning views. Header, legend and total-count lines are ignored.
    """
    records: list[dict[str, Any]] = []
    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith(("-", "+")):
            continue
        lower = line.casefold()
        if lower.startswith(("show mac", "legend:", "mac address:", "domain ", "total number of valid mac")):
            continue

        macs = _mac_matches(line)
        if not macs:
            continue

        tokens = line.replace("|", " ").split()
        normalized_mac = macs[0]
        mac_position = next((index for index, token in enumerate(tokens) if normalize_mac(token) == normalized_mac), -1)

        vlan = ""
        # Native ALE source-learning format: Domain then Vlan/SrvcId before MAC.
        if len(tokens) >= 3 and tokens[0].casefold() == "vlan" and tokens[1].isdigit():
            value = int(tokens[1])
            if 1 <= value <= 4094:
                vlan = tokens[1]
        if not vlan:
            vlan_match = VLAN_RE.search(line)
            if vlan_match:
                vlan = vlan_match.group(1)
        if not vlan:
            candidates = tokens[:mac_position] if mac_position > 0 else tokens
            for token in candidates:
                if token.isdigit() and 1 <= int(token) <= 4094:
                    vlan = token
                    break

        ports = PORT_RE.findall(line)
        records.append(_record(
            port=ports[-1] if ports else "",
            mac=normalized_mac,
            vlan=vlan,
            status="learned",
            source="MAC table",
            raw=raw_line.rstrip(),
        ))
    return records


def parse_lldp(output: str) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    current: dict[str, str] = {}

    def flush() -> None:
        nonlocal current
        if current.get("port") and any(current.get(key) for key in ("hostname", "mac", "raw")):
            records.append(_record(source="LLDP", **current))
        current = {}

    for raw_line in str(output or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("-"):
            continue
        lower = line.lower()
        if lower.startswith("show lldp"):
            continue
        local_match = re.search(r"(?i)(?:local\s+port|port\s+id|interface)\s*[:=]\s*(\d+(?:/\d+){1,2})", line)
        if local_match:
            if current.get("port") and current.get("port") != local_match.group(1):
                flush()
            current["port"] = local_match.group(1)
            current["raw"] = (current.get("raw", "") + " " + line).strip()
            continue
        if "system name" in lower or "remote system" in lower:
            value = line.split(":", 1)[-1].strip() if ":" in line else line.split()[-1]
            current["hostname"] = value
            current["raw"] = (current.get("raw", "") + " " + line).strip()
            continue
        if "chassis" in lower:
            macs = _mac_matches(line)
            if macs:
                current["mac"] = macs[0]
            current["raw"] = (current.get("raw", "") + " " + line).strip()
            continue

        port_match = PORT_RE.match(line)
        if port_match:
            flush()
            current["port"] = port_match.group(0)
            current["raw"] = line
            macs = _mac_matches(line)
            if macs:
                current["mac"] = macs[0]
            remainder = line[port_match.end():].strip(" |")
            if remainder:
                current["hostname"] = remainder.split()[0]
            flush()
    flush()
    return records


def detect_search_type(query: str, requested: str) -> str:
    if requested and requested != "auto":
        return requested
    value = query.strip()
    if normalize_ip(value):
        return "ip"
    if len(normalize_mac(value)) >= 6 and re.fullmatch(r"[0-9a-fA-F.:-]+", value):
        return "mac"
    vlan_match = VLAN_RE.search(value)
    if vlan_match or (value.isdigit() and 1 <= int(value) <= 4094):
        return "vlan"
    return "text"


def _text_contains(value: str, query: str) -> bool:
    return query.casefold() in str(value or "").casefold()


def record_matches(record: dict[str, Any], query: str, search_type: str) -> tuple[bool, str]:
    resolved = detect_search_type(query, search_type)
    value = query.strip()
    if resolved == "ip":
        target = normalize_ip(value)
        return (bool(target and normalize_ip(record.get("ip", "")) == target), "ip")
    if resolved == "mac":
        target = normalize_mac(value)
        candidate = normalize_mac(record.get("mac", ""))
        return (bool(target and candidate and target in candidate), "mac")
    if resolved == "vlan":
        match = VLAN_RE.search(value)
        target = match.group(1) if match else value
        return str(record.get("vlan", "")) == target, "vlan"
    if resolved == "profile":
        matched = _text_contains(record.get("profile_name", ""), value) or _text_contains(record.get("profile_id", ""), value)
        return matched, "profile"
    if resolved == "username":
        return _text_contains(record.get("username", ""), value), "username"
    if resolved == "hostname":
        return (_text_contains(record.get("hostname", ""), value) or _text_contains(record.get("raw", ""), value)), "hostname"

    fields = ("ip", "mac", "username", "hostname", "vlan", "profile_id", "profile_name", "port", "raw")
    for field in fields:
        candidate = record.get(field, "")
        if field == "mac":
            target_mac = normalize_mac(value)
            if target_mac and target_mac in normalize_mac(candidate):
                return True, "mac"
        elif _text_contains(candidate, value):
            return True, "profile" if field.startswith("profile_") else field
    return False, ""


def _annotate_record(record: dict[str, Any], device: dict[str, Any]) -> dict[str, Any]:
    item = dict(record)
    item.update({
        "device_id": int(device["id"]),
        "switch_name": str(device.get("name") or device.get("host") or "Switch"),
        "switch_host": str(device.get("host") or ""),
        "site": str(device.get("site") or ""),
        "group": str(device.get("group_name") or ""),
        "model": str(device.get("model") or ""),
        "aos_profile": str(device.get("profile") or ""),
    })
    return item


def _commands_for_actions(profile: str, actions: Iterable[str]) -> dict[str, str]:
    commands: dict[str, str] = {}
    for action in actions:
        try:
            command, _ = render_command(profile, action)
        except Exception:
            continue
        commands[action] = command
    return commands


def _parse_outputs(outputs: dict[str, str]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    if output := outputs.get("unp_users"):
        records.extend(parse_unp_users(output))
    if output := outputs.get("arp_table"):
        records.extend(parse_arp(output))
    if output := outputs.get("mac_table"):
        records.extend(parse_mac_table(output))
    if output := outputs.get("lldp_neighbors"):
        records.extend(parse_lldp(output))
    return records


def _scan_one(device: dict[str, Any], credentials: dict[str, str], actions: list[str], phase: str) -> dict[str, Any]:
    # A recently known-offline switch should not consume the full SSH retry
    # budget. Verify the TCP port once with a sub-second probe first, while
    # still allowing a recovered switch to participate immediately.
    if phase == "primary" and str(device.get("last_status") or "").casefold() == "offline":
        try:
            with socket.create_connection((str(device.get("host") or ""), int(device.get("ssh_port") or 22)), timeout=0.65):
                pass
        except OSError:
            return {"records": [], "error": "SSH TCP port is currently unreachable", "command_errors": {}}
    candidate = {**device, **credentials}
    commands = _commands_for_actions(str(device.get("profile") or "AOS8"), actions)
    if not commands:
        return {"records": [], "error": "No supported search commands for this AOS profile", "command_errors": {}}
    batch = run_command_collection(candidate, commands, pause_between=0.0, operation=f"device finder: {phase}")
    if not batch.connected:
        return {"records": [], "error": batch.connection_error or "SSH connection failed", "command_errors": {}}
    return {
        "records": [_annotate_record(record, device) for record in _parse_outputs(batch.outputs)],
        "error": "",
        "command_errors": batch.errors,
    }


def _identity_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").casefold())


def _lldp_inventory_neighbor(lldp: dict[str, Any], local_device_id: int, devices: list[dict[str, Any]]) -> tuple[bool, str]:
    hostname = str(lldp.get("hostname") or "")
    raw = str(lldp.get("raw") or "")
    host_token = _identity_token(hostname)
    raw_folded = raw.casefold()
    for device in devices:
        if int(device.get("id") or 0) == local_device_id:
            continue
        candidate_name = str(device.get("name") or "")
        candidate_host = str(device.get("host") or "")
        name_token = _identity_token(candidate_name)
        if candidate_host and candidate_host.casefold() in raw_folded:
            return True, candidate_name or candidate_host
        if host_token and name_token:
            exact = host_token == name_token
            qualified = min(len(host_token), len(name_token)) >= 6 and (host_token in name_token or name_token in host_token)
            if exact or qualified:
                return True, candidate_name or hostname
    return False, hostname


def _pick_value(records: list[dict[str, Any]], field: str, *, source: str | None = None, preferred: str = "") -> str:
    candidates = [record for record in records if record.get(field) and (source is None or record.get("source") == source)]
    if preferred:
        exact = next((str(record.get(field) or "") for record in candidates if str(record.get(field) or "").casefold() == preferred.casefold()), "")
        if exact:
            return exact
    return str(candidates[0].get(field) or "") if candidates else ""


def _confidence(evidence: set[str], topology_checked: bool, is_uplink: bool, exact_match: bool, source: str) -> tuple[int, str]:
    if source == "LLDP" and "LLDP" in evidence:
        score = 76 + (9 if exact_match else 0)
        return min(score, 95), "LLDP device"
    score = 0
    if "MAC table" in evidence:
        score += 45
    if "UNP" in evidence:
        score += 20
    if "ARP" in evidence:
        score += 20
    if topology_checked and not is_uplink:
        score += 10
    if exact_match:
        score += 5
    if is_uplink:
        score -= 35
    score = max(20, min(score, 100))
    if score >= 90:
        label = "Confirmed"
    elif score >= 75:
        label = "High confidence"
    elif score >= 55:
        label = "Probable"
    else:
        label = "Observed"
    if is_uplink:
        label = "Upstream observation"
    return score, label


def _result_sort_key(item: dict[str, Any]) -> tuple[Any, ...]:
    return (
        bool(item.get("is_uplink")),
        -int(item.get("confidence") or 0),
        0 if item.get("is_edge_port") is True else 1,
        str(item.get("site") or "").casefold(),
        str(item.get("switch_name") or "").casefold(),
        str(item.get("port") or "999/999/999"),
    )


def _dedupe_results(records: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for record in records:
        key = (
            int(record.get("device_id") or 0),
            str(record.get("port") or ""),
            normalize_mac(record.get("mac", "")),
            str(record.get("ip") or ""),
            str(record.get("hostname") or ""),
        )
        existing = unique.get(key)
        if existing is None or int(record.get("confidence") or 0) > int(existing.get("confidence") or 0):
            unique[key] = dict(record)
    return list(unique.values())


def _target_macs(records: list[dict[str, Any]], query: str, search_type: str) -> set[str]:
    targets: set[str] = set()
    for record in records:
        matched, _ = record_matches(record, query, search_type)
        mac = normalize_mac(record.get("mac", ""))
        if matched and len(mac) == 12:
            targets.add(mac)
    if detect_search_type(query, search_type) == "mac":
        direct = normalize_mac(query)
        if len(direct) == 12:
            targets.add(direct)
    return targets


def build_results(
    records: list[dict[str, Any]],
    devices: list[dict[str, Any]],
    query: str,
    search_type: str,
    *,
    target_macs: set[str] | None = None,
    topology_checked_ids: set[int] | None = None,
) -> list[dict[str, Any]]:
    """Correlate observations into ranked physical endpoint locations.

    MAC is the primary identity key. Port equality alone is never used to join
    unrelated endpoint records, preventing data from multiple MACs on the same
    access port from being mixed together.
    """
    resolved = detect_search_type(query, search_type)
    topology_checked_ids = topology_checked_ids or set()
    target_macs = set(target_macs or _target_macs(records, query, search_type))
    by_mac: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_device_port_lldp: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        mac = normalize_mac(record.get("mac", ""))
        if len(mac) == 12:
            by_mac[mac].append(record)
        if record.get("source") == "LLDP" and record.get("port"):
            by_device_port_lldp[(int(record.get("device_id") or 0), str(record.get("port") or ""))].append(record)

    location_records: list[dict[str, Any]] = []
    if resolved == "vlan":
        # VLAN is a location/network query, not an endpoint identity query. Keep
        # only forwarding entries that actually belong to the requested VLAN.
        location_records.extend(
            record for record in records
            if record.get("source") == "MAC table"
            and record.get("port")
            and record_matches(record, query, "vlan")[0]
        )
    elif target_macs:
        for mac in target_macs:
            mac_records = by_mac.get(mac, [])
            mac_table_locations = [record for record in mac_records if record.get("source") == "MAC table" and record.get("port")]
            if mac_table_locations:
                location_records.extend(mac_table_locations)
            else:
                location_records.extend(record for record in mac_records if record.get("source") == "UNP" and record.get("port"))
    else:
        for record in records:
            matched, _ = record_matches(record, query, search_type)
            if not matched or not record.get("port"):
                continue
            if resolved == "vlan" and record.get("source") != "MAC table":
                continue
            location_records.append(record)

    # Hostname searches may legitimately target an LLDP neighbor with no usable MAC.
    if resolved in {"hostname", "text"}:
        for record in records:
            matched, _ = record_matches(record, query, search_type)
            if matched and record.get("source") == "LLDP" and record.get("port") and record not in location_records:
                location_records.append(record)

    results: list[dict[str, Any]] = []
    now = utc_now()
    for location in location_records:
        mac = normalize_mac(location.get("mac", ""))
        related = list(by_mac.get(mac, [])) if len(mac) == 12 else [location]
        device_id = int(location.get("device_id") or 0)
        port = str(location.get("port") or "")
        local_related = [record for record in related if int(record.get("device_id") or 0) == device_id]
        lldp_records = by_device_port_lldp.get((device_id, port), [])
        topology_checked = device_id in topology_checked_ids
        is_uplink = False
        neighbor_name = ""
        for lldp in lldp_records:
            matched_inventory, candidate_name = _lldp_inventory_neighbor(lldp, device_id, devices)
            if candidate_name and not neighbor_name:
                neighbor_name = candidate_name
            if matched_inventory:
                is_uplink = True
                neighbor_name = candidate_name
                break
        is_edge_port: bool | None = None if not topology_checked else not is_uplink

        evidence = {str(record.get("source") or "") for record in related if record.get("source")}
        if lldp_records:
            evidence.add("LLDP")
        matched_field = ""
        exact_match = False
        for record in related + [location]:
            matched, field = record_matches(record, query, search_type)
            if matched:
                matched_field = field
                exact_match = True
                break
        if resolved == "ip" and mac:
            matched_field = "IP → MAC"
        elif resolved in {"username", "profile", "hostname", "text"} and mac and any(r.get("source") == "MAC table" for r in related):
            matched_field = f"{matched_field or resolved} → MAC"

        preferred_ip = normalize_ip(query) if resolved == "ip" else ""
        ip_value = _pick_value(related, "ip", preferred=preferred_ip)
        username_value = _pick_value(related, "username", source="UNP")
        hostname_value = _pick_value(related, "hostname", source="LLDP") or _pick_value(related, "hostname")
        profile_id = _pick_value(related, "profile_id", source="UNP")
        profile_name = _pick_value(related, "profile_name", source="UNP")
        vlan = str(location.get("vlan") or "") or _pick_value(local_related, "vlan", source="MAC table") or _pick_value(related, "vlan", source="ARP")
        source = str(location.get("source") or "")
        score, confidence_label = _confidence(evidence, topology_checked, is_uplink, exact_match, source)

        result = {
            "device_id": device_id,
            "switch_name": str(location.get("switch_name") or "Switch"),
            "switch_host": str(location.get("switch_host") or ""),
            "site": str(location.get("site") or ""),
            "group": str(location.get("group") or ""),
            "model": str(location.get("model") or ""),
            "aos_profile": str(location.get("aos_profile") or ""),
            "port": port,
            "ip": ip_value,
            "mac": display_mac(mac) if mac else "",
            "username": username_value,
            "hostname": hostname_value,
            "vlan": vlan,
            "profile_id": profile_id,
            "profile_name": profile_name,
            "profile": profile_name,
            "status": str(location.get("status") or "learned"),
            "source": ", ".join(sorted(evidence, key=lambda item: SOURCE_ORDER.get(item, 99))),
            "evidence": sorted(evidence, key=lambda item: SOURCE_ORDER.get(item, 99)),
            "matched_field": matched_field,
            "confidence": score,
            "confidence_label": confidence_label,
            "is_uplink": is_uplink,
            "is_edge_port": is_edge_port,
            "topology_verified": topology_checked,
            "neighbor_name": neighbor_name,
            "best_match": False,
            "upstream_count": 0,
            "live_verified": True,
            "current_status": "live",
            "last_seen": now,
            "last_known": False,
        }
        results.append(result)

    results = _dedupe_results(results)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for result in results:
        key = normalize_mac(result.get("mac", "")) or f"direct:{result.get('device_id')}:{result.get('port')}:{result.get('hostname')}"
        grouped[key].append(result)
    for group in grouped.values():
        group.sort(key=_result_sort_key)
        upstream_count = sum(1 for item in group if item.get("is_uplink"))
        edge_candidates = [item for item in group if not item.get("is_uplink")]
        for item in group:
            item["upstream_count"] = upstream_count
            item["alternate_edge_count"] = max(0, len(edge_candidates) - 1)
            item["ambiguous"] = False
        best = edge_candidates[0] if edge_candidates else (group[0] if group else None)
        if best is not None and edge_candidates:
            best["best_match"] = True
            if len(edge_candidates) > 1:
                second = edge_candidates[1]
                score_gap = int(best.get("confidence") or 0) - int(second.get("confidence") or 0)
                if score_gap < 15:
                    best["ambiguous"] = True
                    best["confidence"] = min(int(best.get("confidence") or 0), 70)
                    best["confidence_label"] = "Multiple edge candidates"
    results.sort(key=lambda item: (0 if item.get("best_match") else 1, *_result_sort_key(item)))
    return results


def _active_probe_ip(target: str) -> bool:
    """Send one safe, short probe to stimulate ARP/neighbor discovery.

    A reply is helpful but not required. Even a filtered ICMP echo can cause the
    routed network to resolve the destination at Layer 2 before the ARP retry.
    """
    ip = normalize_ip(target)
    if not ip:
        return False
    try:
        if platform.system().lower().startswith("win"):
            command = ["ping", "-n", "1", "-w", "900", ip]
            if ":" in ip:
                command.insert(1, "-6")
        else:
            command = ["ping", "-c", "1", "-W", "1", ip]
            if ":" in ip:
                command.insert(1, "-6")
        completed = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2.0, check=False)
        return completed.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def lookup_last_known(query: str, search_type: str) -> dict[str, Any] | None:
    resolved = detect_search_type(query, search_type)
    value = query.strip()
    where = ""
    params: list[Any] = []
    if resolved == "ip":
        target = normalize_ip(value)
        if not target:
            return None
        where, params = "e.ip = ?", [target]
    elif resolved == "mac":
        target = normalize_mac(value)
        if len(target) != 12:
            return None
        where, params = "e.mac = ?", [target]
    elif resolved == "username":
        where, params = "e.username LIKE ?", [f"%{value}%"]
    elif resolved == "hostname":
        where, params = "e.hostname LIKE ?", [f"%{value}%"]
    elif resolved == "profile":
        where, params = "(e.profile_name LIKE ? OR e.profile_id LIKE ?)", [f"%{value}%", f"%{value}%"]
    elif resolved == "text":
        pattern = f"%{value}%"
        where, params = "(e.ip LIKE ? OR e.mac LIKE ? OR e.username LIKE ? OR e.hostname LIKE ? OR e.profile_name LIKE ?)", [pattern] * 5
    else:
        return None
    with db() as conn:
        row = conn.execute(
            f"""
            SELECT e.*
            FROM endpoint_last_seen e
            WHERE {where}
            ORDER BY e.last_seen DESC
            LIMIT 1
            """,
            params,
        ).fetchone()
    if not row:
        return None
    item = {key: row[key] for key in row.keys()}
    item.update({
        "mac": display_mac(item.get("mac", "")),
        "profile": item.get("profile_name", ""),
        "source": item.get("source", ""),
        "evidence": [part for part in str(item.get("source") or "").split(", ") if part],
        "confidence_label": "Last known",
        "confidence": int(item.get("confidence") or 0),
        "live_verified": False,
        "current_status": "not_detected",
        "last_known": True,
        "best_match": False,
        "is_uplink": False,
        "is_edge_port": True,
        "topology_verified": True,
        "upstream_count": 0,
        "matched_field": "last known",
    })
    return item


def persist_endpoint_results(results: list[dict[str, Any]]) -> None:
    endpoints = [item for item in results if item.get("best_match") and not item.get("is_uplink") and len(normalize_mac(item.get("mac", ""))) == 12]
    if not endpoints:
        return
    with db() as conn:
        for item in endpoints:
            mac = normalize_mac(item.get("mac", ""))
            conn.execute(
                """
                INSERT INTO endpoint_last_seen(
                    mac, ip, username, hostname, device_id, switch_name, switch_host, site, group_name,
                    port, vlan, profile_id, profile_name, confidence, confidence_label, source, last_seen
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(mac) DO UPDATE SET
                    ip = excluded.ip,
                    username = excluded.username,
                    hostname = excluded.hostname,
                    device_id = excluded.device_id,
                    switch_name = excluded.switch_name,
                    switch_host = excluded.switch_host,
                    site = excluded.site,
                    group_name = excluded.group_name,
                    port = excluded.port,
                    vlan = excluded.vlan,
                    profile_id = excluded.profile_id,
                    profile_name = excluded.profile_name,
                    confidence = excluded.confidence,
                    confidence_label = excluded.confidence_label,
                    source = excluded.source,
                    last_seen = excluded.last_seen
                """,
                (
                    mac, str(item.get("ip") or ""), str(item.get("username") or ""), str(item.get("hostname") or ""),
                    int(item.get("device_id") or 0) or None, str(item.get("switch_name") or ""), str(item.get("switch_host") or ""),
                    str(item.get("site") or ""), str(item.get("group") or ""), str(item.get("port") or ""), str(item.get("vlan") or ""),
                    str(item.get("profile_id") or ""), str(item.get("profile_name") or ""), int(item.get("confidence") or 0),
                    str(item.get("confidence_label") or ""), str(item.get("source") or ""), str(item.get("last_seen") or utc_now()),
                ),
            )


@dataclass
class DeviceSearchState:
    search_id: str
    owner: str
    query: str
    search_type: str
    total: int
    status: str = "queued"
    phase: str = "queued"
    scanned: int = 0
    progress_done: int = 0
    progress_total: int = 0
    started_at: str = ""
    completed_at: str = ""
    results: list[dict[str, Any]] | None = None
    errors: list[dict[str, Any]] | None = None
    last_known: dict[str, Any] | None = None
    active_probe_attempted: bool = False
    active_probe_replied: bool = False

    def to_dict(self) -> dict[str, Any]:
        live_results = deepcopy(self.results or [])
        return {
            "search_id": self.search_id,
            "query": self.query,
            "search_type": self.search_type,
            "status": self.status,
            "phase": self.phase,
            "total": self.total,
            "scanned": self.scanned,
            "progress_done": self.progress_done,
            "progress_total": self.progress_total or self.total,
            "found": len(live_results),
            "endpoint_found": sum(1 for item in live_results if item.get("best_match") and not item.get("is_uplink")),
            "upstream_found": sum(1 for item in live_results if item.get("is_uplink")),
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "results": live_results,
            "errors": deepcopy(self.errors or []),
            "last_known": deepcopy(self.last_known),
            "active_probe_attempted": self.active_probe_attempted,
            "active_probe_replied": self.active_probe_replied,
        }


class DeviceSearchRegistry:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._states: dict[str, DeviceSearchState] = {}
        self._created: dict[str, float] = {}

    def _cleanup(self) -> None:
        cutoff = time.time() - 3600
        expired = [search_id for search_id, created in self._created.items() if created < cutoff]
        for search_id in expired:
            self._states.pop(search_id, None)
            self._created.pop(search_id, None)

    def create(self, owner: str, query: str, search_type: str, total: int) -> str:
        with self._lock:
            self._cleanup()
            search_id = secrets.token_urlsafe(18)
            self._states[search_id] = DeviceSearchState(
                search_id=search_id,
                owner=owner,
                query=query,
                search_type=search_type,
                total=total,
                progress_total=total,
                results=[],
                errors=[],
            )
            self._created[search_id] = time.time()
            return search_id

    def start(self, search_id: str) -> None:
        with self._lock:
            state = self._states[search_id]
            state.status = "running"
            state.phase = "primary"
            state.started_at = utc_now()

    def set_last_known(self, search_id: str, item: dict[str, Any] | None) -> None:
        with self._lock:
            state = self._states.get(search_id)
            if state:
                state.last_known = deepcopy(item)

    def set_phase(self, search_id: str, phase: str, added_work: int = 0) -> None:
        with self._lock:
            state = self._states.get(search_id)
            if not state:
                return
            state.phase = phase
            state.progress_total += max(0, int(added_work))

    def set_probe(self, search_id: str, replied: bool) -> None:
        with self._lock:
            state = self._states.get(search_id)
            if state:
                state.active_probe_attempted = True
                state.active_probe_replied = bool(replied)

    def advance(self, search_id: str, device: dict[str, Any], phase: str, result: dict[str, Any], *, primary: bool = False) -> None:
        with self._lock:
            state = self._states.get(search_id)
            if not state:
                return
            state.progress_done += 1
            if primary:
                state.scanned += 1
            if result.get("error"):
                state.errors.append({
                    "device_id": int(device["id"]),
                    "switch_name": str(device.get("name") or device.get("host") or "Switch"),
                    "switch_host": str(device.get("host") or ""),
                    "phase": phase,
                    "error": str(result["error"]),
                })
            elif result.get("command_errors") and not result.get("records"):
                state.errors.append({
                    "device_id": int(device["id"]),
                    "switch_name": str(device.get("name") or device.get("host") or "Switch"),
                    "switch_host": str(device.get("host") or ""),
                    "phase": phase,
                    "error": "; ".join(f"{key}: {value}" for key, value in result["command_errors"].items()),
                })
            if len(state.errors) > 150:
                state.errors = state.errors[:150]

    def set_results(self, search_id: str, results: list[dict[str, Any]]) -> None:
        with self._lock:
            state = self._states.get(search_id)
            if state:
                state.results = deepcopy(results)

    def finish(self, search_id: str, error: str = "") -> None:
        with self._lock:
            state = self._states.get(search_id)
            if not state:
                return
            state.status = "failed" if error else "completed"
            state.phase = "failed" if error else "completed"
            state.completed_at = utc_now()
            if error:
                state.errors.append({"device_id": 0, "switch_name": "Search", "switch_host": "", "phase": "search", "error": error})

    def get(self, search_id: str, owner: str) -> dict[str, Any] | None:
        with self._lock:
            self._cleanup()
            state = self._states.get(search_id)
            if not state or state.owner != owner:
                return None
            return state.to_dict()


device_search_registry = DeviceSearchRegistry()


def _scan_phase(
    search_id: str,
    devices: list[dict[str, Any]],
    credentials: dict[str, str],
    actions: list[str],
    phase: str,
    *,
    primary: bool = False,
    add_work: bool = True,
) -> list[dict[str, Any]]:
    if not devices:
        return []
    if add_work:
        device_search_registry.set_phase(search_id, phase, len(devices))
    else:
        device_search_registry.set_phase(search_id, phase)
    records: list[dict[str, Any]] = []
    workers = max(1, min(int(getattr(settings, "finder_max_parallel_switches", 12)), len(devices)))
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix=f"finder-{phase}") as executor:
        future_map = {
            executor.submit(_scan_one, device, credentials, actions, phase): device
            for device in devices
        }
        for future in as_completed(future_map):
            device = future_map[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {"records": [], "error": f"{type(exc).__name__}: {exc}", "command_errors": {}}
            records.extend(result.get("records") or [])
            device_search_registry.advance(search_id, device, phase, result, primary=primary)
    return records


def _candidate_devices(records: list[dict[str, Any]], macs: set[str], devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ids = {
        int(record.get("device_id") or 0)
        for record in records
        if normalize_mac(record.get("mac", "")) in macs and record.get("port")
    }
    return [device for device in devices if int(device.get("id") or 0) in ids]


def _merge_new_records(all_records: list[dict[str, Any]], new_records: list[dict[str, Any]]) -> None:
    all_records.extend(new_records)


def execute_device_search(
    search_id: str,
    devices: list[dict[str, Any]],
    credentials: dict[str, str],
    query: str,
    search_type: str,
) -> None:
    device_search_registry.start(search_id)
    resolved = detect_search_type(query, search_type)
    all_records: list[dict[str, Any]] = []
    topology_checked_ids: set[int] = set()
    try:
        device_search_registry.set_last_known(search_id, lookup_last_known(query, resolved))

        # Primary phase is tailored to the identifier. IP keeps ARP, MAC and UNP
        # in one SSH session per switch to avoid a costly second fleet-wide login.
        if resolved == "ip":
            primary_actions = ["arp_table", "mac_table", "unp_users"]
        elif resolved == "mac":
            primary_actions = ["mac_table"]
        elif resolved == "vlan":
            primary_actions = ["mac_table"]
        elif resolved in {"username", "profile"}:
            primary_actions = ["unp_users"]
        elif resolved == "hostname":
            primary_actions = ["lldp_neighbors", "unp_users"]
        else:
            primary_actions = ["unp_users", "lldp_neighbors"]

        primary_records = _scan_phase(
            search_id, devices, credentials, primary_actions, "primary",
            primary=True, add_work=False,
        )
        _merge_new_records(all_records, primary_records)
        target_macs = _target_macs(all_records, query, resolved)

        # Static-IP support. If no ARP/UNP record exists, stimulate the routed
        # network once, then retry ARP only. The first-pass MAC tables are already
        # available, so a newly learned MAC can be located without another MAC scan.
        if resolved == "ip" and not target_macs:
            device_search_registry.set_phase(search_id, "active_probe")
            replied = _active_probe_ip(query)
            device_search_registry.set_probe(search_id, replied)
            time.sleep(0.25)
            retry_records = _scan_phase(search_id, devices, credentials, ["arp_table"], "arp_retry")
            _merge_new_records(all_records, retry_records)
            target_macs = _target_macs(all_records, query, resolved)

        # MAC fallback. A learned UNP endpoint may exist even when the forwarding
        # table has already aged out, so search UNP only when the fast MAC pass misses.
        if resolved == "mac" and not any(
            normalize_mac(record.get("mac", "")) in target_macs and record.get("source") == "MAC table"
            for record in all_records
        ):
            fallback_records = _scan_phase(search_id, devices, credentials, ["unp_users"], "unp_fallback")
            _merge_new_records(all_records, fallback_records)
            target_macs = _target_macs(all_records, query, resolved)

        # Show an early location as soon as the primary identity is known. Further
        # phases only enrich/verify it, keeping the UI useful while the search runs.
        preliminary = build_results(
            all_records, devices, query, resolved,
            target_macs=target_macs,
            topology_checked_ids=topology_checked_ids,
        )
        if preliminary:
            device_search_registry.set_results(search_id, preliminary)

        # Username/profile/text/hostname searches resolve their matching UNP/LLDP
        # identity to MAC, then verify the physical location in forwarding tables.
        needs_mac_resolution = resolved in {"username", "profile", "hostname", "text"} and bool(target_macs)
        if needs_mac_resolution:
            mac_records = _scan_phase(search_id, devices, credentials, ["mac_table"], "mac_resolution")
            _merge_new_records(all_records, mac_records)

        # Recompute candidates after MAC resolution and verify only those switches
        # with LLDP. This removes learned uplinks without paying for LLDP fleet-wide
        # on MAC/IP/VLAN searches.
        target_macs = _target_macs(all_records, query, resolved) or target_macs
        candidate_devices = _candidate_devices(all_records, target_macs, devices) if target_macs else []
        if resolved == "vlan":
            vlan_locations = [record for record in all_records if record_matches(record, query, "vlan")[0] and record.get("source") == "MAC table"]
            candidate_ids = {int(record.get("device_id") or 0) for record in vlan_locations}
            candidate_devices = [device for device in devices if int(device.get("id") or 0) in candidate_ids]

        if candidate_devices:
            topology_actions = ["lldp_neighbors"]
            # Candidate-local UNP enrichment is cheap for MAC/VLAN searches and
            # adds username/profile data without scanning UNP across the whole fleet.
            if resolved in {"mac", "vlan"}:
                topology_actions.append("unp_users")
            topology_records = _scan_phase(search_id, candidate_devices, credentials, topology_actions, "topology")
            _merge_new_records(all_records, topology_records)
            topology_checked_ids.update(int(device["id"]) for device in candidate_devices)

        results = build_results(
            all_records, devices, query, resolved,
            target_macs=target_macs,
            topology_checked_ids=topology_checked_ids,
        )
        if results:
            device_search_registry.set_results(search_id, results)

        # MAC searches can locate the edge port very quickly. ARP is enrichment,
        # so only perform the fleet-wide ARP pass when the located endpoint still
        # lacks an IP address. The already-visible result remains usable meanwhile.
        if resolved == "mac" and results and not any(item.get("ip") for item in results if item.get("best_match")):
            arp_records = _scan_phase(search_id, devices, credentials, ["arp_table"], "arp_enrichment")
            _merge_new_records(all_records, arp_records)
            results = build_results(
                all_records, devices, query, resolved,
                target_macs=target_macs,
                topology_checked_ids=topology_checked_ids,
            )
            device_search_registry.set_results(search_id, results)

        persist_endpoint_results(results)
        device_search_registry.finish(search_id)
    except Exception as exc:
        device_search_registry.finish(search_id, f"{type(exc).__name__}: {exc}")
