# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import ipaddress
import json
import logging
import socket
import threading
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .config import settings
from .crypto import decrypt_secret, encrypt_secret
from .db import db, get_app_setting_int, utc_now
from .time_service import format_platform_datetime, platform_timezone_name


logger = logging.getLogger(__name__)
_worker_stop = threading.Event()
_worker_wake = threading.Event()
_worker_thread: threading.Thread | None = None



class _NoWebhookRedirects(HTTPRedirectHandler):
    """Fail closed on webhook redirects so a validated public URL cannot redirect to an internal target."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


_WEBHOOK_OPENER = build_opener(_NoWebhookRedirects())

_PROVIDERS = {"microsoft", "slack", "discord", "generic"}
_MICROSOFT_SUFFIXES = (
    ".environment.api.powerplatform.com",
    ".api.powerplatform.com",
    ".logic.azure.com",
    ".logic.azure.us",
    ".logic.azure.cn",
    ".logic.azure.de",
    ".webhook.office.com",
    ".webhook.office365.com",
)
_SLACK_SUFFIXES = (".slack.com", ".slack-gov.com")
_DISCORD_SUFFIXES = (".discord.com", ".discordapp.com")
_MAX_OUTBOX_ATTEMPTS = 8
_RETRY_DELAYS_SECONDS = (30, 60, 120, 300, 600, 1200, 1800, 3600)


def purge_ups_reachability_noise() -> dict[str, int]:
    """Keep UPS communication history local to Power and remove webhook noise.

    Reachability is useful operational information inside the Power workspace,
    but it is not a power fault and must never create webhook deliveries or
    Notification Center alert counts.  Older delivery rows are removed and the
    retired destination flag remains disabled.
    """
    with db() as conn:
        delivery_count = int(conn.execute(
            "SELECT COUNT(*) FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')"
        ).fetchone()[0] or 0)
        conn.execute(
            "DELETE FROM notification_outbox WHERE event_type IN ('ups_unreachable','ups_reachable')"
        )
        conn.execute("UPDATE notification_destinations SET notify_ups_unreachable=0 WHERE notify_ups_unreachable<>0")
    return {"incidents": 0, "deliveries": delivery_count, "ups_normalized": 0}


def _utc_dt() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def _json_list(raw: Any) -> list[str]:
    try:
        values = json.loads(raw or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    return [str(item) for item in values if str(item).strip()]


def _host_matches(host: str, suffixes: tuple[str, ...]) -> bool:
    host = host.lower().rstrip(".")
    return any(host == suffix.lstrip(".") or host.endswith(suffix) for suffix in suffixes)


def _validate_public_generic_host(host: str) -> None:
    if host.lower() in {"localhost", "localhost.localdomain"}:
        raise ValueError("Generic webhook endpoints cannot target localhost")
    try:
        literal = ipaddress.ip_address(host)
        addresses = [literal]
    except ValueError:
        try:
            info = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise ValueError(f"Webhook hostname could not be resolved: {exc}") from exc
        addresses = []
        for entry in info:
            try:
                addresses.append(ipaddress.ip_address(entry[4][0]))
            except ValueError:
                continue
        if not addresses:
            raise ValueError("Webhook hostname did not resolve to an IP address")
    for address in addresses:
        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_multicast
            or address.is_reserved
            or address.is_unspecified
        ):
            raise ValueError("Generic webhook endpoints must resolve to public network addresses")


def validate_webhook_url(value: str, provider: str = "generic") -> str:
    provider = str(provider or "generic").strip().lower()
    if provider not in _PROVIDERS:
        raise ValueError("Unsupported webhook provider")
    url = (value or "").strip()
    if not url:
        raise ValueError("A webhook URL is required")
    if len(url) > 4000:
        raise ValueError("Webhook URL is too long")
    parts = urlsplit(url)
    if parts.scheme.lower() != "https":
        raise ValueError("Webhook URL must use HTTPS")
    if not parts.hostname or parts.username or parts.password:
        raise ValueError("Webhook URL is not valid")
    if parts.port not in (None, 443):
        raise ValueError("Webhook URL must use the standard HTTPS port")
    host = parts.hostname.lower().rstrip(".")
    if provider == "microsoft" and not _host_matches(host, _MICROSOFT_SUFFIXES):
        raise ValueError("This does not look like a Microsoft Power Automate or Teams webhook URL")
    if provider == "slack" and not _host_matches(host, _SLACK_SUFFIXES):
        raise ValueError("This does not look like a Slack webhook URL")
    if provider == "discord" and not _host_matches(host, _DISCORD_SUFFIXES):
        raise ValueError("This does not look like a Discord webhook URL")
    if provider == "generic":
        _validate_public_generic_host(host)
    return url


def mask_webhook_url(value: str) -> str:
    if not value:
        return ""
    try:
        parts = urlsplit(value)
        path_bits = [part for part in parts.path.split("/") if part]
        tail = "/" + "/".join(path_bits[-2:]) if path_bits else ""
        return f"https://{parts.hostname}/…{tail}?••••••"
    except Exception:
        return "Configured"


def _policy_row(conn: Any) -> Any:
    return conn.execute("SELECT * FROM notification_policy WHERE id = 1").fetchone()


def _policy_from_row(row: Any) -> dict[str, Any]:
    if not row:
        return {
            "enabled": False,
            "scope_mode": "all",
            "sites": [],
            "groups": [],
            "notify_offline": True,
            "notify_recovery": True,
            "failure_threshold": 3,
            "reminder_minutes": 0,
        }
    return {
        "enabled": bool(row["enabled"]),
        "scope_mode": str(row["scope_mode"] or "all"),
        "sites": _json_list(row["sites_json"]),
        "groups": _json_list(row["groups_json"]),
        "notify_offline": bool(row["notify_offline"]),
        "notify_recovery": bool(row["notify_recovery"]),
        "failure_threshold": max(2, int(row["failure_threshold"] or 3)),
        "reminder_minutes": max(0, int(row["reminder_minutes"] or 0)),
        "updated_at": row["updated_at"],
        "updated_by": str(row["updated_by"] or "system"),
    }


def _destination_from_row(row: Any, *, include_mask: bool = True) -> dict[str, Any]:
    encrypted = str(row["webhook_url_enc"] or "")
    masked = ""
    if encrypted and include_mask:
        try:
            masked = mask_webhook_url(decrypt_secret(encrypted))
        except ValueError:
            masked = "Configured, but cannot be decrypted"
    return {
        "id": int(row["id"]),
        "name": str(row["name"] or "Webhook"),
        "provider": str(row["provider"] or "generic"),
        "enabled": bool(row["enabled"]),
        "webhook_configured": bool(encrypted),
        "webhook_masked": masked,
        "last_test_at": row["last_test_at"],
        "last_test_status": str(row["last_test_status"] or "never"),
        "last_delivery_at": row["last_delivery_at"],
        "last_delivery_status": str(row["last_delivery_status"] or "never"),
        "last_error": str(row["last_error"] or ""),
        "scope_mode": str(row["scope_mode"] or "all"),
        "sites": _json_list(row["sites_json"]),
        "groups": _json_list(row["groups_json"]),
        "notify_offline": bool(row["notify_offline"]),
        "notify_recovery": bool(row["notify_recovery"]),
        "notify_reminder": bool(row["notify_reminder"]),
        "notify_stack_degraded": bool(row["notify_stack_degraded"]),
        "notify_stack_recovery": bool(row["notify_stack_recovery"]),
        "notify_ups_on_battery": bool(row["notify_ups_on_battery"]),
        "notify_ups_power_restored": bool(row["notify_ups_power_restored"]),
        "notify_ups_low_battery": bool(row["notify_ups_low_battery"]),
        "notify_ups_unreachable": False,
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "updated_by": str(row["updated_by"] or "system"),
    }


def _matches_scope(device: dict[str, Any], routing: dict[str, Any]) -> bool:
    if routing.get("scope_mode") == "all":
        return True
    sites = {str(value).casefold() for value in routing.get("sites", [])}
    groups = {str(value).casefold() for value in routing.get("groups", [])}
    if not sites and not groups:
        return False
    site_ok = not sites or str(device.get("site") or "").casefold() in sites
    group_ok = not groups or str(device.get("group_name") or "").casefold() in groups
    return site_ok and group_ok


def _destination_routing(row: Any) -> dict[str, Any]:
    return {
        "scope_mode": str(row["scope_mode"] or "all"),
        "sites": _json_list(row["sites_json"]),
        "groups": _json_list(row["groups_json"]),
        "notify_offline": bool(row["notify_offline"]),
        "notify_recovery": bool(row["notify_recovery"]),
        "notify_reminder": bool(row["notify_reminder"]),
        "notify_stack_degraded": bool(row["notify_stack_degraded"]),
        "notify_stack_recovery": bool(row["notify_stack_recovery"]),
        "notify_ups_on_battery": bool(row["notify_ups_on_battery"]),
        "notify_ups_power_restored": bool(row["notify_ups_power_restored"]),
        "notify_ups_low_battery": bool(row["notify_ups_low_battery"]),
        "notify_ups_unreachable": False,
    }


def _destination_subscribed(row: Any, event_type: str) -> bool:
    routing = _destination_routing(row)
    if event_type == "switch_offline":
        return bool(routing["notify_offline"])
    if event_type == "switch_recovered":
        return bool(routing["notify_recovery"] and routing["notify_offline"])
    if event_type == "switch_offline_reminder":
        return bool(routing["notify_reminder"] and routing["notify_offline"])
    if event_type == "stack_degraded":
        return bool(routing["notify_stack_degraded"])
    if event_type == "stack_recovered":
        return bool(routing["notify_stack_recovery"] and routing["notify_stack_degraded"])
    if event_type == "ups_on_battery":
        return bool(routing["notify_ups_on_battery"])
    if event_type == "ups_power_restored":
        return bool(routing["notify_ups_power_restored"] and routing["notify_ups_on_battery"])
    if event_type == "ups_low_battery":
        return bool(routing["notify_ups_low_battery"])
    if event_type in {"ups_unreachable", "ups_reachable"}:
        return False
    return True


def _destination_accepts(row: Any, device: dict[str, Any], event_type: str) -> bool:
    routing = _destination_routing(row)
    return _destination_subscribed(row, event_type) and _matches_scope(device, routing)


def get_notification_state(*, include_inventory: bool = True, history_limit: int = 50) -> dict[str, Any]:
    history_limit = max(1, min(int(history_limit), 1000))
    with db() as conn:
        policy = _policy_from_row(_policy_row(conn))
        destination_rows = conn.execute("SELECT * FROM notification_destinations ORDER BY name COLLATE NOCASE, id").fetchall()
        destinations = [_destination_from_row(row) for row in destination_rows]
        result: dict[str, Any] = {"policy": policy, "destinations": destinations}
        enabled_destinations = [item for item in destinations if item["enabled"] and item["webhook_configured"]]
        switch_open = int(conn.execute("SELECT COUNT(*) AS count FROM notification_incidents WHERE status = 'open'").fetchone()["count"])
        power_open = int(conn.execute("SELECT COUNT(*) AS count FROM power_incidents WHERE status = 'open' AND incident_type<>'ups_unreachable'").fetchone()["count"])
        result["summary"] = {
            "destination_count": len(destinations),
            "enabled_destination_count": len(enabled_destinations),
            "open_incidents": switch_open + power_open,
            "open_switch_incidents": switch_open,
            "open_power_incidents": power_open,
            "pending_deliveries": int(conn.execute("SELECT COUNT(*) AS count FROM notification_outbox WHERE status IN ('queued','retrying','delivering') AND event_type NOT IN ('ups_unreachable','ups_reachable')").fetchone()["count"]),
            "failed_deliveries": int(conn.execute("SELECT COUNT(*) AS count FROM notification_outbox WHERE status = 'failed' AND event_type NOT IN ('ups_unreachable','ups_reachable')").fetchone()["count"]),
        }
        if include_inventory:
            switch_inventory = conn.execute("SELECT id, site, group_name FROM devices WHERE enabled = 1 ORDER BY id").fetchall()
            ups_inventory = conn.execute("SELECT id, site, group_name FROM ups_devices WHERE enabled = 1 ORDER BY id").fetchall()
            switch_dicts = [_row_to_dict(item) for item in switch_inventory]
            ups_dicts = [_row_to_dict(item) for item in ups_inventory]
            enabled_rows = conn.execute("SELECT * FROM notification_destinations WHERE enabled=1 AND webhook_url_enc<>'' ORDER BY id").fetchall()
            covered_switch_ids: set[int] = set()
            covered_ups_ids: set[int] = set()
            switch_coverage_by_destination: dict[int, int] = {}
            ups_coverage_by_destination: dict[int, int] = {}
            for destination_row in enabled_rows:
                routing = _destination_routing(destination_row)
                switch_count = 0
                ups_count = 0
                for device in switch_dicts:
                    if (routing.get("notify_offline") or routing.get("notify_stack_degraded")) and _matches_scope(device, routing):
                        switch_count += 1
                        covered_switch_ids.add(int(device["id"]))
                for ups in ups_dicts:
                    if any((routing.get("notify_ups_on_battery"), routing.get("notify_ups_low_battery"))) and _matches_scope(ups, routing):
                        ups_count += 1
                        covered_ups_ids.add(int(ups["id"]))
                switch_coverage_by_destination[int(destination_row["id"])] = switch_count
                ups_coverage_by_destination[int(destination_row["id"])] = ups_count
            for destination in destinations:
                destination["covered_switch_count"] = switch_coverage_by_destination.get(int(destination["id"]), 0)
                destination["enabled_switch_count"] = len(switch_dicts)
                destination["covered_ups_count"] = ups_coverage_by_destination.get(int(destination["id"]), 0)
                destination["enabled_ups_count"] = len(ups_dicts)
            all_scope_rows = [*switch_inventory, *ups_inventory]
            result["inventory"] = {
                "available_sites": sorted({str(item["site"] or "").strip() for item in all_scope_rows if str(item["site"] or "").strip()}, key=str.casefold),
                "available_groups": sorted({str(item["group_name"] or "").strip() for item in all_scope_rows if str(item["group_name"] or "").strip()}, key=str.casefold),
                "enabled_switch_count": len(switch_inventory),
                "covered_switch_count": len(covered_switch_ids),
                "enabled_ups_count": len(ups_inventory),
                "covered_ups_count": len(covered_ups_ids),
            }
        switch_rows = conn.execute(
            """
            SELECT i.*, d.host, d.site, d.group_name, d.model
            FROM notification_incidents i
            LEFT JOIN devices d ON d.id = i.device_id
            ORDER BY CASE WHEN i.status='open' THEN 0 ELSE 1 END, i.opened_at DESC
            LIMIT ?
            """,
            (history_limit,),
        ).fetchall()
        incidents: list[dict[str, Any]] = []
        for row in switch_rows:
            item = _row_to_dict(row)
            item["source_type"] = "switch"
            item["source_name"] = str(item.get("device_name") or "")
            try:
                item["details"] = json.loads(str(item.get("details_json") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                item["details"] = {}
            incidents.append(item)
        power_rows = conn.execute(
            """
            SELECT p.*, u.host, u.site, u.group_name, u.model
            FROM power_incidents p
            LEFT JOIN ups_devices u ON u.id=p.ups_id
            WHERE p.incident_type<>'ups_unreachable'
            ORDER BY CASE WHEN p.status='open' THEN 0 ELSE 1 END, p.opened_at DESC
            LIMIT ?
            """,
            (history_limit,),
        ).fetchall()
        for row in power_rows:
            item = _row_to_dict(row)
            item["source_type"] = "ups"
            item["source_name"] = str(item.get("ups_name") or "")
            item["device_id"] = None
            item["device_name"] = str(item.get("ups_name") or "")
            try:
                item["details"] = json.loads(str(item.get("details_json") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                item["details"] = {}
            incidents.append(item)
        incidents.sort(key=lambda item: (0 if str(item.get("status") or "") == "open" else 1, str(item.get("opened_at") or "")), reverse=False)
        # Keep open incidents first while showing newest incidents first within each state.
        incidents = sorted(incidents, key=lambda item: str(item.get("opened_at") or ""), reverse=True)
        incidents = sorted(incidents, key=lambda item: 0 if str(item.get("status") or "") == "open" else 1)
        result["incidents"] = incidents[:history_limit]
        delivery_rows = conn.execute(
            """
            SELECT o.id, o.event_type, o.device_name, o.severity, o.status, o.attempts,
                   o.created_at, o.delivered_at, o.http_status, o.last_error, o.destination_id,
                   o.incident_id, o.power_incident_id,
                   COALESCE(d.name, 'Legacy destination') AS destination_name,
                   COALESCE(d.provider, 'generic') AS provider
            FROM notification_outbox o
            LEFT JOIN notification_destinations d ON d.id = o.destination_id
            WHERE o.event_type NOT IN ('ups_unreachable','ups_reachable')
            ORDER BY o.id DESC LIMIT ?
            """,
            (history_limit,),
        ).fetchall()
        result["deliveries"] = [_row_to_dict(row) for row in delivery_rows]
    return result


def save_notification_policy(
    *, actor: str, enabled: bool, scope_mode: str, sites: list[str], groups: list[str],
    notify_offline: bool, notify_recovery: bool, failure_threshold: int, reminder_minutes: int,
) -> dict[str, Any]:
    if scope_mode not in {"all", "selected"}:
        raise ValueError("Invalid notification scope")
    normalized_sites = sorted({item.strip() for item in sites if item.strip()}, key=str.casefold)
    normalized_groups = sorted({item.strip() for item in groups if item.strip()}, key=str.casefold)
    if failure_threshold < 2 or failure_threshold > 10:
        raise ValueError("Failure threshold must be between 2 and 10 checks")
    if reminder_minutes not in {0, 30, 60, 120, 240, 480, 720, 1440}:
        raise ValueError("Invalid reminder interval")
    with db() as conn:
        if enabled:
            count = int(conn.execute("SELECT COUNT(*) AS count FROM notification_destinations WHERE enabled=1 AND webhook_url_enc<>''").fetchone()["count"])
            if count == 0:
                raise ValueError("Configure and enable at least one webhook destination before enabling notifications")
        now = utc_now()
        # Routing scope and event subscriptions moved to each destination in v1.4.0.
        # The legacy columns remain untouched for backward database compatibility.
        conn.execute(
            """
            UPDATE notification_policy SET enabled=?, failure_threshold=?, reminder_minutes=?,
                updated_at=?, updated_by=? WHERE id=1
            """,
            (1 if enabled else 0, failure_threshold, reminder_minutes, now, actor),
        )
        if not enabled:
            conn.execute(
                "UPDATE notification_outbox SET status='cancelled', last_error='Notifications disabled by administrator' WHERE status IN ('queued','retrying') AND event_type<>'test'"
            )
            conn.execute(
                "UPDATE notification_incidents SET status='closed', recovered_at=COALESCE(recovered_at, ?), updated_at=? WHERE status='open'",
                (now, now),
            )
    _worker_wake.set()
    return get_notification_state()


def save_destination(
    *, actor: str, destination_id: int | None, name: str, provider: str, enabled: bool,
    webhook_url: str | None, scope_mode: str = "all", sites: list[str] | None = None, groups: list[str] | None = None,
    notify_offline: bool = True, notify_recovery: bool = True, notify_reminder: bool = True,
    notify_stack_degraded: bool = True, notify_stack_recovery: bool = True,
    notify_ups_on_battery: bool = True, notify_ups_power_restored: bool = True,
    notify_ups_low_battery: bool = True, notify_ups_unreachable: bool = True,
    keep_existing_webhook: bool = True,
) -> dict[str, Any]:
    # UPS SNMP reachability is internal polling telemetry only. The legacy
    # destination flag is retained in the schema for upgrade compatibility but
    # can no longer be enabled or routed.
    notify_ups_unreachable = False
    provider = str(provider or "generic").strip().lower()
    if provider not in _PROVIDERS:
        raise ValueError("Unsupported webhook provider")
    name = str(name or "").strip()
    if not name:
        raise ValueError("Destination name is required")
    if len(name) > 120:
        raise ValueError("Destination name is too long")
    if scope_mode not in {"all", "selected"}:
        raise ValueError("Invalid destination routing scope")
    normalized_sites = sorted({str(item).strip() for item in (sites or []) if str(item).strip()}, key=str.casefold)
    normalized_groups = sorted({str(item).strip() for item in (groups or []) if str(item).strip()}, key=str.casefold)
    if scope_mode == "selected" and not normalized_sites and not normalized_groups:
        raise ValueError("Select at least one site or group for this destination")
    if not notify_offline and (notify_recovery or notify_reminder):
        raise ValueError("Recovery and still-offline reminders require Switch Offline to be enabled")
    if not notify_stack_degraded and notify_stack_recovery:
        raise ValueError("Stack recovery requires Stack degraded to be enabled")
    if not notify_ups_on_battery and notify_ups_power_restored:
        raise ValueError("UPS power restored requires UPS on battery to be enabled")
    if not any((notify_offline, notify_recovery, notify_reminder, notify_stack_degraded, notify_stack_recovery, notify_ups_on_battery, notify_ups_power_restored, notify_ups_low_battery, notify_ups_unreachable)):
        raise ValueError("Enable at least one event type for this destination")
    with db() as conn:
        existing = None
        if destination_id is not None:
            existing = conn.execute("SELECT * FROM notification_destinations WHERE id=?", (int(destination_id),)).fetchone()
            if not existing:
                raise ValueError("Notification destination was not found")
        encrypted = str(existing["webhook_url_enc"] or "") if existing and keep_existing_webhook else ""
        if webhook_url is not None and webhook_url.strip():
            encrypted = encrypt_secret(validate_webhook_url(webhook_url, provider))
        if not encrypted:
            raise ValueError("Webhook URL is required")
        if existing and str(existing["provider"] or "generic") != provider and not (webhook_url or "").strip():
            raise ValueError("Enter the webhook URL again when changing provider type")
        now = utc_now()
        if existing:
            conn.execute(
                """
                UPDATE notification_destinations SET name=?, provider=?, enabled=?, webhook_url_enc=?,
                    scope_mode=?, sites_json=?, groups_json=?, notify_offline=?, notify_recovery=?, notify_reminder=?,
                    notify_stack_degraded=?, notify_stack_recovery=?, notify_ups_on_battery=?, notify_ups_power_restored=?,
                    notify_ups_low_battery=?, notify_ups_unreachable=?, updated_at=?, updated_by=? WHERE id=?
                """,
                (
                    name, provider, 1 if enabled else 0, encrypted, scope_mode,
                    json.dumps(normalized_sites, ensure_ascii=False), json.dumps(normalized_groups, ensure_ascii=False),
                    1 if notify_offline else 0, 1 if notify_recovery else 0, 1 if notify_reminder else 0,
                    1 if notify_stack_degraded else 0, 1 if notify_stack_recovery else 0,
                    1 if notify_ups_on_battery else 0, 1 if notify_ups_power_restored else 0,
                    1 if notify_ups_low_battery else 0, 1 if notify_ups_unreachable else 0, now, actor, int(destination_id),
                ),
            )
            saved_id = int(destination_id)
        else:
            cursor = conn.execute(
                """
                INSERT INTO notification_destinations(
                    name, provider, enabled, webhook_url_enc, scope_mode, sites_json, groups_json,
                    notify_offline, notify_recovery, notify_reminder, notify_stack_degraded, notify_stack_recovery,
                    notify_ups_on_battery, notify_ups_power_restored, notify_ups_low_battery, notify_ups_unreachable, created_at, updated_at, updated_by
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name, provider, 1 if enabled else 0, encrypted, scope_mode,
                    json.dumps(normalized_sites, ensure_ascii=False), json.dumps(normalized_groups, ensure_ascii=False),
                    1 if notify_offline else 0, 1 if notify_recovery else 0, 1 if notify_reminder else 0,
                    1 if notify_stack_degraded else 0, 1 if notify_stack_recovery else 0,
                    1 if notify_ups_on_battery else 0, 1 if notify_ups_power_restored else 0,
                    1 if notify_ups_low_battery else 0, 1 if notify_ups_unreachable else 0, now, now, actor,
                ),
            )
            saved_id = int(cursor.lastrowid)
    _worker_wake.set()
    return {"ok": True, "destination_id": saved_id, **get_notification_state()}


def delete_destination(*, actor: str, destination_id: int) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT id FROM notification_destinations WHERE id=?", (int(destination_id),)).fetchone()
        if not row:
            raise ValueError("Notification destination was not found")
        conn.execute(
            "UPDATE notification_outbox SET status='cancelled', last_error='Destination removed by administrator' WHERE destination_id=? AND status IN ('queued','retrying')",
            (int(destination_id),),
        )
        conn.execute("DELETE FROM notification_destinations WHERE id=?", (int(destination_id),))
        enabled_destinations = int(conn.execute("SELECT COUNT(*) AS count FROM notification_destinations WHERE enabled=1 AND webhook_url_enc<>''").fetchone()["count"])
        if enabled_destinations == 0:
            conn.execute("UPDATE notification_policy SET enabled=0, updated_at=?, updated_by=? WHERE id=1", (utc_now(), actor))
    return get_notification_state()


def _duration_text(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def _display_time(value: object, *, fallback: str = "Not reported") -> str:
    rendered = format_platform_datetime(value, fallback="")
    if not rendered:
        return fallback
    return f"{rendered} ({platform_timezone_name()})"


def _member_sort_key(value: Any) -> tuple[int, Any]:
    text = str(value or "").strip()
    return (0, int(text)) if text.isdigit() else (1, text.casefold())


def _json_object_list(raw: Any) -> list[dict[str, Any]]:
    try:
        values = json.loads(str(raw or "[]"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    return [dict(item) for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def _stack_incident_details(
    device: dict[str, Any], *, expected_members: int, current_members: int,
    member_ids: list[str], members: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build diagnostic stack evidence using the learned healthy baseline.

    AOS8 keeps Config Chas ID visible for Unassigned/Not-Joined members even
    when Oper Chas becomes '-'.  The active member list therefore tells us
    what is healthy while the full current rows and learned baseline let us
    name the exact physical chassis that disappeared.
    """
    active_ids = sorted({str(item) for item in member_ids if str(item).strip()}, key=_member_sort_key)
    baseline_ids = sorted(set(_json_list(device.get("stack_baseline_member_ids_json"))), key=_member_sort_key)
    if not baseline_ids:
        baseline_ids = list(active_ids)
    current_rows = [dict(item) for item in members if isinstance(item, dict)]
    baseline_rows = _json_object_list(device.get("stack_baseline_members_json"))
    current_by_id = {str(item.get("id") or item.get("config_id") or "").strip(): item for item in current_rows if str(item.get("id") or item.get("config_id") or "").strip()}
    baseline_by_id = {str(item.get("id") or item.get("config_id") or "").strip(): item for item in baseline_rows if str(item.get("id") or item.get("config_id") or "").strip()}
    active_set = set(active_ids)
    baseline_set = set(baseline_ids)
    missing_ids = sorted(baseline_set - active_set, key=_member_sort_key)
    unexpected_ids = sorted(active_set - baseline_set, key=_member_sort_key)
    missing_members: list[dict[str, Any]] = []
    for member_id in missing_ids:
        current = current_by_id.get(member_id, {})
        baseline = baseline_by_id.get(member_id, {})
        state = str(current.get("status") or "Missing").strip() or "Missing"
        missing_members.append({
            "id": member_id,
            "config_id": str(current.get("config_id") or baseline.get("config_id") or member_id),
            "state": state,
            "current_role": str(current.get("role") or ""),
            "last_known_role": str(baseline.get("role") or ""),
            "last_known_mac": str(baseline.get("mac") or ""),
            "last_known_model": str(baseline.get("model") or ""),
            "last_known_serial": str(baseline.get("serial") or ""),
            "evidence": str(current.get("evidence") or ""),
        })
    return {
        "expected_members": int(expected_members),
        "current_members": int(current_members),
        "member_ids": active_ids,
        "members": current_rows,
        "baseline_member_ids": baseline_ids,
        "missing_member_ids": missing_ids,
        "missing_members": missing_members,
        "unexpected_member_ids": unexpected_ids,
    }


def _stack_member_fact_values(stack: dict[str, Any]) -> list[tuple[str, str]]:
    facts: list[tuple[str, str]] = []
    missing_ids = [str(item) for item in (stack.get("missing_member_ids") or []) if str(item).strip()]
    recovered_ids = [str(item) for item in (stack.get("recovered_member_ids") or []) if str(item).strip()]
    if missing_ids:
        facts.append(("Missing chassis", ", ".join(missing_ids)))
        missing = stack.get("missing_members") or []
        if len(missing) == 1 and isinstance(missing[0], dict):
            item = missing[0]
            if item.get("state"):
                facts.append(("Member state", str(item.get("state"))))
            if item.get("last_known_role"):
                facts.append(("Last known role", str(item.get("last_known_role"))))
            if item.get("last_known_mac"):
                facts.append(("Last known MAC", str(item.get("last_known_mac"))))
    elif recovered_ids:
        facts.append(("Recovered chassis", ", ".join(recovered_ids)))
    return facts


def _adaptive_card(payload: dict[str, Any]) -> dict[str, Any]:
    device = payload.get("device", {})
    health = payload.get("health", {})
    incident = payload.get("incident", {})
    severity = payload.get("severity", "info")
    accent = {"critical": "Attention", "resolved": "Good", "warning": "Warning"}.get(severity, "Accent")
    power = payload.get("power") or {}
    event_type = str(payload.get("event_type") or "")
    asset_label = "UPS" if event_type.startswith("ups_") else "Switch"
    switch_availability_event = event_type in {"switch_offline", "switch_recovered"}
    facts = [
        {"title": asset_label, "value": str(device.get("name") or "Unknown")},
        {"title": "Management IP", "value": str(device.get("ip") or "Not reported")},
        {"title": "Site", "value": str(device.get("site") or "Not assigned")},
        {"title": "Group", "value": str(device.get("group") or "Not assigned")},
    ]
    if switch_availability_event:
        facts.append({"title": "Assigned UPS", "value": str(power.get("ups_name") or "Not assigned")})
    if power.get("power_state"):
        facts.append({"title": "UPS power state" if asset_label == "Switch" else "Power state", "value": str(power.get("power_state")).replace("_", " ").title()})
    if power.get("battery_charge_percent") is not None:
        facts.append({"title": "UPS battery" if asset_label == "Switch" else "Battery", "value": f"{power.get('battery_charge_percent')}%"})
    if power.get("runtime_minutes") is not None:
        facts.append({"title": "UPS runtime" if asset_label == "Switch" else "Runtime", "value": f"{power.get('runtime_minutes')} min"})
    if power.get("load_percent") is not None:
        facts.append({"title": "UPS load" if asset_label == "Switch" else "Load", "value": f"{power.get('load_percent')}%"})
    if power.get("reason") and asset_label == "Switch":
        facts.append({"title": "Probable root cause", "value": str(power.get("reason"))})
        if power.get("confidence"):
            facts.append({"title": "Confidence", "value": str(power.get("confidence")).replace("_", " ").title()})
    if power.get("utility_restored") and asset_label == "Switch":
        facts.append({"title": "Recovery evidence", "value": "Assigned UPS returned to normal utility power"})
    elif power.get("current_power_state") and asset_label == "Switch" and str(payload.get("event_type") or "") == "switch_recovered":
        facts.append({"title": "UPS state at recovery", "value": str(power.get("current_power_state")).replace("_", " ").title()})
    if health.get("failed_checks"):
        facts.append({"title": "Failed checks", "value": str(health["failed_checks"])})
    stack = payload.get("stack") or {}
    if stack.get("expected_members"):
        facts.append({"title": "Stack members", "value": f"{stack.get('current_members')}/{stack.get('expected_members')}"})
        if stack.get("member_ids"):
            facts.append({"title": "Detected members", "value": ", ".join(str(v) for v in stack.get("member_ids") or [])})
        for title, value in _stack_member_fact_values(stack):
            facts.append({"title": title, "value": value})
    if incident.get("last_reachable"):
        facts.append({"title": "Last reachable", "value": _display_time(incident["last_reachable"])})
    if incident.get("downtime"):
        facts.append({"title": "Downtime", "value": str(incident["downtime"])})
    return {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": [
            {"type": "TextBlock", "text": str(payload.get("title") or "Portivo notification"), "weight": "Bolder", "size": "Large", "color": accent},
            {"type": "TextBlock", "text": str(payload.get("summary") or ""), "wrap": True, "spacing": "Small"},
            {"type": "FactSet", "facts": facts},
            {"type": "TextBlock", "text": f"Portivo Control Center · {_display_time(payload.get('occurred_at'))}", "isSubtle": True, "size": "Small", "spacing": "Medium"},
        ],
    }


def _build_payload(
    *, event_type: str, device: dict[str, Any], incident_id: int | None, failed_checks: int = 0,
    opened_at: str | None = None, recovered_at: str | None = None, last_reachable: str | None = None,
    response_ms: int | None = None, error: str = "", stack: dict[str, Any] | None = None,
    power: dict[str, Any] | None = None,
) -> dict[str, Any]:
    now = utc_now()
    severity = "critical"
    title = "Switch Offline"
    summary = f"{device.get('name') or device.get('host')} is unreachable after {failed_checks} consecutive health checks."
    downtime_seconds = None
    if event_type == "switch_recovered":
        severity = "resolved"
        title = "Switch Recovered"
        opened = _parse_dt(opened_at)
        recovered = _parse_dt(recovered_at or now)
        downtime_seconds = int((recovered - opened).total_seconds()) if opened and recovered else None
        summary = f"{device.get('name') or device.get('host')} is reachable again."
    elif event_type == "switch_offline_reminder":
        severity = "warning"
        title = "Switch Still Offline"
        opened = _parse_dt(opened_at)
        downtime_seconds = int((_utc_dt() - opened).total_seconds()) if opened else None
        summary = f"{device.get('name') or device.get('host')} remains unreachable."
    elif event_type == "stack_degraded":
        severity = "warning"
        title = "Stack Degraded"
        stack = stack or {}
        missing_ids = [str(item) for item in (stack.get("missing_member_ids") or []) if str(item).strip()]
        missing_suffix = f" Missing chassis: {', '.join(missing_ids)}." if missing_ids else ""
        summary = f"{device.get('name') or device.get('host')} management remains reachable, but only {int(stack.get('current_members') or 0)}/{int(stack.get('expected_members') or 0)} stack members are detected.{missing_suffix}"
    elif event_type == "stack_recovered":
        severity = "resolved"
        title = "Stack Recovered"
        stack = stack or {}
        recovered_ids = [str(item) for item in (stack.get("recovered_member_ids") or []) if str(item).strip()]
        recovered_suffix = f" Chassis {', '.join(recovered_ids)} rejoined." if recovered_ids else ""
        summary = f"{device.get('name') or device.get('host')} stack membership is healthy again ({int(stack.get('current_members') or 0)}/{int(stack.get('expected_members') or 0)}).{recovered_suffix}"
    elif event_type == "ups_on_battery":
        severity = "warning"
        title = "UPS On Battery"
        power = power or {}
        summary = f"{device.get('name') or device.get('host')} lost normal input power and is supplying its protected switches from battery."
    elif event_type == "ups_power_restored":
        severity = "resolved"
        title = "UPS Power Restored"
        power = power or {}
        summary = f"Normal input power has returned to {device.get('name') or device.get('host')}."
    elif event_type == "ups_low_battery":
        severity = "critical"
        title = "UPS Low Battery"
        power = power or {}
        summary = f"{device.get('name') or device.get('host')} has critically low remaining battery runtime."
    elif event_type == "ups_unreachable":
        severity = "critical"
        title = "UPS Monitoring Unreachable"
        power = power or {}
        summary = f"Portivo can no longer read {device.get('name') or device.get('host')} through SNMPv3."
    elif event_type == "ups_reachable":
        severity = "resolved"
        title = "UPS Monitoring Restored"
        power = power or {}
        summary = f"SNMPv3 monitoring for {device.get('name') or device.get('host')} is reachable again."
    elif event_type == "test":
        severity = "resolved"
        title = "Portivo Webhook Test"
        summary = "Webhook delivery from Portivo Control Center is configured correctly."

    power = power or {}
    if event_type in {"switch_offline", "switch_offline_reminder"} and power.get("correlated"):
        reason = str(power.get("reason") or "power evidence from the assigned UPS")
        confidence = str(power.get("confidence") or "probable").replace("_", " ").title()
        if event_type == "switch_offline":
            title = "Switch Offline · Power-related"
        summary = f"{summary} Power-related root cause: {reason}. Confidence: {confidence}."
    elif event_type == "switch_recovered" and power.get("correlated"):
        title = "Switch Recovered · Power-related outage"
        ups_name = power.get("ups_name") or "its assigned UPS"
        if power.get("utility_restored"):
            summary = f"{summary} Recovery followed restoration of normal utility power on {ups_name}."
        else:
            summary = f"{summary} The outage was correlated with {ups_name}."

    event_id = str(uuid.uuid4())
    payload: dict[str, Any] = {
        "schema_version": "1.1",
        "source": "Portivo Control Center",
        "source_version": settings.app_version,
        "event_id": event_id,
        "event_type": event_type,
        "severity": severity,
        "title": title,
        "summary": summary,
        "occurred_at": recovered_at or now,
        "device": {
            "id": device.get("id"), "name": device.get("name") or "", "ip": device.get("host") or "",
            "site": device.get("site") or "", "group": device.get("group_name") or "", "model": device.get("model") or "",
            "aos_version": device.get("aos_version") or "", "profile": device.get("profile") or "",
        },
        "health": {"failed_checks": int(failed_checks or 0), "response_ms": response_ms, "error": error},
        "stack": stack or {},
        "power": power or {},
        "incident": {
            "id": incident_id, "opened_at": opened_at, "recovered_at": recovered_at, "last_reachable": last_reachable,
            "downtime_seconds": downtime_seconds,
            "downtime": _duration_text(downtime_seconds) if downtime_seconds is not None else None,
        },
    }
    payload["adaptive_card"] = _adaptive_card(payload)
    return payload


def _plain_message(payload: dict[str, Any]) -> str:
    device = payload.get("device", {})
    incident = payload.get("incident", {})
    health = payload.get("health", {})
    lines = [str(payload.get("title") or "Portivo notification"), str(payload.get("summary") or "")]
    if device.get("name"):
        label = "UPS" if str(payload.get("event_type") or "").startswith("ups_") else "Switch"
        lines.append(f"{label}: {device.get('name')}")
    if device.get("ip"):
        lines.append(f"IP: {device.get('ip')}")
    if device.get("site"):
        lines.append(f"Site: {device.get('site')}")
    if device.get("group"):
        lines.append(f"Group: {device.get('group')}")
    if health.get("failed_checks"):
        lines.append(f"Failed checks: {health.get('failed_checks')}")
    stack = payload.get("stack") or {}
    if stack.get("expected_members"):
        lines.append(f"Stack members: {stack.get('current_members')}/{stack.get('expected_members')}")
        if stack.get("member_ids"):
            lines.append(f"Detected members: {', '.join(str(v) for v in stack.get('member_ids') or [])}")
        for title, value in _stack_member_fact_values(stack):
            lines.append(f"{title}: {value}")
    power = payload.get("power") or {}
    event_type = str(payload.get("event_type") or "")
    is_switch_event = not event_type.startswith("ups_")
    switch_availability_event = event_type in {"switch_offline", "switch_recovered"}
    if switch_availability_event:
        lines.append(f"Assigned UPS: {power.get('ups_name') or 'Not assigned'}")
    if power.get("power_state"):
        lines.append(f"{'UPS power state' if is_switch_event else 'Power state'}: {str(power.get('power_state')).replace('_', ' ').title()}")
    if power.get("battery_charge_percent") is not None:
        lines.append(f"{'UPS battery' if is_switch_event else 'Battery'}: {power.get('battery_charge_percent')}%")
    if power.get("runtime_minutes") is not None:
        lines.append(f"{'UPS runtime' if is_switch_event else 'Runtime'}: {power.get('runtime_minutes')} min")
    if power.get("reason") and not str(payload.get("event_type") or "").startswith("ups_"):
        lines.append(f"Probable root cause: {power.get('reason')}")
        if power.get("confidence"):
            lines.append(f"Confidence: {str(power.get('confidence')).replace('_', ' ').title()}")
    if power.get("utility_restored") and not str(payload.get("event_type") or "").startswith("ups_"):
        lines.append("Recovery evidence: assigned UPS returned to normal utility power")
    elif power.get("current_power_state") and str(payload.get("event_type") or "") == "switch_recovered":
        lines.append(f"UPS state at recovery: {str(power.get('current_power_state')).replace('_', ' ').title()}")
    if incident.get("downtime"):
        lines.append(f"Downtime: {incident.get('downtime')}")
    lines.append(f"Time: {_display_time(payload.get('occurred_at'))}")
    return "\n".join(line for line in lines if line)


def _provider_payload(provider: str, payload: dict[str, Any]) -> dict[str, Any]:
    provider = str(provider or "generic").lower()
    if provider == "slack":
        device = payload.get("device", {})
        incident = payload.get("incident", {})
        health = payload.get("health", {})
        fields = [
            f"*{'UPS' if str(payload.get('event_type') or '').startswith('ups_') else 'Switch'}*\n{device.get('name') or 'Unknown'}",
            f"*Management IP*\n{device.get('ip') or 'Not reported'}",
            f"*Site*\n{device.get('site') or 'Not assigned'}",
            f"*Group*\n{device.get('group') or 'Not assigned'}",
        ]
        if health.get("failed_checks"):
            fields.append(f"*Failed checks*\n{health.get('failed_checks')}")
        stack = payload.get("stack") or {}
        if stack.get("expected_members"):
            fields.append(f"*Stack members*\n{stack.get('current_members')}/{stack.get('expected_members')}")
            for title, value in _stack_member_fact_values(stack):
                fields.append(f"*{title}*\n{value}")
        if incident.get("downtime"):
            fields.append(f"*Downtime*\n{incident.get('downtime')}")
        return {
            "text": _plain_message(payload),
            "blocks": [
                {"type": "header", "text": {"type": "plain_text", "text": str(payload.get("title") or "Portivo notification")[:150]}},
                {"type": "section", "text": {"type": "mrkdwn", "text": str(payload.get("summary") or "")[:3000]}},
                {"type": "section", "fields": [{"type": "mrkdwn", "text": value[:2000]} for value in fields[:10]]},
                {"type": "context", "elements": [{"type": "mrkdwn", "text": f"Portivo Control Center · {_display_time(payload.get('occurred_at'))}"}]},
            ],
        }
    if provider == "discord":
        device = payload.get("device", {})
        incident = payload.get("incident", {})
        health = payload.get("health", {})
        color = {"critical": 0xD64545, "warning": 0xD99020, "resolved": 0x27956F}.get(str(payload.get("severity") or ""), 0x6F42C1)
        fields = [
            {"name": "UPS" if str(payload.get("event_type") or "").startswith("ups_") else "Switch", "value": str(device.get("name") or "Unknown"), "inline": True},
            {"name": "Management IP", "value": str(device.get("ip") or "Not reported"), "inline": True},
            {"name": "Site", "value": str(device.get("site") or "Not assigned"), "inline": True},
            {"name": "Group", "value": str(device.get("group") or "Not assigned"), "inline": True},
        ]
        if health.get("failed_checks"):
            fields.append({"name": "Failed checks", "value": str(health.get("failed_checks")), "inline": True})
        stack = payload.get("stack") or {}
        if stack.get("expected_members"):
            fields.append({"name": "Stack members", "value": f"{stack.get('current_members')}/{stack.get('expected_members')}", "inline": True})
            for title, value in _stack_member_fact_values(stack):
                fields.append({"name": title, "value": value, "inline": True})
        if incident.get("downtime"):
            fields.append({"name": "Downtime", "value": str(incident.get("downtime")), "inline": True})
        return {
            "username": "Portivo Control Center",
            "embeds": [{
                "title": str(payload.get("title") or "Portivo notification")[:256],
                "description": str(payload.get("summary") or "")[:4096],
                "color": color,
                "fields": fields[:25],
                "footer": {"text": "Portivo Control Center"},
                "timestamp": str(payload.get("occurred_at") or ""),
            }],
        }
    if provider == "microsoft":
        # Microsoft Teams Workflows / Power Automate webhooks accept either a
        # simple text body (used by the built-in "Send webhook alerts to a
        # channel" templates) or a Teams webhook message envelope containing
        # Adaptive Card attachments. Send both fields so Portivo works with the
        # common text template and with flows that consume the Adaptive Card.
        # A 2xx response means the workflow accepted the request; downstream
        # Teams posting still depends on the flow configuration.
        return {
            "text": _plain_message(payload),
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "contentUrl": None,
                    "content": _adaptive_card(payload),
                }
            ],
        }
    outgoing = dict(payload)
    outgoing.pop("adaptive_card", None)
    outgoing["platform_timezone"] = platform_timezone_name()
    outgoing["occurred_at_local"] = _display_time(payload.get("occurred_at"), fallback="")
    incident = dict(payload.get("incident") or {})
    if incident.get("last_reachable"):
        incident["last_reachable_local"] = _display_time(incident.get("last_reachable"), fallback="")
    if incident.get("opened_at"):
        incident["opened_at_local"] = _display_time(incident.get("opened_at"), fallback="")
    if incident.get("recovered_at"):
        incident["recovered_at_local"] = _display_time(incident.get("recovered_at"), fallback="")
    outgoing["incident"] = incident
    return outgoing


def _insert_outbox(
    conn: Any, *, event_type: str, device: dict[str, Any], incident_id: int | None,
    payload: dict[str, Any], destination_id: int, power_incident_id: int | None = None,
) -> int:
    now = utc_now()
    cursor = conn.execute(
        """
        INSERT INTO notification_outbox(
            event_id, event_type, incident_id, power_incident_id, destination_id, device_id, device_name, severity,
            payload_json, status, attempts, next_attempt_at, created_at
        ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', 0, ?, ?)
        """,
        (
            payload["event_id"], event_type, incident_id, power_incident_id, int(destination_id), device.get("id"),
            str(device.get("name") or device.get("host") or "Unknown"), payload.get("severity", "info"),
            json.dumps(payload, ensure_ascii=False), now, now,
        ),
    )
    return int(cursor.lastrowid)


def _enabled_destinations(conn: Any) -> list[Any]:
    return conn.execute("SELECT * FROM notification_destinations WHERE enabled=1 AND webhook_url_enc<>'' ORDER BY id").fetchall()


def _enqueue_for_destinations(
    conn: Any, *, event_type: str, device: dict[str, Any], incident_id: int | None,
    payload: dict[str, Any], destination_ids: list[int] | None = None, power_incident_id: int | None = None,
) -> list[int]:
    rows = _enabled_destinations(conn)
    allowed = set(destination_ids or []) if destination_ids is not None else None
    inserted: list[int] = []
    for row in rows:
        destination_id = int(row["id"])
        if allowed is not None and destination_id not in allowed:
            continue
        # Recovery closes the loop for destinations that actually received the
        # original offline alert. A later scope edit must not strand an open
        # alert, so explicit recovery recipients are checked by subscription
        # but not re-filtered by current Site/Group scope.
        if allowed is not None and event_type in {"switch_recovered", "stack_recovered", "ups_power_restored", "ups_reachable"}:
            if not _destination_subscribed(row, event_type):
                continue
        elif not _destination_accepts(row, device, event_type):
            continue
        per_destination = dict(payload)
        per_destination["event_id"] = str(uuid.uuid4())
        inserted.append(_insert_outbox(
            conn, event_type=event_type, device=device, incident_id=incident_id,
            payload=per_destination, destination_id=destination_id, power_incident_id=power_incident_id,
        ))
    return inserted




def _power_correlation_for_switch(conn: Any, device: dict[str, Any]) -> dict[str, Any]:
    ups_id = int(device.get("power_source_ups_id") or 0)
    if not ups_id:
        return {}
    row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    if not row:
        return {}
    state = str(row["power_state"] or "unknown")
    reachability = str(row["last_status"] or "unknown")
    charge = row["battery_charge_percent"]
    runtime = row["runtime_minutes"]
    correlated = state in {"on_battery", "low_battery", "depleted", "output_off"}
    reason = ""
    confidence = "possible"
    if state == "depleted":
        correlated, reason, confidence = True, "assigned UPS battery is depleted", "high"
    elif state == "low_battery":
        correlated, reason, confidence = True, "assigned UPS is on critically low battery", "high"
    elif state == "output_off":
        correlated, reason, confidence = True, "assigned UPS reports no output power", "high"
    elif state == "on_battery":
        reason, confidence = "assigned UPS is operating on battery", "probable"
    if reachability == "unreachable" and state in {"on_battery", "low_battery", "depleted"}:
        correlated = True
        if runtime is not None and int(runtime) <= 5:
            reason, confidence = "UPS monitoring disappeared after critically low remaining runtime", "high"
        elif charge is not None and int(charge) <= 15:
            reason, confidence = "UPS monitoring disappeared after critically low battery charge", "high"
        else:
            reason, confidence = "UPS monitoring disappeared during an active battery event", "probable"
    return {
        "correlated": correlated, "confidence": confidence, "reason": reason,
        "ups_id": int(row["id"]), "ups_name": str(row["name"] or ""), "ups_host": str(row["host"] or ""),
        "power_state": state, "reachability": reachability, "battery_charge_percent": charge,
        "runtime_minutes": runtime, "load_percent": row["load_percent"],
        "power_event_started_at": row["power_event_started_at"], "last_checked": row["last_checked"],
    }

def observe_health_result(device: dict[str, Any], *, checked_at: str | None = None) -> None:
    checked_at = checked_at or str(device.get("last_checked") or utc_now())
    with db() as conn:
        policy = _policy_from_row(_policy_row(conn))
        if not policy["enabled"] or not _enabled_destinations(conn):
            return
        incident = conn.execute(
            "SELECT * FROM notification_incidents WHERE device_id=? AND incident_type='switch_offline' AND status='open' ORDER BY id DESC LIMIT 1",
            (device["id"],),
        ).fetchone()
        online = str(device.get("last_status") or "unknown").lower() == "online"
        failures = int(device.get("consecutive_failures") or 0)

        if online:
            if not incident:
                return
            conn.execute(
                "UPDATE notification_incidents SET status='closed', recovered_at=?, updated_at=? WHERE id=?",
                (checked_at, checked_at, incident["id"]),
            )
            delivered_rows = conn.execute(
                "SELECT DISTINCT destination_id FROM notification_outbox WHERE incident_id=? AND event_type='switch_offline' AND status='delivered' AND destination_id IS NOT NULL",
                (incident["id"],),
            ).fetchall()
            delivered_destinations = [int(row["destination_id"]) for row in delivered_rows]
            if delivered_destinations:
                try:
                    incident_details = json.loads(str(incident["details_json"] or "{}"))
                except Exception:
                    incident_details = {}
                original_power = incident_details.get("power") or {}
                recovery_power = dict(original_power)
                if original_power.get("correlated"):
                    current_power = _power_correlation_for_switch(conn, device)
                    if current_power:
                        recovery_power["current_power_state"] = current_power.get("power_state")
                        recovery_power["current_reachability"] = current_power.get("reachability")
                        recovery_power["current_battery_charge_percent"] = current_power.get("battery_charge_percent")
                        recovery_power["current_runtime_minutes"] = current_power.get("runtime_minutes")
                        recovery_power["utility_restored"] = bool(
                            current_power.get("power_state") == "normal" and current_power.get("reachability") == "online"
                        )
                payload = _build_payload(
                    event_type="switch_recovered", device=device, incident_id=int(incident["id"]),
                    failed_checks=int(incident["failure_threshold"] or 0), opened_at=incident["opened_at"],
                    recovered_at=checked_at, last_reachable=incident["last_reachable"], response_ms=device.get("response_ms"),
                    power=recovery_power,
                )
                _enqueue_for_destinations(
                    conn, event_type="switch_recovered", device=device, incident_id=int(incident["id"]),
                    payload=payload, destination_ids=delivered_destinations,
                )
            conn.execute(
                """
                UPDATE notification_outbox SET status='cancelled', last_error='Switch recovered before the alert could be delivered'
                WHERE incident_id=? AND event_type IN ('switch_offline','switch_offline_reminder') AND status IN ('queued','retrying')
                """,
                (incident["id"],),
            )
            _trim_history(conn)
            _worker_wake.set()
            return

        if incident or failures < policy["failure_threshold"]:
            return
        last_reachable = str(device.get("last_seen") or "") or None
        power = _power_correlation_for_switch(conn, device)
        details_json = json.dumps({"power": power} if power else {}, ensure_ascii=False)
        cursor = conn.execute(
            """
            INSERT INTO notification_incidents(
                device_id, device_name, opened_at, confirmed_at, status, failure_threshold,
                last_reachable, first_delivery_at, last_reminder_at, created_at, updated_at, incident_type, details_json
            ) VALUES(?, ?, ?, ?, 'open', ?, ?, NULL, NULL, ?, ?, 'switch_offline', ?)
            """,
            (
                device["id"], str(device.get("name") or device.get("host") or "Unknown"), checked_at, checked_at,
                policy["failure_threshold"], last_reachable, checked_at, checked_at, details_json,
            ),
        )
        incident_id = int(cursor.lastrowid)
        payload = _build_payload(
            event_type="switch_offline", device=device, incident_id=incident_id, failed_checks=failures,
            opened_at=checked_at, last_reachable=last_reachable, response_ms=device.get("response_ms"),
            error=str(device.get("last_error") or ""), power=power,
        )
        _enqueue_for_destinations(conn, event_type="switch_offline", device=device, incident_id=incident_id, payload=payload)
        _trim_history(conn)
    _worker_wake.set()



def observe_stack_result(
    device: dict[str, Any], *, checked_at: str, expected_members: int,
    current_members: int, member_ids: list[str], members: list[dict[str, Any]],
) -> None:
    """Open/close a stack-specific incident without interfering with IP reachability incidents."""
    with db() as conn:
        policy = _policy_from_row(_policy_row(conn))
        if not policy["enabled"] or not _enabled_destinations(conn):
            return
        incident = conn.execute(
            "SELECT * FROM notification_incidents WHERE device_id=? AND incident_type='stack_degraded' AND status='open' ORDER BY id DESC LIMIT 1",
            (device["id"],),
        ).fetchone()
        healthy = str(device.get("stack_last_status") or "unknown") == "healthy"
        details = _stack_incident_details(
            device, expected_members=expected_members, current_members=current_members,
            member_ids=member_ids, members=members,
        )
        if healthy:
            if not incident:
                return
            try:
                previous_details = json.loads(str(incident["details_json"] or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                previous_details = {}
            affected_ids = [str(item) for item in (previous_details.get("missing_member_ids") or []) if str(item).strip()]
            affected_members = [dict(item) for item in (previous_details.get("missing_members") or []) if isinstance(item, dict)]
            details["recovered_member_ids"] = affected_ids
            details["recovered_members"] = affected_members
            # Preserve the identity evidence that opened the incident even after
            # the current stack is healthy again. This keeps closed incidents
            # and recovery webhooks useful for post-event review.
            details["affected_member_ids"] = affected_ids
            details["affected_members"] = affected_members
            conn.execute(
                "UPDATE notification_incidents SET status='closed', recovered_at=?, updated_at=?, details_json=? WHERE id=?",
                (checked_at, checked_at, json.dumps(details, ensure_ascii=False), incident["id"]),
            )
            delivered_rows = conn.execute(
                "SELECT DISTINCT destination_id FROM notification_outbox WHERE incident_id=? AND event_type='stack_degraded' AND status='delivered' AND destination_id IS NOT NULL",
                (incident["id"],),
            ).fetchall()
            destination_ids = [int(row["destination_id"]) for row in delivered_rows]
            if destination_ids:
                payload = _build_payload(
                    event_type="stack_recovered", device=device, incident_id=int(incident["id"]),
                    opened_at=incident["opened_at"], recovered_at=checked_at, stack=details,
                )
                _enqueue_for_destinations(
                    conn, event_type="stack_recovered", device=device, incident_id=int(incident["id"]),
                    payload=payload, destination_ids=destination_ids,
                )
            conn.execute(
                "UPDATE notification_outbox SET status='cancelled', last_error='Stack recovered before the alert could be delivered' WHERE incident_id=? AND event_type='stack_degraded' AND status IN ('queued','retrying')",
                (incident["id"],),
            )
            _trim_history(conn)
            _worker_wake.set()
            return
        if incident:
            conn.execute("UPDATE notification_incidents SET updated_at=?, details_json=? WHERE id=?", (checked_at, json.dumps(details, ensure_ascii=False), incident["id"]))
            return
        cursor = conn.execute(
            """
            INSERT INTO notification_incidents(
                device_id, device_name, opened_at, confirmed_at, status, failure_threshold,
                last_reachable, first_delivery_at, last_reminder_at, created_at, updated_at, incident_type, details_json
            ) VALUES(?, ?, ?, ?, 'open', 2, ?, NULL, NULL, ?, ?, 'stack_degraded', ?)
            """,
            (
                device["id"], str(device.get("name") or device.get("host") or "Unknown"), checked_at, checked_at,
                str(device.get("last_seen") or "") or None, checked_at, checked_at, json.dumps(details, ensure_ascii=False),
            ),
        )
        incident_id = int(cursor.lastrowid)
        payload = _build_payload(
            event_type="stack_degraded", device=device, incident_id=incident_id,
            opened_at=checked_at, stack=details,
        )
        _enqueue_for_destinations(conn, event_type="stack_degraded", device=device, incident_id=incident_id, payload=payload)
        _trim_history(conn)
    _worker_wake.set()



def _power_payload(ups: dict[str, Any], *, reason: str = "") -> dict[str, Any]:
    return {
        "ups_id": int(ups.get("id") or 0), "ups_name": str(ups.get("name") or ""),
        "power_state": str(ups.get("power_state") or "unknown"), "output_source": str(ups.get("output_source") or "unknown"),
        "battery_status": str(ups.get("battery_status") or "unknown"),
        "battery_charge_percent": ups.get("battery_charge_percent"), "runtime_minutes": ups.get("runtime_minutes"),
        "seconds_on_battery": ups.get("seconds_on_battery"), "load_percent": ups.get("load_percent"),
        "alarm_count": int(ups.get("alarm_count") or 0), "alarms": list(ups.get("alarms") or []),
        "protected_switch_count": int(ups.get("protected_switch_count") or 0),
        "reason": reason,
    }


def observe_ups_result(ups: dict[str, Any], *, previous: dict[str, Any] | None = None, checked_at: str | None = None) -> None:
    checked_at = checked_at or utc_now()
    previous = previous or {}
    with db() as conn:
        policy = _policy_from_row(_policy_row(conn))
        # Power incidents are first-class operational history and must be kept
        # even when webhook delivery is disabled or no destination exists.
        # Routing only controls whether a newly opened/recovered incident is
        # placed in the notification outbox.
        delivery_enabled = bool(policy["enabled"] and _enabled_destinations(conn))
        protected = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE power_source_ups_id=? AND enabled=1", (int(ups.get("id") or 0),)).fetchone()["c"])
        ups = dict(ups)
        ups["protected_switch_count"] = protected
        device = {"id": None, "name": ups.get("name"), "host": ups.get("host"), "site": ups.get("site"), "group_name": ups.get("group_name"), "model": ups.get("model"), "aos_version": "", "profile": "UPS-MIB"}

        def open_incident(kind: str, event_type: str, reason: str, *, opened_at: str | None = None, notify: bool = True) -> None:
            event_opened_at = str(opened_at or checked_at)
            existing = conn.execute("SELECT * FROM power_incidents WHERE ups_id=? AND incident_type=? AND status='open' ORDER BY id DESC LIMIT 1", (int(ups["id"]), kind)).fetchone()
            if existing:
                conn.execute("UPDATE power_incidents SET updated_at=?, details_json=? WHERE id=?", (checked_at, json.dumps(_power_payload(ups, reason=reason), ensure_ascii=False), int(existing["id"])))
                return
            cursor = conn.execute("INSERT INTO power_incidents(ups_id,ups_name,incident_type,status,opened_at,details_json,created_at,updated_at) VALUES(?,?,?,'open',?,?,?,?)", (int(ups["id"]), str(ups.get("name") or "UPS"), kind, event_opened_at, json.dumps(_power_payload(ups, reason=reason), ensure_ascii=False), checked_at, checked_at))
            power_incident_id = int(cursor.lastrowid)
            if delivery_enabled and notify:
                payload = _build_payload(event_type=event_type, device=device, incident_id=None, opened_at=event_opened_at, power=_power_payload(ups, reason=reason), error=str(ups.get("last_error") or ""))
                _enqueue_for_destinations(conn, event_type=event_type, device=device, incident_id=None, payload=payload, power_incident_id=power_incident_id)

        def close_incident(kind: str, event_type: str, reason: str, *, send_recovery: bool = True, recovered_at: str | None = None) -> None:
            event_recovered_at = str(recovered_at or checked_at)
            incident = conn.execute("SELECT * FROM power_incidents WHERE ups_id=? AND incident_type=? AND status='open' ORDER BY id DESC LIMIT 1", (int(ups["id"]), kind)).fetchone()
            if not incident:
                return
            conn.execute("UPDATE power_incidents SET status='closed', recovered_at=?, updated_at=?, details_json=? WHERE id=?", (event_recovered_at, checked_at, json.dumps(_power_payload(ups, reason=reason), ensure_ascii=False), int(incident["id"])))
            # A transient condition that recovered before its webhook was ever
            # delivered must not produce a stale outage alert after recovery.
            conn.execute(
                "UPDATE notification_outbox SET status='cancelled', last_error='UPS condition recovered before the alert could be delivered' WHERE power_incident_id=? AND status IN ('queued','retrying')",
                (int(incident["id"]),),
            )
            rows = conn.execute("SELECT DISTINCT destination_id FROM notification_outbox WHERE power_incident_id=? AND status='delivered' AND destination_id IS NOT NULL", (int(incident["id"]),)).fetchall()
            destination_ids = [int(row["destination_id"]) for row in rows]
            if delivery_enabled and destination_ids and send_recovery:
                payload = _build_payload(event_type=event_type, device=device, incident_id=None, opened_at=incident["opened_at"], recovered_at=event_recovered_at, power=_power_payload(ups, reason=reason))
                _enqueue_for_destinations(conn, event_type=event_type, device=device, incident_id=None, payload=payload, destination_ids=destination_ids, power_incident_id=int(incident["id"]))

        def state_age_seconds(started_at: str | None) -> float:
            started = _parse_dt(started_at)
            current = _parse_dt(checked_at)
            if started is None or current is None:
                return 0.0
            return max(0.0, (current - started).total_seconds())

        prev_status = str(previous.get("last_status") or "unknown")
        current_status = str(ups.get("last_status") or "unknown")
        current_power = str(ups.get("power_state") or "unknown")
        power_started_at = str(ups.get("power_event_started_at") or checked_at)
        power_state_age = state_age_seconds(power_started_at)
        confirm_seconds = get_app_setting_int("ups_power_confirm_seconds", 20, 5, 300)
        recovery_seconds = get_app_setting_int("ups_power_recovery_seconds", 20, 5, 300)

        # UPS communication state is recorded only as informational Power
        # history.  It never enters webhook routing, Notification Center or
        # Dashboard attention.  The reachability transition has already been
        # debounced by the Power monitor's consecutive-failure threshold.
        if current_status == "unreachable":
            open_incident(
                "ups_unreachable",
                "ups_unreachable",
                "SNMPv3 telemetry is currently unavailable; last valid power telemetry is preserved",
                opened_at=str(ups.get("status_changed_at") or checked_at),
                notify=False,
            )
        elif current_status == "online" and prev_status == "unreachable":
            close_incident(
                "ups_unreachable",
                "ups_reachable",
                "SNMPv3 telemetry is reachable again",
                send_recovery=False,
                recovered_at=str(ups.get("status_changed_at") or checked_at),
            )

        if current_status == "online":
            # Power-state incidents use a confirmation window. A single delayed,
            # incomplete or contradictory UPS poll is therefore retained only as
            # telemetry and never becomes operational outage history by itself.
            if current_power in {"on_battery", "low_battery", "depleted"} and power_state_age >= confirm_seconds:
                open_incident(
                    "ups_on_battery",
                    "ups_on_battery",
                    "Normal utility input is not supplying the UPS output",
                    opened_at=power_started_at,
                )
            if current_power in {"low_battery", "depleted"} and power_state_age >= confirm_seconds:
                open_incident(
                    "ups_low_battery",
                    "ups_low_battery",
                    "Remaining UPS battery runtime is critically low",
                    opened_at=power_started_at,
                )
            if current_power == "normal" and power_state_age >= recovery_seconds:
                # Close the nested low-battery condition silently and send one
                # consolidated restoration event for the parent battery incident.
                # recovered_at points to the first healthy observation, while the
                # close itself waits for the recovery confirmation window.
                close_incident("ups_low_battery", "ups_power_restored", "Utility input restored", send_recovery=False, recovered_at=power_started_at)
                close_incident("ups_on_battery", "ups_power_restored", "Utility input restored", recovered_at=power_started_at)
        _trim_history(conn)
    _worker_wake.set()

def _trim_history(conn: Any) -> None:
    conn.execute(
        "DELETE FROM notification_outbox WHERE status IN ('delivered','failed','cancelled') AND id NOT IN (SELECT id FROM notification_outbox ORDER BY id DESC LIMIT 5000)"
    )
    conn.execute(
        "DELETE FROM notification_incidents WHERE status='closed' AND id NOT IN (SELECT id FROM notification_incidents ORDER BY id DESC LIMIT 5000)"
    )
    conn.execute(
        "DELETE FROM power_incidents WHERE status='closed' AND id NOT IN (SELECT id FROM power_incidents ORDER BY id DESC LIMIT 5000)"
    )


def _destination_secret(row: Any) -> tuple[str, str]:
    provider = str(row["provider"] or "generic")
    encrypted = str(row["webhook_url_enc"] or "")
    if not encrypted:
        raise ValueError("Webhook destination is not configured")
    return provider, validate_webhook_url(decrypt_secret(encrypted), provider)


def _post_payload(provider: str, webhook_url: str, payload: dict[str, Any]) -> tuple[int, str]:
    # Re-validate immediately before the network connection. For generic endpoints
    # this also re-resolves the hostname and rejects private/link-local addresses.
    webhook_url = validate_webhook_url(webhook_url, provider)
    outgoing = _provider_payload(provider, payload)
    body = json.dumps(outgoing, ensure_ascii=False).encode("utf-8")
    request = Request(
        webhook_url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json, text/plain, */*",
            "User-Agent": f"Portivo-Control-Center/{settings.app_version}",
            "X-Portivo-Event-Id": str(payload.get("event_id") or ""),
            "X-Portivo-Event-Type": str(payload.get("event_type") or ""),
        },
    )
    try:
        with _WEBHOOK_OPENER.open(request, timeout=12) as response:  # noqa: S310 - destination is admin-configured and validated.
            text = response.read(4096).decode("utf-8", errors="replace")
            status = int(getattr(response, "status", 200) or 200)
            if status < 200 or status >= 300:
                raise RuntimeError(f"Webhook returned HTTP {status}")
            return status, text
    except HTTPError as exc:
        if 300 <= int(exc.code) < 400:
            raise RuntimeError("Webhook redirects are not allowed") from exc
        retry_after = exc.headers.get("Retry-After", "") if exc.headers else ""
        detail = exc.read(2048).decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        suffix = f"; Retry-After={retry_after}s" if retry_after else ""
        raise RuntimeError(f"Webhook returned HTTP {exc.code}{suffix}: {detail[:500]}") from exc
    except URLError as exc:
        raise RuntimeError(f"Webhook connection failed: {exc.reason}") from exc


def send_test_notification(destination_id: int) -> dict[str, Any]:
    with db() as conn:
        destination = conn.execute("SELECT * FROM notification_destinations WHERE id=?", (int(destination_id),)).fetchone()
        if not destination:
            raise ValueError("Notification destination was not found")
        provider, webhook = _destination_secret(destination)
        device = {"id": None, "name": "Portivo notification service", "host": "", "site": "", "group_name": "", "model": "", "aos_version": "", "profile": ""}
        payload = _build_payload(event_type="test", device=device, incident_id=None)
        outbox_id = _insert_outbox(conn, event_type="test", device=device, incident_id=None, payload=payload, destination_id=int(destination_id))
        conn.execute("UPDATE notification_outbox SET status='delivering' WHERE id=?", (outbox_id,))
    try:
        http_status, _ = _post_payload(provider, webhook, payload)
    except Exception as exc:
        now = utc_now()
        with db() as conn:
            conn.execute(
                "UPDATE notification_outbox SET status='failed', attempts=1, last_attempt_at=?, last_error=? WHERE id=?",
                (now, str(exc)[:1000], outbox_id),
            )
            conn.execute(
                "UPDATE notification_destinations SET last_test_at=?, last_test_status='failed', last_error=?, updated_at=? WHERE id=?",
                (now, str(exc)[:1000], now, int(destination_id)),
            )
        raise
    now = utc_now()
    with db() as conn:
        conn.execute(
            "UPDATE notification_outbox SET status='delivered', attempts=1, last_attempt_at=?, delivered_at=?, http_status=?, last_error='' WHERE id=?",
            (now, now, http_status, outbox_id),
        )
        conn.execute(
            "UPDATE notification_destinations SET last_test_at=?, last_test_status='delivered', last_delivery_at=?, last_delivery_status='delivered', last_error='', updated_at=? WHERE id=?",
            (now, now, now, int(destination_id)),
        )
        _trim_history(conn)
    return {"ok": True, "http_status": http_status, "delivered_at": now, "destination_id": int(destination_id)}


def _enqueue_due_reminders(conn: Any, policy: dict[str, Any]) -> None:
    minutes = int(policy.get("reminder_minutes") or 0)
    if minutes <= 0 or not policy.get("enabled"):
        return
    cutoff = _utc_dt() - timedelta(minutes=minutes)
    rows = conn.execute(
        """
        SELECT i.*, d.host, d.site, d.group_name, d.model, d.aos_version, d.profile,
               d.last_error, d.response_ms, d.consecutive_failures
        FROM notification_incidents i JOIN devices d ON d.id=i.device_id
        WHERE i.status='open' AND i.incident_type='switch_offline' AND i.first_delivery_at IS NOT NULL ORDER BY i.id
        """
    ).fetchall()
    for row in rows:
        marker = _parse_dt(row["last_reminder_at"] or row["first_delivery_at"])
        if not marker or marker > cutoff:
            continue
        device = {
            "id": row["device_id"], "name": row["device_name"], "host": row["host"], "site": row["site"],
            "group_name": row["group_name"], "model": row["model"], "aos_version": row["aos_version"],
            "profile": row["profile"], "last_error": row["last_error"], "response_ms": row["response_ms"],
            "consecutive_failures": row["consecutive_failures"],
        }
        delivered_destinations = conn.execute(
            "SELECT DISTINCT destination_id FROM notification_outbox WHERE incident_id=? AND event_type='switch_offline' AND status='delivered' AND destination_id IS NOT NULL",
            (row["id"],),
        ).fetchall()
        destination_ids = [int(item["destination_id"]) for item in delivered_destinations]
        if not destination_ids:
            continue
        payload = _build_payload(
            event_type="switch_offline_reminder", device=device, incident_id=int(row["id"]),
            failed_checks=int(row["consecutive_failures"] or 0), opened_at=row["opened_at"],
            last_reachable=row["last_reachable"], response_ms=row["response_ms"], error=str(row["last_error"] or ""),
        )
        for destination_id in destination_ids:
            pending = conn.execute(
                "SELECT id FROM notification_outbox WHERE incident_id=? AND destination_id=? AND event_type='switch_offline_reminder' AND status IN ('queued','retrying','delivering') LIMIT 1",
                (row["id"], destination_id),
            ).fetchone()
            if pending:
                continue
            destination = conn.execute("SELECT * FROM notification_destinations WHERE id=?", (destination_id,)).fetchone()
            if not destination or not bool(destination["enabled"]) or not _destination_accepts(destination, device, "switch_offline_reminder"):
                continue
            per_destination = dict(payload)
            per_destination["event_id"] = str(uuid.uuid4())
            _insert_outbox(
                conn, event_type="switch_offline_reminder", device=device, incident_id=int(row["id"]),
                payload=per_destination, destination_id=destination_id,
            )
        conn.execute("UPDATE notification_incidents SET last_reminder_at=?, updated_at=? WHERE id=?", (utc_now(), utc_now(), row["id"]))


def _process_one_delivery() -> bool:
    with db() as conn:
        policy = _policy_from_row(_policy_row(conn))
        _enqueue_due_reminders(conn, policy)
        row = conn.execute(
            """
            SELECT o.*, d.provider, d.webhook_url_enc, d.enabled AS destination_enabled
            FROM notification_outbox o
            LEFT JOIN notification_destinations d ON d.id=o.destination_id
            WHERE o.status IN ('queued','retrying') AND o.next_attempt_at<=?
            ORDER BY o.id LIMIT 1
            """,
            (utc_now(),),
        ).fetchone()
        if not row:
            return False
        if row["event_type"] != "test" and not policy["enabled"]:
            conn.execute("UPDATE notification_outbox SET status='cancelled', last_error='Notifications disabled' WHERE id=?", (row["id"],))
            return True
        if not row["destination_id"] or not bool(row["destination_enabled"]) or not row["webhook_url_enc"]:
            conn.execute("UPDATE notification_outbox SET status='cancelled', last_error='Webhook destination is unavailable or disabled' WHERE id=?", (row["id"],))
            return True
        provider = str(row["provider"] or "generic")
        webhook = validate_webhook_url(decrypt_secret(str(row["webhook_url_enc"])), provider)
        attempts = int(row["attempts"] or 0) + 1
        conn.execute(
            "UPDATE notification_outbox SET status='delivering', attempts=?, last_attempt_at=? WHERE id=?",
            (attempts, utc_now(), row["id"]),
        )
        payload = json.loads(row["payload_json"] or "{}")
        row_id = int(row["id"])
        incident_id = row["incident_id"]
        destination_id = int(row["destination_id"])
        event_type = str(row["event_type"])

    try:
        http_status, _ = _post_payload(provider, webhook, payload)
    except Exception as exc:
        now = utc_now()
        with db() as conn:
            incident_closed = False
            if incident_id and event_type in {"switch_offline", "switch_offline_reminder", "stack_degraded"}:
                incident_row = conn.execute("SELECT status FROM notification_incidents WHERE id=?", (incident_id,)).fetchone()
                incident_closed = bool(incident_row and incident_row["status"] == "closed")
            if incident_closed:
                status = "cancelled"
                next_attempt = now
                error_text = "Incident recovered before the alert could be delivered"
            elif attempts >= _MAX_OUTBOX_ATTEMPTS:
                status = "failed"
                next_attempt = now
                error_text = str(exc)[:1000]
            else:
                status = "retrying"
                delay = _RETRY_DELAYS_SECONDS[min(attempts - 1, len(_RETRY_DELAYS_SECONDS) - 1)]
                next_attempt = (_utc_dt() + timedelta(seconds=delay)).isoformat()
                error_text = str(exc)[:1000]
            conn.execute(
                "UPDATE notification_outbox SET status=?, next_attempt_at=?, last_error=? WHERE id=?",
                (status, next_attempt, error_text, row_id),
            )
            if status != "cancelled":
                conn.execute(
                    "UPDATE notification_destinations SET last_delivery_status=?, last_error=?, updated_at=? WHERE id=?",
                    (status, error_text, now, destination_id),
                )
        logger.warning("Webhook notification delivery failed for destination %s: %s", destination_id, exc)
        return True

    now = utc_now()
    with db() as conn:
        conn.execute(
            "UPDATE notification_outbox SET status='delivered', delivered_at=?, http_status=?, last_error='' WHERE id=?",
            (now, http_status, row_id),
        )
        conn.execute(
            "UPDATE notification_destinations SET last_delivery_at=?, last_delivery_status='delivered', last_error='', updated_at=? WHERE id=?",
            (now, now, destination_id),
        )
        if incident_id and event_type in {"switch_offline", "stack_degraded"}:
            conn.execute(
                "UPDATE notification_incidents SET first_delivery_at=COALESCE(first_delivery_at, ?), updated_at=? WHERE id=?",
                (now, now, incident_id),
            )
        _trim_history(conn)
    return True


def _recover_inflight_deliveries() -> None:
    now = utc_now()
    with db() as conn:
        conn.execute(
            """
            UPDATE notification_outbox SET status='retrying', next_attempt_at=?,
                last_error=CASE WHEN last_error='' THEN 'Recovered after Portivo restart' ELSE last_error END
            WHERE status='delivering'
            """,
            (now,),
        )


def _worker_loop() -> None:
    while not _worker_stop.is_set():
        try:
            worked = _process_one_delivery()
        except Exception as exc:  # pragma: no cover
            logger.exception("Notification worker failed", exc_info=exc)
            worked = False
        if worked:
            continue
        _worker_wake.wait(5)
        _worker_wake.clear()


def start_notification_worker() -> None:
    global _worker_thread
    if _worker_thread and _worker_thread.is_alive():
        return
    _worker_stop.clear()
    _worker_wake.clear()
    _recover_inflight_deliveries()
    _worker_thread = threading.Thread(target=_worker_loop, name="portivo-notifications", daemon=True)
    _worker_thread.start()


def stop_notification_worker() -> None:
    _worker_stop.set()
    _worker_wake.set()
    if _worker_thread and _worker_thread.is_alive():
        _worker_thread.join(timeout=15)
