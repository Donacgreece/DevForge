# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import hashlib
import secrets
import threading
import time
from dataclasses import dataclass

from .crypto import decrypt_secret, encrypt_secret


@dataclass
class SshSessionCredential:
    username: str
    password_enc: str
    created_at: float
    last_used_at: float


class SessionCredentialStore:
    """Process-local SSH credentials keyed by an opaque session token.

    The browser cookie contains only the random token. Passwords are encrypted in
    process memory and are never written to SQLite, job payloads, audit logs, or
    browser storage. A server restart or logout removes access to the credential.
    """

    def __init__(self, ttl_seconds: int = 8 * 60 * 60) -> None:
        self._ttl_seconds = ttl_seconds
        self._items: dict[str, SshSessionCredential] = {}
        self._lock = threading.RLock()

    def create(self, username: str, password: str) -> str:
        self.cleanup()
        normalized_username = username.strip()
        token = secrets.token_urlsafe(32)
        now = time.time()
        with self._lock:
            # A Portivo user owns one personal access credential at a time.
            # A fresh login invalidates older browser/session tokens for the
            # same username instead of leaving stale credentials active for
            # the full eight-hour inactivity window.
            existing_tokens = [
                existing_token
                for existing_token, item in self._items.items()
                if item.username.casefold() == normalized_username.casefold()
            ]
            for existing_token in existing_tokens:
                self._items.pop(existing_token, None)
            self._items[token] = SshSessionCredential(
                username=normalized_username,
                password_enc=encrypt_secret(password),
                created_at=now,
                last_used_at=now,
            )
        return token

    def revoke_username(self, username: str) -> int:
        normalized_username = str(username or "").strip().casefold()
        if not normalized_username:
            return 0
        with self._lock:
            tokens = [
                token for token, item in self._items.items()
                if item.username.casefold() == normalized_username
            ]
            for token in tokens:
                self._items.pop(token, None)
            return len(tokens)

    def get_device_credentials(self, token: str | None) -> dict[str, str] | None:
        if not token:
            return None
        now = time.time()
        with self._lock:
            item = self._items.get(token)
            if item is None:
                return None
            if now - item.last_used_at > self._ttl_seconds:
                self._items.pop(token, None)
                return None
            item.last_used_at = now
            return {"username": item.username, "password_enc": item.password_enc}

    def username(self, token: str | None) -> str | None:
        credentials = self.get_device_credentials(token)
        return credentials["username"] if credentials else None


    @staticmethod
    def _public_id(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]

    def list_sessions(self) -> list[dict[str, object]]:
        self.cleanup()
        now = time.time()
        with self._lock:
            return [
                {
                    "session_id": self._public_id(token),
                    "username": item.username,
                    "created_at": item.created_at,
                    "last_used_at": item.last_used_at,
                    "age_seconds": max(0, int(now - item.created_at)),
                    "idle_seconds": max(0, int(now - item.last_used_at)),
                }
                for token, item in sorted(self._items.items(), key=lambda pair: pair[1].created_at, reverse=True)
            ]

    def revoke_public_id(self, session_id: str) -> bool:
        with self._lock:
            for token in list(self._items):
                if self._public_id(token) == session_id:
                    self._items.pop(token, None)
                    return True
        return False

    def count(self) -> int:
        self.cleanup()
        with self._lock:
            return len(self._items)

    def remove(self, token: str | None) -> None:
        if not token:
            return
        with self._lock:
            self._items.pop(token, None)

    def clear_all(self) -> int:
        """Remove every process-local SSH credential and return the count."""
        with self._lock:
            count = len(self._items)
            self._items.clear()
            return count

    def cleanup(self) -> None:
        cutoff = time.time() - self._ttl_seconds
        with self._lock:
            expired = [token for token, item in self._items.items() if item.last_used_at < cutoff]
            for token in expired:
                self._items.pop(token, None)


session_credentials = SessionCredentialStore()
