# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import asyncio
import re
import socket
from typing import Any

ENTITY_PHYSICAL_TABLE = "1.3.6.1.2.1.47.1.1.1.1"
SYS_DESCR = "1.3.6.1.2.1.1.1.0"
SYS_UPTIME = "1.3.6.1.2.1.1.3.0"

_AUTH_PROTOCOLS = {
    "SHA": "USM_AUTH_HMAC96_SHA",
    "SHA256": "USM_AUTH_HMAC192_SHA256",
}
# Keep both operator-facing AES names. PySNMP represents standard SNMPv3 AES
# privacy as the RFC 3826 128-bit CFB protocol, so AES and AES128 resolve to
# the same wire protocol while the selected label is preserved in the profile.
# DES is retained for interoperability with legacy SNMPv3 agents and maps to
# the RFC 3414 CBC56-DES privacy protocol.
_PRIV_PROTOCOLS = {
    "AES": "USM_PRIV_CFB128_AES",
    "AES128": "USM_PRIV_CFB128_AES",
    "DES": "USM_PRIV_CBC56_DES",
}


def _normalize_oid(value: Any) -> str:
    return str(value or "").strip().lstrip(".")


def parse_entity_mib(varbinds: list[tuple[str, str]]) -> dict[str, Any]:
    """Parse ENTITY-MIB entPhysicalTable into stack member candidates.

    The parser is intentionally conservative. A stack is considered observable
    only when at least two physical chassis entries are present. Member identity
    prefers a numeric chassis/member token, then entPhysicalParentRelPos, then the
    stable entPhysicalIndex. No synthetic healthy result is produced from a
    single chassis entry.
    """
    base = ENTITY_PHYSICAL_TABLE + "."
    rows: dict[str, dict[int, str]] = {}
    for oid, value in varbinds:
        oid = _normalize_oid(oid)
        if not oid.startswith(base):
            continue
        tail = oid[len(base):].split(".")
        if len(tail) < 2 or not tail[0].isdigit():
            continue
        column = int(tail[0])
        index = tail[1]
        rows.setdefault(index, {})[column] = str(value or "").strip()

    chassis: list[dict[str, str]] = []
    for index, columns in rows.items():
        # entPhysicalClass: chassis(3)
        class_text = str(columns.get(5, "")).strip().lower()
        class_is_chassis = class_text in {"3", "chassis", "chassis(3)"} or class_text.endswith("(3)")
        if not class_is_chassis:
            continue
        name = columns.get(7, "")
        descr = columns.get(2, "")
        parent_pos = str(columns.get(6, "") or "").strip()
        member_id = ""
        for text in (name, descr):
            match = re.search(r"(?:member|chassis|switch|slot)\s*[-:#]?\s*(\d+)\b", text, re.I)
            if match:
                member_id = str(int(match.group(1)))
                break
        if not member_id and parent_pos.lstrip("-").isdigit() and int(parent_pos) > 0:
            member_id = str(int(parent_pos))
        if not member_id:
            member_id = f"ent:{index}"
        chassis.append({
            "id": member_id,
            "role": "",
            "status": "present",
            "mac": "",
            "model": columns.get(13, "") or descr,
            "serial": columns.get(11, ""),
            "name": name,
            "entity_index": index,
            "evidence": descr or name or f"ENTITY-MIB index {index}",
        })

    # De-duplicate member identifiers while preserving stable order.
    unique: dict[str, dict[str, str]] = {}
    for item in chassis:
        unique.setdefault(item["id"], item)
    members = sorted(unique.values(), key=lambda item: (0, int(item["id"])) if item["id"].isdigit() else (1, item["id"]))
    return {
        "ok": len(members) >= 2,
        "count": len(members),
        "member_ids": [item["id"] for item in members],
        "members": members,
        "count_source": "entity_mib_chassis" if len(members) >= 2 else "unavailable",
        "evidence": [item["evidence"] for item in members[:24]],
    }


def _pysnmp_imports():
    try:
        from pysnmp.hlapi.v3arch.asyncio import (  # type: ignore
            ContextData, ObjectIdentity, ObjectType, SnmpEngine, UdpTransportTarget,
            UsmUserData, bulk_walk_cmd, get_cmd,
            USM_AUTH_HMAC96_SHA, USM_AUTH_HMAC192_SHA256,
            USM_PRIV_CFB128_AES, USM_PRIV_CBC56_DES,
        )
    except Exception as exc:  # pragma: no cover - dependency is installed by the Portivo installer
        raise RuntimeError("PySNMP is not installed in the Portivo runtime") from exc
    return {
        "ContextData": ContextData, "ObjectIdentity": ObjectIdentity, "ObjectType": ObjectType,
        "SnmpEngine": SnmpEngine, "UdpTransportTarget": UdpTransportTarget, "UsmUserData": UsmUserData,
        "bulk_walk_cmd": bulk_walk_cmd, "get_cmd": get_cmd,
        "USM_AUTH_HMAC96_SHA": USM_AUTH_HMAC96_SHA,
        "USM_AUTH_HMAC192_SHA256": USM_AUTH_HMAC192_SHA256,
        "USM_PRIV_CFB128_AES": USM_PRIV_CFB128_AES,
        "USM_PRIV_CBC56_DES": USM_PRIV_CBC56_DES,
    }


def _auth_data(imports: dict[str, Any], profile: dict[str, Any]):
    """Build USM auth data using PySNMP's documented passphrase defaults.

    Do not force authKeyType/privKeyType. PySNMP already defaults both to
    passphrase material and performs remote engine discovery/localization. The
    simpler documented form has proven more interoperable with vendor agents.
    """
    auth_name = str(profile.get("snmp_auth_protocol") or "SHA").upper()
    priv_name = str(profile.get("snmp_priv_protocol") or "AES").upper()
    auth_const = imports[_AUTH_PROTOCOLS.get(auth_name, "USM_AUTH_HMAC96_SHA")]
    priv_const = imports[_PRIV_PROTOCOLS.get(priv_name, "USM_PRIV_CFB128_AES")]
    return imports["UsmUserData"](
        str(profile.get("username") or ""),
        authKey=str(profile.get("snmp_auth_password") or ""),
        privKey=str(profile.get("snmp_priv_password") or ""),
        authProtocol=auth_const,
        privProtocol=priv_const,
    )


def _route_source_ip(host: str, port: int) -> str:
    """Report which IPv4 source address the OS routing table selects.

    This is diagnostic only. Normal SNMP requests deliberately leave source
    binding to the OS, matching common desktop SNMP tools on the same server.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect((host, int(port)))
            return str(sock.getsockname()[0] or "")
    except Exception:
        return ""


async def _udp_target(
    imports: dict[str, Any],
    host: str,
    profile: dict[str, Any],
    *,
    bind_source: bool = False,
    timeout: float = 3.0,
    retries: int = 1,
):
    port = int(profile.get("snmp_port") or 161)
    # Normal telemetry keeps the historical request window. Lightweight health
    # probes override this with a shorter single-request budget.
    target = await imports["UdpTransportTarget"].create(
        (host, port), timeout=max(0.25, float(timeout)), retries=max(0, int(retries))
    )
    source_ip = _route_source_ip(host, port)
    if bind_source and source_ip and source_ip != "0.0.0.0":
        target.set_local_address((source_ip, 0))
    return target, source_ip


def _is_timeout(error: Any) -> bool:
    text = str(error or "").strip().lower()
    return "timeout" in text or "no snmp response" in text or "request timed out" in text


def _raise_snmp_error(error: Any, host: str, profile: dict[str, Any], source_ip: str = "", *, bound: bool = False) -> None:
    text = str(error or "").strip() or "SNMP request failed"
    if _is_timeout(text):
        port = int(profile.get("snmp_port") or 161)
        auth = str(profile.get("snmp_auth_protocol") or "SHA").upper()
        priv = str(profile.get("snmp_priv_protocol") or "AES").upper()
        source = f"; OS route source {source_ip}" if source_ip else ""
        mode = "; explicit source retry" if bound else "; OS-managed source"
        raise TimeoutError(f"No SNMPv3 response from {host}:{port}{source}{mode} using authPriv {auth}/{priv}")
    raise RuntimeError(text)


async def _get_sysdescr_once(host: str, profile: dict[str, Any], *, bind_source: bool = False) -> str:
    p = _pysnmp_imports()
    target, source_ip = await _udp_target(p, host, profile, bind_source=bind_source)
    engine = p["SnmpEngine"]()
    try:
        result = await p["get_cmd"](
            engine, _auth_data(p, profile), target, p["ContextData"](),
            p["ObjectType"](p["ObjectIdentity"](SYS_DESCR)), lookupMib=False,
        )
    finally:
        # PySNMP 7.1 SnmpEngine supports context-manager cleanup, but closing
        # through the dispatcher keeps this compatible with minor 7.1 releases.
        dispatcher = getattr(engine, "transport_dispatcher", None)
        if dispatcher is not None:
            try:
                dispatcher.close_dispatcher()
            except Exception:
                pass
    error_indication, error_status, error_index, var_binds = result
    if error_indication:
        _raise_snmp_error(error_indication, host, profile, source_ip, bound=bind_source)
    if error_status:
        raise RuntimeError(str(error_status.prettyPrint() if hasattr(error_status, "prettyPrint") else error_status))
    if not var_binds:
        raise RuntimeError("SNMPv3 returned no sysDescr value")
    return str(var_binds[0][1].prettyPrint() if hasattr(var_binds[0][1], "prettyPrint") else var_binds[0][1])


async def _get_sysdescr_async(host: str, profile: dict[str, Any]) -> str:
    """Verify SNMPv3 with OS-managed source first, then a bound-source fallback.

    Desktop SNMP tools normally let Windows/Linux choose the outbound source
    address. Portivo now mirrors that behavior first. Explicit source binding is
    retained only as a compatibility fallback for unusual multi-NIC setups.
    """
    first_error: Exception | None = None
    try:
        return await _get_sysdescr_once(host, profile, bind_source=False)
    except TimeoutError as exc:
        first_error = exc
    try:
        return await _get_sysdescr_once(host, profile, bind_source=True)
    except TimeoutError as exc:
        if first_error:
            raise TimeoutError(f"{first_error}; fallback also timed out") from exc
        raise


async def _walk_entity_once(host: str, profile: dict[str, Any], *, bind_source: bool = False) -> list[tuple[str, str]]:
    p = _pysnmp_imports()
    target, source_ip = await _udp_target(p, host, profile, bind_source=bind_source)
    engine = p["SnmpEngine"]()
    values: list[tuple[str, str]] = []
    try:
        iterator = p["bulk_walk_cmd"](
            engine, _auth_data(p, profile), target, p["ContextData"](), 0, 25,
            p["ObjectType"](p["ObjectIdentity"](ENTITY_PHYSICAL_TABLE)),
            lookupMib=False, lexicographicMode=False, maxRows=2048,
        )
        async for error_indication, error_status, error_index, var_binds in iterator:
            if error_indication:
                _raise_snmp_error(error_indication, host, profile, source_ip, bound=bind_source)
            if error_status:
                raise RuntimeError(str(error_status.prettyPrint() if hasattr(error_status, "prettyPrint") else error_status))
            for var_bind in var_binds:
                oid_obj, value_obj = var_bind[0], var_bind[1]
                oid = oid_obj.prettyPrint() if hasattr(oid_obj, "prettyPrint") else str(oid_obj)
                value = value_obj.prettyPrint() if hasattr(value_obj, "prettyPrint") else str(value_obj)
                values.append((str(oid), str(value)))
    finally:
        dispatcher = getattr(engine, "transport_dispatcher", None)
        if dispatcher is not None:
            try:
                dispatcher.close_dispatcher()
            except Exception:
                pass
    return values


async def _walk_entity_async(host: str, profile: dict[str, Any]) -> list[tuple[str, str]]:
    first_error: Exception | None = None
    try:
        return await _walk_entity_once(host, profile, bind_source=False)
    except TimeoutError as exc:
        first_error = exc
    try:
        return await _walk_entity_once(host, profile, bind_source=True)
    except TimeoutError as exc:
        if first_error:
            raise TimeoutError(f"{first_error}; fallback also timed out") from exc
        raise


def snmpv3_verify(host: str, profile: dict[str, Any]) -> str:
    return asyncio.run(_get_sysdescr_async(host, profile))


def snmpv3_stack_members(host: str, profile: dict[str, Any]) -> dict[str, Any]:
    varbinds = asyncio.run(_walk_entity_async(host, profile))
    parsed = parse_entity_mib(varbinds)
    if not parsed.get("ok"):
        raise RuntimeError("SNMPv3 ENTITY-MIB did not expose at least two chassis members")
    return parsed

async def _get_many_once(host: str, profile: dict[str, Any], oids: list[str], *, bind_source: bool = False) -> dict[str, str]:
    p = _pysnmp_imports()
    target, source_ip = await _udp_target(p, host, profile, bind_source=bind_source)
    engine = p["SnmpEngine"]()
    try:
        objects = [p["ObjectType"](p["ObjectIdentity"](_normalize_oid(oid))) for oid in oids]
        result = await p["get_cmd"](
            engine, _auth_data(p, profile), target, p["ContextData"](), *objects, lookupMib=False,
        )
    finally:
        dispatcher = getattr(engine, "transport_dispatcher", None)
        if dispatcher is not None:
            try:
                dispatcher.close_dispatcher()
            except Exception:
                pass
    error_indication, error_status, error_index, var_binds = result
    if error_indication:
        _raise_snmp_error(error_indication, host, profile, source_ip, bound=bind_source)
    if error_status:
        raise RuntimeError(str(error_status.prettyPrint() if hasattr(error_status, "prettyPrint") else error_status))
    values: dict[str, str] = {}
    for var_bind in var_binds or []:
        oid_obj, value_obj = var_bind[0], var_bind[1]
        oid = _normalize_oid(oid_obj.prettyPrint() if hasattr(oid_obj, "prettyPrint") else oid_obj)
        value = value_obj.prettyPrint() if hasattr(value_obj, "prettyPrint") else str(value_obj)
        values[oid] = str(value)
    return values


async def _get_many_async(host: str, profile: dict[str, Any], oids: list[str]) -> dict[str, str]:
    first_error: Exception | None = None
    try:
        return await _get_many_once(host, profile, oids, bind_source=False)
    except TimeoutError as exc:
        first_error = exc
    try:
        return await _get_many_once(host, profile, oids, bind_source=True)
    except TimeoutError as exc:
        if first_error:
            raise TimeoutError(f"{first_error}; fallback also timed out") from exc
        raise


async def _walk_oid_once(host: str, profile: dict[str, Any], oid: str, *, bind_source: bool = False, max_rows: int = 512) -> list[tuple[str, str]]:
    p = _pysnmp_imports()
    target, source_ip = await _udp_target(p, host, profile, bind_source=bind_source)
    engine = p["SnmpEngine"]()
    values: list[tuple[str, str]] = []
    try:
        iterator = p["bulk_walk_cmd"](
            engine, _auth_data(p, profile), target, p["ContextData"](), 0, 25,
            p["ObjectType"](p["ObjectIdentity"](_normalize_oid(oid))),
            lookupMib=False, lexicographicMode=False, maxRows=max(1, int(max_rows)),
        )
        async for error_indication, error_status, error_index, var_binds in iterator:
            if error_indication:
                _raise_snmp_error(error_indication, host, profile, source_ip, bound=bind_source)
            if error_status:
                raise RuntimeError(str(error_status.prettyPrint() if hasattr(error_status, "prettyPrint") else error_status))
            for var_bind in var_binds:
                oid_obj, value_obj = var_bind[0], var_bind[1]
                actual_oid = _normalize_oid(oid_obj.prettyPrint() if hasattr(oid_obj, "prettyPrint") else oid_obj)
                value = value_obj.prettyPrint() if hasattr(value_obj, "prettyPrint") else str(value_obj)
                values.append((actual_oid, str(value)))
    finally:
        dispatcher = getattr(engine, "transport_dispatcher", None)
        if dispatcher is not None:
            try:
                dispatcher.close_dispatcher()
            except Exception:
                pass
    return values


async def _walk_oid_async(host: str, profile: dict[str, Any], oid: str, *, max_rows: int = 512) -> list[tuple[str, str]]:
    first_error: Exception | None = None
    try:
        return await _walk_oid_once(host, profile, oid, bind_source=False, max_rows=max_rows)
    except TimeoutError as exc:
        first_error = exc
    try:
        return await _walk_oid_once(host, profile, oid, bind_source=True, max_rows=max_rows)
    except TimeoutError as exc:
        if first_error:
            raise TimeoutError(f"{first_error}; fallback also timed out") from exc
        raise


def snmpv3_get_many(host: str, profile: dict[str, Any], oids: list[str]) -> dict[str, str]:
    normalized = [_normalize_oid(oid) for oid in oids if _normalize_oid(oid)]
    if not normalized:
        return {}
    return asyncio.run(_get_many_async(host, profile, normalized))


def snmpv3_walk(host: str, profile: dict[str, Any], oid: str, *, max_rows: int = 512) -> list[tuple[str, str]]:
    return asyncio.run(_walk_oid_async(host, profile, _normalize_oid(oid), max_rows=max_rows))


async def _health_probe_async(host: str, profile: dict[str, Any], *, timeout: float = 1.5) -> str:
    """Perform one lightweight authenticated SNMPv3 GET for sysUpTime.0.

    Unlike detailed telemetry, this path deliberately uses one request window
    and no source-binding retry so background availability monitoring stays
    bounded on large fleets. A failure here never makes a ping-reachable switch
    offline; callers keep SNMP telemetry state separate from reachability.
    """
    p = _pysnmp_imports()
    target, source_ip = await _udp_target(
        p, host, profile, bind_source=False, timeout=timeout, retries=0
    )
    engine = p["SnmpEngine"]()
    try:
        result = await p["get_cmd"](
            engine, _auth_data(p, profile), target, p["ContextData"](),
            p["ObjectType"](p["ObjectIdentity"](SYS_UPTIME)), lookupMib=False,
        )
    finally:
        dispatcher = getattr(engine, "transport_dispatcher", None)
        if dispatcher is not None:
            try:
                dispatcher.close_dispatcher()
            except Exception:
                pass
    error_indication, error_status, error_index, var_binds = result
    if error_indication:
        _raise_snmp_error(error_indication, host, profile, source_ip, bound=False)
    if error_status:
        raise RuntimeError(str(error_status.prettyPrint() if hasattr(error_status, "prettyPrint") else error_status))
    if not var_binds:
        raise RuntimeError("SNMPv3 returned no sysUpTime value")
    value = var_binds[0][1]
    return str(value.prettyPrint() if hasattr(value, "prettyPrint") else value)


def snmpv3_health_probe(host: str, profile: dict[str, Any], *, timeout: float = 1.5) -> str:
    """Lightweight SNMPv3 liveness/telemetry probe used by switch health."""
    return asyncio.run(_health_probe_async(host, profile, timeout=timeout))
