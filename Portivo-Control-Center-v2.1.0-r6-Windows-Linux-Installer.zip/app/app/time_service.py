# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from datetime import date, datetime, time, timezone
from functools import lru_cache
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError, available_timezones

from .db import get_app_setting

DEFAULT_PLATFORM_TIMEZONE = "UTC"


@lru_cache(maxsize=128)
def _zone(name: str) -> ZoneInfo:
    return ZoneInfo(name)


def validate_timezone_name(value: str | None) -> str:
    name = str(value or "").strip() or DEFAULT_PLATFORM_TIMEZONE
    if len(name) > 120:
        raise ValueError("Timezone name is too long")
    try:
        _zone(name)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise ValueError(f"Unknown IANA timezone: {name}") from exc
    return name


def platform_timezone_name() -> str:
    configured = get_app_setting("platform_timezone", DEFAULT_PLATFORM_TIMEZONE)
    try:
        return validate_timezone_name(configured)
    except ValueError:
        return DEFAULT_PLATFORM_TIMEZONE


def platform_zone() -> ZoneInfo:
    return _zone(platform_timezone_name())


def parse_timestamp(value: object) -> datetime | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        parsed = value
    else:
        raw = str(value).strip()
        if not raw:
            return None
        try:
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def to_platform_datetime(value: object) -> datetime | None:
    parsed = parse_timestamp(value)
    return parsed.astimezone(platform_zone()) if parsed else None


def format_platform_datetime(value: object, *, fmt: str = "%d/%m/%Y %H:%M:%S", fallback: str = "-") -> str:
    localized = to_platform_datetime(value)
    return localized.strftime(fmt) if localized else fallback


def platform_now() -> datetime:
    return datetime.now(timezone.utc).astimezone(platform_zone())


def local_date_boundary_utc(value: str, *, end_of_day: bool = False) -> datetime:
    """Convert a local calendar-day boundary in the Platform Timezone to UTC.

    End-of-day returns the start of the following local day and is intended for
    an exclusive '<' comparison. This remains correct across DST transitions.
    """
    parsed_date = date.fromisoformat(str(value).strip())
    boundary_date = parsed_date
    if end_of_day:
        boundary_date = date.fromordinal(parsed_date.toordinal() + 1)
    localized = datetime.combine(boundary_date, time.min, tzinfo=platform_zone())
    return localized.astimezone(timezone.utc)


def available_timezone_names() -> list[str]:
    names = set(available_timezones())
    names.add("UTC")
    preferred = [
        "UTC", "Europe/Athens", "Europe/London", "Europe/Berlin", "Europe/Paris",
        "Europe/Rome", "Europe/Madrid", "America/New_York", "America/Chicago",
        "America/Denver", "America/Los_Angeles", "Asia/Dubai", "Asia/Singapore",
        "Asia/Tokyo", "Australia/Sydney",
    ]
    ordered = [name for name in preferred if name in names]
    ordered.extend(sorted(names.difference(ordered)))
    return ordered
