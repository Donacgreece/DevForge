# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
from typing import Any

# Common OmniSwitch model suffixes expose the access-port count directly, for
# example OS6560-P48X4, OS6450-24 and OS6860E-P48. The optional X suffix is
# treated as a dedicated uplink count and is kept outside the symmetric access
# port front panel.
_LAYOUT_PATTERNS = (
    re.compile(r"(?:^|[-_])(?:P|U)?(?P<access>8|12|16|24|28|32|40|48)(?:X(?P<uplinks>2|4|6|8)?)?(?:$|[-_])", re.I),
    re.compile(r"(?:^|[-_])X(?P<access>24|32|40|48|72)(?:$|[-_])", re.I),
)

# Compact OS6360 models use a marketing suffix of 10 even though the physical
# front panel exposes eight access ports plus four dedicated uplink interfaces
# (two copper and two SFP). Treat these explicitly instead of interpreting the
# suffix as a generic access-port count.
_OS6360_COMPACT_RE = re.compile(r"OS6360[-_]?(?:P)?10(?!\d)", re.I)
_OS6360_FAMILY_RE = re.compile(r"OS6360(?!\d)", re.I)


def is_compact_os6360_model(model: str) -> bool:
    """Return True for OS6360-10/P10 strings, even when inventory text follows the model.

    Real device identity strings are not always a bare marketing SKU. Some AOS
    releases append revision or descriptive text, so matching must stop at the
    numeric SKU boundary rather than requiring the model string to end there.
    """
    normalized = re.sub(r"\s+", "-", str(model or "").upper()).strip("-")
    return bool(_OS6360_COMPACT_RE.search(normalized))


def is_os6360_family_model(model: str) -> bool:
    """Return True when identity evidence points to the OS6360 family."""
    normalized = re.sub(r"\s+", "-", str(model or "").upper()).strip("-")
    return bool(_OS6360_FAMILY_RE.search(normalized))


def infer_compact_os6360_from_live_ports(model: str, ports: Any, profile: str = "AOS8") -> bool:
    """Infer the compact 8+4 OS6360 chassis from authoritative live interface rows.

    Some AOS releases report only the generic ``OS6360`` family in identity
    commands. In that case Portivo may still identify the compact chassis when
    the live interface evidence is unambiguous: physical ports 1..12 are all
    present, there are no ports 13..99, and any additional numeric rows are
    high-numbered pseudo/summary identifiers such as 108/111/120.

    The heuristic is deliberately restricted to AOS8 and the OS6360 family so
    an unknown switch from another family is never assigned a fabricated layout.
    """
    if is_compact_os6360_model(model):
        return True
    if not is_os6360_family_model(model):
        return False

    numbers: set[int] = set()
    for value in ports or []:
        token = str(value.get("port") if isinstance(value, dict) else value or "").strip()
        parts = token.split("/")
        if len(parts) not in (2, 3) or not all(part.isdigit() for part in parts):
            continue
        numbers.add(int(parts[-1]))
    if not set(range(1, 13)).issubset(numbers):
        return False
    if any(13 <= number < 100 for number in numbers):
        return False
    # Generic-family inference is intentionally reserved for the exact field
    # shape that exposed the original bug. At least one high pseudo/summary row
    # must be present, otherwise a partially parsed larger OS6360 must not be
    # mistaken for the compact chassis.
    if not any(number >= 100 for number in numbers):
        return False
    return True


def compact_os6360_port_allowed(port: str, profile: str = "AOS8") -> bool:
    """Validate a physical compact OS6360 front-panel interface identifier.

    OS6360-10/P10 expose twelve physical data interfaces. CLI summary/pseudo
    rows outside that range must never be rendered as front-panel ports.
    Chassis numbering is intentionally left flexible for Virtual Chassis.
    """
    parts = str(port or "").strip().split("/")
    # AOS8 normally reports slot/module/port, but some compatibility views can
    # expose slot/port. Once the chassis is positively identified as compact,
    # the physical-port decision is the final numeric component, not the view's
    # formatting depth.
    if len(parts) not in (2, 3) or not all(part.isdigit() for part in parts):
        return False
    number = int(parts[-1])
    return 1 <= number <= 12


def _port_name(profile: str, number: int) -> str:
    return f"1/1/{number}" if str(profile or "AOS8").upper() == "AOS8" else f"1/{number}"


def infer_device_port_layout(model: str, profile: str = "AOS8") -> dict[str, Any]:
    """Return a conservative logical front-panel layout for a detected model.

    A layout is returned only when the model string clearly includes a known
    port-count suffix. Unknown models are left unresolved instead of inventing
    a physical layout. Live inventory data can still populate the map normally.
    """
    normalized = re.sub(r"\s+", "-", str(model or "").upper()).strip("-")
    access_ports = 0
    uplink_ports = 0

    if is_compact_os6360_model(normalized):
        access_ports = 8
        uplink_ports = 4

    for pattern in _LAYOUT_PATTERNS if access_ports == 0 else ():
        matches = list(pattern.finditer(normalized))
        if not matches:
            continue
        match = matches[-1]
        access_ports = int(match.group("access"))
        uplink_ports = int(match.groupdict().get("uplinks") or 0)
        break

    if access_ports <= 0:
        return {
            "known": False,
            "access_ports": 0,
            "uplink_ports": 0,
            "total_ports": 0,
            "modules": [],
        }

    access = [_port_name(profile, number) for number in range(1, access_ports + 1)]
    uplinks = [
        _port_name(profile, number)
        for number in range(access_ports + 1, access_ports + uplink_ports + 1)
    ]
    modules: list[dict[str, Any]] = [
        {
            "id": "access",
            "label": "Access ports",
            "role": "access",
            "ports": access,
        }
    ]
    if uplinks:
        modules.append(
            {
                "id": "uplinks",
                "label": "Uplinks",
                "role": "uplink",
                "ports": uplinks,
            }
        )
    return {
        "known": True,
        "access_ports": access_ports,
        "uplink_ports": uplink_ports,
        "total_ports": access_ports + uplink_ports,
        "modules": modules,
    }
