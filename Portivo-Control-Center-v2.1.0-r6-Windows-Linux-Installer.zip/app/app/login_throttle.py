# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Deque


@dataclass(frozen=True)
class RateLimitDecision:
    allowed: bool
    retry_after_seconds: int = 0
    pair_failures: int = 0
    ip_failures: int = 0


class LoginRateLimiter:
    """In-memory progressive login throttling without hard account lockout.

    Failures are tracked by both source IP + username and source IP. Delays are
    enforced before any local password verification or SSH/AAA attempt. State is
    time-bounded and periodically compacted so random usernames cannot grow the
    limiter indefinitely.
    """

    def __init__(self, *, window_seconds: int = 300, max_delay_seconds: int = 30) -> None:
        self.window_seconds = max(60, int(window_seconds))
        self.max_delay_seconds = max(1, int(max_delay_seconds))
        self._lock = threading.Lock()
        self._pair_failures: dict[tuple[str, str], Deque[float]] = defaultdict(deque)
        self._ip_failures: dict[str, Deque[float]] = defaultdict(deque)
        self._pair_blocked_until: dict[tuple[str, str], float] = {}
        self._ip_blocked_until: dict[str, float] = {}
        self._operations = 0

    @staticmethod
    def _normalize_ip(value: str) -> str:
        normalized = str(value or "unknown").strip()
        return normalized[:128] or "unknown"

    @staticmethod
    def _normalize_username(value: str) -> str:
        return str(value or "").strip().casefold()[:120]

    def _purge(self, entries: Deque[float], now: float) -> None:
        cutoff = now - self.window_seconds
        while entries and entries[0] < cutoff:
            entries.popleft()

    def _compact_locked(self, now: float) -> None:
        self._operations += 1
        if self._operations % 256:
            return
        for key, entries in list(self._pair_failures.items()):
            self._purge(entries, now)
            if not entries:
                self._pair_failures.pop(key, None)
        for key, entries in list(self._ip_failures.items()):
            self._purge(entries, now)
            if not entries:
                self._ip_failures.pop(key, None)
        self._pair_blocked_until = {key: until for key, until in self._pair_blocked_until.items() if until > now}
        self._ip_blocked_until = {key: until for key, until in self._ip_blocked_until.items() if until > now}

    def _pair_delay(self, failures: int) -> int:
        if failures <= 3:
            return 0
        if failures == 4:
            return 2
        if failures == 5:
            return 5
        if failures == 6:
            return 10
        return self.max_delay_seconds

    def _ip_delay(self, failures: int) -> int:
        # The IP-wide threshold is intentionally higher so a few mistyped
        # passwords from a shared admin workstation do not penalize everyone.
        if failures < 10:
            return 0
        if failures < 15:
            return 2
        if failures < 20:
            return 5
        if failures < 25:
            return 10
        return self.max_delay_seconds

    def check(self, source_ip: str, username: str) -> RateLimitDecision:
        now = time.monotonic()
        ip = self._normalize_ip(source_ip)
        pair = (ip, self._normalize_username(username))
        with self._lock:
            self._compact_locked(now)
            pair_entries = self._pair_failures.get(pair)
            ip_entries = self._ip_failures.get(ip)
            if pair_entries is not None:
                self._purge(pair_entries, now)
                if not pair_entries:
                    self._pair_failures.pop(pair, None)
                    pair_entries = None
            if ip_entries is not None:
                self._purge(ip_entries, now)
                if not ip_entries:
                    self._ip_failures.pop(ip, None)
                    ip_entries = None
            blocked_until = max(
                self._pair_blocked_until.get(pair, 0.0),
                self._ip_blocked_until.get(ip, 0.0),
            )
            pair_count = len(pair_entries) if pair_entries is not None else 0
            ip_count = len(ip_entries) if ip_entries is not None else 0
            if blocked_until <= now:
                self._pair_blocked_until.pop(pair, None)
                self._ip_blocked_until.pop(ip, None)
                return RateLimitDecision(True, 0, pair_count, ip_count)
            retry_after = max(1, int(blocked_until - now + 0.999))
            return RateLimitDecision(False, retry_after, pair_count, ip_count)

    def record_failure(self, source_ip: str, username: str) -> RateLimitDecision:
        now = time.monotonic()
        ip = self._normalize_ip(source_ip)
        pair = (ip, self._normalize_username(username))
        with self._lock:
            self._compact_locked(now)
            pair_entries = self._pair_failures[pair]
            ip_entries = self._ip_failures[ip]
            self._purge(pair_entries, now)
            self._purge(ip_entries, now)
            pair_entries.append(now)
            ip_entries.append(now)
            pair_delay = self._pair_delay(len(pair_entries))
            ip_delay = self._ip_delay(len(ip_entries))
            if pair_delay:
                self._pair_blocked_until[pair] = max(self._pair_blocked_until.get(pair, 0.0), now + pair_delay)
            if ip_delay:
                self._ip_blocked_until[ip] = max(self._ip_blocked_until.get(ip, 0.0), now + ip_delay)
            return RateLimitDecision(True, max(pair_delay, ip_delay), len(pair_entries), len(ip_entries))

    def record_success(self, source_ip: str, username: str) -> None:
        ip = self._normalize_ip(source_ip)
        pair = (ip, self._normalize_username(username))
        with self._lock:
            self._pair_failures.pop(pair, None)
            self._pair_blocked_until.pop(pair, None)
            # IP-wide failures are intentionally retained until the window
            # expires so one valid account cannot erase brute-force history
            # against other usernames from the same source.

    def status(self) -> dict[str, int]:
        now = time.monotonic()
        with self._lock:
            self._compact_locked(now)
            active_pairs = sum(1 for until in self._pair_blocked_until.values() if until > now)
            active_ips = sum(1 for until in self._ip_blocked_until.values() if until > now)
        return {
            "window_seconds": self.window_seconds,
            "max_delay_seconds": self.max_delay_seconds,
            "active_pair_blocks": active_pairs,
            "active_ip_blocks": active_ips,
        }
