# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import hashlib
import re
import socket
import time
from dataclasses import dataclass
from typing import Any

try:
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException
except ImportError:  # Allows the UI and dry-run mode to start before dependencies are installed.
    ConnectHandler = None

    class NetmikoAuthenticationException(Exception):
        pass

    class NetmikoTimeoutException(Exception):
        pass

from .config import settings
from .crypto import decrypt_secret
from .ssh_coordinator import SSHDeviceBusyError, SSHLease, ssh_coordinator
from .vendor_drivers import command_failed as driver_command_failed, netmiko_device_type



@dataclass
class CommandResult:
    ok: bool
    output: str = ""
    error: str = ""


@dataclass
class CommandCollectionResult:
    connected: bool
    outputs: dict[str, str]
    errors: dict[str, str]
    connection_error: str = ""


class SSHConnectionFailure(RuntimeError):
    pass


class SSHAuthenticationFailure(SSHConnectionFailure):
    pass


class SSHTimeoutFailure(SSHConnectionFailure):
    pass


def _connection_args(device: dict[str, Any], *, connect_timeout: float | None = None) -> dict[str, Any]:
    profile = str(device.get("profile") or "AOS8")
    timeout = settings.ssh_connect_timeout if connect_timeout is None else max(0.5, float(connect_timeout))
    return {
        "device_type": netmiko_device_type(profile),
        "host": device["host"],
        "port": int(device["ssh_port"]),
        "username": device["username"],
        "password": decrypt_secret(device["password_enc"]),
        "conn_timeout": timeout,
        "auth_timeout": timeout,
        "banner_timeout": timeout,
        "read_timeout_override": settings.ssh_command_timeout,
        "fast_cli": False,
    }


def _looks_failed(device: dict[str, Any], output: str) -> bool:
    return driver_command_failed(str(device.get("profile") or "AOS8"), output)


def _device_id(device: dict[str, Any]) -> int | None:
    try:
        value = int(device.get("id"))
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def _transient_error(exc: Exception) -> bool:
    if isinstance(exc, (NetmikoTimeoutException, TimeoutError, ConnectionError, EOFError, OSError, socket.timeout)):
        return True
    message = str(exc).lower()
    return any(
        token in message
        for token in (
            "timed out",
            "timeout",
            "connection reset",
            "connection refused",
            "banner",
            "eof",
            "not open",
            "channel closed",
            "transport is not active",
        )
    )


def _credential_fingerprint(args: dict[str, Any]) -> str:
    username = str(args.get("username") or "")
    password = str(args.get("password") or "")
    if not username and not password:
        return ""
    key = str(getattr(settings, "secret_key", "portivo-session-key")).encode("utf-8")
    return hashlib.blake2b(
        f"{username}\0{password}".encode("utf-8"),
        key=key[:64],
        digest_size=20,
    ).hexdigest()


def _connect_with_retry(device: dict[str, Any]) -> Any:
    if ConnectHandler is None:
        raise SSHConnectionFailure("Netmiko is not installed. Run pip install -r requirements.txt")
    attempts = max(1, int(settings.ssh_connect_retries))
    last_error: Exception | None = None
    args = _connection_args(device)
    device_id = _device_id(device)
    credential_fingerprint = _credential_fingerprint(args)

    for attempt in range(1, attempts + 1):
        try:
            connection = ConnectHandler(**args)
            if device_id is not None:
                ssh_coordinator.mark_connection_success(device_id, credential_fingerprint)
            return connection
        except NetmikoAuthenticationException as exc:
            last_error = exc
            # Some OmniSwitch/AOS combinations briefly reject a fresh login while
            # the previous SSH session or flash save is still settling. Retry an
            # authentication failure only when the exact same credentials were
            # proven on this switch very recently. Bad/new credentials still fail
            # immediately, avoiding unnecessary lockout risk.
            recently_valid = bool(
                device_id is not None
                and ssh_coordinator.credentials_succeeded_recently(
                    device_id,
                    credential_fingerprint,
                    within_seconds=settings.ssh_recent_auth_success_window_seconds,
                )
            )
            if attempt >= attempts or not recently_valid:
                raise SSHAuthenticationFailure("SSH authentication failed") from exc
            time.sleep(settings.ssh_recent_auth_retry_delay_seconds + max(0, attempt - 1))
        except Exception as exc:
            last_error = exc
            if attempt >= attempts or not _transient_error(exc):
                break
            time.sleep(settings.ssh_retry_backoff_seconds * attempt)
    if isinstance(last_error, NetmikoAuthenticationException):
        raise SSHAuthenticationFailure("SSH authentication failed") from last_error
    if isinstance(last_error, NetmikoTimeoutException) or (last_error and _transient_error(last_error)):
        raise SSHTimeoutFailure(f"SSH connection failed after {attempts} attempts: {last_error}") from last_error
    raise SSHConnectionFailure(f"{type(last_error).__name__}: {last_error}") from last_error


def authenticate_login_once(
    device: dict[str, Any],
    username: str,
    password_enc: str,
    *,
    timeout: float | None = None,
) -> CommandResult:
    """Perform one bounded SSH authentication attempt for interactive sign-in.

    Login intentionally bypasses normal operation retry/backoff policy. A bad
    credential must fail immediately and an unavailable authentication source
    must hand off quickly to the next configured source.
    """
    if ConnectHandler is None:
        return CommandResult(ok=False, error="Netmiko is not installed. Run pip install -r requirements.txt")
    candidate = {**device, "username": username, "password_enc": password_enc}
    args = _connection_args(candidate, connect_timeout=timeout or settings.auth_connect_timeout)
    connection = None
    try:
        connection = ConnectHandler(**args)
        device_id = _device_id(candidate)
        if device_id is not None:
            ssh_coordinator.mark_connection_success(device_id, _credential_fingerprint(args))
        return CommandResult(ok=True, output="SSH authentication accepted")
    except NetmikoAuthenticationException:
        return CommandResult(ok=False, error="SSH authentication failed")
    except NetmikoTimeoutException as exc:
        return CommandResult(ok=False, error=f"SSH authentication source timed out: {exc}")
    except Exception as exc:
        return CommandResult(ok=False, error=f"{type(exc).__name__}: {exc}")
    finally:
        if connection is not None:
            try:
                connection.disconnect()
            except Exception:
                pass


class ManagedCommandSession:
    """One serialized SSH connection used for several switch commands."""

    def __init__(
        self,
        device: dict[str, Any],
        *,
        operation: str = "SSH operation",
        lock_timeout: float | None = None,
    ) -> None:
        self.device = device
        self.operation = operation
        self.lock_timeout = settings.ssh_operation_lock_timeout if lock_timeout is None else float(lock_timeout)
        self.connection: Any = None
        self.lease: SSHLease | None = None
        self._release_cooldown_seconds = 0.0

    def __enter__(self) -> "ManagedCommandSession":
        device_id = _device_id(self.device)
        if device_id is not None:
            self.lease = ssh_coordinator.acquire_automation(device_id, self.operation, self.lock_timeout)
        try:
            self.connection = _connect_with_retry(self.device)
            return self
        except Exception:
            if self.lease is not None:
                self.lease.release()
                self.lease = None
            raise

    def set_release_cooldown(self, seconds: float) -> None:
        self._release_cooldown_seconds = max(self._release_cooldown_seconds, max(0.0, float(seconds)))

    def wait_for_prompt(self, *, timeout: float = 20.0, poll_interval: float = 0.5) -> CommandResult:
        """Wait until the switch exposes a stable CLI prompt again.

        Flash saves can return timing output before the switch is ready to accept
        a brand-new SSH login. Keeping the per-device lease while waiting here
        prevents the next Job from racing the tail end of the save.
        """
        if self.connection is None:
            return CommandResult(ok=False, error="SSH command session is not connected")
        deadline = time.monotonic() + max(0.1, float(timeout))
        last_error = ""
        while True:
            try:
                prompt = str(self.connection.find_prompt() or "").strip()
                if prompt:
                    return CommandResult(ok=True, output=prompt)
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return CommandResult(
                    ok=False,
                    error=last_error or "The switch did not return a stable CLI prompt after the save",
                )
            time.sleep(min(max(0.05, float(poll_interval)), remaining))

    def execute_confirmed_reload(self, command: str, *, confirmation: str = "y", read_timeout: int | None = None) -> CommandResult:
        """Send a reload command, require the switch confirmation prompt, then answer it.

        A successful return means the switch accepted the reload request. The SSH
        session may disappear immediately afterwards, which is expected behavior.
        """
        if self.connection is None:
            return CommandResult(ok=False, error="SSH command session is not connected")
        try:
            output = self.connection.send_command_timing(
                command, strip_prompt=False, strip_command=False,
                read_timeout=read_timeout or settings.ssh_command_timeout,
            )
            if _looks_failed(self.device, output):
                return CommandResult(ok=False, output=output, error="The switch rejected the reload command")
            lowered = str(output or "").lower()
            if "confirm" not in lowered and "(y/n" not in lowered and "[y/n" not in lowered:
                return CommandResult(
                    ok=False, output=output,
                    error="The switch did not present a reload confirmation prompt. No confirmation was sent.",
                )
            # Do not wait for a new CLI prompt. A reload normally tears down the
            # transport immediately after the confirmation is accepted.
            self.connection.write_channel(f"{confirmation}\n")
            time.sleep(0.45)
            tail = ""
            try:
                tail = str(self.connection.read_channel() or "")
            except Exception:
                tail = ""
            combined = (str(output or "") + ("\n" + tail if tail else "")).strip()
            return CommandResult(ok=True, output=combined or "Reload confirmation sent")
        except NetmikoAuthenticationException:
            return CommandResult(ok=False, error="SSH authentication failed")
        except NetmikoTimeoutException:
            return CommandResult(ok=False, error="SSH reload command timed out before confirmation")
        except Exception as exc:
            return CommandResult(ok=False, error=f"{type(exc).__name__}: {exc}")

    def execute(self, command: str, *, read_timeout: int | None = None) -> CommandResult:
        if self.connection is None:
            return CommandResult(ok=False, error="SSH command session is not connected")
        try:
            output = self.connection.send_command_timing(
                command,
                strip_prompt=False,
                strip_command=False,
                read_timeout=read_timeout or settings.ssh_command_timeout,
            )
            if _looks_failed(self.device, output):
                return CommandResult(ok=False, output=output, error="The switch rejected the command")
            return CommandResult(ok=True, output=output)
        except NetmikoAuthenticationException:
            return CommandResult(ok=False, error="SSH authentication failed")
        except NetmikoTimeoutException:
            return CommandResult(ok=False, error="SSH command timed out")
        except Exception as exc:
            return CommandResult(ok=False, error=f"{type(exc).__name__}: {exc}")

    def close(self) -> None:
        if self.connection is not None:
            try:
                self.connection.disconnect()
            except Exception:
                pass
            self.connection = None
        if self.lease is not None:
            if self._release_cooldown_seconds:
                self.lease.set_cooldown(self._release_cooldown_seconds)
            self.lease.release()
            self.lease = None

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()


def command_session(
    device: dict[str, Any],
    *,
    operation: str = "SSH operation",
    lock_timeout: float | None = None,
) -> ManagedCommandSession:
    return ManagedCommandSession(device, operation=operation, lock_timeout=lock_timeout)


def _connection_error_text(exc: Exception) -> str:
    if isinstance(exc, SSHDeviceBusyError):
        return str(exc)
    if isinstance(exc, SSHAuthenticationFailure):
        return "SSH authentication failed"
    if isinstance(exc, SSHTimeoutFailure):
        return str(exc)
    if isinstance(exc, SSHConnectionFailure):
        return str(exc)
    return f"{type(exc).__name__}: {exc}"


def run_session_commands(
    session: ManagedCommandSession,
    commands: list[str],
    *,
    pause_between: float = 0.3,
    read_timeout: int | None = None,
) -> CommandResult:
    """Execute commands through an already-owned SSH session.

    This is used by atomic configuration transactions so the primary command,
    verification and persistent save keep the same per-device lock and the
    same SSH connection from start to finish.
    """
    combined: list[str] = []
    for command in commands:
        result = session.execute(command, read_timeout=read_timeout)
        if result.output:
            combined.append(result.output)
        if not result.ok:
            return CommandResult(ok=False, output="\n".join(combined), error=result.error)
        if pause_between:
            time.sleep(pause_between)
    return CommandResult(ok=True, output="\n".join(combined))


def run_commands(
    device: dict[str, Any],
    commands: list[str],
    *,
    pause_between: float = 0.3,
    read_timeout: int | None = None,
    operation: str = "command execution",
    lock_timeout: float | None = None,
) -> CommandResult:
    combined: list[str] = []
    try:
        with command_session(device, operation=operation, lock_timeout=lock_timeout) as session:
            result = run_session_commands(
                session,
                commands,
                pause_between=pause_between,
                read_timeout=read_timeout,
            )
            return result
    except Exception as exc:
        return CommandResult(ok=False, output="\n".join(combined), error=_connection_error_text(exc))


def open_interactive_connection(device: dict[str, Any]):
    """Open a persistent Netmiko session for the browser terminal.

    The caller must hold the per-device terminal lease and owns the returned
    connection. No paging command is sent because OmniSwitch AOS releases do not
    share one universal paging-disable command.
    """
    connection = _connect_with_retry(device)
    prompt = connection.find_prompt().strip()
    return connection, prompt


def _interactive_channel(connection: Any) -> Any:
    channel = getattr(connection, "remote_conn", None)
    if channel is None:
        raise RuntimeError("The SSH driver did not expose an interactive channel")
    return channel


def write_interactive_data(connection: Any, data: str) -> None:
    if not isinstance(data, str):
        data = str(data)
    if not data:
        return
    if len(data.encode("utf-8", errors="ignore")) > 16_384:
        raise ValueError("Terminal input chunk is too large")
    _interactive_channel(connection).send(data)


def read_interactive_data(connection: Any, *, max_bytes: int = 262_144) -> str:
    channel = _interactive_channel(connection)
    chunks: list[bytes] = []
    total = 0
    while channel.recv_ready() and total < max_bytes:
        chunk = channel.recv(min(65_535, max_bytes - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
    return b"".join(chunks).decode("utf-8", errors="replace")


def resize_interactive_terminal(connection: Any, columns: int, rows: int) -> None:
    columns = max(40, min(int(columns), 320))
    rows = max(12, min(int(rows), 120))
    channel = _interactive_channel(connection)
    try:
        channel.resize_pty(width=columns, height=rows)
    except Exception:
        pass


def close_interactive_connection(connection: Any) -> None:
    try:
        connection.disconnect()
    except Exception:
        pass


def run_command_collection(
    device: dict[str, Any],
    commands: dict[str, str],
    *,
    pause_between: float = 0.05,
    operation: str = "read-only command collection",
    lock_timeout: float | None = None,
) -> CommandCollectionResult:
    outputs: dict[str, str] = {}
    errors: dict[str, str] = {}
    try:
        with command_session(device, operation=operation, lock_timeout=lock_timeout) as session:
            for key, command in commands.items():
                result = session.execute(command)
                if result.output:
                    outputs[key] = result.output
                if not result.ok:
                    errors[key] = result.error or "The switch rejected the command"
                if pause_between:
                    time.sleep(pause_between)
        return CommandCollectionResult(connected=True, outputs=outputs, errors=errors)
    except Exception as exc:
        return CommandCollectionResult(False, outputs, errors, _connection_error_text(exc))
