# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from typing import Any

from .db import get_app_setting, get_app_setting_bool

MONITORING_MODE_FULL = "full"
MONITORING_MODE_MANAGEMENT_ONLY = "management_only"

_SERVICE_SETTING = {
    "switch_availability": "monitoring_switch_availability",
    "stack_health": "monitoring_stack_health",
    "power_ups": "monitoring_power_ups",
    "incident_detection": "monitoring_incident_detection",
}


def monitoring_mode() -> str:
    value = get_app_setting("monitoring_mode", MONITORING_MODE_FULL).strip().lower()
    if value not in {MONITORING_MODE_FULL, MONITORING_MODE_MANAGEMENT_ONLY}:
        return MONITORING_MODE_FULL
    return value


def monitoring_policy() -> dict[str, Any]:
    mode = monitoring_mode()
    services = {
        key: get_app_setting_bool(setting_name, True)
        for key, setting_name in _SERVICE_SETTING.items()
    }
    active = mode == MONITORING_MODE_FULL
    return {
        "mode": mode,
        "background_monitoring_enabled": active,
        "services": services,
        "effective": {key: bool(active and enabled) for key, enabled in services.items()},
    }


def monitoring_service_enabled(service: str) -> bool:
    key = str(service or "").strip().lower()
    setting_name = _SERVICE_SETTING.get(key)
    if not setting_name:
        return False
    return monitoring_mode() == MONITORING_MODE_FULL and get_app_setting_bool(setting_name, True)


def incident_detection_enabled() -> bool:
    return monitoring_service_enabled("incident_detection")
