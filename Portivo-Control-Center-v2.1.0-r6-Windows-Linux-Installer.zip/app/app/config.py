# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _split_csv(value: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in str(value or "").split(",") if part.strip())


def _normalize_public_scheme(value: str) -> str:
    scheme = str(value or "http").strip().lower()
    if scheme not in {"http", "https"}:
        raise RuntimeError("PUBLIC_URL_SCHEME must be either http or https")
    return scheme


def _validate_secret_key(value: str) -> str:
    secret = value.strip()
    forbidden = {
        "",
        "CHANGE_THIS_TO_A_LONG_RANDOM_VALUE",
        "development-only-change-me",
        "change-me",
    }
    if secret in forbidden or len(secret) < 32:
        raise RuntimeError(
            "APP_SECRET_KEY is missing or unsafe. Run the setup script or set a random value with at least 32 characters."
        )
    return secret


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "Portivo Control Center")
    app_version: str = os.getenv("APP_VERSION", "2.1.0")
    host: str = os.getenv("APP_HOST", "0.0.0.0")
    port: int = int(os.getenv("APP_PORT", "8766"))
    secret_key: str = _validate_secret_key(os.getenv("APP_SECRET_KEY", ""))
    admin_username: str = os.getenv("APP_ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("APP_ADMIN_PASSWORD", "")
    public_url_scheme: str = _normalize_public_scheme(
        os.getenv("PUBLIC_URL_SCHEME", "https" if _as_bool(os.getenv("COOKIE_SECURE"), False) else "http")
    )
    cookie_secure: bool = public_url_scheme == "https"
    trust_proxy_headers: bool = _as_bool(os.getenv("TRUST_PROXY_HEADERS"), False)
    trusted_proxy_ips: tuple[str, ...] = _split_csv(os.getenv("TRUSTED_PROXY_IPS", "127.0.0.1,::1"))
    login_rate_limit_enabled: bool = _as_bool(os.getenv("LOGIN_RATE_LIMIT_ENABLED"), True)
    login_rate_limit_window_seconds: int = max(60, int(os.getenv("LOGIN_RATE_LIMIT_WINDOW_SECONDS", "300")))
    login_rate_limit_max_delay_seconds: int = max(1, min(300, int(os.getenv("LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS", "30"))))
    ssh_connect_timeout: int = int(os.getenv("SSH_CONNECT_TIMEOUT", "12"))
    auth_connect_timeout: float = max(0.5, float(os.getenv("AUTH_CONNECT_TIMEOUT", "2.5")))
    auth_global_timeout_seconds: float = max(1.0, float(os.getenv("AUTH_GLOBAL_TIMEOUT_SECONDS", "5")))
    auth_max_sources: int = max(1, min(5, int(os.getenv("AUTH_MAX_SOURCES", "5"))))
    ssh_command_timeout: int = int(os.getenv("SSH_COMMAND_TIMEOUT", "30"))
    ssh_connect_retries: int = max(1, int(os.getenv("SSH_CONNECT_RETRIES", "3")))
    ssh_retry_backoff_seconds: float = max(0.1, float(os.getenv("SSH_RETRY_BACKOFF_SECONDS", "0.75")))
    ssh_operation_lock_timeout: float = max(0.1, float(os.getenv("SSH_OPERATION_LOCK_TIMEOUT", "180")))
    ssh_post_save_prompt_timeout: float = max(1.0, float(os.getenv("SSH_POST_SAVE_PROMPT_TIMEOUT", "20")))
    ssh_post_save_cooldown_seconds: float = max(0.0, float(os.getenv("SSH_POST_SAVE_COOLDOWN_SECONDS", "2")))
    ssh_post_save_fallback_cooldown_seconds: float = max(0.0, float(os.getenv("SSH_POST_SAVE_FALLBACK_COOLDOWN_SECONDS", "5")))
    ssh_recent_auth_success_window_seconds: float = max(1.0, float(os.getenv("SSH_RECENT_AUTH_SUCCESS_WINDOW_SECONDS", "60")))
    ssh_recent_auth_retry_delay_seconds: float = max(0.1, float(os.getenv("SSH_RECENT_AUTH_RETRY_DELAY_SECONDS", "2")))
    ssh_terminal_idle_minutes: int = max(5, int(os.getenv("SSH_TERMINAL_IDLE_MINUTES", "15")))
    max_parallel_switches: int = int(os.getenv("MAX_PARALLEL_SWITCHES", "6"))
    finder_max_parallel_switches: int = max(2, min(24, int(os.getenv("FINDER_MAX_PARALLEL_SWITCHES", "12"))))
    health_monitor_enabled: bool = _as_bool(os.getenv("HEALTH_MONITOR_ENABLED"), True)
    health_poll_interval_seconds: int = max(5, int(os.getenv("HEALTH_POLL_INTERVAL_SECONDS", "30")))
    health_ping_timeout_seconds: float = max(0.25, float(os.getenv("HEALTH_PING_TIMEOUT_SECONDS", "1.5")))
    health_snmp_timeout_seconds: float = max(0.25, float(os.getenv("HEALTH_SNMP_TIMEOUT_SECONDS", "1.5")))
    health_snmp_poll_interval_seconds: int = max(30, int(os.getenv("HEALTH_SNMP_POLL_INTERVAL_SECONDS", "120")))
    health_max_parallel_switches: int = max(1, min(128, int(os.getenv("HEALTH_MAX_PARALLEL_SWITCHES", "32"))))
    health_ping_attempts: int = max(1, min(5, int(os.getenv("HEALTH_PING_ATTEMPTS", "3"))))
    health_ping_retry_delay_seconds: float = max(0.0, min(30.0, float(os.getenv("HEALTH_PING_RETRY_DELAY_SECONDS", "5"))))
    health_poll_jitter_seconds: float = max(0.0, min(60.0, float(os.getenv("HEALTH_POLL_JITTER_SECONDS", "10"))))
    health_offline_poll_interval_seconds: int = max(10, int(os.getenv("HEALTH_OFFLINE_POLL_INTERVAL_SECONDS", "60")))
    health_long_offline_after_seconds: int = max(60, int(os.getenv("HEALTH_LONG_OFFLINE_AFTER_SECONDS", "900")))
    health_long_offline_poll_interval_seconds: int = max(30, int(os.getenv("HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS", "120")))
    database_path: Path = Path(os.getenv("DATABASE_PATH", str(BASE_DIR / "data" / "portivo.db")))
    command_profiles_path: Path = Path(
        os.getenv("COMMAND_PROFILES_PATH", str(BASE_DIR / "data" / "command_profiles.json"))
    )
    action_catalog_path: Path = Path(
        os.getenv("ACTION_CATALOG_PATH", str(BASE_DIR / "data" / "action_catalog.json"))
    )


settings = Settings()
settings.database_path.parent.mkdir(parents=True, exist_ok=True)
