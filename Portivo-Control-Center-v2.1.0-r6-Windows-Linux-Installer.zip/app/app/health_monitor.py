# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import logging
import math
import os
import subprocess
import threading
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .config import settings
from .db import db, get_app_setting_int, utc_now
from .monitoring_credentials import get_monitoring_profile
from .notification_engine import observe_health_result
from .monitoring_policy import incident_detection_enabled, monitoring_service_enabled
from .snmp_monitor import snmpv3_health_probe
from .ssh_runner import CommandResult


logger = logging.getLogger(__name__)
_monitor_stop = threading.Event()
_monitor_wake = threading.Event()
_monitor_lock = threading.Lock()
_monitor_thread: threading.Thread | None = None
_status_lock = threading.Lock()
_monitor_status: dict[str, Any] = {
    "last_cycle_at": "",
    "last_cycle_seconds": 0.0,
    "last_checked": 0,
    "last_online": 0,
    "last_offline": 0,
    "last_skipped": 0,
    "last_mode": "idle",
    "last_ping": 0,
    "last_snmp": 0,
}


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def _device_from_row(row: Any) -> dict[str, Any]:
    return _row_to_dict(row)


def _write_status_audit(
    conn: Any,
    *,
    actor: str,
    device_id: int,
    previous_status: str,
    status: str,
    response_ms: int,
    error: str,
    source: str,
    checked_at: str,
) -> None:
    conn.execute(
        """
        INSERT INTO audit_log(actor, event, object_type, object_id, details_json, created_at)
        VALUES(?, 'device_status_changed', 'device', ?, ?, ?)
        """,
        (
            actor or "health-monitor",
            str(device_id),
            json.dumps(
                {
                    "from": previous_status,
                    "to": status,
                    "response_ms": response_ms,
                    "error": error,
                    "source": source,
                },
                ensure_ascii=False,
            ),
            checked_at,
        ),
    )


def confirmed_connectivity_status(device: dict[str, Any], failure_threshold: int) -> str:
    """Return the operator-facing connectivity state after outage confirmation."""
    raw_status = str(device.get("last_status") or "unknown").strip().lower()
    threshold = max(2, min(10, int(failure_threshold or 3)))
    failures = max(0, int(device.get("consecutive_failures") or 0))
    if raw_status == "online":
        return "online"
    if raw_status == "offline":
        if failures >= threshold:
            return "offline"
        return "online" if str(device.get("last_seen") or "").strip() else "unknown"
    return "unknown"


def record_health_result(
    device_id: int,
    result: CommandResult,
    *,
    response_ms: int,
    source: str,
    actor: str = "health-monitor",
    identity: dict[str, Any] | None = None,
    probe_method: str = "",
    snmp_telemetry: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Update current reachability while keeping SNMP telemetry independent.

    ICMP/SNMP reachability results update the existing Online/Offline state and
    retain the established consecutive-failure incident confirmation. Optional
    SNMP telemetry is recorded separately so an SNMP credential/agent problem can
    never make an otherwise reachable switch appear Offline.
    """
    checked_at = utc_now()
    status = "online" if result.ok else "offline"
    error = "" if result.ok else (result.error or "Reachability check failed")
    identity = identity or {}
    snmp_telemetry = snmp_telemetry or {}

    with db() as conn:
        current = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
        if not current:
            return None

        previous_status = str(current["last_status"] or "unknown")
        previous_failures = int(current["consecutive_failures"] or 0)
        changed = previous_status != status
        consecutive_failures = 0 if result.ok else previous_failures + 1

        updates: dict[str, Any] = {
            "last_checked": checked_at,
            "last_status": status,
            "last_error": error,
            "response_ms": max(0, int(response_ms)),
            "consecutive_failures": consecutive_failures,
        }
        if probe_method:
            updates["last_health_probe_method"] = str(probe_method)
        if result.ok:
            updates["last_seen"] = checked_at
        if changed:
            updates["status_changed_at"] = checked_at
        if identity.get("model"):
            updates["model"] = identity["model"]
        if identity.get("aos_version"):
            updates["aos_version"] = identity["aos_version"]
        if identity.get("detected_profile"):
            updates["profile"] = identity["detected_profile"]

        if snmp_telemetry.get("checked"):
            updates["health_snmp_checked_at"] = str(snmp_telemetry.get("checked_at") or checked_at)
            updates["health_snmp_status"] = "available" if snmp_telemetry.get("ok") else "unavailable"
            updates["health_snmp_error"] = "" if snmp_telemetry.get("ok") else str(snmp_telemetry.get("error") or "SNMPv3 telemetry unavailable")[:1000]
            updates["health_snmp_response_ms"] = max(0, int(snmp_telemetry.get("response_ms") or 0))

        assignments = ", ".join(f"{key} = ?" for key in updates)
        conn.execute(
            f"UPDATE devices SET {assignments} WHERE id = ?",
            list(updates.values()) + [device_id],
        )
        if changed:
            _write_status_audit(
                conn,
                actor=actor,
                device_id=device_id,
                previous_status=previous_status,
                status=status,
                response_ms=max(0, int(response_ms)),
                error=error,
                source=source,
                checked_at=checked_at,
            )

        updated = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
    payload = _row_to_dict(updated) if updated else None
    if payload and incident_detection_enabled() and (consecutive_failures >= 2 or (result.ok and previous_failures >= 2)):
        try:
            observe_health_result(payload, checked_at=checked_at)
        except Exception as exc:  # pragma: no cover
            logger.exception("Health notification evaluation failed", exc_info=exc)
    return payload


def _elapsed_ms(started: float) -> int:
    return max(0, round((time.perf_counter() - started) * 1000))


def _probe_ping(host: str) -> tuple[bool, int, str]:
    """Send one ICMP echo using the platform ping utility.

    No SSH session or authentication is created. Windows uses a millisecond
    timeout; Linux uses one packet and a bounded whole-second reply window.
    """
    started = time.perf_counter()
    timeout = max(0.5, float(settings.health_ping_timeout_seconds))
    if os.name == "nt":
        command = ["ping", "-n", "1", "-w", str(max(250, int(timeout * 1000))), str(host)]
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        command = ["ping", "-n", "-c", "1", "-W", str(max(1, int(math.ceil(timeout)))), str(host)]
        creationflags = 0
    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=timeout + 1.5,
            creationflags=creationflags,
        )
        ok = completed.returncode == 0
        return ok, _elapsed_ms(started), "" if ok else "ICMP echo failed"
    except (OSError, subprocess.SubprocessError) as exc:
        return False, _elapsed_ms(started), f"ICMP echo failed: {exc}"


def _effective_snmp_profile_id(device: dict[str, Any]) -> int:
    explicit = int(device.get("health_monitor_profile_id") or 0)
    if explicit > 0:
        return explicit
    # Reuse an existing SNMPv3 stack profile when the operator has not selected
    # a dedicated health profile. This avoids duplicate credentials.
    if str(device.get("stack_monitor_method") or "").lower() == "snmpv3":
        return int(device.get("stack_monitor_profile_id") or 0)
    return 0


def _snmp_due(device: dict[str, Any], now: datetime | None = None) -> bool:
    last = _parse_timestamp(device.get("health_snmp_checked_at"))
    if last is None:
        return True
    now = now or datetime.now(timezone.utc)
    return (now - last).total_seconds() >= float(settings.health_snmp_poll_interval_seconds)


def _probe_snmp(device: dict[str, Any], profile: dict[str, Any] | None) -> tuple[bool, int, str]:
    if not profile:
        return False, 0, "No SNMPv3 monitoring profile configured"
    started = time.perf_counter()
    try:
        snmpv3_health_probe(
            str(device.get("host") or ""),
            profile,
            timeout=float(settings.health_snmp_timeout_seconds),
        )
        return True, _elapsed_ms(started), ""
    except Exception as exc:
        return False, _elapsed_ms(started), f"SNMPv3 telemetry unavailable: {exc}"


def _resolve_snmp_profiles(devices: list[dict[str, Any]]) -> dict[int, dict[str, Any]]:
    profiles: dict[int, dict[str, Any]] = {}
    for profile_id in sorted({_effective_snmp_profile_id(device) for device in devices} - {0}):
        profile = get_monitoring_profile(profile_id, decrypt=True)
        if profile and str(profile.get("method") or "").lower() == "snmpv3":
            profiles[profile_id] = profile
    return profiles


def _wait_ping_retry() -> None:
    delay = max(0.0, float(settings.health_ping_retry_delay_seconds))
    if delay > 0:
        _monitor_stop.wait(delay)


def _probe_ping_confirmed(host: str) -> tuple[bool, int, str, int]:
    """Use ICMP only, with two bounded retries by default.

    This confirmation happens inside one health probe so no TCP or SSH connection
    is ever opened merely to decide whether a switch is reachable.
    """
    attempts = max(1, min(5, int(settings.health_ping_attempts)))
    last_ms = 0
    last_error = "ICMP echo failed"
    for attempt in range(1, attempts + 1):
        ok, response_ms, error = _probe_ping(host)
        last_ms = response_ms
        last_error = error or last_error
        if ok:
            return True, response_ms, "", attempt
        if attempt < attempts:
            _wait_ping_retry()
    return False, last_ms, f"ICMP echo failed after {attempts} attempts: {last_error}", attempts


def _probe_device(
    device: dict[str, Any],
    profiles: dict[int, dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], CommandResult, int, str, dict[str, Any]]:
    """Perform the lowest-impact supported reachability check.

    auto: ICMP with two quick retries -> one SNMPv3 sysUpTime confirmation when
    a profile is configured. There is deliberately no TCP/22 or SSH fallback.
    Successful ICMP may also collect independent SNMP telemetry when its slower
    telemetry interval is due.
    """
    profiles = profiles or {}
    mode = str(device.get("health_probe_mode") or "auto").strip().lower()
    if mode not in {"auto", "ping", "snmp"}:
        mode = "auto"
    profile_id = _effective_snmp_profile_id(device)
    profile = profiles.get(profile_id)
    telemetry: dict[str, Any] = {}

    if mode in {"auto", "ping"}:
        ok, response_ms, error, attempts = _probe_ping_confirmed(str(device.get("host") or ""))
        if ok:
            if mode == "auto" and profile and _snmp_due(device):
                snmp_ok, snmp_ms, snmp_error = _probe_snmp(device, profile)
                telemetry = {
                    "checked": True,
                    "checked_at": utc_now(),
                    "ok": snmp_ok,
                    "response_ms": snmp_ms,
                    "error": snmp_error,
                }
            label = "ICMP reachable" if attempts == 1 else f"ICMP reachable on attempt {attempts}"
            return device, CommandResult(ok=True, output=label), response_ms, "ping", telemetry
        if mode == "ping":
            return device, CommandResult(ok=False, error=error), response_ms, "ping", telemetry

        # Auto uses exactly one SNMP request only after every ICMP attempt failed.
        # If no SNMPv3 profile exists, ICMP confirmation alone determines reachability.
        if profile:
            snmp_ok, snmp_ms, snmp_error = _probe_snmp(device, profile)
            telemetry = {
                "checked": True,
                "checked_at": utc_now(),
                "ok": snmp_ok,
                "response_ms": snmp_ms,
                "error": snmp_error,
            }
            if snmp_ok:
                return device, CommandResult(ok=True, output="SNMPv3 confirmed reachable after ICMP failure"), snmp_ms, "snmpv3", telemetry
            return device, CommandResult(ok=False, error=f"{error}; {snmp_error or 'SNMPv3 confirmation failed'}"), snmp_ms, "snmpv3", telemetry
        return device, CommandResult(ok=False, error=error), response_ms, "ping", telemetry

    snmp_ok, snmp_ms, snmp_error = _probe_snmp(device, profile)
    telemetry = {
        "checked": True,
        "checked_at": utc_now(),
        "ok": snmp_ok,
        "response_ms": snmp_ms,
        "error": snmp_error,
    }
    if snmp_ok:
        return device, CommandResult(ok=True, output="SNMPv3 reachable"), snmp_ms, "snmpv3", telemetry
    return device, CommandResult(ok=False, error=snmp_error or "SNMPv3 unavailable"), snmp_ms, "snmpv3", telemetry

def _scan_devices(devices: list[dict[str, Any]], source: str) -> dict[str, int]:
    summary = {"checked": 0, "online": 0, "offline": 0, "skipped": 0, "ping": 0, "snmp": 0}
    if not devices:
        return summary
    profiles = _resolve_snmp_profiles(devices)
    worker_count = max(1, min(settings.health_max_parallel_switches, len(devices)))
    with ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="portivo-health") as executor:
        futures = [executor.submit(_probe_device, device, profiles) for device in devices]
        for future in as_completed(futures):
            try:
                device, result, response_ms, probe_method, telemetry = future.result()
            except Exception as exc:  # pragma: no cover
                logger.exception("Health probe worker failed", exc_info=exc)
                summary["skipped"] += 1
                continue
            record_health_result(
                int(device["id"]),
                result,
                response_ms=response_ms,
                source=f"{source}:{probe_method}",
                actor="health-monitor",
                probe_method=probe_method,
                snmp_telemetry=telemetry,
            )
            summary["checked"] += 1
            summary["online" if result.ok else "offline"] += 1
            if probe_method in summary:
                summary[probe_method] += 1
            elif probe_method == "snmpv3":
                summary["snmp"] += 1
    return summary


def _record_monitor_status(summary: dict[str, int], *, started: float, mode: str) -> None:
    with _status_lock:
        _monitor_status.update({
            "last_cycle_at": utc_now(),
            "last_cycle_seconds": round(max(0.0, time.perf_counter() - started), 3),
            "last_checked": int(summary.get("checked", 0)),
            "last_online": int(summary.get("online", 0)),
            "last_offline": int(summary.get("offline", 0)),
            "last_skipped": int(summary.get("skipped", 0)),
            "last_mode": mode,
            "last_ping": int(summary.get("ping", 0)),
            "last_snmp": int(summary.get("snmp", 0)),
        })


def health_monitor_status() -> dict[str, Any]:
    with _status_lock:
        runtime = dict(_monitor_status)
    running = bool(_monitor_thread and _monitor_thread.is_alive())
    runtime.update({
        "enabled": bool(settings.health_monitor_enabled and monitoring_service_enabled("switch_availability")),
        "running": running,
        "architecture": "icmp-confirmed-snmpv3-fallback-no-tcp",
        "default_probe_mode": "auto",
        "ssh_login_used": False,
        "workers": int(settings.health_max_parallel_switches) if running else 0,
        "ping_timeout_seconds": float(settings.health_ping_timeout_seconds),
        "snmp_timeout_seconds": float(settings.health_snmp_timeout_seconds),
        "snmp_poll_interval_seconds": int(settings.health_snmp_poll_interval_seconds),
        "online_poll_interval_seconds": get_app_setting_int(
            "health_poll_interval_seconds", settings.health_poll_interval_seconds, 10, 3600
        ),
        "ping_attempts": int(settings.health_ping_attempts),
        "ping_retry_delay_seconds": float(settings.health_ping_retry_delay_seconds),
        "poll_jitter_seconds": float(settings.health_poll_jitter_seconds),
        "offline_poll_interval_seconds": int(settings.health_offline_poll_interval_seconds),
        "long_offline_after_seconds": int(settings.health_long_offline_after_seconds),
        "long_offline_poll_interval_seconds": int(settings.health_long_offline_poll_interval_seconds),
    })
    return runtime


def scan_all_devices(source: str = "scheduled") -> dict[str, int]:
    if not _monitor_lock.acquire(blocking=False):
        return {"checked": 0, "online": 0, "offline": 0, "skipped": 1}
    started = time.perf_counter()
    try:
        with db() as conn:
            rows = conn.execute(
                "SELECT * FROM devices WHERE enabled = 1 ORDER BY id"
            ).fetchall()
        summary = _scan_devices([_device_from_row(row) for row in rows], source)
        _record_monitor_status(summary, started=started, mode="full")
        return summary
    finally:
        _monitor_lock.release()


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _device_jitter_seconds(device: dict[str, Any]) -> float:
    """Return stable per-device jitter so large fleets do not probe in lockstep."""
    window = max(0.0, float(settings.health_poll_jitter_seconds))
    if window <= 0:
        return 0.0
    device_id = max(1, int(device.get("id") or 1))
    slots = max(1, int(window * 1000))
    return ((device_id * 2654435761) % (slots + 1)) / 1000.0


def _device_due_in_seconds(device: dict[str, Any], now: datetime) -> float:
    jitter = _device_jitter_seconds(device)
    last_checked = _parse_timestamp(device.get("last_checked"))
    if last_checked is None:
        return jitter
    failures = max(0, int(device.get("consecutive_failures") or 0))
    if failures >= 1:
        status_changed = _parse_timestamp(device.get("status_changed_at"))
        offline_age = (now - status_changed).total_seconds() if status_changed else 0.0
        if offline_age >= settings.health_long_offline_after_seconds:
            interval = settings.health_long_offline_poll_interval_seconds
        else:
            interval = settings.health_offline_poll_interval_seconds
    else:
        interval = get_app_setting_int(
            "health_poll_interval_seconds", settings.health_poll_interval_seconds, 10, 3600
        )
    elapsed = max(0.0, (now - last_checked).total_seconds())
    return max(0.0, float(interval) + jitter - elapsed)

def _scan_due_devices() -> tuple[dict[str, int], float]:
    if not _monitor_lock.acquire(blocking=False):
        return {"checked": 0, "online": 0, "offline": 0, "skipped": 1}, 1.0
    started = time.perf_counter()
    try:
        with db() as conn:
            rows = conn.execute("SELECT * FROM devices WHERE enabled = 1 ORDER BY id").fetchall()
        devices = [_device_from_row(row) for row in rows]
        now = datetime.now(timezone.utc)
        due = [device for device in devices if _device_due_in_seconds(device, now) <= 0.0]
        summary = _scan_devices(due, "scheduled-adaptive")
        _record_monitor_status(summary, started=started, mode="adaptive")

        with db() as conn:
            refreshed_rows = conn.execute("SELECT * FROM devices WHERE enabled = 1 ORDER BY id").fetchall()
        refreshed = [_device_from_row(row) for row in refreshed_rows]
        if not refreshed:
            return summary, 30.0
        after = datetime.now(timezone.utc)
        next_due = min(_device_due_in_seconds(device, after) for device in refreshed)
        return summary, max(0.5, min(float(next_due), 30.0))
    finally:
        _monitor_lock.release()


def request_health_scan() -> None:
    _monitor_wake.set()


def _monitor_loop() -> None:
    wait_seconds = 0.0
    while not _monitor_stop.is_set():
        if wait_seconds > 0:
            _monitor_wake.wait(wait_seconds)
            _monitor_wake.clear()
            if _monitor_stop.is_set():
                break
        try:
            _, wait_seconds = _scan_due_devices()
        except Exception as exc:  # pragma: no cover
            logger.exception("Scheduled switch health scan failed", exc_info=exc)
            wait_seconds = 5.0


def start_health_monitor() -> None:
    global _monitor_thread
    if not settings.health_monitor_enabled:
        return
    if _monitor_thread and _monitor_thread.is_alive():
        return
    _monitor_stop.clear()
    _monitor_wake.clear()
    _monitor_thread = threading.Thread(target=_monitor_loop, name="osc-health-monitor", daemon=True)
    _monitor_thread.start()


def stop_health_monitor() -> None:
    _monitor_stop.set()
    _monitor_wake.set()
    if _monitor_thread and _monitor_thread.is_alive():
        _monitor_thread.join(timeout=3)
