# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from typing import Any

from .crypto import decrypt_secret
from .db import db


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def list_monitoring_profiles() -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT id,name,method,username,snmp_port,snmp_auth_protocol,snmp_priv_protocol,
                   verified_device_id,verified_device_name,verified_target_type,verified_target_id,
                   verified_at,last_status,updated_at,updated_by
            FROM monitoring_credential_profiles
            ORDER BY method,name COLLATE NOCASE,id
            """
        ).fetchall()
    result: list[dict[str, Any]] = []
    for row in rows:
        item = _row_to_dict(row)
        item["configured"] = True
        result.append(item)
    return result


def get_monitoring_profile(profile_id: int, *, decrypt: bool = False) -> dict[str, Any] | None:
    with db() as conn:
        row = conn.execute("SELECT * FROM monitoring_credential_profiles WHERE id=?", (int(profile_id),)).fetchone()
    if not row:
        return None
    item = _row_to_dict(row)
    if decrypt:
        item["ssh_password"] = decrypt_secret(str(item.get("ssh_password_enc") or ""))
        item["snmp_auth_password"] = decrypt_secret(str(item.get("snmp_auth_password_enc") or ""))
        item["snmp_priv_password"] = decrypt_secret(str(item.get("snmp_priv_password_enc") or ""))
    for key in ("ssh_password_enc", "snmp_auth_password_enc", "snmp_priv_password_enc"):
        item.pop(key, None)
    return item


def profile_matches_method(profile: dict[str, Any] | None, method: str) -> bool:
    return bool(profile and str(profile.get("method") or "").lower() == str(method or "").lower())
