# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

from typing import Any

from .db import db, utc_now


def record_pending_change(*, device_id: int, job_id: int | None, job_item_id: int | None, action: str, port: str = "", slot: str = "", command: str = "", actor: str = "", verification_status: str = "not_required") -> None:
    with db() as conn:
        conn.execute(
            """
            INSERT INTO pending_config_changes(
                device_id, job_id, job_item_id, action, port, slot, command, actor, verification_status, created_at
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (device_id, job_id, job_item_id, action, port, slot, command, actor, verification_status, utc_now()),
        )


def clear_pending_changes(device_id: int) -> int:
    with db() as conn:
        count = conn.execute(
            "SELECT COUNT(*) AS count FROM pending_config_changes WHERE device_id = ?", (device_id,)
        ).fetchone()["count"]
        conn.execute("DELETE FROM pending_config_changes WHERE device_id = ?", (device_id,))
    return int(count or 0)


def pending_count_for_device(device_id: int) -> int:
    with db() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS count FROM pending_config_changes WHERE device_id = ?", (device_id,)
        ).fetchone()
    return int(row["count"] if row else 0)


def list_pending_configuration() -> dict[str, Any]:
    with db() as conn:
        summary_rows = conn.execute(
            """
            SELECT d.id AS device_id, d.name AS device_name, d.host, d.profile, d.model,
                   COUNT(p.id) AS change_count, MIN(p.created_at) AS pending_since, MAX(p.created_at) AS last_change_at
            FROM pending_config_changes p
            JOIN devices d ON d.id = p.device_id
            GROUP BY d.id, d.name, d.host, d.profile, d.model
            ORDER BY MAX(p.created_at) DESC, d.name ASC
            """
        ).fetchall()
        devices: list[dict[str, Any]] = []
        total_changes = 0
        for row in summary_rows:
            changes = conn.execute(
                """
                SELECT id, job_id, job_item_id, action, port, slot, command, actor, verification_status, created_at
                FROM pending_config_changes
                WHERE device_id = ?
                ORDER BY id DESC
                LIMIT 100
                """,
                (row["device_id"],),
            ).fetchall()
            change_count = int(row["change_count"] or 0)
            total_changes += change_count
            devices.append({
                "device_id": int(row["device_id"]),
                "device_name": row["device_name"],
                "host": row["host"],
                "profile": row["profile"],
                "model": row["model"],
                "change_count": change_count,
                "pending_since": row["pending_since"],
                "last_change_at": row["last_change_at"],
                "changes": [{key: item[key] for key in item.keys()} for item in changes],
            })
    return {"device_count": len(devices), "change_count": total_changes, "devices": devices}
