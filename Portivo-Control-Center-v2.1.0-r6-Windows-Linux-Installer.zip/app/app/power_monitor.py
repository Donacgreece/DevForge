# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import logging
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any

from .db import db, get_app_setting_int, utc_now
from .monitoring_credentials import get_monitoring_profile
from .snmp_monitor import snmpv3_get_many, snmpv3_walk
from .monitoring_policy import incident_detection_enabled, monitoring_service_enabled
from .power_drivers import (
    EATON_ALARMS, SYS_DESCR, SYS_OBJECT_ID, clean_snmp_value, detect_driver, driver_has_vendor_evidence,
    enrich_snapshot, normalize_driver_mode, vendor_alarm_label, vendor_detail_scalar_oids,
    vendor_detail_walk_oids, build_vendor_detail_metrics, normalize_sys_object_id,
    XPPC_UPS_ROOT, XPPC_MODEL, XPPC_BATTERY_STATUS, XPPC_BATTERY_CAPACITY, XPPC_RUNTIME_SECONDS,
    XPPC_OUTPUT_STATUS, XPPC_OUTPUT_LOAD, XPPC_INPUT_VOLTAGE, XPPC_INPUT_FREQUENCY,
    XPPC_OUTPUT_VOLTAGE, XPPC_OUTPUT_FREQUENCY, XPPC_3P_BATTERY_VOLTAGE, XPPC_3P_BATTERY_CAPACITY,
    XPPC_3P_RUNTIME_MINUTES, XPPC_3P_BATTERY_CURRENT, XPPC_3P_BATTERY_TEMPERATURE,
    XPPC_3P_INPUT_FREQUENCY, XPPC_3P_INPUT_VOLTAGE_R, XPPC_3P_INPUT_VOLTAGE_S, XPPC_3P_INPUT_VOLTAGE_T,
    XPPC_3P_OUTPUT_FREQUENCY, XPPC_3P_OUTPUT_VOLTAGE_R, XPPC_3P_OUTPUT_VOLTAGE_S, XPPC_3P_OUTPUT_VOLTAGE_T,
    XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S, XPPC_3P_OUTPUT_LOAD_T, XPPC_3P_BYPASS_FREQUENCY,
    XPPC_ENV_TEMPERATURE, XPPC_ENV_HUMIDITY,
    VERTIV_LGP_MEASUREMENT_ROOT, VERTIV_SYSTEM_STATUS, VERTIV_BATTERY_CAPACITY,
    VERTIV_BATTERY_RUNTIME, VERTIV_OUTPUT_LOAD, VERTIV_OUTPUT_SOURCE,
)

logger = logging.getLogger(__name__)

_worker_stop = threading.Event()
_worker_wake = threading.Event()
_worker_thread: threading.Thread | None = None
_status_lock = threading.Lock()
_status: dict[str, Any] = {"running": False, "last_cycle_at": None, "last_cycle_seconds": 0.0, "checked": 0, "errors": 0}

UPS_IDENT_MANUFACTURER = "1.3.6.1.2.1.33.1.1.1.0"
UPS_IDENT_MODEL = "1.3.6.1.2.1.33.1.1.2.0"
UPS_IDENT_SOFTWARE = "1.3.6.1.2.1.33.1.1.3.0"
UPS_IDENT_NAME = "1.3.6.1.2.1.33.1.1.5.0"
UPS_BATTERY_STATUS = "1.3.6.1.2.1.33.1.2.1.0"
UPS_SECONDS_ON_BATTERY = "1.3.6.1.2.1.33.1.2.2.0"
UPS_RUNTIME_MINUTES = "1.3.6.1.2.1.33.1.2.3.0"
UPS_CHARGE_PERCENT = "1.3.6.1.2.1.33.1.2.4.0"
UPS_OUTPUT_SOURCE = "1.3.6.1.2.1.33.1.4.1.0"
UPS_ALARMS_PRESENT = "1.3.6.1.2.1.33.1.6.1.0"
UPS_OUTPUT_LOAD_TABLE = "1.3.6.1.2.1.33.1.4.4.1.5"
UPS_ALARM_DESCR_TABLE = "1.3.6.1.2.1.33.1.6.2.1.2"
UPS_IDENT_UPS_SOFTWARE = "1.3.6.1.2.1.33.1.1.3.0"
UPS_IDENT_AGENT_SOFTWARE = "1.3.6.1.2.1.33.1.1.4.0"
UPS_IDENT_ATTACHED_DEVICES = "1.3.6.1.2.1.33.1.1.6.0"
UPS_BATTERY_VOLTAGE = "1.3.6.1.2.1.33.1.2.5.0"
UPS_BATTERY_CURRENT = "1.3.6.1.2.1.33.1.2.6.0"
UPS_BATTERY_TEMPERATURE = "1.3.6.1.2.1.33.1.2.7.0"
UPS_INPUT_LINE_BADS = "1.3.6.1.2.1.33.1.3.1.0"
UPS_INPUT_NUM_LINES = "1.3.6.1.2.1.33.1.3.2.0"
UPS_INPUT_TABLE = "1.3.6.1.2.1.33.1.3.3.1"
UPS_OUTPUT_FREQUENCY = "1.3.6.1.2.1.33.1.4.2.0"
UPS_OUTPUT_NUM_LINES = "1.3.6.1.2.1.33.1.4.3.0"
UPS_OUTPUT_TABLE = "1.3.6.1.2.1.33.1.4.4.1"
UPS_BYPASS_FREQUENCY = "1.3.6.1.2.1.33.1.5.1.0"
UPS_BYPASS_NUM_LINES = "1.3.6.1.2.1.33.1.5.2.0"
UPS_BYPASS_TABLE = "1.3.6.1.2.1.33.1.5.3.1"
UPS_TEST_RESULTS_SUMMARY = "1.3.6.1.2.1.33.1.7.3.0"
UPS_TEST_RESULTS_DETAIL = "1.3.6.1.2.1.33.1.7.4.0"
UPS_TEST_START_TIME = "1.3.6.1.2.1.33.1.7.5.0"
UPS_TEST_ELAPSED_TIME = "1.3.6.1.2.1.33.1.7.6.0"
UPS_CONFIG_INPUT_VOLTAGE = "1.3.6.1.2.1.33.1.9.1.0"
UPS_CONFIG_INPUT_FREQUENCY = "1.3.6.1.2.1.33.1.9.2.0"
UPS_CONFIG_OUTPUT_VOLTAGE = "1.3.6.1.2.1.33.1.9.3.0"
UPS_CONFIG_OUTPUT_FREQUENCY = "1.3.6.1.2.1.33.1.9.4.0"
UPS_CONFIG_OUTPUT_VA = "1.3.6.1.2.1.33.1.9.5.0"
UPS_CONFIG_OUTPUT_POWER = "1.3.6.1.2.1.33.1.9.6.0"
UPS_CONFIG_LOW_BATTERY_TIME = "1.3.6.1.2.1.33.1.9.7.0"
UPS_CONFIG_AUDIBLE_STATUS = "1.3.6.1.2.1.33.1.9.8.0"
UPS_CONFIG_LOW_TRANSFER_VOLTAGE = "1.3.6.1.2.1.33.1.9.9.0"
UPS_CONFIG_HIGH_TRANSFER_VOLTAGE = "1.3.6.1.2.1.33.1.9.10.0"

DETAIL_SCALAR_OIDS = [
    UPS_IDENT_UPS_SOFTWARE, UPS_IDENT_AGENT_SOFTWARE, UPS_IDENT_ATTACHED_DEVICES,
    UPS_BATTERY_VOLTAGE, UPS_BATTERY_CURRENT, UPS_BATTERY_TEMPERATURE,
    UPS_INPUT_LINE_BADS, UPS_INPUT_NUM_LINES, UPS_OUTPUT_FREQUENCY, UPS_OUTPUT_NUM_LINES,
    UPS_BYPASS_FREQUENCY, UPS_BYPASS_NUM_LINES, UPS_TEST_RESULTS_SUMMARY, UPS_TEST_RESULTS_DETAIL,
    UPS_TEST_START_TIME, UPS_TEST_ELAPSED_TIME, UPS_CONFIG_INPUT_VOLTAGE, UPS_CONFIG_INPUT_FREQUENCY,
    UPS_CONFIG_OUTPUT_VOLTAGE, UPS_CONFIG_OUTPUT_FREQUENCY, UPS_CONFIG_OUTPUT_VA, UPS_CONFIG_OUTPUT_POWER,
    UPS_CONFIG_LOW_BATTERY_TIME, UPS_CONFIG_AUDIBLE_STATUS, UPS_CONFIG_LOW_TRANSFER_VOLTAGE, UPS_CONFIG_HIGH_TRANSFER_VOLTAGE,
]

SCALAR_OIDS = [
    SYS_DESCR, SYS_OBJECT_ID,
    UPS_IDENT_MANUFACTURER, UPS_IDENT_MODEL, UPS_IDENT_SOFTWARE, UPS_IDENT_NAME,
    UPS_BATTERY_STATUS, UPS_SECONDS_ON_BATTERY, UPS_RUNTIME_MINUTES,
    UPS_CHARGE_PERCENT, UPS_OUTPUT_SOURCE, UPS_ALARMS_PRESENT,
]

IDENTITY_OIDS = [SYS_DESCR, SYS_OBJECT_ID, UPS_IDENT_MANUFACTURER, UPS_IDENT_MODEL]

BATTERY_STATUS = {1: "unknown", 2: "normal", 3: "low", 4: "depleted"}
OUTPUT_SOURCE = {1: "other", 2: "none", 3: "normal", 4: "bypass", 5: "battery", 6: "booster", 7: "reducer"}
WELL_KNOWN_ALARMS = {
    "1.3.6.1.2.1.33.1.6.3.1": "Battery replacement required",
    "1.3.6.1.2.1.33.1.6.3.2": "On battery",
    "1.3.6.1.2.1.33.1.6.3.3": "Low battery",
    "1.3.6.1.2.1.33.1.6.3.4": "Battery depleted",
    "1.3.6.1.2.1.33.1.6.3.5": "Temperature out of tolerance",
    "1.3.6.1.2.1.33.1.6.3.6": "Input out of tolerance",
    "1.3.6.1.2.1.33.1.6.3.7": "Output out of tolerance",
    "1.3.6.1.2.1.33.1.6.3.8": "Output overload",
    "1.3.6.1.2.1.33.1.6.3.9": "On bypass",
    "1.3.6.1.2.1.33.1.6.3.10": "Bypass out of tolerance",
    "1.3.6.1.2.1.33.1.6.3.13": "Charger failed",
    "1.3.6.1.2.1.33.1.6.3.16": "Fan failure",
    "1.3.6.1.2.1.33.1.6.3.17": "Fuse failure",
    "1.3.6.1.2.1.33.1.6.3.18": "General fault",
    "1.3.6.1.2.1.33.1.6.3.20": "UPS communications lost",
    "1.3.6.1.2.1.33.1.6.3.21": "Awaiting input power",
    "1.3.6.1.2.1.33.1.6.3.23": "Shutdown imminent",
}


def _int_value(value: Any, default: int | None = None) -> int | None:
    text = str(value or "").strip()
    match = re.search(r"-?\d+", text)
    if not match:
        return default
    try:
        return int(match.group(0))
    except ValueError:
        return default


def _text(values: dict[str, str], oid: str) -> str:
    return clean_snmp_value(values.get(oid, ""))



def _float_value(value: Any, scale: float = 1.0) -> float | None:
    text = clean_snmp_value(value)
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return round(float(match.group(0)) * float(scale), 3)
    except (TypeError, ValueError):
        return None


def _detail_metric(key: str, label: str, value: Any, unit: str = "", source: str = "RFC 1628 UPS-MIB") -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, str) and not clean_snmp_value(value):
        return None
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


def _detail_table_by_index(rows: list[tuple[str, str]], base_oid: str) -> dict[str, dict[int, str]]:
    base = str(base_oid).strip().lstrip(".")
    result: dict[str, dict[int, str]] = {}
    for oid, raw in rows or []:
        normalized = str(oid or "").strip().lstrip(".")
        if not normalized.startswith(base + "."):
            continue
        suffix = normalized[len(base) + 1:].split(".")
        if len(suffix) < 2:
            continue
        try:
            column = int(suffix[0])
        except ValueError:
            continue
        index = ".".join(suffix[1:])
        value = clean_snmp_value(raw)
        if value:
            result.setdefault(index, {})[column] = value
    return result


def _append_metric(sections: dict[str, list[dict[str, Any]]], section: str, item: dict[str, Any] | None) -> None:
    if item:
        sections.setdefault(section, []).append(item)


def _build_standard_detail_metrics(values: dict[str, str], walks: dict[str, list[tuple[str, str]]]) -> dict[str, list[dict[str, Any]]]:
    sections: dict[str, list[dict[str, Any]]] = {"identity": [], "battery": [], "input": [], "output": [], "bypass": [], "diagnostics": []}
    add = lambda section, item: _append_metric(sections, section, item)

    add("identity", _detail_metric("manufacturer", "Manufacturer", _text(values, UPS_IDENT_MANUFACTURER)))
    add("identity", _detail_metric("model", "Model", _text(values, UPS_IDENT_MODEL)))
    add("identity", _detail_metric("ups_software", "UPS software", _text(values, UPS_IDENT_UPS_SOFTWARE)))
    add("identity", _detail_metric("agent_software", "SNMP agent software", _text(values, UPS_IDENT_AGENT_SOFTWARE)))
    add("identity", _detail_metric("reported_name", "Reported name", _text(values, UPS_IDENT_NAME)))
    add("identity", _detail_metric("attached_devices", "Attached devices", _text(values, UPS_IDENT_ATTACHED_DEVICES)))
    add("identity", _detail_metric("sys_object_id", "SNMP object ID", clean_snmp_value(values.get(SYS_OBJECT_ID))))

    battery_code = _int_value(_text(values, UPS_BATTERY_STATUS), 1) or 1
    add("battery", _detail_metric("battery_status", "Battery status", BATTERY_STATUS.get(battery_code, "unknown").replace("_", " ").title()))
    add("battery", _detail_metric("battery_charge", "Battery capacity remaining", _int_value(_text(values, UPS_CHARGE_PERCENT)), "%"))
    add("battery", _detail_metric("battery_runtime", "Battery time remaining", _int_value(_text(values, UPS_RUNTIME_MINUTES)), "min"))
    add("battery", _detail_metric("seconds_on_battery", "Time running on battery", _int_value(_text(values, UPS_SECONDS_ON_BATTERY)), "s"))
    add("battery", _detail_metric("battery_voltage", "Battery voltage", _float_value(_text(values, UPS_BATTERY_VOLTAGE), 0.1), "V"))
    add("battery", _detail_metric("battery_current", "Battery current", _float_value(_text(values, UPS_BATTERY_CURRENT), 0.1), "A"))
    add("battery", _detail_metric("battery_temperature", "Battery temperature", _float_value(_text(values, UPS_BATTERY_TEMPERATURE)), "°C"))

    add("input", _detail_metric("input_line_bads", "Input out-of-tolerance count", _int_value(_text(values, UPS_INPUT_LINE_BADS))))
    add("input", _detail_metric("input_lines", "Input phases", _int_value(_text(values, UPS_INPUT_NUM_LINES))))
    input_rows = _detail_table_by_index(walks.get("rfc_input", []), UPS_INPUT_TABLE)
    for index in sorted(input_rows.keys(), key=lambda x: [int(v) if v.isdigit() else v for v in x.split('.')]):
        row = input_rows[index]
        phase = _int_value(row.get(1)) or index
        add("input", _detail_metric(f"input_frequency_{phase}", f"Input frequency L{phase}", _float_value(row.get(2), 0.1), "Hz"))
        add("input", _detail_metric(f"input_voltage_{phase}", f"Input voltage L{phase}", _float_value(row.get(3)), "V"))
        add("input", _detail_metric(f"input_current_{phase}", f"Input current L{phase}", _float_value(row.get(4), 0.1), "A"))
        add("input", _detail_metric(f"input_power_{phase}", f"Input active power L{phase}", _float_value(row.get(5)), "W"))

    source_code = _int_value(_text(values, UPS_OUTPUT_SOURCE), 1) or 1
    add("output", _detail_metric("output_source", "UPS operation mode", OUTPUT_SOURCE.get(source_code, "other").replace("_", " ").title()))
    add("output", _detail_metric("output_frequency", "Output frequency", _float_value(_text(values, UPS_OUTPUT_FREQUENCY), 0.1), "Hz"))
    add("output", _detail_metric("output_lines", "Output phases", _int_value(_text(values, UPS_OUTPUT_NUM_LINES))))
    output_rows = _detail_table_by_index(walks.get("rfc_output", []), UPS_OUTPUT_TABLE)
    for index in sorted(output_rows.keys(), key=lambda x: [int(v) if v.isdigit() else v for v in x.split('.')]):
        row = output_rows[index]
        phase = _int_value(row.get(1)) or index
        add("output", _detail_metric(f"output_voltage_{phase}", f"Output voltage L{phase}", _float_value(row.get(2)), "V"))
        add("output", _detail_metric(f"output_current_{phase}", f"Output current L{phase}", _float_value(row.get(3), 0.1), "A"))
        add("output", _detail_metric(f"output_power_{phase}", f"Output active power L{phase}", _float_value(row.get(4)), "W"))
        add("output", _detail_metric(f"output_load_{phase}", f"Output load L{phase}", _float_value(row.get(5)), "%"))

    add("bypass", _detail_metric("bypass_frequency", "Bypass frequency", _float_value(_text(values, UPS_BYPASS_FREQUENCY), 0.1), "Hz"))
    add("bypass", _detail_metric("bypass_lines", "Bypass phases", _int_value(_text(values, UPS_BYPASS_NUM_LINES))))
    bypass_rows = _detail_table_by_index(walks.get("rfc_bypass", []), UPS_BYPASS_TABLE)
    for index in sorted(bypass_rows.keys(), key=lambda x: [int(v) if v.isdigit() else v for v in x.split('.')]):
        row = bypass_rows[index]
        phase = _int_value(row.get(1)) or index
        add("bypass", _detail_metric(f"bypass_voltage_{phase}", f"Bypass voltage L{phase}", _float_value(row.get(2)), "V"))
        add("bypass", _detail_metric(f"bypass_current_{phase}", f"Bypass current L{phase}", _float_value(row.get(3), 0.1), "A"))
        add("bypass", _detail_metric(f"bypass_power_{phase}", f"Bypass active power L{phase}", _float_value(row.get(4)), "W"))

    test_summary = _int_value(_text(values, UPS_TEST_RESULTS_SUMMARY))
    add("diagnostics", _detail_metric("test_summary", "Diagnostic test result", {1:"Passed",2:"Warning",3:"Error",4:"Aborted",5:"In progress",6:"No tests initiated"}.get(test_summary)))
    add("diagnostics", _detail_metric("test_detail", "Diagnostic test detail", _text(values, UPS_TEST_RESULTS_DETAIL)))
    add("diagnostics", _detail_metric("test_start", "Diagnostic test start", _text(values, UPS_TEST_START_TIME)))
    add("diagnostics", _detail_metric("test_elapsed", "Diagnostic test elapsed", _text(values, UPS_TEST_ELAPSED_TIME)))
    add("diagnostics", _detail_metric("active_alarm_count", "Active alarms", _int_value(_text(values, UPS_ALARMS_PRESENT))))

    add("input", _detail_metric("nominal_input_voltage", "Nominal input voltage", _float_value(_text(values, UPS_CONFIG_INPUT_VOLTAGE)), "V"))
    add("input", _detail_metric("nominal_input_frequency", "Nominal input frequency", _float_value(_text(values, UPS_CONFIG_INPUT_FREQUENCY), 0.1), "Hz"))
    add("output", _detail_metric("nominal_output_voltage", "Nominal output voltage", _float_value(_text(values, UPS_CONFIG_OUTPUT_VOLTAGE)), "V"))
    add("output", _detail_metric("nominal_output_frequency", "Nominal output frequency", _float_value(_text(values, UPS_CONFIG_OUTPUT_FREQUENCY), 0.1), "Hz"))
    add("output", _detail_metric("rated_output_va", "Output maximum capacity", _float_value(_text(values, UPS_CONFIG_OUTPUT_VA)), "VA"))
    add("output", _detail_metric("rated_output_power", "Rated output power", _float_value(_text(values, UPS_CONFIG_OUTPUT_POWER)), "W"))
    add("battery", _detail_metric("low_battery_threshold", "Low battery runtime threshold", _int_value(_text(values, UPS_CONFIG_LOW_BATTERY_TIME)), "min"))
    audible = _int_value(_text(values, UPS_CONFIG_AUDIBLE_STATUS))
    add("diagnostics", _detail_metric("audible_status", "Audible alarm", {1:"Disabled",2:"Enabled",3:"Muted"}.get(audible)))
    add("input", _detail_metric("low_transfer_voltage", "Low voltage transfer point", _float_value(_text(values, UPS_CONFIG_LOW_TRANSFER_VOLTAGE)), "V"))
    add("input", _detail_metric("high_transfer_voltage", "High voltage transfer point", _float_value(_text(values, UPS_CONFIG_HIGH_TRANSFER_VOLTAGE)), "V"))
    return {key: items for key, items in sections.items() if items}


def _merge_detail_sections(standard: dict[str, list[dict[str, Any]]], vendor: dict[str, list[dict[str, Any]]], *, prefer_vendor: bool = False) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for section in set(standard) | set(vendor):
        ordered: list[dict[str, Any]] = []
        seen: set[str] = set()
        # RFC 1628 is preferred by default because its units are standardized.
        # XPPC cards often expose a partial RFC facade with placeholder zeroes,
        # while their native XPPC-MIB values are authoritative. For that driver
        # vendor metrics intentionally win duplicate keys.
        primary = vendor if prefer_vendor else standard
        secondary = standard if prefer_vendor else vendor
        for item in [*(primary.get(section) or []), *(secondary.get(section) or [])]:
            key = str(item.get("key") or "")
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            ordered.append(item)
        if ordered:
            result[section] = ordered
    return result


def _human_battery_status(value: Any) -> str:
    status = str(value or "").strip().casefold()
    return {
        "normal": "Normal",
        "low": "Low",
        "depleted": "Depleted",
        "fault": "Fault",
        "discharging": "Discharging",
        "charging": "Charging",
        "floating": "Normal",
        "resting": "Normal",
    }.get(status, "")


def _upsert_detail_metric(sections: dict[str, list[dict[str, Any]]], section: str, metric: dict[str, Any]) -> None:
    items = sections.setdefault(section, [])
    key = str(metric.get("key") or "")
    for index, existing in enumerate(items):
        if str(existing.get("key") or "") == key:
            items[index] = metric
            return
    items.insert(0, metric)


def _resolved_detail_sections(
    sections: dict[str, list[dict[str, Any]]], snapshot: dict[str, Any], driver: Any
) -> dict[str, list[dict[str, Any]]]:
    """Reconcile detail cards with the already enriched authoritative snapshot.

    Some UPS devices return ``unknown`` from the generic RFC1628 status object
    while exposing a valid APC/Eaton/Vertiv vendor status, charge, runtime or load.
    The core snapshot already resolves those sources. Details must therefore
    reflect that resolved state rather than showing a weaker raw RFC enum.

    Optional metrics whose only value is ``Unknown`` are removed. Portivo does
    not invent a healthy state when neither standard nor vendor telemetry says
    one exists.
    """
    result = {name: [dict(item) for item in items] for name, items in sections.items()}
    source = str(getattr(driver, "name", "") or "RFC 1628 UPS-MIB")

    if str(getattr(driver, "key", "")) == "xppc":
        # Classic XPPC cards frequently implement a partial RFC1628 facade and
        # return literal zero for unsupported optional objects. Do not present
        # those placeholders as real electrical measurements. Native XPPC
        # metrics have already won duplicate keys during the merge above.
        zero_placeholder_prefixes = ("input_current_", "input_power_", "output_current_", "output_power_", "bypass_voltage_", "bypass_current_", "bypass_power_")
        zero_placeholder_keys = {
            "battery_runtime", "output_load", "output_load_1", "output_load_2", "output_load_3",
            "output_frequency", "bypass_frequency", "nominal_input_voltage", "nominal_input_frequency",
            "nominal_output_voltage", "nominal_output_frequency", "rated_output_va", "rated_output_power",
            "low_transfer_voltage", "high_transfer_voltage", "low_battery_threshold",
            "test_start", "test_elapsed",
        }
        for section_name, items in list(result.items()):
            cleaned = []
            for item in items:
                key = str(item.get("key") or "")
                item_source = str(item.get("source") or "")
                value = item.get("value")
                zeroish = value == 0 or value == 0.0 or str(value).strip() in {"0", "0.0", "0.00"}
                is_placeholder = key in zero_placeholder_keys or key.startswith(zero_placeholder_prefixes)
                if zeroish and is_placeholder and item_source in {"RFC 1628 UPS-MIB", "Phoenixtec XPPC-MIB"}:
                    continue
                cleaned.append(item)
            result[section_name] = cleaned

    battery_label = _human_battery_status(snapshot.get("battery_status"))
    if battery_label:
        _upsert_detail_metric(result, "battery", {
            "key": "battery_status", "label": "Battery status", "value": battery_label,
            "unit": "", "source": source,
        })

    charge = snapshot.get("battery_charge_percent")
    if charge is not None:
        existing = {str(item.get("key") or "") for item in result.get("battery", [])}
        if "battery_charge" not in existing:
            _upsert_detail_metric(result, "battery", {
                "key": "battery_charge", "label": "Battery capacity remaining", "value": charge,
                "unit": "%", "source": source,
            })

    runtime = snapshot.get("runtime_minutes")
    if runtime is not None:
        existing = {str(item.get("key") or "") for item in result.get("battery", [])}
        if "battery_runtime" not in existing:
            _upsert_detail_metric(result, "battery", {
                "key": "battery_runtime", "label": "Battery time remaining", "value": runtime,
                "unit": "min", "source": source,
            })

    load = snapshot.get("load_percent")
    if load is not None:
        has_load = any(str(item.get("key") or "").startswith("output_load") for item in result.get("output", []))
        if not has_load:
            _upsert_detail_metric(result, "output", {
                "key": "output_load", "label": "Output load", "value": load,
                "unit": "%", "source": source,
            })

    cleaned: dict[str, list[dict[str, Any]]] = {}
    for section, items in result.items():
        useful: list[dict[str, Any]] = []
        for item in items:
            value = item.get("value")
            if isinstance(value, str) and value.strip().casefold() in {"unknown", "not reported", "n/a"}:
                continue
            useful.append(item)
        if useful:
            cleaned[section] = useful
    return cleaned


def _alarm_name(value: str) -> str:
    raw = str(value or "").strip()
    if raw and not re.fullmatch(r"\.?[0-9.]+", raw):
        return raw
    oid = raw.lstrip(".")
    if oid in WELL_KNOWN_ALARMS:
        return WELL_KNOWN_ALARMS[oid]
    for known, name in WELL_KNOWN_ALARMS.items():
        if oid.endswith(known):
            return name
    return oid or "Unknown alarm"


def parse_ups_snapshot(values: dict[str, str], load_rows: list[tuple[str, str]] | None = None, alarm_rows: list[tuple[str, str]] | None = None) -> dict[str, Any]:
    battery_code = _int_value(_text(values, UPS_BATTERY_STATUS), 1) or 1
    source_code = _int_value(_text(values, UPS_OUTPUT_SOURCE), 1) or 1
    charge = _int_value(_text(values, UPS_CHARGE_PERCENT))
    runtime = _int_value(_text(values, UPS_RUNTIME_MINUTES))
    seconds_on_battery = _int_value(_text(values, UPS_SECONDS_ON_BATTERY), 0) or 0
    alarm_count = _int_value(_text(values, UPS_ALARMS_PRESENT), 0) or 0
    loads = [value for _, raw in (load_rows or []) if (value := _int_value(raw)) is not None]
    alarms = []
    seen: set[str] = set()
    for _, raw in alarm_rows or []:
        label = _alarm_name(raw)
        if label and label.casefold() not in seen:
            seen.add(label.casefold())
            alarms.append(label)
    source = OUTPUT_SOURCE.get(source_code, "other")
    battery = BATTERY_STATUS.get(battery_code, "unknown")
    snapshot = {
        "manufacturer": _text(values, UPS_IDENT_MANUFACTURER),
        "model": _text(values, UPS_IDENT_MODEL),
        "software_version": _text(values, UPS_IDENT_SOFTWARE),
        "reported_name": _text(values, UPS_IDENT_NAME),
        "battery_status": battery,
        "battery_charge_percent": charge,
        "runtime_minutes": runtime,
        "seconds_on_battery": seconds_on_battery,
        "output_source": source,
        "load_percent": max(loads) if loads else None,
        "alarm_count": alarm_count,
        "alarms": alarms[:24],
    }
    snapshot["power_state"] = _derive_power_state(snapshot)
    return snapshot


def _derive_power_state(snapshot: dict[str, Any]) -> str:
    low_charge = get_app_setting_int("ups_low_charge_percent", 15, 1, 50)
    low_runtime = get_app_setting_int("ups_low_runtime_minutes", 5, 1, 60)
    source = str(snapshot.get("output_source") or "unknown")
    battery = str(snapshot.get("battery_status") or "unknown")
    charge = snapshot.get("battery_charge_percent")
    runtime = snapshot.get("runtime_minutes")
    if source == "battery":
        if battery == "depleted" or charge == 0 or runtime == 0:
            return "depleted"
        if battery in {"low", "fault"} or (charge is not None and int(charge) <= low_charge) or (runtime is not None and int(runtime) <= low_runtime):
            return "low_battery"
        return "on_battery"
    if source == "normal":
        return "normal"
    if source == "bypass":
        return "bypass"
    if source == "none":
        return "output_off"
    # Optional output-source OIDs are not authoritative enough to create
    # operator attention by themselves. If a successful poll still reports a
    # normal battery, healthy charge and no time on battery, normalize the
    # partial state to Normal. Confirmed battery/discharge evidence still wins.
    seconds_on_battery = snapshot.get("seconds_on_battery")
    if source in {"unknown", "other", ""}:
        if battery in {"discharging"}:
            return "on_battery"
        if battery in {"normal", "charging", "floating", "resting"}:
            if charge is None or int(charge) > low_charge:
                if seconds_on_battery in {None, 0, "0"}:
                    return "normal"
    return source or "unknown"


def _get_many_resilient(host: str, profile: dict[str, Any], oids: list[str] | tuple[str, ...], *, batch_size: int = 6) -> dict[str, str]:
    """Collect optional SNMP scalars in small independent batches.

    Older UPS network cards can answer normal RFC1628 requests but reject or
    time out when a large vendor GET PDU is sent. One optional object must not
    discard every other valid vendor metric.
    """
    unique = list(dict.fromkeys(str(oid).strip().lstrip(".") for oid in oids if str(oid).strip()))
    result: dict[str, str] = {}
    for start in range(0, len(unique), max(1, int(batch_size))):
        batch = unique[start:start + max(1, int(batch_size))]
        try:
            result.update(snmpv3_get_many(host, profile, batch))
            continue
        except Exception:
            pass
        # Last-resort scalar requests recover useful telemetry from particularly
        # small/old agents without failing the entire UPS poll.
        for oid in batch:
            try:
                result.update(snmpv3_get_many(host, profile, [oid]))
            except Exception:
                continue
    return result


def _merge_walk_values(values: dict[str, str], rows: list[tuple[str, str]]) -> None:
    for oid, raw in rows or []:
        key = str(oid or "").strip().lstrip(".")
        if key:
            values[key] = str(raw or "")


def _select_power_driver(values: dict[str, str], requested_mode: str):
    """Resolve the live driver before collecting vendor telemetry.

    Auto and legacy Generic rows are always upgraded when live SNMP identity
    proves a known vendor enterprise or product family. Explicit non-generic
    operator selections remain available for unusual cards whose identity is
    intentionally generic.
    """
    mode = normalize_driver_mode(requested_mode)
    detected = detect_driver(values, requested="auto")
    if detected.key != "generic" and mode in {"auto", "generic"}:
        return mode, detected
    return mode, detect_driver(values, requested=mode)


def probe_ups(host: str, profile: dict[str, Any], *, driver_mode: str = "auto", detailed: bool = False) -> dict[str, Any]:
    # Identity-first collection is deliberate. Some older UPS agents tolerate a
    # few standard objects but reject a larger mixed GET PDU. Driver selection
    # must therefore happen from a small, resilient identity read before any
    # vendor-specific requests are sent.
    # Fail fast when the UPS is not reachable. Without this gate, a powered-off
    # UPS would force every optional scalar and vendor fallback to consume its
    # own SNMP timeout window, making the Details modal appear to collect forever.
    # sysDescr is part of MIB-II and is already the credential verification probe.
    values = snmpv3_get_many(host, profile, [SYS_DESCR])
    values.update(_get_many_resilient(host, profile, [oid for oid in IDENTITY_OIDS if oid != SYS_DESCR], batch_size=2))
    remaining_core = [oid for oid in SCALAR_OIDS if oid not in values]
    values.update(_get_many_resilient(host, profile, remaining_core, batch_size=4))
    mode, driver = _select_power_driver(values, driver_mode)

    if driver.extra_oids:
        values.update(_get_many_resilient(host, profile, driver.extra_oids, batch_size=4 if driver.key in {"xppc", "vertiv"} else 6))

    if detailed:
        detail_oids = [*DETAIL_SCALAR_OIDS, *vendor_detail_scalar_oids(driver)]
        values.update(_get_many_resilient(host, profile, detail_oids, batch_size=4 if driver.key in {"xppc", "vertiv"} else 6))

    # XPPC cards are common behind white-label UPS products and some expose a
    # very small SNMP PDU window. If critical native values are still missing,
    # a read-only walk of the UPS subtree recovers model/runtime/load and other
    # vendor telemetry without depending on a single large GET request.
    if driver.key == "xppc":
        critical = (XPPC_MODEL, XPPC_BATTERY_STATUS, XPPC_BATTERY_CAPACITY, XPPC_RUNTIME_SECONDS,
                    XPPC_OUTPUT_STATUS, XPPC_OUTPUT_LOAD, XPPC_INPUT_VOLTAGE, XPPC_INPUT_FREQUENCY,
                    XPPC_OUTPUT_VOLTAGE, XPPC_OUTPUT_FREQUENCY, XPPC_3P_RUNTIME_MINUTES,
                    XPPC_3P_OUTPUT_FREQUENCY, XPPC_3P_OUTPUT_LOAD_R, XPPC_3P_OUTPUT_LOAD_S,
                    XPPC_3P_OUTPUT_LOAD_T, XPPC_3P_BATTERY_CAPACITY)
        missing = [oid for oid in critical if not clean_snmp_value(values.get(oid))]
        if missing:
            try:
                rows = snmpv3_walk(host, profile, XPPC_UPS_ROOT, max_rows=256 if detailed else 96)
                _merge_walk_values(values, rows)
            except Exception:
                # Native GET values already collected above remain usable.
                pass

    # Vertiv/Liebert cards can expose the LGP point tree reliably while a
    # multi-scalar GET is incomplete. A bounded read-only walk recovers those
    # exact measurement point OIDs and lets vendor telemetry override weak RFC
    # placeholders in Details.
    if driver.key == "vertiv":
        critical = (VERTIV_SYSTEM_STATUS, VERTIV_BATTERY_CAPACITY, VERTIV_BATTERY_RUNTIME,
                    VERTIV_OUTPUT_LOAD, VERTIV_OUTPUT_SOURCE)
        missing = [oid for oid in critical if not clean_snmp_value(values.get(oid))]
        if missing or detailed:
            try:
                rows = snmpv3_walk(host, profile, VERTIV_LGP_MEASUREMENT_ROOT, max_rows=640 if detailed else 180)
                _merge_walk_values(values, rows)
            except Exception:
                pass

    generic_evidence = bool(clean_snmp_value(values.get(UPS_BATTERY_STATUS)))
    vendor_evidence = driver_has_vendor_evidence(driver, values)
    if driver.key == "generic" and not generic_evidence:
        raise RuntimeError("SNMPv3 responded but RFC 1628 UPS-MIB battery status was not available")
    if driver.key != "generic" and not generic_evidence and not vendor_evidence:
        raise RuntimeError(f"SNMPv3 responded but {driver.name} / RFC 1628 UPS telemetry was not available")

    load_rows: list[tuple[str, str]] = []
    alarm_rows: list[tuple[str, str]] = []
    try:
        load_rows = snmpv3_walk(host, profile, UPS_OUTPUT_LOAD_TABLE, max_rows=16)
    except Exception:
        pass
    try:
        if (_int_value(values.get(UPS_ALARMS_PRESENT), 0) or 0) > 0:
            alarm_rows = snmpv3_walk(host, profile, UPS_ALARM_DESCR_TABLE, max_rows=64)
    except Exception:
        pass
    if driver.alarm_table_oid:
        try:
            vendor_alarm_count = 0
            if driver.key == "eaton":
                vendor_alarm_count = _int_value(values.get(EATON_ALARMS), 0) or 0
            if vendor_alarm_count > 0:
                vendor_rows = snmpv3_walk(host, profile, driver.alarm_table_oid, max_rows=64)
                existing_labels = {str(value).casefold() for _, value in alarm_rows}
                for oid, raw in vendor_rows:
                    label = vendor_alarm_label(driver, raw)
                    if label and label.casefold() not in existing_labels:
                        alarm_rows.append((oid, label))
                        existing_labels.add(label.casefold())
        except Exception:
            pass
    detail_walks: dict[str, list[tuple[str, str]]] = {}
    if detailed:
        for key, oid in {
            "rfc_input": UPS_INPUT_TABLE,
            "rfc_output": UPS_OUTPUT_TABLE,
            "rfc_bypass": UPS_BYPASS_TABLE,
            **vendor_detail_walk_oids(driver),
        }.items():
            try:
                detail_walks[key] = snmpv3_walk(host, profile, oid, max_rows=96)
            except Exception:
                detail_walks[key] = []

    snapshot = parse_ups_snapshot(values, load_rows, alarm_rows)
    snapshot = enrich_snapshot(driver, snapshot, values)
    snapshot["driver_mode"] = mode
    snapshot["power_state"] = _derive_power_state(snapshot)
    if detailed:
        standard_details = _build_standard_detail_metrics(values, detail_walks)
        vendor_details = build_vendor_detail_metrics(driver, values, detail_walks)
        merged_details = _merge_detail_sections(standard_details, vendor_details, prefer_vendor=(driver.key in {"xppc", "vertiv"}))
        snapshot["telemetry"] = _resolved_detail_sections(merged_details, snapshot, driver)
        snapshot["telemetry"]["monitoring"] = [
            {"key": "driver", "label": "Driver", "value": driver.name, "unit": "", "source": "Portivo"},
            {"key": "protocol", "label": "Telemetry protocol", "value": driver.protocol, "unit": "", "source": "Portivo"},
            {"key": "sys_object_id", "label": "Detected SNMP enterprise", "value": normalize_sys_object_id(values.get(SYS_OBJECT_ID)), "unit": "", "source": "Portivo"},
            {"key": "resolution", "label": "Driver resolution", "value": "Live SNMP identity first", "unit": "", "source": "Portivo"},
        ]
        if driver.key != "generic":
            snapshot["telemetry"]["monitoring"].append({
                "key": "vendor_telemetry", "label": "Native vendor telemetry",
                "value": "Available" if vendor_evidence else "Not exposed by current SNMPv3 view",
                "unit": "", "source": "Portivo",
            })
    return snapshot


def verify_ups(host: str, profile_id: int, *, driver_mode: str = "auto", detailed: bool = False) -> dict[str, Any]:
    profile = get_monitoring_profile(int(profile_id), decrypt=True)
    if not profile or str(profile.get("method") or "") != "snmpv3":
        raise ValueError("Select an SNMPv3 Monitoring Credential profile")
    return probe_ups(str(host).strip(), profile, driver_mode=driver_mode, detailed=detailed)


def _row_dict(row: Any) -> dict[str, Any]:
    item = {key: row[key] for key in row.keys()}
    try:
        item["alarms"] = json.loads(str(item.get("alarms_json") or "[]"))
    except Exception:
        item["alarms"] = []
    item["enabled"] = bool(item.get("enabled"))
    return item


def _poll_one(row: Any) -> tuple[int, dict[str, Any] | None, str]:
    ups_id = int(row["id"])
    profile = get_monitoring_profile(int(row["monitoring_profile_id"] or 0), decrypt=True)
    if not profile or str(profile.get("method") or "") != "snmpv3":
        return ups_id, None, "Assigned Monitoring Credential profile is unavailable or is not SNMPv3"
    try:
        return ups_id, probe_ups(str(row["host"]), profile, driver_mode=str(row["driver_mode"] or "auto")), ""
    except Exception as exc:
        return ups_id, None, str(exc)[:1000]


def _communication_failure_threshold() -> int:
    """Use the same consecutive-check policy as switch outage confirmation.

    UPS communication loss is informational rather than alerting, but operators
    still expect the Offline badge to follow the same Confirm outage after
    setting used elsewhere in Portivo.  Keep the legacy app setting only as a
    defensive fallback for older databases.
    """
    try:
        with db() as conn:
            row = conn.execute("SELECT failure_threshold FROM notification_policy WHERE id=1").fetchone()
        if row is not None:
            return max(2, min(10, int(row["failure_threshold"] or 3)))
    except Exception:
        logger.exception("Could not read shared outage confirmation threshold for UPS monitoring")
    return get_app_setting_int("ups_failure_threshold", 3, 2, 10)


def _apply_result(ups_id: int, snapshot: dict[str, Any] | None, error: str, checked_at: str) -> None:
    from .notification_engine import observe_ups_result

    with db() as conn:
        previous = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
        if not previous:
            return
        previous_dict = _row_dict(previous)
        if snapshot is not None:
            old_reachability = str(previous["last_status"] or "unknown")
            old_power = str(previous["power_state"] or "unknown")
            new_power = str(snapshot.get("power_state") or "unknown")
            power_changed = new_power != old_power
            event_started = checked_at if power_changed else (previous["power_event_started_at"] or checked_at)
            conn.execute(
                """
                UPDATE ups_devices SET manufacturer=?, model=?, software_version=?, reported_name=?, driver_key=?, sys_object_id=?,
                    last_status='online', last_seen=?, last_checked=?, last_error='', consecutive_failures=0,
                    power_state=?, power_event_started_at=?, output_source=?, battery_status=?, battery_charge_percent=?,
                    runtime_minutes=?, seconds_on_battery=?, load_percent=?, alarm_count=?, alarms_json=?, status_changed_at=?, updated_at=?
                WHERE id=?
                """,
                (
                    str(snapshot.get("manufacturer") or previous["manufacturer"] or ""),
                    str(snapshot.get("model") or previous["model"] or ""),
                    str(snapshot.get("software_version") or previous["software_version"] or ""),
                    str(snapshot.get("reported_name") or previous["reported_name"] or ""),
                    str(snapshot.get("driver_key") or previous["driver_key"] or "generic"),
                    str(snapshot.get("sys_object_id") or previous["sys_object_id"] or ""),
                    checked_at, checked_at, new_power, event_started,
                    str(snapshot.get("output_source") or "unknown"), str(snapshot.get("battery_status") or "unknown"),
                    snapshot.get("battery_charge_percent"), snapshot.get("runtime_minutes"), int(snapshot.get("seconds_on_battery") or 0),
                    snapshot.get("load_percent"), int(snapshot.get("alarm_count") or 0), json.dumps(snapshot.get("alarms") or [], ensure_ascii=False),
                    checked_at if old_reachability != "online" else previous["status_changed_at"], checked_at, ups_id,
                ),
            )
        else:
            failures = int(previous["consecutive_failures"] or 0) + 1
            # Communication loss is operational inventory information, but it
            # is deliberately separate from UPS power health.  Do not flip the
            # asset offline on a single missed UDP/SNMP response.  Only expose
            # an Offline communication state after the configured consecutive
            # failure threshold, while preserving the last authoritative power
            # telemetry for battery/runtime/load and power-state decisions.
            failure_threshold = _communication_failure_threshold()
            old_status = str(previous["last_status"] or "unknown")
            if failures >= failure_threshold:
                last_status = "unreachable"
                status_changed_at = checked_at if old_status != "unreachable" else previous["status_changed_at"]
            else:
                last_status = old_status if old_status != "unreachable" else ("online" if previous["last_seen"] else "unknown")
                status_changed_at = previous["status_changed_at"]
            conn.execute(
                "UPDATE ups_devices SET last_checked=?, last_error=?, consecutive_failures=?, last_status=?, status_changed_at=?, updated_at=? WHERE id=?",
                (checked_at, error, failures, last_status, status_changed_at, checked_at, ups_id),
            )
        updated = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    if updated and incident_detection_enabled():
        observe_ups_result(_row_dict(updated), previous=previous_dict, checked_at=checked_at)


def run_power_scan() -> dict[str, Any]:
    started = datetime.now(timezone.utc)
    with db() as conn:
        rows = conn.execute("SELECT * FROM ups_devices WHERE enabled=1 ORDER BY id").fetchall()
    if not rows:
        result = {"checked": 0, "errors": 0, "seconds": 0.0}
    else:
        workers = min(12, max(1, len(rows)))
        errors = 0
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="portivo-ups") as pool:
            futures = [pool.submit(_poll_one, row) for row in rows]
            for future in as_completed(futures):
                ups_id, snapshot, error = future.result()
                if error:
                    errors += 1
                _apply_result(ups_id, snapshot, error, utc_now())
        seconds = (datetime.now(timezone.utc) - started).total_seconds()
        result = {"checked": len(rows), "errors": errors, "seconds": seconds}
    with _status_lock:
        _status.update({"last_cycle_at": utc_now(), "last_cycle_seconds": round(float(result["seconds"]), 3), "checked": int(result["checked"]), "errors": int(result["errors"])})
    return result


def _worker() -> None:
    with _status_lock:
        _status["running"] = True
    try:
        while not _worker_stop.is_set():
            try:
                run_power_scan()
            except Exception:
                logger.exception("Power Infrastructure scan failed")
            interval = get_app_setting_int("ups_poll_interval_seconds", 30, 10, 3600)
            _worker_wake.wait(interval)
            _worker_wake.clear()
    finally:
        with _status_lock:
            _status["running"] = False


def start_power_monitor() -> None:
    global _worker_thread
    if _worker_thread and _worker_thread.is_alive():
        return
    _worker_stop.clear()
    _worker_wake.clear()
    _worker_thread = threading.Thread(target=_worker, name="portivo-power-monitor", daemon=True)
    _worker_thread.start()


def stop_power_monitor() -> None:
    global _worker_thread
    _worker_stop.set()
    _worker_wake.set()
    if _worker_thread and _worker_thread.is_alive():
        _worker_thread.join(timeout=5)
    _worker_thread = None


def request_power_scan() -> None:
    # A scan request must also recover a worker that was not started or died
    # unexpectedly.  This makes the Power workspace self-healing instead of
    # leaving stale Last checked data until the whole Portivo service restarts.
    if monitoring_service_enabled("power_ups"):
        start_power_monitor()
    _worker_wake.set()


def record_ups_probe_failure(ups_id: int, error: str, *, checked_at: str | None = None) -> None:
    """Count a real failed live probe toward UPS communication state."""
    _apply_result(int(ups_id), None, str(error or "UPS telemetry probe failed")[:1000], checked_at or utc_now())


def record_ups_probe_success(ups_id: int, snapshot: dict[str, Any], *, checked_at: str | None = None) -> None:
    """Apply an authoritative successful live UPS probe."""
    _apply_result(int(ups_id), dict(snapshot or {}), "", checked_at or utc_now())


def power_monitor_status() -> dict[str, Any]:
    enabled = monitoring_service_enabled("power_ups")
    if enabled and (not _worker_thread or not _worker_thread.is_alive()):
        start_power_monitor()
    with _status_lock:
        result = dict(_status)
    result["enabled"] = enabled
    result["worker_alive"] = bool(_worker_thread and _worker_thread.is_alive())
    result["failure_threshold"] = _communication_failure_threshold()
    return result
