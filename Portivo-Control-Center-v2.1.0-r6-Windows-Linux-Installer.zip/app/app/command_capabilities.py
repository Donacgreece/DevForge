# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import re
from typing import Any

from .db import db, utc_now

_SYNTAX_REJECTION = re.compile(
    r"(?:invalid\s+(?:entry|command|input|syntax|parameter)|unknown\s+command|incomplete\s+command|syntax\s+error|command\s+not\s+found)",
    re.IGNORECASE,
)


def syntax_rejection(output: str) -> bool:
    return bool(_SYNTAX_REJECTION.search(str(output or "")))


def get_action_capability(device: dict[str, Any] | int, action: str) -> dict[str, Any] | None:
    """Return learned capability only when it still matches device identity.

    A learned rejection is never permanent across an AOS/profile/model change.
    This prevents a legitimate command from remaining blocked after a switch
    software upgrade or hardware replacement.
    """
    if isinstance(device, dict):
        device_id = int(device.get("id") or 0)
        current_profile = str(device.get("profile") or "")
        current_model = str(device.get("model") or "")
        current_aos = str(device.get("aos_version") or "")
    else:
        device_id = int(device)
        current_profile = current_model = current_aos = ""
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM device_action_capabilities WHERE device_id = ? AND action = ?",
            (device_id, str(action)),
        ).fetchone()
    if not row:
        return None
    data = dict(row)
    if isinstance(device, dict):
        stored = (str(data.get("profile") or ""), str(data.get("model") or ""), str(data.get("aos_version") or ""))
        current = (current_profile, current_model, current_aos)
        # Empty identity values are tolerated, but any known mismatch makes the
        # learned result stale and therefore ineligible for blocking execution.
        for old, new in zip(stored, current):
            if old and new and old != new:
                return None
    return data


def record_action_capability(device: dict[str, Any], action: str, state: str, evidence: str = "") -> None:
    if state not in {"supported", "unsupported"}:
        return
    try:
        device_id = int(device.get("id"))
    except (TypeError, ValueError):
        return
    if device_id <= 0 or not action:
        return
    clean_evidence = " ".join(str(evidence or "").replace("\r", " ").replace("\n", " ").split())[:500]
    with db() as conn:
        conn.execute(
            """
            INSERT INTO device_action_capabilities(
                device_id, profile, model, aos_version, action, state, evidence, updated_at
            ) VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(device_id, action) DO UPDATE SET
                profile=excluded.profile, model=excluded.model, aos_version=excluded.aos_version,
                state=excluded.state, evidence=excluded.evidence, updated_at=excluded.updated_at
            """,
            (
                device_id, str(device.get("profile") or ""), str(device.get("model") or ""),
                str(device.get("aos_version") or ""), str(action), state, clean_evidence, utc_now(),
            ),
        )
