# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .crypto import decrypt_secret
from .db import db, utc_now
from .job_runner import run_job
from .runbooks import get_runbook, render_runbook

logger = logging.getLogger(__name__)

_SCHEDULER_LOCK = threading.RLock()
_STOP_EVENT = threading.Event()
_THREAD: threading.Thread | None = None


AUTOMATION_ACTIONS: dict[str, dict[str, Any]] = {
    "check_unp": {
        "id": "check_unp",
        "category": "UNP",
        "label": "Check UNP",
        "description": "Read-only scan for ports where guest and voice/IPTV profiles coexist.",
        "destructive": False,
        "requires_credentials": True,
        "supports_scope": True,
        "safeguard_profile": None,
        "settings": {},
    },
    "fix_unp": {
        "id": "fix_unp",
        "category": "UNP",
        "label": "Check and fix UNP",
        "description": "Detect affected ports and restart only interfaces allowed by the Fix UNP safeguards.",
        "destructive": True,
        "requires_credentials": True,
        "supports_scope": True,
        "safeguard_profile": "fix_unp",
        "settings": {
            "cycle_delay_seconds": {"type": "integer", "default": 5, "min": 1, "max": 300, "label": "Restart delay", "suffix": "seconds"}
        },
    },
    "vlan_port_maintenance": {
        "id": "vlan_port_maintenance",
        "category": "VLAN",
        "label": "VLAN Port Maintenance",
        "description": "Discover access ports for a target VLAN, protect uplinks and infrastructure, then restart PoE or the interface.",
        "destructive": True,
        "requires_credentials": True,
        "supports_scope": True,
        "safeguard_profile": "vlan_port_maintenance",
        "settings": {
            "target_vlan": {"type": "integer", "default": 1, "min": 1, "max": 4094, "label": "Target VLAN"},
            "operation": {
                "type": "choice", "default": "poe_cycle", "label": "Maintenance action",
                "choices": [
                    {"value": "poe_cycle", "label": "Restart PoE"},
                    {"value": "interface_cycle", "label": "Restart interface"}
                ]
            },
            "cycle_delay_seconds": {"type": "integer", "default": 5, "min": 1, "max": 300, "label": "Restart delay", "suffix": "seconds"}
        },
    },
    "custom_runbook": {
        "id": "custom_runbook",
        "category": "Advanced",
        "label": "Custom Runbook",
        "description": "Run an approved reusable CLI workflow with variables, execution limits and audit logging.",
        "destructive": True,
        "requires_credentials": True,
        "supports_scope": True,
        "safeguard_profile": None,
        "settings": {
            "runbook_id": {"type": "runbook", "default": 0, "label": "Runbook"},
            "variables": {"type": "runbook_variables", "default": {}, "label": "Variables"}
        },
    },
}


def public_automation_actions() -> list[dict[str, Any]]:
    return [dict(value) for value in AUTOMATION_ACTIONS.values()]


def automation_action_ids() -> set[str]:
    return set(AUTOMATION_ACTIONS)


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def _json_list(value: str | None) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item).strip() for item in parsed if str(item).strip()]


def list_schedules() -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT * FROM automation_schedules ORDER BY enabled DESC, run_time, name COLLATE NOCASE").fetchall()
    items: list[dict[str, Any]] = []
    for row in rows:
        item = _row_to_dict(row)
        item["enabled"] = bool(item["enabled"])
        item["sites"] = _json_list(item.pop("sites_json", "[]"))
        item["groups"] = _json_list(item.pop("groups_json", "[]"))
        try:
            settings = json.loads(item.pop("settings_json", "{}") or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            settings = {}
        if not isinstance(settings, dict):
            settings = {}
        item["settings"] = settings
        # Compatibility field for v1.6.2 cached clients.
        item["cycle_delay_seconds"] = int(settings.get("cycle_delay_seconds") or 5)
        items.append(item)
    return items


def scheduler_credential_status() -> dict[str, Any]:
    with db() as conn:
        row = conn.execute(
            "SELECT username, verified_device_id, verified_device_name, verified_at, updated_at, updated_by FROM scheduler_credentials WHERE id = 1"
        ).fetchone()
    if not row:
        return {"configured": False, "username": "", "verified_at": None, "verified_device_name": ""}
    result = _row_to_dict(row)
    result["configured"] = True
    return result


def load_scheduler_credentials() -> dict[str, str] | None:
    with db() as conn:
        row = conn.execute("SELECT username, password_enc FROM scheduler_credentials WHERE id = 1").fetchone()
    if not row or not row["username"] or not row["password_enc"]:
        return None
    # Validate decryptability before returning the encrypted value to the SSH runner.
    decrypt_secret(str(row["password_enc"]))
    return {"username": str(row["username"]), "password_enc": str(row["password_enc"])}


def _timezone(name: str) -> ZoneInfo:
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        return ZoneInfo("UTC")


def _device_ids_for_schedule(schedule: dict[str, Any]) -> list[int]:
    sites = schedule.get("sites") or []
    groups = schedule.get("groups") or []
    clauses = ["enabled = 1"]
    params: list[Any] = []
    if sites:
        clauses.append("site IN (%s)" % ",".join("?" for _ in sites))
        params.extend(sites)
    if groups:
        clauses.append("group_name IN (%s)" % ",".join("?" for _ in groups))
        params.extend(groups)
    with db() as conn:
        rows = conn.execute(
            f"SELECT id FROM devices WHERE {' AND '.join(clauses)} ORDER BY site, group_name, name",
            params,
        ).fetchall()
    return [int(row["id"]) for row in rows]


def _create_job(schedule: dict[str, Any], credentials: dict[str, str]) -> int:
    device_ids = _device_ids_for_schedule(schedule)
    if not device_ids:
        raise RuntimeError("No enabled switches match the selected site and group scope")

    action = str(schedule.get("action") or "fix_unp")
    if action not in AUTOMATION_ACTIONS:
        raise RuntimeError(f"Unsupported scheduled action: {action}")
    action_settings = schedule.get("settings") if isinstance(schedule.get("settings"), dict) else {}
    runbook_snapshot = None
    if action == "custom_runbook":
        runbook_id = int(action_settings.get("runbook_id") or 0)
        runbook = get_runbook(runbook_id)
        if not runbook:
            raise RuntimeError("Scheduled runbook no longer exists")
        if str(runbook.get("status") or "draft") != "approved":
            raise RuntimeError("Scheduled runbook is not approved")
        if not bool(runbook.get("allow_scheduled")):
            raise RuntimeError("This runbook is not approved for scheduled execution")
        runbook_snapshot = render_runbook(runbook, action_settings.get("variables") if isinstance(action_settings.get("variables"), dict) else {})
        if len(device_ids) > int(runbook_snapshot.get("max_targets") or 1):
            raise RuntimeError(f"Runbook target limit exceeded: {len(device_ids)} switches > {int(runbook_snapshot.get('max_targets') or 1)}")
    now = utc_now()
    payload = {
        "action": action,
        "targets": [{"device_id": device_id, "port": "", "slot": ""} for device_id in device_ids],
        "dry_run": False,
        "cycle_delay_seconds": int(action_settings.get("cycle_delay_seconds") or schedule.get("cycle_delay_seconds") or 5),
        "port_alias": "",
        "confirmation_text": "EXECUTE" if bool(AUTOMATION_ACTIONS[action].get("destructive")) else "",
        "custom_command": "",
        "target_vlan": int(action_settings.get("target_vlan") or 1),
        "vlan_maintenance_operation": str(action_settings.get("operation") or "poe_cycle"),
        "automation_settings": action_settings,
        "runbook_id": int(action_settings.get("runbook_id") or 0),
        "runbook_variables": action_settings.get("variables") if isinstance(action_settings.get("variables"), dict) else {},
        "runbook_snapshot": runbook_snapshot,
        "scheduled": True,
        "schedule_id": int(schedule["id"]),
        "schedule_name": str(schedule["name"]),
    }
    requested_by = f"scheduler:{schedule['name']}"
    with db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO jobs(action, status, dry_run, target_count, requested_by, payload_json, created_at)
            VALUES(?, 'queued', 0, ?, ?, ?, ?)
            """,
            (action, len(device_ids), requested_by, json.dumps(payload, ensure_ascii=False), now),
        )
        job_id = int(cursor.lastrowid)
        for device_id in device_ids:
            device = conn.execute("SELECT name, host FROM devices WHERE id = ?", (device_id,)).fetchone()
            if not device:
                continue
            conn.execute(
                """
                INSERT INTO job_items(job_id, device_id, device_name, host, port, slot, status)
                VALUES(?, ?, ?, ?, '', '', 'queued')
                """,
                (job_id, device_id, device["name"], device["host"]),
            )
        conn.execute(
            """
            INSERT INTO audit_log(actor, event, object_type, object_id, details_json, created_at)
            VALUES(?, 'scheduled_automation_job_queued', 'schedule', ?, ?, ?)
            """,
            (
                requested_by,
                str(schedule["id"]),
                json.dumps({"job_id": job_id, "action": action, "targets": len(device_ids)}, ensure_ascii=False),
                now,
            ),
        )
    return job_id


def _run_and_finalize(schedule_id: int, job_id: int, credentials: dict[str, str]) -> None:
    status = "failed"
    error = ""
    try:
        run_job(job_id, credentials)
        with db() as conn:
            job = conn.execute("SELECT status FROM jobs WHERE id = ?", (job_id,)).fetchone()
        status = str(job["status"] if job else "failed")
    except Exception as exc:  # pragma: no cover - defensive scheduler guard
        logger.exception("Scheduled automation job %s failed", job_id)
        error = f"{type(exc).__name__}: {exc}"
    with db() as conn:
        conn.execute(
            "UPDATE automation_schedules SET last_status = ?, last_error = ?, updated_at = ? WHERE id = ?",
            (status, error, utc_now(), schedule_id),
        )


def _claim_due_schedule(schedule: dict[str, Any], local_date: str) -> bool:
    with db() as conn:
        cursor = conn.execute(
            """
            UPDATE automation_schedules
            SET last_run_local_date = ?, last_run_at = ?, last_status = 'starting', last_error = '', updated_at = ?
            WHERE id = ? AND enabled = 1 AND COALESCE(last_run_local_date, '') <> ?
            """,
            (local_date, utc_now(), utc_now(), int(schedule["id"]), local_date),
        )
    return bool(cursor.rowcount)


def run_due_schedules_once(now_utc: datetime | None = None) -> int:
    now_utc = now_utc or datetime.now(timezone.utc)
    credentials = load_scheduler_credentials()
    started = 0
    for schedule in list_schedules():
        if not schedule.get("enabled"):
            continue
        zone = _timezone(str(schedule.get("timezone") or "UTC"))
        local_now = now_utc.astimezone(zone)
        run_time = str(schedule.get("run_time") or "06:00")
        try:
            hour, minute = (int(part) for part in run_time.split(":", 1))
        except (TypeError, ValueError):
            continue
        if (local_now.hour, local_now.minute) < (hour, minute):
            continue
        local_date = local_now.date().isoformat()
        if str(schedule.get("last_run_local_date") or "") == local_date:
            continue
        if not credentials:
            with db() as conn:
                conn.execute(
                    "UPDATE automation_schedules SET last_status = 'credential_required', last_error = ?, updated_at = ? WHERE id = ?",
                    ("No verified scheduler SSH account is configured", utc_now(), int(schedule["id"])),
                )
            continue
        if not _claim_due_schedule(schedule, local_date):
            continue
        try:
            job_id = _create_job(schedule, credentials)
        except Exception as exc:
            with db() as conn:
                conn.execute(
                    "UPDATE automation_schedules SET last_status = 'failed', last_error = ?, updated_at = ? WHERE id = ?",
                    (str(exc), utc_now(), int(schedule["id"])),
                )
            continue
        with db() as conn:
            conn.execute(
                "UPDATE automation_schedules SET last_job_id = ?, last_status = 'queued', updated_at = ? WHERE id = ?",
                (job_id, utc_now(), int(schedule["id"])),
            )
        threading.Thread(
            target=_run_and_finalize,
            args=(int(schedule["id"]), job_id, credentials),
            name=f"automation-schedule-{schedule['id']}-job-{job_id}",
            daemon=True,
        ).start()
        started += 1
    return started


def _scheduler_loop() -> None:
    while not _STOP_EVENT.wait(20):
        try:
            run_due_schedules_once()
        except Exception:  # pragma: no cover - keeps background service alive
            logger.exception("Automation scheduler iteration failed")


def start_unp_scheduler() -> None:
    global _THREAD
    with _SCHEDULER_LOCK:
        if _THREAD and _THREAD.is_alive():
            return
        _STOP_EVENT.clear()
        _THREAD = threading.Thread(target=_scheduler_loop, name="automation-scheduler", daemon=True)
        _THREAD.start()


def stop_unp_scheduler() -> None:
    global _THREAD
    _STOP_EVENT.set()
    thread = _THREAD
    if thread and thread.is_alive():
        thread.join(timeout=3)
    _THREAD = None


def run_schedule_now(schedule_id: int) -> int:
    credentials = load_scheduler_credentials()
    if not credentials:
        raise RuntimeError("No verified scheduler SSH account is configured")
    schedule = next((item for item in list_schedules() if int(item["id"]) == int(schedule_id)), None)
    if not schedule:
        raise LookupError("Schedule not found")
    job_id = _create_job(schedule, credentials)
    with db() as conn:
        conn.execute(
            "UPDATE automation_schedules SET last_run_at = ?, last_job_id = ?, last_status = 'queued', last_error = '', updated_at = ? WHERE id = ?",
            (utc_now(), job_id, utc_now(), schedule_id),
        )
    threading.Thread(
        target=_run_and_finalize,
        args=(schedule_id, job_id, credentials),
        name=f"automation-schedule-{schedule_id}-manual-{job_id}",
        daemon=True,
    ).start()
    return job_id
