# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import asyncio
import csv
import io
import ipaddress
import json
import logging
import math
import os
import socket
import sqlite3
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile
from concurrent.futures import ThreadPoolExecutor, as_completed

from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from openpyxl import Workbook, load_workbook
from starlette.background import BackgroundTask
from starlette.middleware.sessions import SessionMiddleware

from .config import settings
from .login_throttle import LoginRateLimiter
from .password_policy import MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH
from .time_service import available_timezone_names, local_date_boundary_utc, platform_now, platform_timezone_name
from .auth import hash_password, verify_password
from .crypto import encrypt_secret, decrypt_secret
from .db import (
    db,
    get_app_setting,
    get_app_setting_bool,
    get_app_setting_int,
    init_db,
    update_app_settings,
    utc_now,
    get_ssh_user_profile,
    register_ssh_user_login,
    list_ssh_user_profiles,
    update_ssh_user_profile,
    update_ssh_user_access,
)
from .device_identity import parse_show_system
from .device_layout import (
    infer_device_port_layout, is_compact_os6360_model, is_os6360_family_model,
    infer_compact_os6360_from_live_ports, compact_os6360_port_allowed,
)
from .job_runner import run_job
from .job_lifecycle import reconcile_orphaned_jobs, TERMINAL_JOB_STATUSES
from .session_credentials import session_credentials
from .health_monitor import (
    record_health_result,
    confirmed_connectivity_status,
    request_health_scan,
    scan_all_devices,
    health_monitor_status,
    start_health_monitor,
    stop_health_monitor,
)
from .stack_monitor import request_stack_scan, reset_stack_baseline, stack_monitor_status, start_stack_monitor, stop_stack_monitor
from .monitoring_credentials import get_monitoring_profile, list_monitoring_profiles
from .snmp_monitor import snmpv3_verify
from .power_monitor import (
    power_monitor_status, request_power_scan, start_power_monitor, stop_power_monitor, verify_ups,
    record_ups_probe_failure, record_ups_probe_success,
)
from .power_drivers import driver_name as power_driver_name, power_driver_catalog
from .monitoring_policy import monitoring_policy, monitoring_service_enabled
from .notification_engine import (
    delete_destination,
    get_notification_state,
    save_destination,
    save_notification_policy,
    send_test_notification,
    start_notification_worker,
    stop_notification_worker,
    purge_ups_reachability_noise,
)
from .profiles import public_profiles, public_action_catalog, public_driver_catalog, render_command, validate_custom_commands, is_read_only_action, creates_pending_configuration
from .persistent_save import save_preview_for_profile
from .reload_actions import reload_command
from .unp_fix import build_restart_commands, detect_conflicts, format_detection_summary, max_ports_per_switch, protected_ports
from .port_inventory import (
    infer_slots,
    merge_inventory,
    merge_port_records,
    observe_port_states,
    parse_interface_alias,
    parse_interface_status,
    parse_lanpower,
    parse_vlan_members,
    summarize_ports,
    load_inventory_snapshot,
    save_inventory_snapshot,
)
from .pdf_reports import build_job_pdf, safe_report_filename
from .audit_reports import build_fleet_audit_pdf, safe_audit_filename
from .fleet_audits import public_audit_catalog, create_audit_run, run_fleet_audit, get_audit_run, list_audit_runs
from .pending_config import list_pending_configuration
from .device_finder import device_search_registry, execute_device_search, detect_search_type
from .ale_cli import action_support, poe_status_command, poe_status_commands, slot_from_port
from .command_capabilities import get_action_capability
from .port_troubleshooter import build_diagnosis, validate_port
from .schemas import (
    BulkExecuteRequest,
    ConnectionTestRequest,
    DeviceCreate,
    DeviceUpdate,
    DraftConnectionTestRequest,
    LoginRequest,
    PreviewRequest,
    PasswordChangeRequest,
    AdminSettingsRequest,
    NotificationPolicyRequest,
    NotificationDestinationRequest,
    AdminMaintenanceRequest,
    SshUserRoleUpdateRequest,
    SshUserAccessUpdateRequest,
    AccessRoleUpsertRequest,
    DeviceFinderRequest,
    PortDiagnosticRequest,
    FleetAuditRequest,
    SchedulerCredentialRequest,
    UnpScheduleRequest,
    AutomationScheduleRequest,
    FixUnpSafeguardsRequest,
    VlanMaintenanceSafeguardsRequest,
    RunbookUpsertRequest,
    MonitoringCredentialProfileRequest,
    UpsAssignmentRequest,
    UpsDeviceRequest,
    UpsVerifyRequest,
)
from .vlan_maintenance import (
    format_assessment as format_vlan_maintenance_assessment,
    inspect_vlan_maintenance_session,
    safeguard_policy as vlan_maintenance_safeguard_policy,
)
from .unp_scheduler import (
    list_schedules,
    scheduler_credential_status,
    start_unp_scheduler,
    stop_unp_scheduler,
    run_schedule_now,
    public_automation_actions,
    automation_action_ids,
    load_scheduler_credentials,
)
from .ssh_runner import (
    close_interactive_connection,
    command_session,
    open_interactive_connection,
    read_interactive_data,
    resize_interactive_terminal,
    run_command_collection,
    run_commands,
    write_interactive_data,
    SSHAuthenticationFailure,
    SSHConnectionFailure,
    SSHTimeoutFailure,
    authenticate_login_once,
)
from .ssh_coordinator import SSHDeviceBusyError, ssh_coordinator
from .vendor_drivers import driver_for_profile
from .runbooks import (
    approve_runbook, delete_runbook, format_runbook_plan, get_runbook, list_runbooks,
    render_runbook, save_runbook,
)
from .access_control import (
    access_context_for_profile, access_context_for_user, action_catalog_for_access,
    capability_catalog_payload, delete_custom_role, device_in_scope, filter_devices,
    list_roles, normalize_scope, role_by_id, save_custom_role, scoped_device_ids,
)


STATIC_DIR = Path(__file__).resolve().parent / "static"
PACKAGE_ROOT = Path(__file__).resolve().parent.parent
logger = logging.getLogger(__name__)

DATABASE_IMPORT_MAX_BYTES = 2 * 1024 * 1024 * 1024
INVENTORY_IMPORT_MAX_BYTES = 20 * 1024 * 1024
INVENTORY_IMPORT_MAX_ROWS = 25_000
INVENTORY_IMPORT_MAX_COLUMNS = 64
INVENTORY_IMPORT_MAX_CELL_CHARS = 32_768
INVENTORY_XLSX_MAX_UNCOMPRESSED_BYTES = 100 * 1024 * 1024
INVENTORY_XLSX_MAX_ZIP_ENTRIES = 2_048
INVENTORY_XLSX_MAX_COMPRESSION_RATIO = 100
_DATABASE_MAINTENANCE_LOCK = threading.Lock()
_REQUIRED_DATABASE_TABLES = {
    "devices", "jobs", "job_items", "audit_log", "app_users", "app_settings"
}

login_rate_limiter = LoginRateLimiter(
    window_seconds=settings.login_rate_limit_window_seconds,
    max_delay_seconds=settings.login_rate_limit_max_delay_seconds,
)


class SSHLoginRejected(Exception):
    def __init__(self, device: dict[str, Any], error: str) -> None:
        super().__init__(error)
        self.device = device
        self.error = error


app = FastAPI(title=settings.app_name, version=settings.app_version, docs_url=None, redoc_url=None, openapi_url=None)
PORTIVO_BUILD_REVISION = "2.1.0-r6"

@app.middleware("http")
async def portivo_build_headers(request: Request, call_next):
    response = await call_next(request)
    if str(request.url.path).startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, max-age=0"
    return response
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    same_site="strict",
    https_only=settings.cookie_secure,
    max_age=8 * 60 * 60,
)

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
        "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; "
        "img-src 'self' data:; connect-src 'self' ws: wss:"
    )
    if settings.public_url_scheme == "https":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response



def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def _sanitize_compact_os6360_inventory(ports: list[dict[str, Any]], model: str, profile: str, *, force_compact: bool = False) -> list[dict[str, Any]]:
    """Drop non-physical pseudo/summary interfaces for compact OS6360 models."""
    if not force_compact and not is_compact_os6360_model(model):
        return ports
    return [
        item for item in ports
        if compact_os6360_port_allowed(str(item.get("port") or ""), profile)
    ]


def _compact_os6360_layout() -> dict[str, Any]:
    """Canonical compact OS6360 front-panel layout used after live inference."""
    layout = infer_device_port_layout("OS6360-P10", "AOS8")
    layout = dict(layout)
    layout["inferred"] = True
    return layout


def _public_device(row: Any) -> dict[str, Any]:
    device = _row_to_dict(row) if hasattr(row, "keys") else dict(row)
    device.pop("password_enc", None)
    device.pop("username", None)
    device.pop("credential_profile_id", None)
    device["enabled"] = bool(device["enabled"])
    device["stack_monitor_enabled"] = bool(device.get("stack_monitor_enabled"))
    for _key in ("stack_member_ids_json", "stack_members_json", "stack_baseline_member_ids_json", "stack_baseline_members_json"):
        try:
            device[_key.removesuffix("_json")] = json.loads(device.get(_key) or "[]")
        except Exception:
            device[_key.removesuffix("_json")] = []
    profile = str(device.get("profile") or "AOS8")
    device["port_layout"] = infer_device_port_layout(str(device.get("model") or ""), profile)
    try:
        descriptor = driver_for_profile(profile).descriptor
        device["vendor"] = descriptor.vendor
        device["os_family"] = descriptor.os_family
        device["driver_key"] = descriptor.key
    except KeyError:
        device["vendor"] = ""
        device["os_family"] = ""
        device["driver_key"] = ""
    return device


def _require_local(request: Request) -> None:
    """Compatibility shim retained for upgraded installations.

    Access is authenticated with application accounts and may originate from the
    local machine or a trusted LAN address. Network exposure is controlled by
    APP_HOST and the Windows firewall, not by a loopback-only browser check.
    """
    return None


def _require_loopback(request: Request) -> None:
    """Allow installer-only diagnostics from the local host without exposing build metadata on the LAN."""
    host = str(request.client.host) if request.client and request.client.host else ""
    try:
        if ipaddress.ip_address(host).is_loopback:
            return
    except ValueError:
        if host.lower() == "localhost":
            return
    raise HTTPException(status_code=404, detail="Not found")


def _websocket_origin_allowed(websocket: WebSocket) -> bool:
    origin = str(websocket.headers.get("origin") or "").strip()
    host = str(websocket.headers.get("host") or "").strip().lower()
    if not origin or not host:
        return False
    try:
        from urllib.parse import urlsplit
        parts = urlsplit(origin)
    except Exception:
        return False
    if parts.scheme.lower() not in {"http", "https"} or not parts.netloc:
        return False
    if parts.username or parts.password:
        return False
    allowed_hosts = {host}
    direct_ip = str(websocket.client.host) if websocket.client and websocket.client.host else ""
    if settings.trust_proxy_headers and direct_ip in settings.trusted_proxy_ips:
        forwarded_host = str(websocket.headers.get("x-forwarded-host") or "").split(",", 1)[0].strip().lower()
        if forwarded_host:
            allowed_hosts.add(forwarded_host)
    return parts.netloc.lower() in allowed_hosts


def current_user(request: Request) -> dict[str, Any]:
    _require_local(request)
    auth_type = str(request.session.get("auth_type") or "")
    if auth_type == "ssh":
        token = str(request.session.get("ssh_token") or "")
        username = session_credentials.username(token)
        if not username:
            request.session.clear()
            raise HTTPException(status_code=401, detail="Your SSH session has expired. Sign in again.")
        profile = get_ssh_user_profile(username)
        if not profile:
            request.session.clear()
            session_credentials.remove(token)
            raise HTTPException(status_code=401, detail="Your SSH user profile is unavailable. Sign in again.")
        if not bool(profile.get("enabled")):
            request.session.clear()
            session_credentials.remove(token)
            raise HTTPException(status_code=403, detail="Your Portivo Control Center access has been disabled by an administrator.")
        access = access_context_for_profile(profile)
        return {
            **profile,
            "id": int(profile["id"]),
            "username": str(profile["username"]),
            "display_name": str(profile.get("display_name") or profile["username"]),
            "role": access.role_key,
            "role_name": access.role_name,
            "auth_type": "ssh",
            "enabled": True,
            "must_change_password": False,
        }

    if auth_type == "admin":
        user_id = request.session.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="Sign in as the bootstrap administrator")
        with db() as conn:
            row = conn.execute(
                "SELECT id, username, display_name, role, enabled, must_change_password, last_login FROM app_users WHERE id = ?",
                (int(user_id),),
            ).fetchone()
        if not row or not row["enabled"] or row["role"] != "admin":
            request.session.clear()
            raise HTTPException(status_code=401, detail="The bootstrap administrator account is unavailable")
        user = _row_to_dict(row)
        user["enabled"] = bool(user["enabled"])
        user["must_change_password"] = bool(user["must_change_password"])
        user["auth_type"] = "admin"
        user["role_name"] = "Administrator"
        return user

    raise HTTPException(status_code=401, detail="Sign in with your personal SSH account")


def _access(user: dict[str, Any]):
    return access_context_for_user(user)


def _is_platform_admin(user: dict[str, Any]) -> bool:
    return _access(user).role_key == "admin"


def _can_change_network(user: dict[str, Any]) -> bool:
    if user.get("auth_type") != "ssh":
        return False
    access = _access(user)
    catalog = public_action_catalog()
    return any(not is_read_only_action(action) and access.can_action(action) for action in catalog)


def _require_capability(user: dict[str, Any], capability: str, message: str | None = None) -> None:
    if not _access(user).has(capability):
        raise HTTPException(status_code=403, detail=message or "Your assigned role does not allow this feature")


def _require_any_capability(user: dict[str, Any], capabilities: set[str], message: str | None = None) -> None:
    access = _access(user)
    if not any(access.has(capability) for capability in capabilities):
        raise HTTPException(status_code=403, detail=message or "Your assigned role does not allow this feature")


def _require_device_scope(user: dict[str, Any], device: Any) -> None:
    if not device_in_scope(_access(user), device):
        raise HTTPException(status_code=403, detail="This switch is outside your assigned Site/Group scope")


def _scoped_device_ids(user: dict[str, Any], *, enabled_only: bool = False) -> set[int]:
    return scoped_device_ids(_access(user), enabled_only=enabled_only)


def _require_target_scope(user: dict[str, Any], device_ids: list[int] | set[int]) -> None:
    requested = {int(value) for value in device_ids}
    if not requested:
        return
    allowed = _scoped_device_ids(user)
    outside = sorted(requested - allowed)
    if outside:
        raise HTTPException(status_code=403, detail=f"One or more selected switches are outside your assigned scope: {outside[:12]}")


def _accessible_job_ids(user: dict[str, Any], candidate_ids: list[int] | None = None) -> set[int] | None:
    access = _access(user)
    if access.scope_mode == "all" or access.global_role:
        return None if candidate_ids is None else {int(value) for value in candidate_ids}
    allowed_devices = _scoped_device_ids(user)
    if not allowed_devices:
        return set()
    where = ""
    params: list[Any] = []
    if candidate_ids:
        ids = [int(value) for value in candidate_ids]
        placeholders = ",".join("?" for _ in ids)
        where = f" WHERE job_id IN ({placeholders})"
        params.extend(ids)
    with db() as conn:
        rows = conn.execute(f"SELECT job_id, device_id FROM job_items{where}", params).fetchall()
    grouped: dict[int, set[int]] = {}
    for row in rows:
        grouped.setdefault(int(row["job_id"]), set()).add(int(row["device_id"]))
    return {job_id for job_id, devices in grouped.items() if devices and devices.issubset(allowed_devices)}


def _install_activity_scope_table(conn: sqlite3.Connection, user: dict[str, Any]) -> bool:
    """Install the current user's device scope in a connection-local temp table.

    Activity pagination must filter before LIMIT/OFFSET. A temporary table keeps
    the SQL bounded even when the fleet grows past SQLite's parameter limit and
    lets Jobs/Audit counts use exactly the same server-side scope as the page.
    """
    access = _access(user)
    if access.scope_mode == "all" or access.global_role:
        return False
    allowed_devices = sorted(_scoped_device_ids(user))
    conn.execute("CREATE TEMP TABLE IF NOT EXISTS portivo_activity_scope_devices(id INTEGER PRIMARY KEY)")
    conn.execute("DELETE FROM temp.portivo_activity_scope_devices")
    if allowed_devices:
        conn.executemany(
            "INSERT INTO temp.portivo_activity_scope_devices(id) VALUES (?)",
            ((int(device_id),) for device_id in allowed_devices),
        )
    return True


def _activity_job_scope_clause(conn: sqlite3.Connection, user: dict[str, Any], *, alias: str = "j") -> str:
    if not _install_activity_scope_table(conn, user):
        return ""
    return (
        f" AND EXISTS (SELECT 1 FROM job_items ji_visible WHERE ji_visible.job_id = {alias}.id)"
        f" AND NOT EXISTS ("
        f"SELECT 1 FROM job_items ji_scope "
        f"LEFT JOIN temp.portivo_activity_scope_devices sd ON sd.id = ji_scope.device_id "
        f"WHERE ji_scope.job_id = {alias}.id AND sd.id IS NULL"
        f")"
    )


def _activity_audit_scope_clause(conn: sqlite3.Connection, user: dict[str, Any], *, alias: str = "a") -> tuple[str, list[Any]]:
    if not _install_activity_scope_table(conn, user):
        return "", []
    username = str(user.get("username") or "")
    clause = (
        " AND ("
        f"({alias}.object_type = 'device' AND EXISTS ("
        "SELECT 1 FROM temp.portivo_activity_scope_devices sd "
        f"WHERE sd.id = CAST({alias}.object_id AS INTEGER)))"
        " OR "
        f"({alias}.object_type = 'job' "
        f"AND EXISTS (SELECT 1 FROM job_items ji_visible WHERE ji_visible.job_id = CAST({alias}.object_id AS INTEGER)) "
        "AND NOT EXISTS (SELECT 1 FROM job_items ji_scope "
        "LEFT JOIN temp.portivo_activity_scope_devices sd ON sd.id = ji_scope.device_id "
        f"WHERE ji_scope.job_id = CAST({alias}.object_id AS INTEGER) AND sd.id IS NULL))"
        " OR "
        f"({alias}.object_type = 'fleet_audit' "
        f"AND EXISTS (SELECT 1 FROM fleet_audit_items fai_visible WHERE fai_visible.run_id = CAST({alias}.object_id AS INTEGER)) "
        "AND NOT EXISTS (SELECT 1 FROM fleet_audit_items fai_scope "
        "LEFT JOIN temp.portivo_activity_scope_devices sd ON sd.id = fai_scope.device_id "
        f"WHERE fai_scope.run_id = CAST({alias}.object_id AS INTEGER) AND sd.id IS NULL))"
        " OR "
        f"({alias}.object_type = 'device_finder' AND lower({alias}.actor) = lower(?))"
        ")"
    )
    return clause, [username]


def _require_job_scope(user: dict[str, Any], job_id: int) -> None:
    allowed = _accessible_job_ids(user, [int(job_id)])
    if allowed is not None and int(job_id) not in allowed:
        raise HTTPException(status_code=403, detail="This Job contains targets outside your assigned Site/Group scope")


def _audit_result_in_scope(user: dict[str, Any], result: dict[str, Any]) -> bool:
    access = _access(user)
    if access.scope_mode == "all" or access.global_role:
        return True
    items = result.get("items") or []
    if not items:
        return False
    return all(device_in_scope(access, item) for item in items)


def _require_audit_scope(user: dict[str, Any], result: dict[str, Any]) -> None:
    if not _audit_result_in_scope(user, result):
        raise HTTPException(status_code=403, detail="This Fleet Audit contains targets outside your assigned Site/Group scope")


def require_admin(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not _is_platform_admin(user):
        raise HTTPException(status_code=403, detail="Administrator access is required")
    return user


def require_bootstrap_admin(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if user.get("auth_type") != "admin" or str(user.get("role") or "") != "admin":
        raise HTTPException(status_code=403, detail="Bootstrap administrator access is required")
    return user


def require_inventory_manager(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    access = _access(user)
    if not access.has("inventory.manage"):
        raise HTTPException(status_code=403, detail="Your assigned role does not allow switch inventory management")
    if user.get("auth_type") == "ssh" and not get_app_setting_bool("ssh_users_manage_inventory", True):
        raise HTTPException(status_code=403, detail="SSH inventory management is disabled by the platform administrator")
    return user


def _require_action_permission(user: dict[str, Any], action: str) -> None:
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to run switch commands")
    access = _access(user)
    if not access.has("operations.view"):
        raise HTTPException(status_code=403, detail="Your assigned role does not include Operations access")
    if not access.can_action(action):
        raise HTTPException(status_code=403, detail="This action is not permitted by your assigned role")


def _require_runbook_permission(user: dict[str, Any], runbook: dict[str, Any], *, scheduled: bool = False) -> None:
    if scheduled:
        if not _is_platform_admin(user):
            raise HTTPException(status_code=403, detail="Administrator access is required to schedule runbooks")
        return
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to run switch commands")
    access = _access(user)
    if not access.has("operations.runbook"):
        raise HTTPException(status_code=403, detail="Your assigned role does not allow Custom Runbook execution")
    if access.role_key != "admin" and str(runbook.get("status") or "draft") != "approved":
        raise HTTPException(status_code=403, detail="Only approved runbooks can be executed by this role")


def _load_runbook_for_execution(user: dict[str, Any], runbook_id: int, variables: dict[str, Any] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    runbook = get_runbook(runbook_id)
    if not runbook:
        raise HTTPException(status_code=404, detail="Runbook not found")
    _require_runbook_permission(user, runbook)
    try:
        snapshot = render_runbook(runbook, variables)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return runbook, snapshot


def _verification_credentials(
    *,
    request: Request,
    user: dict[str, Any],
    verification_username: str = "",
    verification_password: str = "",
) -> dict[str, str]:
    if user.get("auth_type") == "ssh":
        return _session_ssh_credentials(request)
    username = verification_username.strip()
    password = verification_password
    if not username or not password:
        raise HTTPException(
            status_code=400,
            detail="Temporary SSH credentials are required to verify and detect the switch. They are used once and are not stored.",
        )
    return {"username": username, "password_enc": encrypt_secret(password)}


def _verify_inventory_device(
    *,
    host: str,
    ssh_port: int,
    profile: str,
    request: Request,
    user: dict[str, Any],
    verification_username: str = "",
    verification_password: str = "",
) -> dict[str, str]:
    credentials = _verification_credentials(
        request=request,
        user=user,
        verification_username=verification_username,
        verification_password=verification_password,
    )
    candidate = {
        "host": host,
        "ssh_port": ssh_port,
        "profile": profile,
        **credentials,
    }
    try:
        command, _ = render_command(profile, "system_info")
    except Exception:
        command = "show system"
    result = run_commands(candidate, [command])
    if not result.ok:
        raise HTTPException(
            status_code=400,
            detail=f"The switch could not be verified with the supplied SSH credentials: {result.error or 'SSH connection failed'}",
        )
    identity = parse_show_system(result.output, profile_hint=profile)
    detected: dict[str, str] = {}
    if identity.model:
        detected["model"] = identity.model
    if identity.aos_version:
        detected["aos_version"] = identity.aos_version
    if identity.detected_profile:
        detected["profile"] = identity.detected_profile
    if not detected.get("model"):
        raise HTTPException(status_code=400, detail="SSH succeeded, but the switch model could not be detected from show system.")
    return detected


def _detect_imported_device_live(
    device: dict[str, Any],
    credentials: dict[str, str],
    *,
    actor: str,
) -> dict[str, Any]:
    """Verify one imported switch with the importing user's private SSH session.

    The password remains in the in-memory session credential store. This helper
    receives only the encrypted session credential payload and never persists it
    in the inventory or audit data.
    """
    candidate = {
        "host": device["host"],
        "ssh_port": int(device["ssh_port"]),
        "profile": str(device.get("profile") or "AOS8"),
        **credentials,
    }
    try:
        command, _ = render_command(candidate["profile"], "system_info")
    except Exception:
        command = "show system"
    started = time.perf_counter()
    result = run_commands(candidate, [command], pause_between=0)
    response_ms = round((time.perf_counter() - started) * 1000)
    identity = parse_show_system(result.output, profile_hint=candidate["profile"]) if result.ok else None
    detected = identity.to_dict() if identity else {}
    updated = record_health_result(
        int(device["id"]),
        result,
        response_ms=response_ms,
        source="inventory-import-ssh",
        actor=actor,
        identity=detected,
    )
    return {
        "device_id": int(device["id"]),
        "row": int(device.get("row") or 0),
        "host": str(device["host"]),
        "ok": bool(result.ok and detected.get("model")),
        "model": str(detected.get("model") or ""),
        "aos_version": str(detected.get("aos_version") or ""),
        "profile": str(detected.get("detected_profile") or candidate["profile"]),
        "response_ms": response_ms,
        "error": "" if result.ok and detected.get("model") else (result.error or "SSH succeeded, but the switch model could not be detected from show system."),
        "device": _public_device(updated) if updated else None,
    }


def _session_ssh_credentials(request: Request) -> dict[str, str]:
    token = str(request.session.get("ssh_token") or "")
    credentials = session_credentials.get_device_credentials(token)
    if not credentials:
        raise HTTPException(status_code=401, detail="An active personal SSH session is required")
    return credentials


def _device_with_session_credentials(device: Any, request: Request) -> dict[str, Any]:
    data = _row_to_dict(device) if hasattr(device, "keys") else dict(device)
    data.update(_session_ssh_credentials(request))
    return data


def _configured_auth_source_ids() -> list[int]:
    try:
        values = json.loads(get_app_setting("authentication_source_device_ids", "[]"))
    except (TypeError, ValueError, json.JSONDecodeError):
        values = []
    result: list[int] = []
    seen: set[int] = set()
    for value in values if isinstance(values, list) else []:
        try:
            device_id = int(value)
        except (TypeError, ValueError):
            continue
        if device_id <= 0 or device_id in seen:
            continue
        seen.add(device_id)
        result.append(device_id)
    return result[: settings.auth_max_sources]


def _enabled_auth_devices() -> list[dict[str, Any]]:
    configured_ids = _configured_auth_source_ids()
    with db() as conn:
        if configured_ids:
            placeholders = ",".join("?" for _ in configured_ids)
            rows = conn.execute(
                f"SELECT id, name, host, ssh_port, profile, last_status, response_ms, site FROM devices WHERE enabled = 1 AND id IN ({placeholders})",
                configured_ids,
            ).fetchall()
            by_id = {int(row["id"]): _row_to_dict(row) for row in rows}
            return [by_id[device_id] for device_id in configured_ids if device_id in by_id]
        rows = conn.execute(
            """
            SELECT id, name, host, ssh_port, profile, last_status, response_ms, site
            FROM devices
            WHERE enabled = 1
            ORDER BY
                CASE WHEN last_status = 'online' THEN 0 WHEN last_status = 'unknown' THEN 1 ELSE 2 END,
                CASE WHEN response_ms IS NULL THEN 1 ELSE 0 END,
                response_ms,
                name COLLATE NOCASE
            LIMIT ?
            """,
            (settings.auth_max_sources,),
        ).fetchall()
    return [_row_to_dict(row) for row in rows]


def _request_source_ip(request: Request) -> str:
    direct_ip = str(request.client.host) if request.client and request.client.host else "unknown"
    if settings.trust_proxy_headers and direct_ip in settings.trusted_proxy_ips:
        forwarded_for = str(request.headers.get("x-forwarded-for") or "").strip()
        if forwarded_for:
            candidate = forwarded_for.split(",", 1)[0].strip()
            if candidate:
                return candidate[:128]
    return direct_ip[:128]


def _auth_source_tcp_check(device: dict[str, Any]) -> tuple[int, bool, str]:
    try:
        with socket.create_connection(
            (str(device["host"]), int(device["ssh_port"])),
            timeout=settings.auth_connect_timeout,
        ):
            return int(device["id"]), True, ""
    except OSError as exc:
        return int(device["id"]), False, str(exc)


def _authenticate_ssh_login(username: str, password: str) -> tuple[dict[str, Any], str]:
    devices = _enabled_auth_devices()
    if not devices:
        if _configured_auth_source_ids():
            raise HTTPException(
                status_code=503,
                detail="No configured SSH Authentication Source is currently enabled. Sign in as admin and review Authentication Sources.",
            )
        raise HTTPException(
            status_code=409,
            detail="No switch is configured yet. Sign in as admin and add the first switch.",
        )

    started = time.monotonic()
    availability: dict[int, tuple[bool, str]] = {}
    with ThreadPoolExecutor(max_workers=min(len(devices), settings.auth_max_sources), thread_name_prefix="portivo-auth-probe") as pool:
        futures = [pool.submit(_auth_source_tcp_check, device) for device in devices]
        for future in as_completed(futures):
            device_id, reachable, error = future.result()
            availability[device_id] = (reachable, error)

    reachable = [device for device in devices if availability.get(int(device["id"]), (False, ""))[0]]
    if not reachable:
        failures = [
            f"{device['name']}: {availability.get(int(device['id']), (False, 'unreachable'))[1] or 'unreachable'}"
            for device in devices
        ]
        logger.warning("SSH authentication sources unreachable: %s", " | ".join(failures[:3]))
        raise HTTPException(
            status_code=503,
            detail="Authentication service currently unavailable. Try again shortly or contact a Portivo administrator.",
        )

    password_enc = encrypt_secret(password)
    connection_errors: list[str] = []
    deadline = started + settings.auth_global_timeout_seconds
    for device in reachable:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        result = authenticate_login_once(
            device,
            username,
            password_enc,
            timeout=min(settings.auth_connect_timeout, max(0.5, remaining)),
        )
        if result.ok:
            return device, password_enc
        error = result.error or "SSH login failed"
        if "authentication failed" in error.lower() or "permission denied" in error.lower():
            raise SSHLoginRejected(device, error)
        connection_errors.append(f"{device['name']}: {error}")

    if connection_errors:
        logger.warning("SSH authentication fast-login failures: %s", " | ".join(connection_errors[:3]))
    raise HTTPException(
        status_code=503,
        detail="Authentication service currently unavailable. Try again shortly or contact a Portivo administrator.",
    )


def _permissions_for(user: dict[str, Any]) -> dict[str, Any]:
    access = _access(user)
    allowed_actions = sorted(action_catalog_for_access(access).keys()) if user.get("auth_type") == "ssh" else []
    manage_inventory = access.has("inventory.manage") and (
        user.get("auth_type") == "admin" or get_app_setting_bool("ssh_users_manage_inventory", True)
    )
    return {
        "manage_inventory": bool(manage_inventory),
        "admin_panel": access.role_key == "admin",
        "execute_commands": bool(user.get("auth_type") == "ssh" and (access.has("operations.read") or allowed_actions)),
        "execute_changes": _can_change_network(user),
        "use_terminal": bool(user.get("auth_type") == "ssh" and access.has("terminal.use")),
        "custom_cli": bool(user.get("auth_type") == "ssh" and access.has("custom_cli.use")),
        "read_only": access.role_key == "read_only",
        "capabilities": sorted(access.capabilities),
        "allowed_actions": allowed_actions,
        "scope": access.scope_payload(),
        "role_key": access.role_key,
        "role_name": access.role_name,
    }


def audit(actor: str, event: str, object_type: str, object_id: str, details: dict[str, Any]) -> None:
    with db() as conn:
        conn.execute(
            """
            INSERT INTO audit_log(actor, event, object_type, object_id, details_json, created_at)
            VALUES(?, ?, ?, ?, ?, ?)
            """,
            (actor, event, object_type, object_id, json.dumps(details, ensure_ascii=False), utc_now()),
        )


def _sync_monitoring_workers(*, wake_enabled: bool = False) -> dict[str, Any]:
    policy = monitoring_policy()
    effective = policy.get("effective") or {}
    if effective.get("switch_availability"):
        start_health_monitor()
        if wake_enabled:
            request_health_scan()
    else:
        stop_health_monitor()
    if effective.get("stack_health"):
        start_stack_monitor()
        if wake_enabled:
            request_stack_scan()
    else:
        stop_stack_monitor()
    if effective.get("power_ups"):
        start_power_monitor()
        if wake_enabled:
            request_power_scan()
    else:
        stop_power_monitor()
    return policy


@app.on_event("startup")
def startup() -> None:
    init_db()
    reachability_cleanup = purge_ups_reachability_noise()
    if any(reachability_cleanup.values()):
        logger.info(
            "Cleaned legacy UPS reachability notification noise: incidents=%s deliveries=%s ups_normalized=%s",
            reachability_cleanup.get("incidents", 0),
            reachability_cleanup.get("deliveries", 0),
            reachability_cleanup.get("ups_normalized", 0),
        )
    reconciled_jobs = reconcile_orphaned_jobs()
    if reconciled_jobs:
        logger.warning("Marked orphaned Jobs as interrupted after restart: %s", reconciled_jobs)
    start_notification_worker()
    _sync_monitoring_workers()
    start_unp_scheduler()


@app.on_event("shutdown")
def shutdown() -> None:
    stop_unp_scheduler()
    stop_power_monitor()
    stop_stack_monitor()
    stop_health_monitor()
    stop_notification_worker()


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/health/build")
def health_build(request: Request) -> dict[str, str]:
    _require_loopback(request)
    return {"status": "ok", "version": settings.app_version, "revision": PORTIVO_BUILD_REVISION}


@app.get("/api/auth/bootstrap-status")
def bootstrap_status() -> dict[str, Any]:
    with db() as conn:
        device_count = int(conn.execute("SELECT COUNT(*) AS count FROM devices WHERE enabled = 1").fetchone()["count"])
    auth_source_count = len(_enabled_auth_devices())
    return {
        "device_count": device_count,
        "ssh_login_available": auth_source_count > 0,
        "authentication_source_count": auth_source_count,
        "default_mode": "ssh" if auth_source_count > 0 else "admin",
        "default_language": get_app_setting("default_language", "en"),
        "platform_timezone": platform_timezone_name(),
        "password_policy": {
            "min_length": MIN_PASSWORD_LENGTH,
            "max_length": MAX_PASSWORD_LENGTH,
        },
    }


@app.post("/api/auth/login")
def login(payload: LoginRequest, request: Request) -> dict[str, Any]:
    _require_local(request)
    username = payload.username.strip()
    source_ip = _request_source_ip(request)
    request.session.clear()

    if settings.login_rate_limit_enabled:
        decision = login_rate_limiter.check(source_ip, username)
        if not decision.allowed:
            raise HTTPException(
                status_code=429,
                detail="Too many failed sign-in attempts. Try again shortly.",
                headers={"Retry-After": str(decision.retry_after_seconds)},
            )

    if payload.mode == "admin":
        with db() as conn:
            row = conn.execute(
                "SELECT * FROM app_users WHERE username = ? AND role = 'admin'",
                (username,),
            ).fetchone()
        if not row or not row["enabled"] or not verify_password(payload.password, row["password_hash"]):
            failure = login_rate_limiter.record_failure(source_ip, username) if settings.login_rate_limit_enabled else None
            audit(
                username or "unknown",
                "login_failed",
                "session",
                username or "unknown",
                {
                    "mode": "admin",
                    "source_ip": source_ip,
                    "pair_failures": failure.pair_failures if failure else 0,
                    "ip_failures": failure.ip_failures if failure else 0,
                },
            )
            raise HTTPException(status_code=401, detail="Invalid username or password")
        if settings.login_rate_limit_enabled:
            login_rate_limiter.record_success(source_ip, username)
        now = utc_now()
        with db() as conn:
            conn.execute("UPDATE app_users SET last_login = ?, updated_at = ? WHERE id = ?", (now, now, row["id"]))
        request.session["auth_type"] = "admin"
        request.session["user_id"] = int(row["id"])
        request.session["user"] = row["username"]
        request.session["role"] = "admin"
        audit(row["username"], "login", "session", row["username"], {"mode": "admin", "source_ip": source_ip})
        session_user = {
            "id": int(row["id"]), "username": row["username"], "display_name": row["display_name"],
            "role": "admin", "role_name": "Administrator", "auth_type": "admin",
            "must_change_password": bool(row["must_change_password"]),
        }
        return {"authenticated": True, **session_user, "permissions": _permissions_for(session_user)}

    try:
        auth_device, password_enc = _authenticate_ssh_login(username, payload.password)
    except SSHLoginRejected as exc:
        failure = login_rate_limiter.record_failure(source_ip, username) if settings.login_rate_limit_enabled else None
        audit(
            username or "unknown",
            "login_failed",
            "session",
            username or "unknown",
            {
                "mode": "ssh",
                "source_ip": source_ip,
                "reason": "credentials_rejected",
                "authentication_device_id": int(exc.device["id"]),
                "authentication_device": str(exc.device["name"]),
                "pair_failures": failure.pair_failures if failure else 0,
                "ip_failures": failure.ip_failures if failure else 0,
            },
        )
        raise HTTPException(status_code=401, detail="Invalid username or password") from exc

    if settings.login_rate_limit_enabled:
        login_rate_limiter.record_success(source_ip, username)
    ssh_profile = register_ssh_user_login(username, auth_device)
    if not bool(ssh_profile.get("enabled")):
        audit(username, "login_denied", "ssh_user", str(ssh_profile.get("id") or username), {"reason": "disabled", "source_ip": source_ip})
        raise HTTPException(status_code=403, detail="Your Portivo Control Center access has been disabled by an administrator.")
    token = session_credentials.create(username, payload.password)
    now = utc_now()
    with db() as conn:
        current = conn.execute("SELECT last_status FROM devices WHERE id = ?", (int(auth_device["id"]),)).fetchone()
        status_changed_at = now if not current or str(current["last_status"] or "unknown") != "online" else None
        if status_changed_at:
            conn.execute(
                "UPDATE devices SET last_seen = ?, last_checked = ?, last_status = 'online', last_error = '', consecutive_failures = 0, status_changed_at = ? WHERE id = ?",
                (now, now, status_changed_at, int(auth_device["id"])),
            )
        else:
            conn.execute(
                "UPDATE devices SET last_seen = ?, last_checked = ?, last_status = 'online', last_error = '', consecutive_failures = 0 WHERE id = ?",
                (now, now, int(auth_device["id"])),
            )
    request.session["auth_type"] = "ssh"
    request.session["ssh_token"] = token
    request.session["user"] = username
    ssh_access = access_context_for_profile(ssh_profile)
    request.session["role"] = ssh_access.role_key
    request.session["auth_device_id"] = int(auth_device["id"])
    audit(username, "login", "session", username, {
        "mode": "ssh",
        "source_ip": source_ip,
        "authentication_device_id": int(auth_device["id"]),
        "authentication_device": auth_device["name"],
    })
    session_user = {
        **ssh_profile,
        "id": int(ssh_profile.get("id") or 0),
        "username": username,
        "display_name": str(ssh_profile.get("display_name") or username),
        "role": ssh_access.role_key,
        "role_name": ssh_access.role_name,
        "auth_type": "ssh",
        "must_change_password": False,
    }
    return {
        "authenticated": True,
        **session_user,
        "permissions": _permissions_for(session_user),
        "authentication_device": {
            "id": int(auth_device["id"]),
            "name": auth_device["name"],
            "host": auth_device["host"],
        },
    }


@app.post("/api/auth/logout")
def logout(request: Request) -> dict[str, bool]:
    _require_local(request)
    username = str(request.session.get("user") or "unknown")
    session_credentials.remove(str(request.session.get("ssh_token") or ""))
    request.session.clear()
    audit(username, "logout", "session", username, {})
    return {"ok": True}


@app.get("/api/auth/me")
def me(request: Request) -> dict[str, Any]:
    _require_local(request)
    if not request.session.get("auth_type"):
        return {"authenticated": False}
    try:
        user = current_user(request)
    except HTTPException:
        return {"authenticated": False}
    result = {"authenticated": True, **user, "permissions": _permissions_for(user)}
    if user.get("auth_type") == "ssh":
        result["authentication_device_id"] = request.session.get("auth_device_id")
    return result


@app.post("/api/auth/change-password")
def change_password(
    payload: PasswordChangeRequest,
    user: dict[str, Any] = Depends(require_bootstrap_admin),
) -> dict[str, bool]:
    with db() as conn:
        row = conn.execute("SELECT password_hash FROM app_users WHERE id = ?", (user["id"],)).fetchone()
        if not row or not verify_password(payload.current_password, row["password_hash"]):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        conn.execute(
            "UPDATE app_users SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?",
            (hash_password(payload.new_password), utc_now(), user["id"]),
        )
    audit(user["username"], "password_changed", "app_user", str(user["id"]), {})
    return {"ok": True}


@app.get("/api/admin/security-model")
def security_model(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    with db() as conn:
        device_count = int(conn.execute("SELECT COUNT(*) AS count FROM devices").fetchone()["count"])
    return {
        "device_count": device_count,
        "personal_ssh_credentials_stored": False,
        "ssh_password_storage": "session-memory-only",
        "health_probe": "icmp-confirmed-snmpv3-fallback-no-tcp",
        "health_probe_ssh_login": False,
        "health_history": "disabled-current-state-only",
        "scheduled_unp_credential": "optional-encrypted-service-account",
        "teams_webhook_storage": "encrypted-at-rest",
        "public_url_scheme": settings.public_url_scheme,
        "secure_session_cookie": settings.cookie_secure,
        "login_rate_limiting": settings.login_rate_limit_enabled,
    }


@app.get("/api/admin/overview")
def admin_overview(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    with db() as conn:
        counts = {
            "devices": int(conn.execute("SELECT COUNT(*) AS count FROM devices").fetchone()["count"]),
            "enabled_devices": int(conn.execute("SELECT COUNT(*) AS count FROM devices WHERE enabled = 1").fetchone()["count"]),
            "jobs": int(conn.execute("SELECT COUNT(*) AS count FROM jobs").fetchone()["count"]),
            "audit_entries": int(conn.execute("SELECT COUNT(*) AS count FROM audit_log").fetchone()["count"]),
            "health_records": 0,
            "ssh_users": int(conn.execute("SELECT COUNT(*) AS count FROM ssh_user_profiles").fetchone()["count"]),
        }
        settings_rows = conn.execute("SELECT name, value, updated_at, updated_by FROM app_settings ORDER BY name").fetchall()
    database_size = settings.database_path.stat().st_size if settings.database_path.exists() else 0
    return {
        "counts": counts,
        "active_ssh_sessions": session_credentials.count(),
        "database": {
            "path": str(settings.database_path),
            "size_bytes": database_size,
        },
        "network": {
            "host": settings.host,
            "port": settings.port,
            "public_url_scheme": settings.public_url_scheme,
            "secure_session_cookie": settings.cookie_secure,
            "https_mode": "reverse-proxy" if settings.public_url_scheme == "https" else "trusted-lan-http",
            "trust_proxy_headers": settings.trust_proxy_headers,
            "trusted_proxy_ips": list(settings.trusted_proxy_ips),
        },
        "settings": {row["name"]: row["value"] for row in settings_rows},
        "settings_metadata": [_row_to_dict(row) for row in settings_rows],
        "health_monitor": health_monitor_status(),
        "stack_monitor": stack_monitor_status(),
        "monitoring_policy": monitoring_policy(),
        "authentication": {
            "mode": "configured" if _configured_auth_source_ids() else "automatic",
            "source_device_ids": _configured_auth_source_ids(),
            "effective_sources": [
                {
                    "id": int(item.get("id") or 0),
                    "name": str(item.get("name") or ""),
                    "host": str(item.get("host") or ""),
                    "site": str(item.get("site") or ""),
                    "last_status": str(item.get("last_status") or "unknown"),
                    "response_ms": item.get("response_ms"),
                }
                for item in _enabled_auth_devices()
            ],
            "max_sources": settings.auth_max_sources,
            "connect_timeout_seconds": settings.auth_connect_timeout,
            "global_timeout_seconds": settings.auth_global_timeout_seconds,
        },
        "security": {
            "personal_ssh_credentials_stored": False,
            "ssh_password_storage": "encrypted-process-memory-only",
            "bootstrap_admin_enabled": True,
            "ssh_inventory_management": get_app_setting_bool("ssh_users_manage_inventory", True),
            "automation_credential_configured": bool(scheduler_credential_status().get("configured")),
            "monitoring_credential_profiles": len(list_monitoring_profiles()),
            "scheduler_credential_configured": bool(scheduler_credential_status().get("configured")),  # v1.6.2 compatibility
            "notifications_configured": bool(get_notification_state(include_inventory=False).get("summary", {}).get("enabled_destination_count")),
            "password_policy": {"min_length": MIN_PASSWORD_LENGTH, "max_length": MAX_PASSWORD_LENGTH},
            "login_rate_limit_enabled": settings.login_rate_limit_enabled,
            "login_rate_limit": login_rate_limiter.status(),
        },
    }


@app.get("/api/admin/monitoring-profiles")
def monitoring_profiles(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, Any]]:
    return list_monitoring_profiles()


@app.get("/api/admin/monitoring-verification-targets")
def monitoring_verification_targets(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, Any]]:
    """Return managed assets that can safely be used for credential verification.

    SSH profiles can be checked only against switches. SNMPv3 profiles can be
    checked against either switches or UPS assets. Keeping this inventory in a
    dedicated endpoint avoids coupling the Admin credential dialog to the Power
    workspace payload.
    """
    with db() as conn:
        switches = conn.execute(
            "SELECT id,name,host,site,group_name FROM devices WHERE enabled=1 ORDER BY site COLLATE NOCASE,name COLLATE NOCASE,id"
        ).fetchall()
        ups_devices = conn.execute(
            "SELECT id,name,host,site,group_name FROM ups_devices WHERE enabled=1 ORDER BY site COLLATE NOCASE,name COLLATE NOCASE,id"
        ).fetchall()
    result: list[dict[str, Any]] = []
    for row in switches:
        result.append({
            "type": "switch", "id": int(row["id"]), "name": str(row["name"]),
            "host": str(row["host"]), "site": str(row["site"] or ""),
            "group_name": str(row["group_name"] or ""),
        })
    for row in ups_devices:
        result.append({
            "type": "ups", "id": int(row["id"]), "name": str(row["name"]),
            "host": str(row["host"]), "site": str(row["site"] or ""),
            "group_name": str(row["group_name"] or ""),
        })
    return result


def _monitoring_profile_target(target_type: str | None, target_id: int | None) -> dict[str, Any] | None:
    if not target_id:
        return None
    kind = str(target_type or "switch").strip().lower()
    with db() as conn:
        if kind == "switch":
            row = conn.execute(
                "SELECT id,name,host,ssh_port,profile,enabled FROM devices WHERE id=?",
                (int(target_id),),
            ).fetchone()
        elif kind == "ups":
            row = conn.execute(
                "SELECT id,name,host,enabled FROM ups_devices WHERE id=?",
                (int(target_id),),
            ).fetchone()
        else:
            raise HTTPException(status_code=400, detail="Unsupported monitoring credential verification target")
    if not row:
        raise HTTPException(status_code=400, detail="Monitoring credential verification target was not found")
    item = _row_to_dict(row)
    item["target_type"] = kind
    return item


def _save_monitoring_profile_impl(profile_id: int | None, payload: MonitoringCredentialProfileRequest, admin: dict[str, Any]) -> dict[str, Any]:
    method = payload.method.lower()
    existing = None
    if profile_id:
        with db() as conn:
            existing = conn.execute("SELECT * FROM monitoring_credential_profiles WHERE id=?", (int(profile_id),)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Monitoring credential profile not found")
    existing_dict = _row_to_dict(existing) if existing else {}
    if method == "snmpv3":
        for label, clear, encrypted in (("authentication", payload.snmp_auth_password, str(existing_dict.get("snmp_auth_password_enc") or "")), ("privacy", payload.snmp_priv_password, str(existing_dict.get("snmp_priv_password_enc") or ""))):
            if clear and not (8 <= len(clear.encode("utf-8")) <= 32):
                raise HTTPException(status_code=400, detail=f"SNMPv3 {label} password must be 8 to 32 bytes")
            if not clear and encrypted:
                try:
                    current_secret = decrypt_secret(encrypted)
                except Exception as exc:
                    raise HTTPException(status_code=400, detail=f"Stored SNMPv3 {label} secret cannot be decrypted") from exc
                if not (8 <= len(current_secret.encode("utf-8")) <= 32):
                    raise HTTPException(status_code=400, detail=f"Stored SNMPv3 {label} password does not meet the 8 to 32 byte requirement")
    if method == "ssh":
        password_enc = encrypt_secret(payload.password) if payload.password else str(existing_dict.get("ssh_password_enc") or "")
        if not password_enc:
            raise HTTPException(status_code=400, detail="SSH monitoring profile requires a password")
        auth_enc = ""; priv_enc = ""
    else:
        password_enc = ""
        auth_enc = encrypt_secret(payload.snmp_auth_password) if payload.snmp_auth_password else str(existing_dict.get("snmp_auth_password_enc") or "")
        priv_enc = encrypt_secret(payload.snmp_priv_password) if payload.snmp_priv_password else str(existing_dict.get("snmp_priv_password_enc") or "")
        if not auth_enc or not priv_enc:
            raise HTTPException(status_code=400, detail="SNMPv3 monitoring profile requires authentication and privacy passwords")
    # New clients send a generic target type/id. Preserve verify_device_id as
    # a switch-only compatibility path for older cached frontends.
    verify_target_type = payload.verify_target_type
    verify_target_id = payload.verify_target_id
    if verify_target_id is None and payload.verify_device_id is not None:
        verify_target_type = "switch"
        verify_target_id = payload.verify_device_id
    verify_target = _monitoring_profile_target(verify_target_type, verify_target_id)
    verified_at = existing_dict.get("verified_at")
    verified_name = str(existing_dict.get("verified_device_name") or "")
    verified_id = existing_dict.get("verified_device_id")
    verified_target_type = str(existing_dict.get("verified_target_type") or ("switch" if verified_id else ""))
    verified_target_id = existing_dict.get("verified_target_id") or verified_id
    last_status = "unverified"
    if verify_target:
        target_kind = str(verify_target.get("target_type") or "switch")
        if not bool(verify_target.get("enabled")):
            raise HTTPException(status_code=400, detail="Verification target must be enabled")
        if method == "ssh" and target_kind != "switch":
            raise HTTPException(status_code=400, detail="SSH monitoring profiles can only be verified against switches")
        try:
            if method == "ssh":
                candidate = dict(verify_target)
                candidate.update({"username": payload.username, "password_enc": password_enc})
                result = run_commands(candidate, ["show system"], operation="monitoring credential verification", lock_timeout=4.0)
                if not result.ok:
                    raise RuntimeError(result.error or "SSH read-only verification failed")
            else:
                candidate_profile = {
                    "username": payload.username,
                    "snmp_port": payload.snmp_port,
                    "snmp_auth_protocol": payload.snmp_auth_protocol,
                    "snmp_auth_password": decrypt_secret(auth_enc),
                    "snmp_priv_protocol": payload.snmp_priv_protocol,
                    "snmp_priv_password": decrypt_secret(priv_enc),
                }
                # sysDescr is a standard, read-only SNMP object and works as a
                # credential/authPriv check for both managed switches and UPS.
                snmpv3_verify(str(verify_target["host"]), candidate_profile)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Monitoring credential verification failed: {exc}") from exc
        verified_at = utc_now()
        verified_name = str(verify_target["name"])
        verified_target_type = target_kind
        verified_target_id = int(verify_target["id"])
        verified_id = int(verify_target["id"]) if target_kind == "switch" else None
        last_status = "verified"
    now = utc_now()
    try:
        with db() as conn:
            if profile_id:
                conn.execute(
                    """UPDATE monitoring_credential_profiles SET name=?,method=?,username=?,ssh_password_enc=?,snmp_port=?,
                       snmp_auth_protocol=?,snmp_auth_password_enc=?,snmp_priv_protocol=?,snmp_priv_password_enc=?,
                       verified_device_id=?,verified_device_name=?,verified_target_type=?,verified_target_id=?,verified_at=?,
                       last_status=?,updated_at=?,updated_by=? WHERE id=?""",
                    (payload.name, method, payload.username, password_enc, payload.snmp_port, payload.snmp_auth_protocol, auth_enc,
                     payload.snmp_priv_protocol, priv_enc, verified_id, verified_name, verified_target_type, verified_target_id,
                     verified_at, last_status, now, admin["username"], int(profile_id)),
                )
                saved_id = int(profile_id)
            else:
                cursor = conn.execute(
                    """INSERT INTO monitoring_credential_profiles(name,method,username,ssh_password_enc,snmp_port,snmp_auth_protocol,
                       snmp_auth_password_enc,snmp_priv_protocol,snmp_priv_password_enc,verified_device_id,verified_device_name,
                       verified_target_type,verified_target_id,verified_at,last_status,created_at,updated_at,updated_by)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (payload.name, method, payload.username, password_enc, payload.snmp_port, payload.snmp_auth_protocol, auth_enc,
                     payload.snmp_priv_protocol, priv_enc, verified_id, verified_name, verified_target_type, verified_target_id,
                     verified_at, last_status, now, now, admin["username"]),
                )
                saved_id = int(cursor.lastrowid)
    except sqlite3.IntegrityError as exc:
        raise HTTPException(status_code=409, detail="A monitoring profile with this name already exists") from exc
    audit(admin["username"], "monitoring_profile_saved", "monitoring_profile", str(saved_id), {
        "name": payload.name, "method": method, "verified_device": verified_name,
        "verified_target_type": verified_target_type if last_status == "verified" else "",
    })
    return next(item for item in list_monitoring_profiles() if int(item["id"]) == saved_id)


@app.post("/api/admin/monitoring-profiles", status_code=201)
def create_monitoring_profile(payload: MonitoringCredentialProfileRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return _save_monitoring_profile_impl(None, payload, admin)


@app.put("/api/admin/monitoring-profiles/{profile_id}")
def update_monitoring_profile(profile_id: int, payload: MonitoringCredentialProfileRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return _save_monitoring_profile_impl(profile_id, payload, admin)


@app.delete("/api/admin/monitoring-profiles/{profile_id}")
def delete_monitoring_profile(profile_id: int, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    with db() as conn:
        stack_used = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE stack_monitor_enabled=1 AND stack_monitor_profile_id=?", (profile_id,)).fetchone()["c"])
        health_used = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE health_monitor_profile_id=?", (profile_id,)).fetchone()["c"])
        ups_used = int(conn.execute("SELECT COUNT(*) AS c FROM ups_devices WHERE monitoring_profile_id=?", (profile_id,)).fetchone()["c"])
        if stack_used or health_used or ups_used:
            parts = []
            if stack_used:
                parts.append(f"{stack_used} stack configuration(s)")
            if health_used:
                parts.append(f"{health_used} switch health configuration(s)")
            if ups_used:
                parts.append(f"{ups_used} UPS asset(s)")
            raise HTTPException(status_code=409, detail="Monitoring profile is in use by " + " and ".join(parts))
        cursor = conn.execute("DELETE FROM monitoring_credential_profiles WHERE id=?", (profile_id,))
    if not cursor.rowcount:
        raise HTTPException(status_code=404, detail="Monitoring credential profile not found")
    audit(admin["username"], "monitoring_profile_deleted", "monitoring_profile", str(profile_id), {})
    return {"ok": True}



@app.get("/api/admin/settings")
def admin_settings(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    policy = monitoring_policy()
    return {
        "default_language": get_app_setting("default_language", "en"),
        "platform_timezone": platform_timezone_name(),
        "available_timezones": available_timezone_names(),
        "ssh_users_manage_inventory": get_app_setting_bool("ssh_users_manage_inventory", True),
        "health_poll_interval_seconds": get_app_setting_int("health_poll_interval_seconds", 30, 10, 3600),
        "monitoring_mode": policy["mode"],
        "monitoring_switch_availability": bool(policy["services"]["switch_availability"]),
        "monitoring_stack_health": bool(policy["services"]["stack_health"]),
        "monitoring_power_ups": bool(policy["services"]["power_ups"]),
        "monitoring_incident_detection": bool(policy["services"]["incident_detection"]),
        "authentication_source_device_ids": _configured_auth_source_ids(),
        "health_history_enabled": False,
        "unp_fix_protected_ports": get_app_setting("unp_fix_protected_ports", "1/1/1"),
        "unp_fix_guest_keywords": get_app_setting("unp_fix_guest_keywords", "GUEST"),
        "unp_fix_service_keywords": get_app_setting("unp_fix_service_keywords", "VOIP,IPTV"),
        "unp_fix_max_ports_per_switch": get_app_setting_int("unp_fix_max_ports_per_switch", 12, 1, 48),
    }


@app.put("/api/admin/settings")
def save_admin_settings(
    payload: AdminSettingsRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    if payload.authentication_source_device_ids:
        with db() as conn:
            placeholders = ",".join("?" for _ in payload.authentication_source_device_ids)
            rows = conn.execute(
                f"SELECT id FROM devices WHERE enabled = 1 AND id IN ({placeholders})",
                payload.authentication_source_device_ids,
            ).fetchall()
        valid_ids = {int(row["id"]) for row in rows}
        missing = [device_id for device_id in payload.authentication_source_device_ids if device_id not in valid_ids]
        if missing:
            raise HTTPException(status_code=400, detail="Authentication Sources must reference enabled switches")
    values = {
        "default_language": payload.default_language,
        "ssh_users_manage_inventory": "1" if payload.ssh_users_manage_inventory else "0",
        "health_poll_interval_seconds": str(payload.health_poll_interval_seconds),
    }
    if payload.platform_timezone is not None:
        values["platform_timezone"] = payload.platform_timezone
    if payload.monitoring_mode is not None:
        values["monitoring_mode"] = payload.monitoring_mode
    if payload.monitoring_switch_availability is not None:
        values["monitoring_switch_availability"] = "1" if payload.monitoring_switch_availability else "0"
    if payload.monitoring_stack_health is not None:
        values["monitoring_stack_health"] = "1" if payload.monitoring_stack_health else "0"
    if payload.monitoring_power_ups is not None:
        values["monitoring_power_ups"] = "1" if payload.monitoring_power_ups else "0"
    if payload.monitoring_incident_detection is not None:
        values["monitoring_incident_detection"] = "1" if payload.monitoring_incident_detection else "0"
    # Legacy v1.6.2 clients may still submit Fix UNP safeguards through the Admin settings endpoint.
    # New v1.6.3 clients omit them so unrelated Admin saves cannot overwrite the shared Automation policy.
    if payload.unp_fix_protected_ports is not None:
        values["unp_fix_protected_ports"] = payload.unp_fix_protected_ports
    if payload.unp_fix_guest_keywords is not None:
        values["unp_fix_guest_keywords"] = payload.unp_fix_guest_keywords
    if payload.unp_fix_service_keywords is not None:
        values["unp_fix_service_keywords"] = payload.unp_fix_service_keywords
    if payload.unp_fix_max_ports_per_switch is not None:
        values["unp_fix_max_ports_per_switch"] = str(payload.unp_fix_max_ports_per_switch)
    if payload.authentication_source_device_ids is not None:
        values["authentication_source_device_ids"] = json.dumps(payload.authentication_source_device_ids)
    update_app_settings(values, admin["username"])
    active_monitoring_policy = _sync_monitoring_workers(wake_enabled=True)
    audit(admin["username"], "settings_updated", "application", "settings", values)
    return {"ok": True, **payload.model_dump(), "monitoring_policy": active_monitoring_policy}


def _notification_state_for_user(user: dict[str, Any], *, history_limit: int = 50, include_inventory: bool = True) -> dict[str, Any]:
    _require_capability(user, "notifications.view")
    state = get_notification_state(include_inventory=include_inventory, history_limit=history_limit)
    access = _access(user)
    if access.scope_mode == "all" or access.global_role:
        return state
    with db() as conn:
        switch_rows = conn.execute("SELECT id, name, site, group_name FROM devices WHERE enabled=1").fetchall()
        ups_rows = conn.execute("SELECT id, name, site, group_name FROM ups_devices WHERE enabled=1").fetchall()
    visible_switches = filter_devices(access, switch_rows)
    visible_ups = [row for row in ups_rows if device_in_scope(access, {"site": row["site"], "group_name": row["group_name"]})]
    visible_switch_ids = {int(row["id"]) for row in visible_switches}
    visible_ups_ids = {int(row["id"]) for row in visible_ups}
    visible_names = {str(row["name"] or "") for row in [*visible_switches, *visible_ups]}
    incidents = []
    for item in state.get("incidents", []):
        if str(item.get("source_type") or "switch") == "ups":
            if int(item.get("ups_id") or 0) in visible_ups_ids:
                incidents.append(item)
        elif int(item.get("device_id") or 0) in visible_switch_ids:
            incidents.append(item)
    deliveries = [item for item in state.get("deliveries", []) if str(item.get("device_name") or "") in visible_names or str(item.get("event_type") or "") == "test"]
    state["incidents"] = incidents
    state["deliveries"] = deliveries
    summary = dict(state.get("summary") or {})
    summary["open_incidents"] = sum(1 for item in incidents if str(item.get("status") or "") == "open")
    summary["open_power_incidents"] = sum(1 for item in incidents if str(item.get("status") or "") == "open" and str(item.get("source_type") or "") == "ups")
    summary["open_switch_incidents"] = summary["open_incidents"] - summary["open_power_incidents"]
    summary["pending_deliveries"] = sum(1 for item in deliveries if str(item.get("status") or "") in {"queued", "retrying", "delivering"})
    summary["failed_deliveries"] = sum(1 for item in deliveries if str(item.get("status") or "") == "failed")
    state["summary"] = summary
    if include_inventory:
        def destination_matches(row: Any, destination: dict[str, Any]) -> bool:
            if str(destination.get("scope_mode") or "all") == "all":
                return True
            sites = {str(value).casefold() for value in destination.get("sites") or []}
            groups = {str(value).casefold() for value in destination.get("groups") or []}
            site = str(row["site"] or "").casefold()
            group = str(row["group_name"] or "").casefold()
            return (not sites or site in sites) and (not groups or group in groups)
        covered_switch_ids: set[int] = set()
        covered_ups_ids: set[int] = set()
        for destination in state.get("destinations", []):
            switch_events = bool(destination.get("notify_offline") or destination.get("notify_stack_degraded"))
            ups_events = bool(destination.get("notify_ups_on_battery") or destination.get("notify_ups_low_battery"))
            switch_matches = [row for row in visible_switches if switch_events and destination_matches(row, destination)]
            ups_matches = [row for row in visible_ups if ups_events and destination_matches(row, destination)]
            destination["covered_switch_count"] = len(switch_matches)
            destination["enabled_switch_count"] = len(visible_switches)
            destination["covered_ups_count"] = len(ups_matches)
            destination["enabled_ups_count"] = len(visible_ups)
            if destination.get("enabled") and destination.get("webhook_configured"):
                covered_switch_ids.update(int(row["id"]) for row in switch_matches)
                covered_ups_ids.update(int(row["id"]) for row in ups_matches)
        all_rows = [*visible_switches, *visible_ups]
        state["inventory"] = {
            "available_sites": sorted({str(row["site"] or "").strip() for row in all_rows if str(row["site"] or "").strip()}, key=str.casefold),
            "available_groups": sorted({str(row["group_name"] or "").strip() for row in all_rows if str(row["group_name"] or "").strip()}, key=str.casefold),
            "enabled_switch_count": len(visible_switches),
            "covered_switch_count": len(covered_switch_ids),
            "enabled_ups_count": len(visible_ups),
            "covered_ups_count": len(covered_ups_ids),
        }
    return state


@app.get("/api/notifications")
def notification_center(
    history_limit: int = 50,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    return _notification_state_for_user(user, history_limit=history_limit)


@app.get("/api/notifications/summary")
def notification_summary(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return _notification_state_for_user(user, include_inventory=False, history_limit=100).get("summary", {})


@app.put("/api/notifications/policy")
def update_notification_policy(
    payload: NotificationPolicyRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        result = save_notification_policy(
            actor=admin["username"], enabled=payload.enabled, scope_mode=payload.scope_mode,
            sites=payload.sites, groups=payload.groups, notify_offline=payload.notify_offline,
            notify_recovery=payload.notify_recovery, failure_threshold=payload.failure_threshold,
            reminder_minutes=payload.reminder_minutes,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(
        admin["username"], "notification_policy_updated", "notification", "policy",
        {
            "enabled": payload.enabled, "scope_mode": payload.scope_mode, "sites": payload.sites,
            "groups": payload.groups, "notify_offline": payload.notify_offline,
            "notify_recovery": payload.notify_recovery, "failure_threshold": payload.failure_threshold,
            "reminder_minutes": payload.reminder_minutes,
        },
    )
    return result


@app.post("/api/notifications/destinations")
def create_notification_destination(
    payload: NotificationDestinationRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        result = save_destination(
            actor=admin["username"], destination_id=None, name=payload.name, provider=payload.provider,
            enabled=payload.enabled, webhook_url=payload.webhook_url, scope_mode=payload.scope_mode,
            sites=payload.sites, groups=payload.groups, notify_offline=payload.notify_offline,
            notify_recovery=payload.notify_recovery, notify_reminder=payload.notify_reminder,
            notify_stack_degraded=payload.notify_stack_degraded, notify_stack_recovery=payload.notify_stack_recovery,
            notify_ups_on_battery=payload.notify_ups_on_battery, notify_ups_power_restored=payload.notify_ups_power_restored,
            notify_ups_low_battery=payload.notify_ups_low_battery, notify_ups_unreachable=False,
            keep_existing_webhook=False,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "notification_destination_created", "notification_destination", str(result.get("destination_id")), {"name": payload.name, "provider": payload.provider, "enabled": payload.enabled, "scope_mode": payload.scope_mode, "sites": payload.sites, "groups": payload.groups, "notify_offline": payload.notify_offline, "notify_recovery": payload.notify_recovery, "notify_reminder": payload.notify_reminder, "notify_stack_degraded": payload.notify_stack_degraded, "notify_stack_recovery": payload.notify_stack_recovery, "notify_ups_on_battery": payload.notify_ups_on_battery, "notify_ups_power_restored": payload.notify_ups_power_restored, "notify_ups_low_battery": payload.notify_ups_low_battery, "notify_ups_unreachable": False})
    return result


@app.put("/api/notifications/destinations/{destination_id}")
def update_notification_destination(
    destination_id: int,
    payload: NotificationDestinationRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        result = save_destination(
            actor=admin["username"], destination_id=destination_id, name=payload.name, provider=payload.provider,
            enabled=payload.enabled, webhook_url=payload.webhook_url, scope_mode=payload.scope_mode,
            sites=payload.sites, groups=payload.groups, notify_offline=payload.notify_offline,
            notify_recovery=payload.notify_recovery, notify_reminder=payload.notify_reminder,
            notify_stack_degraded=payload.notify_stack_degraded, notify_stack_recovery=payload.notify_stack_recovery,
            notify_ups_on_battery=payload.notify_ups_on_battery, notify_ups_power_restored=payload.notify_ups_power_restored,
            notify_ups_low_battery=payload.notify_ups_low_battery, notify_ups_unreachable=False,
            keep_existing_webhook=True,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "notification_destination_updated", "notification_destination", str(destination_id), {"name": payload.name, "provider": payload.provider, "enabled": payload.enabled, "scope_mode": payload.scope_mode, "sites": payload.sites, "groups": payload.groups, "notify_offline": payload.notify_offline, "notify_recovery": payload.notify_recovery, "notify_reminder": payload.notify_reminder, "notify_stack_degraded": payload.notify_stack_degraded, "notify_stack_recovery": payload.notify_stack_recovery, "notify_ups_on_battery": payload.notify_ups_on_battery, "notify_ups_power_restored": payload.notify_ups_power_restored, "notify_ups_low_battery": payload.notify_ups_low_battery, "notify_ups_unreachable": False})
    return result


@app.delete("/api/notifications/destinations/{destination_id}")
def remove_notification_destination(
    destination_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        result = delete_destination(actor=admin["username"], destination_id=destination_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    audit(admin["username"], "notification_destination_removed", "notification_destination", str(destination_id), {})
    return result


@app.post("/api/notifications/destinations/{destination_id}/test")
def test_notification_destination(
    destination_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        result = send_test_notification(destination_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        audit(admin["username"], "notification_test_failed", "notification_destination", str(destination_id), {"error": str(exc)[:500]})
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    audit(admin["username"], "notification_test_delivered", "notification_destination", str(destination_id), {"http_status": result.get("http_status")})
    return result


@app.get("/api/runbooks")
def runbook_library(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    include_drafts = _is_platform_admin(user)
    if not include_drafts:
        _require_capability(user, "operations.runbook", "Your assigned role does not allow Custom Runbooks")
    items = list_runbooks(include_drafts=include_drafts)
    return {"items": items, "can_manage": _is_platform_admin(user)}


@app.post("/api/runbooks", status_code=201)
def create_runbook(payload: RunbookUpsertRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    try:
        item = save_runbook(payload.model_dump(), admin["username"])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "runbook_created", "runbook", str(item["id"]), {"name": item["name"], "risk": item["risk"]})
    return item


@app.put("/api/runbooks/{runbook_id}")
def update_runbook(runbook_id: int, payload: RunbookUpsertRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    try:
        item = save_runbook(payload.model_dump(), admin["username"], runbook_id=runbook_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "runbook_updated", "runbook", str(runbook_id), {"name": item["name"], "risk": item["risk"], "status": "draft"})
    return item


@app.post("/api/runbooks/{runbook_id}/approve")
def approve_runbook_api(runbook_id: int, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    try:
        item = approve_runbook(runbook_id, admin["username"])
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    audit(admin["username"], "runbook_approved", "runbook", str(runbook_id), {"name": item["name"], "risk": item["risk"], "allow_scheduled": item["allow_scheduled"]})
    return item


@app.delete("/api/runbooks/{runbook_id}")
def delete_runbook_api(runbook_id: int, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    try:
        delete_runbook(runbook_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "runbook_deleted", "runbook", str(runbook_id), {})
    return {"ok": True}


def _automation_action_metadata(action: str) -> dict[str, Any]:
    for item in public_automation_actions():
        if item.get("id") == action:
            return item
    raise HTTPException(status_code=400, detail=f"Unsupported scheduled action: {action}")


def _normalize_automation_settings(action: str, values: dict[str, Any] | None) -> dict[str, Any]:
    metadata = _automation_action_metadata(action)
    incoming = values if isinstance(values, dict) else {}
    normalized: dict[str, Any] = {}
    for name, spec in (metadata.get("settings") or {}).items():
        if not isinstance(spec, dict):
            continue
        value = incoming.get(name, spec.get("default"))
        if spec.get("type") == "integer":
            try:
                number = int(value)
            except (TypeError, ValueError) as exc:
                raise HTTPException(status_code=400, detail=f"Invalid {name}") from exc
            minimum = int(spec.get("min", number))
            maximum = int(spec.get("max", number))
            if number < minimum or number > maximum:
                raise HTTPException(status_code=400, detail=f"{name} must be between {minimum} and {maximum}")
            normalized[name] = number
        elif spec.get("type") == "choice":
            choices = [str(item.get("value")) for item in (spec.get("choices") or []) if isinstance(item, dict)]
            normalized_value = str(value or "").strip()
            if normalized_value not in choices:
                raise HTTPException(status_code=400, detail=f"Invalid {name}")
            normalized[name] = normalized_value
        elif spec.get("type") == "runbook":
            try:
                runbook_id = int(value or 0)
            except (TypeError, ValueError) as exc:
                raise HTTPException(status_code=400, detail="Select a valid runbook") from exc
            runbook = get_runbook(runbook_id)
            if not runbook or str(runbook.get("status") or "draft") != "approved" or not bool(runbook.get("allow_scheduled")):
                raise HTTPException(status_code=400, detail="Select an approved runbook that allows scheduled execution")
            normalized[name] = runbook_id
        elif spec.get("type") == "runbook_variables":
            runbook_id = int(incoming.get("runbook_id") or normalized.get("runbook_id") or 0)
            runbook = get_runbook(runbook_id)
            if not runbook:
                raise HTTPException(status_code=400, detail="Select a runbook before configuring variables")
            try:
                snapshot = render_runbook(runbook, value if isinstance(value, dict) else {})
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            normalized[name] = snapshot.get("variables") or {}
        else:
            normalized[name] = value
    return normalized


def _create_automation_schedule(payload: AutomationScheduleRequest, actor: str) -> dict[str, Any]:
    if payload.action not in automation_action_ids():
        raise HTTPException(status_code=400, detail=f"Unsupported scheduled action: {payload.action}")
    settings_json = json.dumps(_normalize_automation_settings(payload.action, payload.settings), ensure_ascii=False)
    now = utc_now()
    with db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO automation_schedules(
                name, enabled, action, run_time, timezone, sites_json, groups_json, settings_json,
                created_at, updated_at, updated_by
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload.name, int(payload.enabled), payload.action, payload.run_time, payload.timezone,
                json.dumps(payload.sites, ensure_ascii=False), json.dumps(payload.groups, ensure_ascii=False),
                settings_json, now, now, actor,
            ),
        )
        schedule_id = int(cursor.lastrowid)
    audit(actor, "automation_schedule_created", "schedule", str(schedule_id), payload.model_dump())
    return next(item for item in list_schedules() if int(item["id"]) == schedule_id)


def _update_automation_schedule(schedule_id: int, payload: AutomationScheduleRequest, actor: str) -> dict[str, Any]:
    if payload.action not in automation_action_ids():
        raise HTTPException(status_code=400, detail=f"Unsupported scheduled action: {payload.action}")
    settings_json = json.dumps(_normalize_automation_settings(payload.action, payload.settings), ensure_ascii=False)
    with db() as conn:
        cursor = conn.execute(
            """
            UPDATE automation_schedules SET
                name = ?, enabled = ?, action = ?, run_time = ?, timezone = ?,
                sites_json = ?, groups_json = ?, settings_json = ?, updated_at = ?, updated_by = ?
            WHERE id = ?
            """,
            (
                payload.name, int(payload.enabled), payload.action, payload.run_time, payload.timezone,
                json.dumps(payload.sites, ensure_ascii=False), json.dumps(payload.groups, ensure_ascii=False),
                settings_json, utc_now(), actor, schedule_id,
            ),
        )
    if not cursor.rowcount:
        raise HTTPException(status_code=404, detail="Schedule not found")
    audit(actor, "automation_schedule_updated", "schedule", str(schedule_id), payload.model_dump())
    return next(item for item in list_schedules() if int(item["id"]) == schedule_id)


def _delete_automation_schedule(schedule_id: int, actor: str) -> dict[str, bool]:
    with db() as conn:
        cursor = conn.execute("DELETE FROM automation_schedules WHERE id = ?", (schedule_id,))
    if not cursor.rowcount:
        raise HTTPException(status_code=404, detail="Schedule not found")
    audit(actor, "automation_schedule_deleted", "schedule", str(schedule_id), {})
    return {"ok": True}


def _legacy_unp_schedule_payload(payload: UnpScheduleRequest) -> AutomationScheduleRequest:
    return AutomationScheduleRequest(
        name=payload.name, enabled=payload.enabled, action=payload.action, run_time=payload.run_time,
        timezone=payload.timezone, sites=payload.sites, groups=payload.groups,
        settings={"cycle_delay_seconds": payload.cycle_delay_seconds},
    )


@app.get("/api/automation")
def automation_center(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {
        "credential": scheduler_credential_status(),
        "actions": public_automation_actions(),
        "schedules": list_schedules(),
        "runbooks": [item for item in list_runbooks(include_drafts=False) if bool(item.get("allow_scheduled"))],
        "safeguards": {
            "fix_unp": {
                "protected_ports": get_app_setting("unp_fix_protected_ports", "1/1/1"),
                "guest_keywords": get_app_setting("unp_fix_guest_keywords", "GUEST"),
                "service_keywords": get_app_setting("unp_fix_service_keywords", "VOIP,IPTV"),
                "max_ports_per_switch": get_app_setting_int("unp_fix_max_ports_per_switch", 12, 1, 48),
            },
            "vlan_port_maintenance": vlan_maintenance_safeguard_policy(),
        },
    }


@app.get("/api/automation/actions")
def automation_actions(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, Any]]:
    return public_automation_actions()


@app.put("/api/automation/credential")
def automation_save_credential(
    payload: SchedulerCredentialRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _save_scheduler_credential_impl(payload, admin)


@app.delete("/api/automation/credential")
def automation_delete_credential(admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    return _delete_scheduler_credential_impl(admin)


@app.post("/api/automation/schedules", status_code=201)
def automation_create_schedule(
    payload: AutomationScheduleRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _create_automation_schedule(payload, admin["username"])


@app.put("/api/automation/schedules/{schedule_id}")
def automation_update_schedule(
    schedule_id: int,
    payload: AutomationScheduleRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _update_automation_schedule(schedule_id, payload, admin["username"])


@app.delete("/api/automation/schedules/{schedule_id}")
def automation_delete_schedule(
    schedule_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, bool]:
    return _delete_automation_schedule(schedule_id, admin["username"])


@app.post("/api/automation/schedules/{schedule_id}/run", status_code=202)
def automation_run_schedule(
    schedule_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        job_id = run_schedule_now(schedule_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "automation_schedule_run_now", "schedule", str(schedule_id), {"job_id": job_id})
    return {"job_id": job_id, "status": "queued"}


@app.get("/api/automation/safeguards/fix-unp")
def automation_fix_unp_safeguards(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not _is_platform_admin(user):
        _require_action_permission(user, "fix_unp")
    return {
        "protected_ports": get_app_setting("unp_fix_protected_ports", "1/1/1"),
        "guest_keywords": get_app_setting("unp_fix_guest_keywords", "GUEST"),
        "service_keywords": get_app_setting("unp_fix_service_keywords", "VOIP,IPTV"),
        "max_ports_per_switch": get_app_setting_int("unp_fix_max_ports_per_switch", 12, 1, 48),
    }


@app.put("/api/automation/safeguards/fix-unp")
def automation_save_fix_unp_safeguards(
    payload: FixUnpSafeguardsRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    values = {
        "unp_fix_protected_ports": payload.protected_ports or "1/1/1",
        "unp_fix_guest_keywords": payload.guest_keywords or "GUEST",
        "unp_fix_service_keywords": payload.service_keywords or "VOIP,IPTV",
        "unp_fix_max_ports_per_switch": str(payload.max_ports_per_switch),
    }
    update_app_settings(values, admin["username"])
    audit(admin["username"], "fix_unp_safeguards_updated", "automation_policy", "fix_unp", values)
    return {
        "protected_ports": values["unp_fix_protected_ports"],
        "guest_keywords": values["unp_fix_guest_keywords"],
        "service_keywords": values["unp_fix_service_keywords"],
        "max_ports_per_switch": payload.max_ports_per_switch,
    }


@app.get("/api/automation/safeguards/vlan-maintenance")
def automation_vlan_maintenance_safeguards(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not _is_platform_admin(user):
        _require_action_permission(user, "vlan_port_maintenance")
    return vlan_maintenance_safeguard_policy()


@app.put("/api/automation/safeguards/vlan-maintenance")
def automation_save_vlan_maintenance_safeguards(
    payload: VlanMaintenanceSafeguardsRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    values = {
        "vlan_maintenance_protected_ports": payload.protected_ports,
        "vlan_maintenance_max_ports_per_switch": str(payload.max_ports_per_switch),
        "vlan_maintenance_max_total_ports": str(payload.max_total_ports),
        "vlan_maintenance_trunk_vlan_threshold": str(payload.trunk_vlan_threshold),
        "vlan_maintenance_mac_threshold": str(payload.mac_address_threshold),
    }
    update_app_settings(values, admin["username"])
    audit(admin["username"], "vlan_maintenance_safeguards_updated", "automation_policy", "vlan_port_maintenance", values)
    return vlan_maintenance_safeguard_policy()


# v1.3.7 compatibility endpoints. They expose the generic notification center
# while old cached clients transition to the v1.4.0 static bundle.
@app.get("/api/admin/teams-notifications")
def legacy_teams_notifications(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    state = get_notification_state()
    destinations = state.get("destinations", [])
    microsoft = next((item for item in destinations if item.get("provider") == "microsoft"), None)
    policy = state.get("policy", {})
    inventory = state.get("inventory", {})
    summary = state.get("summary", {})
    return {
        **policy,
        "webhook_configured": bool(microsoft and microsoft.get("webhook_configured")),
        "webhook_masked": microsoft.get("webhook_masked", "") if microsoft else "",
        "available_sites": inventory.get("available_sites", []), "available_groups": inventory.get("available_groups", []),
        "enabled_switch_count": inventory.get("enabled_switch_count", 0), "covered_switch_count": inventory.get("covered_switch_count", 0),
        "open_incidents": summary.get("open_incidents", 0), "pending_deliveries": summary.get("pending_deliveries", 0),
        "recent_deliveries": state.get("deliveries", [])[:20],
    }


@app.get("/api/admin/unp-scheduler")
def admin_unp_scheduler(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {
        "credential": scheduler_credential_status(),
        "schedules": list_schedules(),
    }


def _save_scheduler_credential_impl(payload: SchedulerCredentialRequest, admin: dict[str, Any]) -> dict[str, Any]:
    with db() as conn:
        device = conn.execute(
            """
            SELECT id, name, host, ssh_port, profile, last_status, response_ms, site
            FROM devices
            WHERE enabled = 1
            ORDER BY CASE WHEN last_status = 'online' THEN 0 ELSE 1 END, name COLLATE NOCASE
            LIMIT 1
            """
        ).fetchone()
    if not device:
        raise HTTPException(status_code=400, detail="Add at least one enabled switch before configuring the scheduler SSH account")
    candidate = _row_to_dict(device)
    candidate.update({"username": payload.username, "password_enc": encrypt_secret(payload.password)})
    test = run_commands(candidate, ["show system"])
    if not test.ok:
        raise HTTPException(status_code=400, detail=test.error or "Scheduler SSH verification failed")
    now = utc_now()
    with db() as conn:
        conn.execute(
            """
            INSERT INTO scheduler_credentials(
                id, username, password_enc, verified_device_id, verified_device_name,
                verified_at, updated_at, updated_by
            ) VALUES(1, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                username = excluded.username,
                password_enc = excluded.password_enc,
                verified_device_id = excluded.verified_device_id,
                verified_device_name = excluded.verified_device_name,
                verified_at = excluded.verified_at,
                updated_at = excluded.updated_at,
                updated_by = excluded.updated_by
            """,
            (payload.username, candidate["password_enc"], device["id"], device["name"], now, now, admin["username"]),
        )
    audit(admin["username"], "scheduler_credential_updated", "application", "automation", {"username": payload.username, "verified_device": device["name"]})
    return scheduler_credential_status()


@app.put("/api/admin/unp-scheduler/credential")
def save_scheduler_credential(
    payload: SchedulerCredentialRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _save_scheduler_credential_impl(payload, admin)


def _delete_scheduler_credential_impl(admin: dict[str, Any]) -> dict[str, bool]:
    with db() as conn:
        conn.execute("DELETE FROM scheduler_credentials WHERE id = 1")
    audit(admin["username"], "scheduler_credential_removed", "application", "automation", {})
    return {"ok": True}


@app.delete("/api/admin/unp-scheduler/credential")
def delete_scheduler_credential(admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    return _delete_scheduler_credential_impl(admin)


@app.post("/api/admin/unp-schedules", status_code=201)
def create_unp_schedule(
    payload: UnpScheduleRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _create_automation_schedule(_legacy_unp_schedule_payload(payload), admin["username"])


@app.put("/api/admin/unp-schedules/{schedule_id}")
def update_unp_schedule(
    schedule_id: int,
    payload: UnpScheduleRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    return _update_automation_schedule(schedule_id, _legacy_unp_schedule_payload(payload), admin["username"])


@app.delete("/api/admin/unp-schedules/{schedule_id}")
def delete_unp_schedule(
    schedule_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, bool]:
    return _delete_automation_schedule(schedule_id, admin["username"])


@app.post("/api/admin/unp-schedules/{schedule_id}/run", status_code=202)
def run_unp_schedule(
    schedule_id: int,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    try:
        job_id = run_schedule_now(schedule_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "unp_schedule_run_now", "schedule", str(schedule_id), {"job_id": job_id})
    return {"job_id": job_id, "status": "queued"}


@app.get("/api/admin/sessions")
def admin_sessions(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, object]]:
    return session_credentials.list_sessions()


def _public_ssh_user_access(profile: dict[str, Any]) -> dict[str, Any]:
    access = access_context_for_profile(profile)
    result = dict(profile)
    result["enabled"] = bool(result.get("enabled"))
    result["role"] = access.role_key
    result["role_id"] = access.role_id
    result["role_name"] = access.role_name
    result["scope"] = access.scope_payload()
    result["permissions"] = {
        "capabilities": sorted(access.capabilities),
        "allowed_actions": sorted(action_catalog_for_access(access).keys()),
    }
    return result


def _validate_access_scope_for_role(role: dict[str, Any], scope: dict[str, Any]) -> dict[str, Any]:
    if bool(role.get("global_role")):
        return {"mode": "all", "sites": [], "groups": []}
    normalized = normalize_scope(scope)
    if normalized["mode"] == "none":
        raise HTTPException(status_code=400, detail="This role requires an explicit Site/Group scope or All Sites access")
    if normalized["mode"] == "selected":
        with db() as conn:
            inventory_rows = conn.execute("SELECT DISTINCT site, group_name FROM devices ORDER BY site, group_name").fetchall()
        valid_sites = {str(row["site"] or "").strip().casefold() for row in inventory_rows if str(row["site"] or "").strip()}
        unknown_sites = [site for site in normalized["sites"] if site.casefold() not in valid_sites]
        if unknown_sites:
            raise HTTPException(status_code=400, detail=f"Unknown Site in access scope: {unknown_sites[0]}")
        valid_pairs = {(str(row["site"] or "").strip().casefold(), str(row["group_name"] or "").strip().casefold()) for row in inventory_rows}
        for item in normalized["groups"]:
            if item["site"].casefold() not in {site.casefold() for site in normalized["sites"]}:
                raise HTTPException(status_code=400, detail=f"Group scope references a Site that is not selected: {item['site']}")
            if (item["site"].casefold(), item["group"].casefold()) not in valid_pairs:
                raise HTTPException(status_code=400, detail=f"Unknown Site/Group scope: {item['site']} / {item['group']}")
    return normalized


@app.get("/api/admin/ssh-users")
def admin_ssh_users(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, Any]]:
    return [_public_ssh_user_access(dict(profile)) for profile in list_ssh_user_profiles()]


@app.get("/api/admin/access-control")
def admin_access_control(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    with db() as conn:
        rows = conn.execute("SELECT DISTINCT site, group_name FROM devices ORDER BY site COLLATE NOCASE, group_name COLLATE NOCASE").fetchall()
    sites = sorted({str(row["site"] or "").strip() for row in rows if str(row["site"] or "").strip()}, key=str.casefold)
    groups = [
        {"site": str(row["site"] or "").strip(), "group": str(row["group_name"] or "").strip()}
        for row in rows if str(row["site"] or "").strip() and str(row["group_name"] or "").strip()
    ]
    action_catalog = public_action_catalog()
    actions = [
        {"id": action, "label": str(meta.get("label") or action), "category": str(meta.get("category") or "Other"),
         "description": str(meta.get("description") or ""), "risk": str(meta.get("risk") or "read")}
        for action, meta in action_catalog.items()
        if action not in {"custom_runbook"}
    ]
    actions.sort(key=lambda item: (item["category"].casefold(), item["label"].casefold()))
    return {
        "roles": list_roles(),
        "capabilities": capability_catalog_payload(),
        "actions": actions,
        "sites": sites,
        "groups": groups,
    }


@app.post("/api/admin/access-roles", status_code=201)
def admin_create_access_role(payload: AccessRoleUpsertRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    try:
        role = save_custom_role(
            role_id=None, name=payload.name, description=payload.description,
            capabilities=payload.capabilities, allowed_actions=payload.allowed_actions, actor=admin["username"],
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "access_role_created", "access_role", str(role["id"]), {"name": role["name"]})
    return role


@app.put("/api/admin/access-roles/{role_id}")
def admin_update_access_role(role_id: int, payload: AccessRoleUpsertRequest, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    try:
        role = save_custom_role(
            role_id=role_id, name=payload.name, description=payload.description,
            capabilities=payload.capabilities, allowed_actions=payload.allowed_actions, actor=admin["username"],
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit(admin["username"], "access_role_updated", "access_role", str(role_id), {"name": role["name"]})
    return role


@app.delete("/api/admin/access-roles/{role_id}")
def admin_delete_access_role(role_id: int, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    try:
        delete_custom_role(role_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    audit(admin["username"], "access_role_deleted", "access_role", str(role_id), {})
    return {"ok": True}


@app.put("/api/admin/ssh-users/{user_id}/access")
def admin_update_ssh_user_access(
    user_id: int,
    payload: SshUserAccessUpdateRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    role = role_by_id(payload.role_id)
    if not role:
        raise HTTPException(status_code=400, detail="Selected access role does not exist")
    raw_scope = {"mode": payload.scope_mode, "sites": payload.sites, "groups": [item.model_dump() for item in payload.groups]}
    scope = _validate_access_scope_for_role(role, raw_scope)
    updated = update_ssh_user_access(
        user_id, role_id=payload.role_id, enabled=payload.enabled,
        scope_json=json.dumps(scope, ensure_ascii=False), actor=admin["username"],
    )
    if not updated:
        raise HTTPException(status_code=404, detail="SSH user not found")
    public = _public_ssh_user_access(updated)
    # Scope or role changes must take effect immediately on active sessions.
    # current_user re-reads the profile on every request, so no credential
    # session needs to be destroyed. Audit the effective assignment explicitly.
    audit(admin["username"], "ssh_user_access_updated", "ssh_user", str(user_id), {
        "username": public["username"], "role": public["role"], "role_name": public["role_name"],
        "scope": public["scope"], "enabled": public["enabled"],
    })
    return public


@app.put("/api/admin/ssh-users/{user_id}")
def admin_update_ssh_user(
    user_id: int,
    payload: SshUserRoleUpdateRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, object]:
    updated = update_ssh_user_profile(
        user_id,
        role=payload.role,
        enabled=payload.enabled,
        actor=admin["username"],
    )
    if not updated:
        raise HTTPException(status_code=404, detail="SSH user not found")
    audit(
        admin["username"],
        "ssh_user_role_updated",
        "ssh_user",
        str(user_id),
        {"username": updated["username"], "role": updated["role"], "enabled": updated["enabled"]},
    )
    return updated


@app.delete("/api/admin/sessions/{session_id}")
def revoke_admin_session(
    session_id: str,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, bool]:
    revoked = session_credentials.revoke_public_id(session_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="SSH session not found")
    audit(admin["username"], "ssh_session_revoked", "session", session_id, {})
    return {"ok": True}


@app.post("/api/admin/health-scan", status_code=202)
def admin_health_scan(
    background_tasks: BackgroundTasks,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, Any]:
    background_tasks.add_task(scan_all_devices, "admin-manual")
    audit(admin["username"], "health_scan_requested", "application", "health-monitor", {})
    return {"queued": True}


@app.post("/api/admin/maintenance/prune")
def admin_prune(
    payload: AdminMaintenanceRequest,
    admin: dict[str, Any] = Depends(require_admin),
) -> dict[str, int]:
    now = datetime.now(timezone.utc)
    audit_cutoff = (now - timedelta(days=payload.audit_retention_days)).isoformat()
    jobs_cutoff = (now - timedelta(days=payload.completed_jobs_retention_days)).isoformat()
    with db() as conn:
        audit_deleted = conn.execute("DELETE FROM audit_log WHERE created_at < ?", (audit_cutoff,)).rowcount
        jobs_deleted = conn.execute(
            "DELETE FROM jobs WHERE status IN ('completed','failed','partial','cancelled','interrupted') AND created_at < ?",
            (jobs_cutoff,),
        ).rowcount
        fleet_audits_deleted = conn.execute(
            "DELETE FROM fleet_audit_runs WHERE status IN ('completed','failed') AND created_at < ?",
            (jobs_cutoff,),
        ).rowcount
    result = {
        "audit_deleted": max(0, int(audit_deleted or 0)),
        "jobs_deleted": max(0, int(jobs_deleted or 0)),
        "fleet_audits_deleted": max(0, int(fleet_audits_deleted or 0)),
        "health_deleted": 0,
    }
    audit(admin["username"], "maintenance_prune", "application", "database", result)
    return result


@app.get("/api/admin/backup")
def admin_backup(admin: dict[str, Any] = Depends(require_admin)) -> FileResponse:
    temp_handle = tempfile.NamedTemporaryFile(prefix="portivo-backup-", suffix=".db", delete=False)
    temp_path = Path(temp_handle.name)
    temp_handle.close()
    try:
        source = sqlite3.connect(str(settings.database_path))
        destination = sqlite3.connect(str(temp_path))
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()
        backup_size = temp_path.stat().st_size
        timestamp = platform_now().strftime("%Y%m%d-%H%M%S")
        audit(admin["username"], "database_backup", "application", "database", {"bytes": backup_size, "delivery": "streamed-file"})
        return FileResponse(
            path=str(temp_path),
            media_type="application/vnd.sqlite3",
            filename=f"portivo-backup-{timestamp}.db",
            background=BackgroundTask(lambda: temp_path.unlink(missing_ok=True)),
        )
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def _validate_database_backup(path: Path) -> dict[str, Any]:
    try:
        conn = sqlite3.connect(str(path), timeout=10)
    except sqlite3.Error as exc:
        raise ValueError(f"Unable to open SQLite database: {exc}") from exc
    try:
        quick_check = conn.execute("PRAGMA quick_check").fetchone()
        if not quick_check or str(quick_check[0]).lower() != "ok":
            raise ValueError("SQLite integrity check failed")
        tables = {
            str(row[0])
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'").fetchall()
        }
        missing = sorted(_REQUIRED_DATABASE_TABLES - tables)
        if missing:
            raise ValueError("Missing required tables: " + ", ".join(missing))
        enabled_admins = int(
            conn.execute(
                "SELECT COUNT(*) FROM app_users WHERE role = 'admin' AND enabled = 1"
            ).fetchone()[0]
        )
        if enabled_admins < 1:
            raise ValueError("The backup does not contain an enabled bootstrap administrator")
        return {
            "devices": int(conn.execute("SELECT COUNT(*) FROM devices").fetchone()[0]),
            "jobs": int(conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]),
            "job_items": int(conn.execute("SELECT COUNT(*) FROM job_items").fetchone()[0]),
            "audit_entries": int(conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]),
        }
    finally:
        conn.close()


def _backup_database_file(destination_path: Path) -> None:
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    source = sqlite3.connect(str(settings.database_path), timeout=30)
    destination = sqlite3.connect(str(destination_path), timeout=30)
    try:
        source.backup(destination)
    finally:
        destination.close()
        source.close()


@app.post("/api/admin/database/import")
async def admin_import_database(
    file: UploadFile = File(...),
    admin: dict[str, Any] = Depends(require_bootstrap_admin),
) -> dict[str, Any]:
    if not _DATABASE_MAINTENANCE_LOCK.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="A database maintenance operation is already running")

    temp_path: Path | None = None
    monitor_stopped = False
    scheduler_stopped = False
    notification_worker_stopped = False
    power_monitor_stopped = False
    safety_backup: Path | None = None
    try:
        with db() as conn:
            active_jobs = int(
                conn.execute(
                    "SELECT COUNT(*) FROM jobs WHERE status IN ('queued', 'running', 'cancelling')"
                ).fetchone()[0]
            )
            active_fleet_audits = int(
                conn.execute(
                    "SELECT COUNT(*) FROM fleet_audit_runs WHERE status IN ('queued', 'running')"
                ).fetchone()[0]
            )
        if active_jobs or active_fleet_audits:
            raise HTTPException(
                status_code=409,
                detail="Database import is unavailable while jobs or fleet audits are queued or running",
            )

        suffix = Path(file.filename or "database.db").suffix.lower() or ".db"
        handle = tempfile.NamedTemporaryFile(prefix="osc-import-", suffix=suffix, delete=False)
        temp_path = Path(handle.name)
        total = 0
        try:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > DATABASE_IMPORT_MAX_BYTES:
                    raise HTTPException(status_code=413, detail="Database backup exceeds the 2 GB import limit")
                handle.write(chunk)
        finally:
            handle.close()
            await file.close()

        if total < 100:
            raise HTTPException(status_code=400, detail="The uploaded database backup is empty or incomplete")
        try:
            imported_counts = _validate_database_backup(temp_path)
        except (ValueError, sqlite3.Error) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        timestamp = platform_now().strftime("%Y%m%d-%H%M%S")
        safety_backup = settings.database_path.parent / "backups" / f"pre-import-{timestamp}.db"

        stop_unp_scheduler()
        scheduler_stopped = True
        stop_power_monitor()
        power_monitor_stopped = True
        stop_health_monitor()
        monitor_stopped = True
        stop_notification_worker()
        notification_worker_stopped = True
        _backup_database_file(safety_backup)

        source = sqlite3.connect(str(temp_path), timeout=30)
        destination = sqlite3.connect(str(settings.database_path), timeout=30)
        try:
            source.backup(destination)
            try:
                destination.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except sqlite3.OperationalError:
                pass
            destination.commit()
        finally:
            destination.close()
            source.close()

        init_db()
        revoked_sessions = session_credentials.clear_all()
        audit(
            admin["username"],
            "database_import",
            "application",
            "database",
            {
                "filename": Path(file.filename or "database.db").name,
                "bytes": total,
                "safety_backup": str(safety_backup),
                "revoked_ssh_sessions": revoked_sessions,
                **imported_counts,
            },
        )
        return {
            "imported": True,
            "bytes": total,
            "safety_backup": str(safety_backup),
            "revoked_ssh_sessions": revoked_sessions,
            "counts": imported_counts,
            "restart_recommended": True,
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Database import failed", exc_info=exc)
        if safety_backup and safety_backup.exists():
            try:
                backup_source = sqlite3.connect(str(safety_backup), timeout=30)
                destination = sqlite3.connect(str(settings.database_path), timeout=30)
                try:
                    backup_source.backup(destination)
                    destination.commit()
                finally:
                    destination.close()
                    backup_source.close()
                init_db()
            except Exception:
                logger.exception("Automatic restore after failed database import also failed")
        raise HTTPException(status_code=500, detail=f"Database import failed: {exc}") from exc
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
        if monitor_stopped:
            start_health_monitor()
        if scheduler_stopped:
            start_unp_scheduler()
        if notification_worker_stopped:
            start_notification_worker()
        if power_monitor_stopped:
            start_power_monitor()
        _DATABASE_MAINTENANCE_LOCK.release()


def _connectivity_percent(total: int, online: int) -> float:
    """Return fleet availability to one decimal without rounding a degraded fleet up to 100%."""
    total = max(0, int(total or 0))
    online = max(0, min(int(online or 0), total))
    if total == 0:
        return 0.0
    if online == total:
        return 100.0
    return (online * 1000 // total) / 10.0



def _public_ups(row: Any, *, protected_switches: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    item = _row_to_dict(row) if hasattr(row, "keys") else dict(row)
    item["enabled"] = bool(item.get("enabled"))
    try:
        item["alarms"] = json.loads(str(item.get("alarms_json") or "[]"))
    except Exception:
        item["alarms"] = []
    item.pop("alarms_json", None)
    # Detailed telemetry is intentionally omitted from the inventory endpoint.
    # It can be large on multi-phase/vendor-rich UPS models and is loaded only
    # when the operator opens the UPS details workspace.
    item.pop("telemetry_json", None)
    protected_switches = protected_switches or []
    item["protected_switches"] = protected_switches
    item["protected_switch_count"] = len(protected_switches)
    state = str(item.get("power_state") or "unknown")
    status = str(item.get("last_status") or "unknown")
    item["communication_status"] = status
    # UPS severity is based only on authoritative power telemetry. A confirmed
    # communication outage is displayed in Power as information, but never
    # escalates the UPS health severity or Dashboard attention by itself.
    if state in {"depleted", "output_off"}:
        severity = "critical"
    elif state in {"low_battery", "on_battery", "bypass"}:
        severity = "warning"
    elif state == "normal" and item.get("last_seen"):
        severity = "healthy"
    elif state == "unknown" and str(item.get("battery_status") or "") in {"normal", "charging", "floating", "resting"} and item.get("last_seen"):
        severity = "healthy"
        item["power_state"] = "normal"
    else:
        severity = "unknown"
    item["severity"] = severity
    item["driver_mode"] = str(item.get("driver_mode") or "auto")
    item["driver_key"] = str(item.get("driver_key") or "generic")
    has_driver_evidence = bool(str(item.get("sys_object_id") or "").strip() or item.get("last_seen"))
    if has_driver_evidence:
        item["driver_name"] = power_driver_name(item["driver_key"])
    elif item["driver_mode"] in {"apc", "eaton", "vertiv", "socomec", "acculine", "xppc", "generic"}:
        item["driver_name"] = power_driver_name(item["driver_mode"])
    else:
        item["driver_name"] = "Auto detect"
    return item


def _ups_in_scope(user: dict[str, Any], row: Any) -> bool:
    return device_in_scope(_access(user), {"site": row["site"] if hasattr(row, "keys") else row.get("site", ""), "group_name": row["group_name"] if hasattr(row, "keys") else row.get("group_name", "")})


def _require_ups_scope(user: dict[str, Any], row: Any) -> None:
    if not _ups_in_scope(user, row):
        raise HTTPException(status_code=403, detail="This UPS is outside your assigned Site/Group scope")


def _validate_ups_profile(profile_id: int) -> dict[str, Any]:
    profile = get_monitoring_profile(int(profile_id), decrypt=False)
    if not profile or str(profile.get("method") or "") != "snmpv3":
        raise HTTPException(status_code=400, detail="Select a valid SNMPv3 Monitoring Credential profile")
    return profile


def _validate_power_source_assignment(user: dict[str, Any], ups_id: int | None, *, site: str, group_name: str) -> Any | None:
    if ups_id is None:
        return None
    _require_capability(user, "power.assign", "Your assigned role does not allow power-source assignments")
    with db() as conn:
        row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (int(ups_id),)).fetchone()
    if not row:
        raise HTTPException(status_code=400, detail="Selected UPS power source was not found")
    _require_ups_scope(user, row)
    ups_site = str(row["site"] or "").strip()
    switch_site = str(site or "").strip()
    if ups_site and ups_site.casefold() != switch_site.casefold():
        raise HTTPException(status_code=400, detail="A switch can only be assigned to a UPS in the same Site")
    return row


@app.get("/api/power")
def power_infrastructure(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.view")
    access = _access(user)
    with db() as conn:
        ups_rows = conn.execute("SELECT * FROM ups_devices ORDER BY site COLLATE NOCASE, name COLLATE NOCASE, id").fetchall()
        visible_ups = [row for row in ups_rows if device_in_scope(access, {"site": row["site"], "group_name": row["group_name"]})]
        visible_ids = {int(row["id"]) for row in visible_ups}
        switch_rows = conn.execute("SELECT id,name,host,site,group_name,last_status,power_source_ups_id FROM devices WHERE power_source_ups_id IS NOT NULL ORDER BY site,name").fetchall()
        switch_rows = filter_devices(access, switch_rows)
        by_ups: dict[int, list[dict[str, Any]]] = {}
        for row in switch_rows:
            ups_id = int(row["power_source_ups_id"] or 0)
            if ups_id not in visible_ids:
                continue
            by_ups.setdefault(ups_id, []).append({
                "id": int(row["id"]), "name": str(row["name"]), "host": str(row["host"]),
                "site": str(row["site"] or ""), "group_name": str(row["group_name"] or ""),
                "last_status": str(row["last_status"] or "unknown"),
            })
    ups = [_public_ups(row, protected_switches=by_ups.get(int(row["id"]), [])) for row in visible_ups]
    normal = sum(1 for item in ups if item["last_status"] == "online" and item["power_state"] == "normal")
    offline = sum(1 for item in ups if item["last_status"] == "unreachable")
    on_battery = sum(1 for item in ups if item["last_status"] == "online" and item["power_state"] in {"on_battery", "low_battery", "depleted"})
    critical = sum(1 for item in ups if item["severity"] == "critical")
    warning = sum(1 for item in ups if item["severity"] == "warning")
    protected_switch_count = sum(int(item["protected_switch_count"]) for item in ups)
    open_incident_count = 0
    if visible_ids:
        placeholders = ",".join("?" for _ in visible_ids)
        with db() as conn:
            open_incident_count = int(conn.execute(
                f"SELECT COUNT(*) FROM power_incidents WHERE ups_id IN ({placeholders}) AND status='open' AND incident_type<>'ups_unreachable'",
                tuple(sorted(visible_ids)),
            ).fetchone()[0] or 0)
    return {
        "summary": {
            "ups_total": len(ups), "ups_normal": normal, "ups_on_battery": on_battery, "ups_offline": offline,
            "ups_warning": warning, "ups_critical": critical, "protected_switches": protected_switch_count,
            "open_incidents": open_incident_count,
        },
        "ups": ups,
        "incidents": [],
        "monitor": power_monitor_status(),
        "monitoring_policy": monitoring_policy(),
        "drivers": power_driver_catalog(),
    }


@app.get("/api/power/incidents")
def power_incident_history(
    search: str = "",
    status: str = "",
    incident_type: str = "",
    ups_id: int = 0,
    page: int = 1,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Return scoped Power incidents with a hard 25-row page size."""
    _require_capability(user, "power.view")
    access = _access(user)
    normalized_status = str(status or "").strip().lower()
    if normalized_status not in {"", "open", "closed"}:
        raise HTTPException(status_code=400, detail="Invalid power incident status filter")
    normalized_type = str(incident_type or "").strip()
    normalized_search = str(search or "").strip().lower()[:180]
    page_number = max(1, int(page or 1))
    page_size = 25

    with db() as conn:
        ups_rows = conn.execute(
            "SELECT id,name,host,site,group_name FROM ups_devices ORDER BY site COLLATE NOCASE, name COLLATE NOCASE, id"
        ).fetchall()
        visible_ups = [
            row for row in ups_rows
            if device_in_scope(access, {"site": row["site"], "group_name": row["group_name"]})
        ]
        visible_ids = [int(row["id"]) for row in visible_ups]
        if not visible_ids:
            return {
                "items": [],
                "pagination": {"page": 1, "page_size": page_size, "pages": 1, "total": 0},
                "filter_options": {"types": [], "ups": []},
            }

        if int(ups_id or 0) and int(ups_id) not in set(visible_ids):
            raise HTTPException(status_code=404, detail="UPS not found in your assigned scope")

        placeholders = ",".join("?" for _ in visible_ids)
        clauses = [f"ups_id IN ({placeholders})"]
        params: list[Any] = list(visible_ids)
        if normalized_status:
            clauses.append("status = ?")
            params.append(normalized_status)
        if normalized_type:
            clauses.append("incident_type = ?")
            params.append(normalized_type)
        if int(ups_id or 0):
            clauses.append("ups_id = ?")
            params.append(int(ups_id))
        if normalized_search:
            like = f"%{normalized_search}%"
            clauses.append("(LOWER(ups_name) LIKE ? OR LOWER(incident_type) LIKE ? OR LOWER(status) LIKE ? OR LOWER(details_json) LIKE ?)")
            params.extend([like, like, like, like])

        where_sql = " AND ".join(clauses)
        total = int(conn.execute(f"SELECT COUNT(*) FROM power_incidents WHERE {where_sql}", tuple(params)).fetchone()[0] or 0)
        pages = max(1, math.ceil(total / page_size))
        page_number = min(page_number, pages)
        offset = (page_number - 1) * page_size
        rows = conn.execute(
            f"SELECT * FROM power_incidents WHERE {where_sql} ORDER BY id DESC LIMIT ? OFFSET ?",
            tuple([*params, page_size, offset]),
        ).fetchall()
        type_rows = conn.execute(
            f"SELECT DISTINCT incident_type FROM power_incidents WHERE ups_id IN ({placeholders}) ORDER BY incident_type COLLATE NOCASE",
            tuple(visible_ids),
        ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        item = _row_to_dict(row)
        try:
            item["details"] = json.loads(str(item.get("details_json") or "{}"))
        except Exception:
            item["details"] = {}
        item.pop("details_json", None)
        items.append(item)
    return {
        "items": items,
        "pagination": {"page": page_number, "page_size": page_size, "pages": pages, "total": total},
        "filter_options": {
            "types": [str(row["incident_type"]) for row in type_rows if str(row["incident_type"] or "").strip()],
            "ups": [
                {"id": int(row["id"]), "name": str(row["name"]), "host": str(row["host"]), "site": str(row["site"] or "")}
                for row in visible_ups
            ],
        },
    }


@app.get("/api/power/monitoring-profiles")
def power_monitoring_profiles(user: dict[str, Any] = Depends(current_user)) -> list[dict[str, Any]]:
    _require_any_capability(user, {"power.create", "power.edit", "power.verify"}, "Your assigned role does not allow UPS monitoring configuration")
    return [profile for profile in list_monitoring_profiles() if str(profile.get("method") or "") == "snmpv3"]


@app.post("/api/power/verify")
def verify_power_ups(payload: UpsVerifyRequest, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.verify", "Your assigned role does not allow UPS telemetry verification")
    _validate_ups_profile(payload.monitoring_profile_id)
    try:
        snapshot = verify_ups(payload.host, payload.monitoring_profile_id, driver_mode=payload.driver_mode)
    except (ValueError, RuntimeError, TimeoutError, OSError) as exc:
        # Verification failures are operator-actionable monitoring errors, not
        # application faults. Return the precise SNMP/network diagnostic to the
        # modal instead of allowing the global 500 handler to hide it behind
        # "Unexpected server error". No credential secrets are included in
        # these exception messages.
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"verified": True, **snapshot}



def _power_ups_details_payload(ups_id: int, user: dict[str, Any], *, live_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    access = _access(user)
    with db() as conn:
        row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (int(ups_id),)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="UPS not found")
        _require_ups_scope(user, row)
        switch_rows = conn.execute(
            "SELECT id,name,host,site,group_name,last_status FROM devices WHERE power_source_ups_id=? ORDER BY name COLLATE NOCASE",
            (int(ups_id),),
        ).fetchall()
        visible_switches = filter_devices(access, switch_rows)
        incident_rows = conn.execute(
            "SELECT * FROM power_incidents WHERE ups_id=? ORDER BY id DESC LIMIT 10",
            (int(ups_id),),
        ).fetchall()
    protected = [
        {"id": int(item["id"]), "name": str(item["name"]), "host": str(item["host"]),
         "site": str(item["site"] or ""), "group_name": str(item["group_name"] or ""),
         "last_status": str(item["last_status"] or "unknown")}
        for item in visible_switches
    ]
    ups = _public_ups(row, protected_switches=protected)
    try:
        stored_telemetry = json.loads(str(row["telemetry_json"] or "{}"))
    except Exception:
        stored_telemetry = {}
    incidents: list[dict[str, Any]] = []
    for incident in incident_rows:
        item = _row_to_dict(incident)
        try:
            item["details"] = json.loads(str(item.get("details_json") or "{}"))
        except Exception:
            item["details"] = {}
        item.pop("details_json", None)
        incidents.append(item)
    return {
        "ups": ups,
        "telemetry": (live_snapshot or {}).get("telemetry") or stored_telemetry,
        "telemetry_updated_at": utc_now() if live_snapshot is not None else row["telemetry_updated_at"],
        "live": live_snapshot or None,
        "protected_switches": protected,
        "recent_incidents": incidents,
    }


@app.get("/api/power/ups/{ups_id}/details")
def get_power_ups_details(ups_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.view")
    return _power_ups_details_payload(ups_id, user)


@app.post("/api/power/ups/{ups_id}/details/refresh")
def refresh_power_ups_details(ups_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Collect a comprehensive read-only UPS telemetry snapshot on demand.

    This does not alter incident state. The background Power monitor remains
    authoritative for health transitions while this endpoint enriches the
    operator-facing details workspace with every supported standard/vendor
    metric that the connected UPS actually reports.
    """
    _require_capability(user, "power.view")
    with db() as conn:
        row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (int(ups_id),)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="UPS not found")
    _require_ups_scope(user, row)
    try:
        snapshot = verify_ups(
            str(row["host"]), int(row["monitoring_profile_id"]),
            driver_mode=str(row["driver_mode"] or "auto"), detailed=True,
        )
    except (ValueError, RuntimeError, TimeoutError, OSError) as exc:
        # A manual Refresh telemetry attempt is a real read-only communication
        # check. Count it exactly like a background poll so a powered-off UPS
        # cannot remain visually Normal forever while every live probe fails.
        record_ups_probe_failure(int(ups_id), str(exc))
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    telemetry = snapshot.get("telemetry") or {}
    collected_at = utc_now()
    # Apply the successful live probe through the same authoritative state path
    # used by the background worker. This resets failed-check counters, restores
    # communication state and keeps power-state history consistent.
    record_ups_probe_success(int(ups_id), snapshot, checked_at=collected_at)
    with db() as conn:
        # Detailed vendor telemetry is larger than the compact background state,
        # so persist it separately after the common probe-state update.
        conn.execute(
            "UPDATE ups_devices SET telemetry_json=?, telemetry_updated_at=?, updated_at=? WHERE id=?",
            (json.dumps(telemetry, ensure_ascii=False), collected_at, collected_at, int(ups_id)),
        )
    payload = _power_ups_details_payload(ups_id, user, live_snapshot=snapshot)
    payload["telemetry_updated_at"] = collected_at
    return payload


@app.post("/api/power/scan", status_code=202)
def scan_power_infrastructure(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.view")
    request_power_scan()
    return {"queued": True}


@app.post("/api/power/ups", status_code=201)
def create_ups(payload: UpsDeviceRequest, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.create", "Your assigned role does not allow adding UPS assets")
    _require_device_scope(user, {"site": payload.site, "group_name": payload.group_name})
    _validate_ups_profile(payload.monitoring_profile_id)
    now = utc_now()
    try:
        with db() as conn:
            cursor = conn.execute(
                """
                INSERT INTO ups_devices(name,host,site,group_name,location,monitoring_profile_id,driver_mode,enabled,created_at,updated_at,updated_by)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                (payload.name, payload.host, payload.site, payload.group_name, payload.location, payload.monitoring_profile_id, payload.driver_mode, int(payload.enabled), now, now, user["username"]),
            )
            ups_id = int(cursor.lastrowid)
            row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    except sqlite3.IntegrityError as exc:
        message = str(exc)
        if "host" in message.lower():
            raise HTTPException(status_code=409, detail="A UPS with this management address already exists") from exc
        raise HTTPException(status_code=409, detail="A UPS with this name already exists") from exc
    audit(user["username"], "create", "ups", str(ups_id), {"name": payload.name, "host": payload.host, "site": payload.site, "group_name": payload.group_name, "driver_mode": payload.driver_mode})
    request_power_scan()
    return _public_ups(row)


@app.put("/api/power/ups/{ups_id}")
def update_ups(ups_id: int, payload: UpsDeviceRequest, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.edit", "Your assigned role does not allow editing UPS assets")
    _validate_ups_profile(payload.monitoring_profile_id)
    with db() as conn:
        existing = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="UPS not found")
    _require_ups_scope(user, existing)
    _require_device_scope(user, {"site": payload.site, "group_name": payload.group_name})
    current_site = str(existing["site"] or "").strip()
    target_site = str(payload.site or "").strip()
    if current_site.casefold() != target_site.casefold():
        with db() as conn:
            linked_rows = conn.execute("SELECT name,site FROM devices WHERE power_source_ups_id=? AND enabled=1 ORDER BY name", (ups_id,)).fetchall()
        incompatible = [str(row["name"] or "Switch") for row in linked_rows if target_site and str(row["site"] or "").strip().casefold() != target_site.casefold()]
        if incompatible:
            sample = ", ".join(incompatible[:3])
            suffix = f" and {len(incompatible) - 3} more" if len(incompatible) > 3 else ""
            raise HTTPException(status_code=400, detail=f"Reassign the protected switches before moving this UPS to another Site: {sample}{suffix}")
    now = utc_now()
    try:
        with db() as conn:
            conn.execute(
                """
                UPDATE ups_devices SET name=?,host=?,site=?,group_name=?,location=?,monitoring_profile_id=?,driver_mode=?,enabled=?,updated_at=?,updated_by=?
                WHERE id=?
                """,
                (payload.name, payload.host, payload.site, payload.group_name, payload.location, payload.monitoring_profile_id, payload.driver_mode, int(payload.enabled), now, user["username"], ups_id),
            )
            row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    except sqlite3.IntegrityError as exc:
        message = str(exc)
        if "host" in message.lower():
            raise HTTPException(status_code=409, detail="A UPS with this management address already exists") from exc
        raise HTTPException(status_code=409, detail="A UPS with this name already exists") from exc
    audit(user["username"], "update", "ups", str(ups_id), {"name": payload.name, "host": payload.host, "site": payload.site, "group_name": payload.group_name, "driver_mode": payload.driver_mode})
    request_power_scan()
    return _public_ups(row)


@app.put("/api/power/ups/{ups_id}/assignments")
def update_ups_assignments(ups_id: int, payload: UpsAssignmentRequest, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.assign", "Your assigned role does not allow UPS power-source assignments")
    with db() as conn:
        ups = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
    if not ups:
        raise HTTPException(status_code=404, detail="UPS not found")
    _require_ups_scope(user, ups)
    requested = list(payload.device_ids or [])
    selected_rows: list[Any] = []
    if requested:
        placeholders = ",".join("?" for _ in requested)
        with db() as conn:
            selected_rows = conn.execute(f"SELECT * FROM devices WHERE id IN ({placeholders}) ORDER BY name", tuple(requested)).fetchall()
        if len(selected_rows) != len(set(requested)):
            raise HTTPException(status_code=400, detail="One or more selected switches no longer exist")
    ups_site = str(ups["site"] or "").strip()
    for row in selected_rows:
        _require_device_scope(user, row)
        switch_site = str(row["site"] or "").strip()
        if ups_site and ups_site.casefold() != switch_site.casefold():
            raise HTTPException(status_code=400, detail=f"{row['name']} is not in the same Site as {ups['name']}")
    now = utc_now()
    selected_ids = [int(row["id"]) for row in selected_rows]
    with db() as conn:
        previous_rows = conn.execute("SELECT id,name FROM devices WHERE power_source_ups_id=? ORDER BY id", (ups_id,)).fetchall()
        previous_ids = {int(row["id"]) for row in previous_rows}
        conn.execute("UPDATE devices SET power_source_ups_id=NULL, updated_at=? WHERE power_source_ups_id=?", (now, ups_id))
        if selected_ids:
            placeholders = ",".join("?" for _ in selected_ids)
            conn.execute(f"UPDATE devices SET power_source_ups_id=?, updated_at=? WHERE id IN ({placeholders})", (ups_id, now, *selected_ids))
    audit(user["username"], "update", "ups_assignments", str(ups_id), {
        "ups_name": str(ups["name"] or ""),
        "protected_switches": len(selected_ids),
        "added": sorted(set(selected_ids) - previous_ids),
        "removed": sorted(previous_ids - set(selected_ids)),
    })
    return {"ok": True, "ups_id": ups_id, "protected_switches": len(selected_ids)}


@app.delete("/api/power/ups/{ups_id}")
def delete_ups(ups_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "power.delete", "Your assigned role does not allow deleting UPS assets")
    with db() as conn:
        row = conn.execute("SELECT * FROM ups_devices WHERE id=?", (ups_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="UPS not found")
        _require_ups_scope(user, row)
        linked = int(conn.execute("SELECT COUNT(*) AS c FROM devices WHERE power_source_ups_id=?", (ups_id,)).fetchone()["c"])
        conn.execute("UPDATE devices SET power_source_ups_id=NULL, updated_at=? WHERE power_source_ups_id=?", (utc_now(), ups_id))
        conn.execute("DELETE FROM ups_devices WHERE id=?", (ups_id,))
    audit(user["username"], "delete", "ups", str(ups_id), {"name": row["name"], "host": row["host"], "unassigned_switches": linked})
    return {"ok": True, "unassigned_switches": linked}


@app.get("/api/dashboard")
def dashboard(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "dashboard.view")
    access = _access(user)
    with db() as conn:
        notification_policy_row = conn.execute("SELECT failure_threshold FROM notification_policy WHERE id=1").fetchone()
        outage_confirmation_checks = max(2, min(10, int((notification_policy_row["failure_threshold"] if notification_policy_row else 3) or 3)))
        device_rows = conn.execute(
            "SELECT id, site, group_name, last_status, last_seen, consecutive_failures, stack_monitor_enabled, stack_last_status FROM devices"
        ).fetchall()
        visible_devices = filter_devices(access, device_rows)
        confirmed_status = {
            int(row["id"]): confirmed_connectivity_status(_row_to_dict(row), outage_confirmation_checks)
            for row in visible_devices
        }
        total = len(visible_devices)
        online = sum(1 for row in visible_devices if confirmed_status.get(int(row["id"])) == "online")
        offline = sum(1 for row in visible_devices if confirmed_status.get(int(row["id"])) == "offline")
        degraded_stacks = sum(
            1 for row in visible_devices
            if confirmed_status.get(int(row["id"])) == "online"
            and bool(row["stack_monitor_enabled"])
            and str(row["stack_last_status"] or "").lower() == "degraded"
        )
        unknown = total - online - offline
        pending_rows = conn.execute("SELECT device_id FROM pending_config_changes").fetchall()
        visible_ids = {int(row["id"]) for row in visible_devices}
        visible_pending = [int(row["device_id"]) for row in pending_rows if int(row["device_id"]) in visible_ids]
        candidate_jobs = conn.execute("SELECT * FROM jobs WHERE removed_at IS NULL ORDER BY id DESC LIMIT 100").fetchall()

        # The dashboard needs only the few switches that require attention. It
        # no longer depends on downloading the full fleet inventory in the
        # browser just to render the Infrastructure attention card.
        attention_ids = [
            int(row["id"])
            for row in visible_devices
            if confirmed_status.get(int(row["id"])) == "offline"
            or (
                confirmed_status.get(int(row["id"])) == "online"
                and bool(row["stack_monitor_enabled"])
                and str(row["stack_last_status"] or "").lower() == "degraded"
            )
        ]
        switch_attention_rows = []
        if attention_ids:
            placeholders = ",".join("?" for _ in attention_ids)
            switch_attention_rows = conn.execute(
                f"""
                SELECT d.*, (SELECT COUNT(*) FROM pending_config_changes p WHERE p.device_id = d.id) AS pending_config_count,
                       u.name AS power_source_ups_name, u.host AS power_source_ups_host,
                       u.last_status AS power_source_ups_status, u.power_state AS power_source_power_state,
                       u.battery_charge_percent AS power_source_battery_charge_percent, u.runtime_minutes AS power_source_runtime_minutes
                FROM devices d
                LEFT JOIN ups_devices u ON u.id = d.power_source_ups_id
                WHERE d.id IN ({placeholders})
                ORDER BY CASE WHEN d.last_status = 'offline' THEN 0 ELSE 1 END, d.name COLLATE NOCASE
                LIMIT 8
                """,
                attention_ids,
            ).fetchall()

        visible_ups_rows = []
        if access.has("power.view"):
            candidate_ups = conn.execute("SELECT id,name,host,site,group_name,last_status,power_state,battery_charge_percent,runtime_minutes,load_percent,last_checked FROM ups_devices WHERE enabled=1 ORDER BY name").fetchall()
            visible_ups_rows = [row for row in candidate_ups if device_in_scope(access, {"site": row["site"], "group_name": row["group_name"]})]
    candidate_ids = [int(row["id"]) for row in candidate_jobs]
    accessible = _accessible_job_ids(user, candidate_ids)
    visible_jobs = [row for row in candidate_jobs if accessible is None or int(row["id"]) in accessible]
    active_jobs = sum(1 for row in visible_jobs if str(row["status"] or "") in {"queued", "running", "cancelling"})
    recent = visible_jobs[:5]
    return {
        "devices_total": total,
        "devices_online": online,
        "devices_offline": offline,
        "devices_unknown": unknown,
        "stacks_degraded": degraded_stacks,
        "connectivity_percent": _connectivity_percent(total, online),
        "active_jobs": active_jobs,
        "pending_config_devices": len(set(visible_pending)),
        "pending_config_changes": len(visible_pending),
        "recent_jobs": [_row_to_dict(row) for row in recent],
        "switch_attention": [
            {**_public_device(row), "last_status": confirmed_status.get(int(row["id"]), str(row["last_status"] or "unknown"))}
            for row in switch_attention_rows
        ],
        "outage_confirmation_checks": outage_confirmation_checks,
        "ups_total": len(visible_ups_rows),
        "ups_attention_count": sum(1 for row in visible_ups_rows if _public_ups(row).get("severity") in {"warning", "critical"}),
        "ups_attention": [_public_ups(row) for row in visible_ups_rows if _public_ups(row).get("severity") in {"warning", "critical"}][:6],
        "monitoring_policy": monitoring_policy(),
    }


@app.get("/api/pending-config")
def pending_configuration(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "devices.view")
    data = list_pending_configuration()
    access = _access(user)
    visible = [item for item in data.get("devices", []) if device_in_scope(access, {"site": item.get("site", ""), "group_name": item.get("group_name", "")})]
    # Older pending-config payloads do not contain Site/Group. Fall back to the
    # authoritative device id scope in that case.
    allowed_ids = _scoped_device_ids(user)
    visible = [item for item in data.get("devices", []) if int(item.get("device_id") or 0) in allowed_ids]
    return {
        "device_count": len(visible),
        "change_count": sum(int(item.get("change_count") or 0) for item in visible),
        "devices": visible,
    }


@app.get("/api/devices")
def list_devices(user: dict[str, Any] = Depends(current_user)) -> list[dict[str, Any]]:
    _require_capability(user, "devices.view")
    with db() as conn:
        rows = conn.execute(
            """
            SELECT d.*, (SELECT COUNT(*) FROM pending_config_changes p WHERE p.device_id = d.id) AS pending_config_count,
                   u.name AS power_source_ups_name, u.host AS power_source_ups_host,
                   u.last_status AS power_source_ups_status, u.power_state AS power_source_power_state,
                   u.battery_charge_percent AS power_source_battery_charge_percent, u.runtime_minutes AS power_source_runtime_minutes
            FROM devices d
            LEFT JOIN ups_devices u ON u.id = d.power_source_ups_id
            ORDER BY d.site, d.name
            """
        ).fetchall()
    return [_public_device(row) for row in filter_devices(_access(user), rows)]


@app.post("/api/devices", status_code=201)
def create_device(
    payload: DeviceCreate,
    request: Request,
    user: dict[str, Any] = Depends(require_inventory_manager),
) -> dict[str, Any]:
    _require_device_scope(user, {"site": payload.site.strip(), "group_name": payload.group_name.strip()})
    detected = _verify_inventory_device(
        host=payload.host,
        ssh_port=payload.ssh_port,
        profile=payload.profile,
        request=request,
        user=user,
        verification_username=payload.verification_username,
        verification_password=payload.verification_password,
    )
    now = utc_now()
    model = detected.get("model", payload.model.strip())
    aos_version = detected.get("aos_version", payload.aos_version.strip())
    profile = detected.get("profile", payload.profile)
    if (payload.health_probe_mode != "auto" or payload.health_monitor_profile_id) and not _is_platform_admin(user):
        raise HTTPException(status_code=403, detail="Only the platform Administrator can change switch health monitoring")
    if payload.health_monitor_profile_id:
        health_profile = get_monitoring_profile(int(payload.health_monitor_profile_id), decrypt=False)
        if not health_profile or str(health_profile.get("method") or "") != "snmpv3":
            raise HTTPException(status_code=400, detail="Switch health monitoring requires an SNMPv3 Monitoring Credential profile")
    if payload.health_probe_mode == "snmp" and not payload.health_monitor_profile_id:
        if not (payload.stack_monitor_enabled and payload.stack_monitor_method == "snmpv3" and payload.stack_monitor_profile_id):
            raise HTTPException(status_code=400, detail="SNMP health mode requires an SNMPv3 Monitoring Credential profile")
    if payload.stack_monitor_enabled and not _is_platform_admin(user):
        raise HTTPException(status_code=403, detail="Only the platform Administrator can enable stack monitoring")
    if payload.stack_monitor_enabled:
        if not payload.stack_monitor_profile_id:
            raise HTTPException(status_code=400, detail="Stack monitoring requires a Monitoring Credential profile")
        monitor_profile = get_monitoring_profile(int(payload.stack_monitor_profile_id), decrypt=False)
        if not monitor_profile or str(monitor_profile.get("method") or "") != payload.stack_monitor_method:
            raise HTTPException(status_code=400, detail="Selected monitoring profile does not match the stack monitoring method")
    _validate_power_source_assignment(user, payload.power_source_ups_id, site=payload.site, group_name=payload.group_name)
    try:
        with db() as conn:
            cursor = conn.execute(
                """
                INSERT INTO devices(
                    name, host, ssh_port, username, password_enc, credential_profile_id,
                    site, group_name, model, aos_version, profile, enabled, notes,
                    health_probe_mode, health_monitor_profile_id,
                    stack_monitor_enabled, stack_expected_members, stack_monitor_method, stack_monitor_profile_id, power_source_ups_id, created_at, updated_at
                ) VALUES(?, ?, ?, '', '', NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    payload.name.strip(), payload.host, payload.ssh_port,
                    payload.site.strip(), payload.group_name.strip(), model,
                    aos_version, profile, int(payload.enabled),
                    payload.notes.strip(), payload.health_probe_mode, payload.health_monitor_profile_id,
                    int(payload.stack_monitor_enabled), 0, payload.stack_monitor_method, payload.stack_monitor_profile_id, payload.power_source_ups_id, now, now,
                ),
            )
            device_id = int(cursor.lastrowid)
            row = conn.execute(
                """SELECT d.*, u.name AS power_source_ups_name, u.host AS power_source_ups_host,
                          u.last_status AS power_source_ups_status, u.power_state AS power_source_power_state,
                          u.battery_charge_percent AS power_source_battery_charge_percent, u.runtime_minutes AS power_source_runtime_minutes
                   FROM devices d LEFT JOIN ups_devices u ON u.id=d.power_source_ups_id WHERE d.id=?""",
                (device_id,),
            ).fetchone()
    except Exception as exc:
        if "UNIQUE constraint failed" in str(exc):
            raise HTTPException(status_code=409, detail="A switch with this management address already exists") from exc
        raise
    audit(user["username"], "create", "device", str(device_id), {
        "host": payload.host,
        "name": payload.name,
        "auth_type": user.get("auth_type"),
        "verified_with_personal_ssh": user.get("auth_type") == "ssh",
    })
    request_health_scan()
    request_stack_scan()
    return _public_device(row)


@app.put("/api/devices/{device_id}")
def update_device(
    device_id: int,
    payload: DeviceUpdate,
    request: Request,
    user: dict[str, Any] = Depends(require_inventory_manager),
) -> dict[str, Any]:
    fields = payload.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(status_code=400, detail="No fields supplied")
    if any(key in fields for key in ("health_probe_mode", "health_monitor_profile_id")) and not _is_platform_admin(user):
        raise HTTPException(status_code=403, detail="Only the platform Administrator can change switch health monitoring")
    if any(key in fields for key in ("stack_monitor_enabled", "stack_expected_members", "stack_monitor_method", "stack_monitor_profile_id")) and not _is_platform_admin(user):
        raise HTTPException(status_code=403, detail="Only the platform Administrator can change stack monitoring")
    with db() as conn:
        existing = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Switch not found")
    _require_device_scope(user, existing)
    target_site = str(fields.get("site", existing["site"]) or "").strip()
    target_group = str(fields.get("group_name", existing["group_name"]) or "").strip()
    _require_device_scope(user, {"site": target_site, "group_name": target_group})
    if "power_source_ups_id" in fields:
        _require_capability(user, "power.assign", "Your assigned role does not allow power-source assignments")
        _validate_power_source_assignment(user, fields.get("power_source_ups_id"), site=target_site, group_name=target_group)
    elif existing["power_source_ups_id"] and target_site.casefold() != str(existing["site"] or "").strip().casefold():
        with db() as conn:
            assigned_ups = conn.execute("SELECT id,name,site,group_name FROM ups_devices WHERE id=?", (int(existing["power_source_ups_id"]),)).fetchone()
        if assigned_ups and str(assigned_ups["site"] or "").strip() and str(assigned_ups["site"] or "").strip().casefold() != target_site.casefold():
            raise HTTPException(status_code=400, detail="Reassign or clear the switch UPS power source before moving it to another Site")

    verification_username = str(fields.pop("verification_username", "") or "")
    verification_password = str(fields.pop("verification_password", "") or "")
    merged_host = str(fields.get("host", existing["host"]))
    merged_port = int(fields.get("ssh_port", existing["ssh_port"]))
    merged_profile = str(fields.get("profile", existing["profile"]))
    connection_changed = any(key in fields for key in ("host", "ssh_port", "profile"))
    must_verify = user.get("auth_type") == "ssh" or connection_changed or not existing["model"]
    if must_verify:
        detected = _verify_inventory_device(
            host=merged_host,
            ssh_port=merged_port,
            profile=merged_profile,
            request=request,
            user=user,
            verification_username=verification_username,
            verification_password=verification_password,
        )
        fields.update(detected)
    if "enabled" in fields:
        fields["enabled"] = int(bool(fields["enabled"]))
    if "stack_monitor_enabled" in fields:
        fields["stack_monitor_enabled"] = int(bool(fields["stack_monitor_enabled"]))
    effective_health_mode = str(fields.get("health_probe_mode", existing["health_probe_mode"] or "auto")).lower()
    effective_health_profile = int(fields.get("health_monitor_profile_id", existing["health_monitor_profile_id"] or 0) or 0)
    if effective_health_profile:
        health_profile = get_monitoring_profile(effective_health_profile, decrypt=False)
        if not health_profile or str(health_profile.get("method") or "") != "snmpv3":
            raise HTTPException(status_code=400, detail="Switch health monitoring requires an SNMPv3 Monitoring Credential profile")
    if effective_health_mode == "snmp" and not effective_health_profile:
        # A configured SNMPv3 stack profile can be reused automatically.
        stack_method_for_health = str(fields.get("stack_monitor_method", existing["stack_monitor_method"] or "ssh"))
        stack_profile_for_health = int(fields.get("stack_monitor_profile_id", existing["stack_monitor_profile_id"] or 0) or 0)
        if stack_method_for_health != "snmpv3" or not stack_profile_for_health:
            raise HTTPException(status_code=400, detail="SNMP health mode requires an SNMPv3 Monitoring Credential profile")
    effective_stack_enabled = bool(fields.get("stack_monitor_enabled", existing["stack_monitor_enabled"]))
    effective_stack_method = str(fields.get("stack_monitor_method", existing["stack_monitor_method"] or "ssh"))
    effective_stack_profile = int(fields.get("stack_monitor_profile_id", existing["stack_monitor_profile_id"] or 0) or 0)
    if effective_stack_enabled:
        if not effective_stack_profile:
            raise HTTPException(status_code=400, detail="Stack monitoring requires a Monitoring Credential profile")
        monitor_profile = get_monitoring_profile(effective_stack_profile, decrypt=False)
        if not monitor_profile or str(monitor_profile.get("method") or "") != effective_stack_method:
            raise HTTPException(status_code=400, detail="Selected monitoring profile does not match the stack monitoring method")
    stack_config_changed = any(key in fields for key in ("stack_monitor_enabled", "stack_monitor_method", "stack_monitor_profile_id"))
    if stack_config_changed:
        fields.update({"stack_expected_members": 0, "stack_last_status": "unknown", "stack_current_members": 0, "stack_member_ids_json": "[]", "stack_members_json": "[]", "stack_baseline_member_ids_json": "[]", "stack_baseline_members_json": "[]", "stack_baseline_candidate_json": "{}", "stack_baseline_stable_checks": 0, "stack_baseline_learned_at": None, "stack_last_error": "", "stack_consecutive_failures": 0, "stack_consecutive_healthy": 0, "stack_last_checked": None, "stack_status_changed_at": None})
    fields["updated_at"] = utc_now()
    assignments = ", ".join(f"{key} = ?" for key in fields)
    values = list(fields.values()) + [device_id]
    with db() as conn:
        conn.execute(f"UPDATE devices SET {assignments} WHERE id = ?", values)
        row = conn.execute(
            """SELECT d.*, u.name AS power_source_ups_name, u.host AS power_source_ups_host,
                      u.last_status AS power_source_ups_status, u.power_state AS power_source_power_state,
                      u.battery_charge_percent AS power_source_battery_charge_percent, u.runtime_minutes AS power_source_runtime_minutes
               FROM devices d LEFT JOIN ups_devices u ON u.id=d.power_source_ups_id WHERE d.id=?""",
            (device_id,),
        ).fetchone()
    audit(user["username"], "update", "device", str(device_id), {
        "fields": sorted(fields.keys()),
        "auth_type": user.get("auth_type"),
        "verified_with_personal_ssh": user.get("auth_type") == "ssh",
    })
    request_health_scan()
    request_stack_scan()
    return _public_device(row)


@app.delete("/api/devices/{device_id}")
def delete_device(device_id: int, user: dict[str, Any] = Depends(require_inventory_manager)) -> dict[str, bool]:
    with db() as conn:
        row = conn.execute("SELECT name, host, site, group_name FROM devices WHERE id = ?", (device_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Switch not found")
        _require_device_scope(user, row)
        conn.execute("DELETE FROM devices WHERE id = ?", (device_id,))
    audit(user["username"], "delete", "device", str(device_id), {**_row_to_dict(row), "auth_type": user.get("auth_type")})
    return {"ok": True}


@app.post("/api/devices/verify")
def verify_device_with_session(
    payload: DraftConnectionTestRequest,
    request: Request,
    user: dict[str, Any] = Depends(require_inventory_manager),
) -> dict[str, Any]:
    access = _access(user)
    if not access.global_role and access.scope_mode != "all":
        if not payload.device_id:
            raise HTTPException(status_code=403, detail="Scoped inventory managers may verify only an existing switch inside their assigned scope")
        with db() as conn:
            scoped_row = conn.execute("SELECT id, site, group_name FROM devices WHERE id = ?", (int(payload.device_id),)).fetchone()
        if not scoped_row:
            raise HTTPException(status_code=404, detail="Switch not found")
        _require_device_scope(user, scoped_row)
    credentials = _verification_credentials(
        request=request,
        user=user,
        verification_username=payload.verification_username,
        verification_password=payload.verification_password,
    )
    device = {
        "host": payload.host,
        "ssh_port": payload.ssh_port,
        "profile": payload.profile,
        **credentials,
    }
    try:
        command, _ = render_command(payload.profile, "system_info")
    except Exception:
        command = "show system"
    result = run_commands(device, [command])
    identity = parse_show_system(result.output, profile_hint=payload.profile) if result.ok else None
    detected = identity.to_dict() if identity else {}
    audit(user["username"], "connection_verify", "device", str(payload.device_id or "draft"), {
        "host": payload.host, "ok": result.ok, "detected": detected, "credential_source": "personal_session"
    })
    return {"ok": result.ok, "output": result.output, "error": result.error, "detected": detected}


@app.post("/api/devices/test")
def test_connection(
    payload: ConnectionTestRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id = ?", (payload.device_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Switch not found")
    _require_capability(user, "devices.live_ports", "Your assigned role does not allow live switch queries")
    _require_device_scope(user, row)
    device = _device_with_session_credentials(row, request)
    try:
        command, _ = render_command(device["profile"], "system_info")
    except Exception:
        command = "show system"
    started = time.perf_counter()
    result = run_commands(device, [command])
    response_ms = round((time.perf_counter() - started) * 1000)
    identity = parse_show_system(result.output, profile_hint=str(device.get("profile") or "")) if result.ok else None
    detected = identity.to_dict() if identity else {}
    updated = record_health_result(
        payload.device_id, result, response_ms=response_ms, source="manual-ssh",
        actor=user["username"], identity=detected,
    )
    audit(user["username"], "connection_test", "device", str(payload.device_id), {
        "ok": result.ok, "detected": detected, "response_ms": response_ms, "credential_source": "personal_session"
    })
    return {
        "ok": result.ok, "output": result.output, "error": result.error,
        "detected": detected, "device": _public_device(updated) if updated else None,
    }


@app.post("/api/devices/health-scan", status_code=202)
def trigger_health_scan(
    background_tasks: BackgroundTasks,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_capability(user, "devices.live_ports", "Your assigned role does not allow manual health scans")
    if _access(user).scope_mode != "all":
        raise HTTPException(status_code=403, detail="Manual fleet-wide health scans require All Sites scope")
    background_tasks.add_task(scan_all_devices, "manual-bulk")
    audit(user["username"], "health_scan_requested", "device", "bulk", {})
    return {"status": "queued"}


@app.post("/api/devices/{device_id}/stack/relearn")
def relearn_device_stack(device_id: int, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    with db() as conn:
        row = conn.execute("SELECT id,stack_monitor_enabled FROM devices WHERE id=?", (device_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Switch not found")
    if not bool(row["stack_monitor_enabled"]):
        raise HTTPException(status_code=400, detail="Stack monitoring is not enabled for this switch")
    reset_stack_baseline(device_id)
    audit(admin["username"], "stack_baseline_relearn", "device", str(device_id), {})
    return {"ok": True}



@app.get("/api/devices/{device_id}/health-history")
def device_health_history(
    device_id: int,
    limit: int = 100,
    user: dict[str, Any] = Depends(current_user),
) -> list[dict[str, Any]]:
    """Compatibility endpoint. Per-probe health history is intentionally disabled."""
    _require_capability(user, "devices.view")
    with db() as conn:
        exists = conn.execute("SELECT id, site, group_name FROM devices WHERE id = ?", (device_id,)).fetchone()
    if not exists:
        raise HTTPException(status_code=404, detail="Switch not found")
    _require_device_scope(user, exists)
    return []


@app.post("/api/devices/{device_id}/port-inventory")
def refresh_port_inventory(
    device_id: int,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to read live port data")
    _require_capability(user, "devices.live_ports", "Your assigned role does not allow live port data")
    with db() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Switch not found")
    _require_device_scope(user, row)
    if not row["enabled"]:
        raise HTTPException(status_code=400, detail="This switch is disabled for operations")

    device = _device_with_session_credentials(row, request)
    profile = str(row["profile"] or "AOS8").upper()
    # Alias/admin/link presentation differs between AOS generations and some
    # releases. Try the family-preferred operational views silently and retain
    # the first one that both succeeds and parses. A rejected compatibility
    # variant is not surfaced when a documented fallback succeeds.
    alias_candidates = (
        ("show interfaces alias", "show interfaces port", "show interfaces")
        if profile == "AOS8"
        else ("show interfaces port", "show interfaces alias", "show interfaces")
    )
    alias_command = ""
    commands = {
        "interface_status": "show interfaces status",
        "vlan_members": "show vlan members",
    }
    model_for_layout = str(row["model"] or "")
    detected_identity: dict[str, str] = {}
    compact_layout_active = is_compact_os6360_model(model_for_layout)

    def cached_or_error(message: str, status_code: int) -> dict[str, Any]:
        cached = load_inventory_snapshot(device_id)
        audit(user["username"], "port_inventory_refresh_failed", "device", str(device_id), {
            "error": message,
            "cached": bool(cached),
        })
        if cached:
            response = dict(cached)
            cached_ports = response.get("ports") if isinstance(response.get("ports"), list) else []
            family_hint = " ".join(filter(None, [model_for_layout, str(detected_identity.get("description") or "")]))
            cached_compact = is_compact_os6360_model(model_for_layout) or infer_compact_os6360_from_live_ports(family_hint, cached_ports, profile)
            sanitized = _sanitize_compact_os6360_inventory(cached_ports, model_for_layout, profile, force_compact=cached_compact)
            if len(sanitized) != len(cached_ports):
                response["ports"] = sanitized
                response["summary"] = summarize_ports(sanitized)
            public_device = _public_device(row)
            if cached_compact and not public_device.get("port_layout", {}).get("known"):
                public_device["port_layout"] = _compact_os6360_layout()
            response["device"] = public_device
            response["cached"] = True
            response["live"] = False
            response["refresh_error"] = message
            return response
        raise HTTPException(status_code=status_code, detail=message)

    warnings: list[str] = []
    outputs: dict[str, str] = {}
    errors: dict[str, str] = {}
    poe_data: dict[str, dict[str, object]] = {}
    poe_commands_ok = 0
    slots: list[str] = []

    try:
        # Compatibility-first mode: every command needed by one inventory
        # refresh is executed over the same serialized SSH connection.
        with command_session(
            device,
            operation="live port inventory",
        ) as session:
            # Older/imported inventory rows may not yet contain a clean model
            # string. Learn identity once, inside the same serialized SSH
            # session, whenever the hardware layout is unresolved. This keeps
            # the front panel tied to authoritative switch identity instead of
            # guessing from arbitrary interface rows.
            if not infer_device_port_layout(model_for_layout, profile).get("known"):
                identity_outputs: list[str] = []
                identity_commands: list[tuple[str, str]] = [
                    ("system_info", "show system"),
                    ("hardware_info", "show hardware-info" if profile == "AOS8" else "show hardware info"),
                    ("chassis_status", "show chassis"),
                ]
                for action, fallback_command in identity_commands:
                    try:
                        identity_command, _ = render_command(profile, action)
                    except Exception:
                        identity_command = fallback_command
                    identity_result = session.execute(identity_command)
                    if not identity_result.ok or not identity_result.output:
                        continue
                    identity_outputs.append(identity_result.output)
                    identity = parse_show_system(identity_result.output, profile_hint=profile).to_dict()
                    if identity.get("model"):
                        detected_identity = identity
                        model_for_layout = str(identity.get("model") or model_for_layout)
                    if infer_device_port_layout(model_for_layout, profile).get("known"):
                        break

                # A hardware view can expose the exact SKU while show system only
                # exposes the family. Parse the combined evidence as a final pass
                # and prefer the most specific model token selected by the driver.
                if identity_outputs and not infer_device_port_layout(model_for_layout, profile).get("known"):
                    identity = parse_show_system("\n".join(identity_outputs), profile_hint=profile).to_dict()
                    if identity.get("model"):
                        detected_identity = identity
                        model_for_layout = str(identity.get("model") or model_for_layout)

            alias_failures: list[str] = []
            alias_ports = {}
            for candidate in alias_candidates:
                alias_result = session.execute(candidate)
                if not alias_result.ok:
                    alias_failures.append(f"{candidate}: {alias_result.error or 'rejected'}")
                    continue
                candidate_ports = parse_interface_alias(alias_result.output or "", source=candidate)
                if candidate_ports:
                    alias_command = candidate
                    outputs["interface_alias"] = alias_result.output or ""
                    alias_ports = candidate_ports
                    break
                alias_failures.append(f"{candidate}: no parseable interface alias/state rows")

            for key, command in commands.items():
                result = session.execute(command)
                if result.output:
                    outputs[key] = result.output
                if not result.ok:
                    errors[key] = result.error or "The switch rejected the command"

            if not alias_ports and alias_failures:
                warnings.append("Interface state/alias view unavailable: " + " | ".join(alias_failures))

            status_ports = parse_interface_status(outputs.get("interface_status", ""), source="show interfaces status")
            parsed = merge_port_records(alias_ports, status_ports)
            vlan_membership = parse_vlan_members(outputs.get("vlan_members", ""))

            # Some compact OS6360 releases expose only the generic OS6360 family
            # through identity commands. When the live interface table itself is
            # unambiguous (ports 1..12 plus high-numbered pseudo rows), infer the
            # compact 8+4 chassis before PoE slot discovery and before any union
            # can promote pseudo rows such as 108/111/120 to front-panel ports.
            family_hint = " ".join(filter(None, [
                model_for_layout,
                str(detected_identity.get("model") or ""),
                str(detected_identity.get("description") or ""),
            ]))
            live_evidence_ports = set(parsed) | set(vlan_membership)
            compact_layout_active = is_compact_os6360_model(model_for_layout) or infer_compact_os6360_from_live_ports(
                family_hint, live_evidence_ports, profile
            )
            if compact_layout_active:
                parsed = {
                    port: record for port, record in parsed.items()
                    if compact_os6360_port_allowed(port, profile)
                }
                vlan_membership = {
                    port: vlans for port, vlans in vlan_membership.items()
                    if compact_os6360_port_allowed(port, profile)
                }

            slots = infer_slots(parsed.keys(), profile)
            for slot in slots:
                accepted = False
                variant_errors: list[str] = []
                for command in poe_status_commands(profile, slot):
                    poe_result = session.execute(command)
                    if poe_result.ok:
                        parsed_poe = parse_lanpower(poe_result.output, slot, parsed.keys())
                        if parsed_poe:
                            poe_commands_ok += 1
                            poe_data.update(parsed_poe)
                        accepted = True
                        break
                    variant_errors.append(f"{command}: {poe_result.error or 'rejected'}")
                if not accepted and variant_errors:
                    warnings.append(" | ".join(variant_errors))
    except SSHDeviceBusyError as exc:
        return cached_or_error(str(exc), 423)
    except SSHAuthenticationFailure as exc:
        return cached_or_error(str(exc), 502)
    except SSHTimeoutFailure as exc:
        return cached_or_error(str(exc), 504)
    except SSHConnectionFailure as exc:
        return cached_or_error(str(exc), 502)
    except Exception as exc:
        return cached_or_error(f"{type(exc).__name__}: {exc}", 502)

    if detected_identity.get("model"):
        with db() as conn:
            updates = {"model": str(detected_identity.get("model") or "")}
            if detected_identity.get("aos_version"):
                updates["aos_version"] = str(detected_identity.get("aos_version") or "")
            assignments = ", ".join(f"{key} = ?" for key in updates)
            conn.execute(
                f"UPDATE devices SET {assignments} WHERE id = ?",
                list(updates.values()) + [device_id],
            )
            refreshed_row = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
            if refreshed_row:
                row = refreshed_row

    # OS6360-10/P10 have exactly twelve physical data interfaces. Some AOS
    # operational views can expose pseudo/summary identifiers such as 1/1/111
    # and 1/1/120. They are not front-panel ports and must be removed from every
    # evidence source, not only LANPOWER, before the inventory union is built.
    if compact_layout_active or is_compact_os6360_model(model_for_layout):
        parsed = {
            port: record for port, record in parsed.items()
            if compact_os6360_port_allowed(port, profile)
        }
        vlan_membership = {
            port: vlans for port, vlans in vlan_membership.items()
            if compact_os6360_port_allowed(port, profile)
        }
        poe_data = {
            port: values for port, values in poe_data.items()
            if compact_os6360_port_allowed(port, profile)
        }

    for key, message in errors.items():
        warnings.append(f"{commands.get(key, key)}: {message}")

    refreshed_at = utc_now()
    ports = merge_inventory(parsed, vlan_membership, poe_data)
    ports = _sanitize_compact_os6360_inventory(ports, model_for_layout, profile, force_compact=compact_layout_active)
    ports = observe_port_states(device_id, ports, refreshed_at)
    summary = summarize_ports(ports)
    core_state_available = bool(alias_ports)
    status_available = bool(status_ports)
    vlan_available = "vlan_members" not in errors
    capabilities = {
        "admin_state": core_state_available or status_available,
        "physical_link": core_state_available,
        "alias": core_state_available,
        "media": status_available,
        "vlans": vlan_available,
        "poe": poe_commands_ok > 0,
        "observed_link_time": True,
    }
    partial = not ports or not core_state_available
    public_device = _public_device(row)
    if compact_layout_active and not public_device.get("port_layout", {}).get("known"):
        public_device["port_layout"] = _compact_os6360_layout()
    response = {
        "device": public_device,
        "ports": ports,
        "summary": summary,
        "capabilities": capabilities,
        "partial": partial,
        "warnings": warnings[:12],
        "errors": warnings[:12],
        "sources": {
            "state_alias": alias_command,
            "media": "show interfaces status",
            "vlans": "show vlan members",
            "poe_slots": slots,
        },
        "refreshed_at": refreshed_at,
        "cached": False,
        "live": True,
        "refresh_error": "",
    }
    save_inventory_snapshot(device_id, response, refreshed_at)
    audit(user["username"], "port_inventory_refresh", "device", str(device_id), {
        "ports": len(ports),
        "warnings": len(warnings),
        "capabilities": capabilities,
        "complete_ports": summary.get("complete", 0),
        "single_ssh_session": True,
    })
    return response


@app.post("/api/devices/{device_id}/port-diagnostics")
def diagnose_port(
    device_id: int,
    payload: PortDiagnosticRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Run an on-demand, read-only diagnostic pass for one physical port.

    The collection is deliberately scoped to one switch and one operator request.
    Commands share a single serialized SSH session so diagnostics cannot race
    configuration Jobs or an interactive terminal on the same device.
    """
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to diagnose a live port")
    _require_capability(user, "devices.live_ports", "Your assigned role does not allow Port Troubleshooter")
    try:
        port = validate_port(payload.port)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    with db() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Switch not found")
    _require_device_scope(user, row)
    if not row["enabled"]:
        raise HTTPException(status_code=400, detail="This switch is disabled for operations")

    device = _device_with_session_credentials(row, request)
    profile = str(row["profile"] or "AOS8").upper()
    poe_slot = slot_from_port(profile, port)
    mac_command, _ = render_command(profile, "mac_table")
    commands = {
        "interface_detail": f"show interfaces {port}",
        "interface_status": f"show interfaces {port} status",
        "counters": f"show interfaces {port} counters",
        "mac": mac_command,
        "lldp": "show lldp remote-system",
    }
    if profile == "AOS8":
        commands["unp"] = "show unp user"
    outputs: dict[str, str] = {}
    errors: dict[str, str] = {}

    try:
        with command_session(device, operation=f"port troubleshooter {port}", lock_timeout=12.0) as session:
            for key, command in commands.items():
                result = session.execute(command)
                if result.output:
                    outputs[key] = result.output
                if not result.ok:
                    errors[key] = result.error or "The switch rejected the command"
            poe_failures: list[str] = []
            for poe_command in poe_status_commands(profile, poe_slot):
                result = session.execute(poe_command)
                if result.ok:
                    outputs["poe"] = result.output or ""
                    break
                poe_failures.append(f"{poe_command}: {result.error or 'rejected'}")
            if "poe" not in outputs and poe_failures:
                errors["poe"] = " | ".join(poe_failures)

    except SSHDeviceBusyError as exc:
        raise HTTPException(status_code=423, detail=str(exc)) from exc
    except SSHAuthenticationFailure as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except SSHTimeoutFailure as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except SSHConnectionFailure as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc

    result = build_diagnosis(
        device_id=device_id,
        port=port,
        profile=profile,
        outputs=outputs,
        command_errors=errors,
    )
    result["device"] = _public_device(row)
    result["commands"] = [
        {"key": key, "command": command, "ok": key not in errors, "error": errors.get(key, "")}
        for key, command in commands.items()
    ]
    audit(user["username"], "port_diagnose", "device", str(device_id), {
        "port": port,
        "health": result.get("health"),
        "findings": len(result.get("findings") or []),
        "command_errors": list(errors),
        "read_only": True,
    })
    return result


@app.get("/api/fleet-audits/catalog")
def fleet_audit_catalog(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "audits.view")
    return {"audits": public_audit_catalog()}


@app.get("/api/fleet-audits")
def fleet_audit_history(
    limit: int = 50,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_capability(user, "audits.view")
    runs = []
    for summary in list_audit_runs(min(max(int(limit or 50), 1) * 4, 200)):
        result = get_audit_run(int(summary["id"]))
        if result and _audit_result_in_scope(user, result):
            runs.append(summary)
        if len(runs) >= max(1, min(int(limit or 50), 200)):
            break
    return {"runs": runs}


@app.post("/api/fleet-audits", status_code=202)
def start_fleet_audit(
    payload: FleetAuditRequest,
    background_tasks: BackgroundTasks,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to run live fleet audits")
    _require_capability(user, "audits.run", "Your assigned role does not allow Fleet Audit execution")
    ids = [int(value) for value in payload.device_ids]
    _require_target_scope(user, ids)
    credentials = _session_ssh_credentials(request)
    placeholders = ",".join("?" for _ in ids)
    with db() as conn:
        rows = conn.execute(
            f"SELECT * FROM devices WHERE enabled=1 AND id IN ({placeholders}) ORDER BY id",
            ids,
        ).fetchall()
    devices = [_row_to_dict(row) for row in rows]
    if not devices:
        raise HTTPException(status_code=400, detail="No enabled switches match the selected audit scope")
    if len(devices) != len(set(ids)):
        missing = sorted(set(ids) - {int(device["id"]) for device in devices})
        raise HTTPException(status_code=400, detail=f"Some selected switches are unavailable or disabled: {missing[:12]}")
    run_id = create_audit_run(payload.audit_type, devices, user["username"])
    background_tasks.add_task(run_fleet_audit, run_id, payload.audit_type, devices, credentials)
    audit(user["username"], "fleet_audit_started", "fleet_audit", str(run_id), {
        "audit_type": payload.audit_type,
        "target_count": len(devices),
        "read_only": True,
    })
    result = get_audit_run(run_id)
    return result or {"id": run_id, "status": "queued", "target_count": len(devices)}


@app.get("/api/fleet-audits/{run_id}")
def fleet_audit_result(
    run_id: int,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_capability(user, "audits.view")
    result = get_audit_run(run_id)
    if not result:
        raise HTTPException(status_code=404, detail="Fleet audit not found")
    _require_audit_scope(user, result)
    return result


@app.get("/api/fleet-audits/{run_id}/pdf")
def fleet_audit_pdf(
    run_id: int,
    lang: str = "en",
    user: dict[str, Any] = Depends(current_user),
) -> StreamingResponse:
    _require_capability(user, "audits.view")
    result = get_audit_run(run_id)
    if not result:
        raise HTTPException(status_code=404, detail="Fleet audit not found")
    _require_audit_scope(user, result)
    if int(result.get("completed_count") or 0) <= 0:
        raise HTTPException(status_code=409, detail="The audit has not produced any results yet")
    pdf = build_fleet_audit_pdf(result, language=lang)
    filename = safe_audit_filename(result)
    audit(user["username"], "fleet_audit_exported", "fleet_audit", str(run_id), {
        "audit_type": result.get("audit_type"),
        "language": lang,
    })
    return StreamingResponse(
        io.BytesIO(pdf),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/api/device-finder/search", status_code=202)
def start_device_finder_search(
    payload: DeviceFinderRequest,
    background_tasks: BackgroundTasks,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    if user.get("auth_type") != "ssh":
        raise HTTPException(status_code=403, detail="Sign in with a personal SSH account to search live switch tables")
    _require_capability(user, "finder.use", "Your assigned role does not allow Find Device")
    credentials = _session_ssh_credentials(request)
    if payload.device_ids:
        _require_target_scope(user, [int(value) for value in payload.device_ids])
    allowed_ids = _scoped_device_ids(user, enabled_only=True)
    with db() as conn:
        if payload.device_ids:
            placeholders = ",".join("?" for _ in payload.device_ids)
            rows = conn.execute(
                f"SELECT * FROM devices WHERE enabled = 1 AND id IN ({placeholders}) ORDER BY id",
                [int(device_id) for device_id in payload.device_ids],
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM devices WHERE enabled = 1 ORDER BY id").fetchall()
    rows = [row for row in rows if int(row["id"]) in allowed_ids]
    devices = [_row_to_dict(row) for row in rows]
    if not devices:
        raise HTTPException(status_code=400, detail="No enabled switches match the selected search scope")
    search_type = detect_search_type(payload.query, payload.search_type)
    search_id = device_search_registry.create(user["username"], payload.query, search_type, len(devices))
    background_tasks.add_task(
        execute_device_search,
        search_id,
        devices,
        credentials,
        payload.query,
        payload.search_type,
    )
    audit(user["username"], "device_search_started", "device_finder", search_id, {
        "search_type": search_type,
        "target_count": len(devices),
    })
    result = device_search_registry.get(search_id, user["username"])
    return result or {"search_id": search_id, "status": "queued", "total": len(devices), "scanned": 0, "found": 0}


@app.get("/api/device-finder/search/{search_id}")
def get_device_finder_search(
    search_id: str,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    result = device_search_registry.get(search_id, user["username"])
    if not result:
        raise HTTPException(status_code=404, detail="Device search was not found or has expired")
    return result


@app.websocket("/ws/devices/{device_id}/terminal")
async def device_terminal(websocket: WebSocket, device_id: int) -> None:
    """Raw, persistent per-user SSH terminal for one enabled switch.

    Browser keystrokes are relayed directly to the OmniSwitch interactive
    shell. This preserves native AOS line editing, command history and Tab
    completion instead of emulating completion from a static command list.
    """
    if not _websocket_origin_allowed(websocket):
        logger.warning("Rejected terminal WebSocket with invalid Origin for device %s", device_id)
        await websocket.close(code=4403)
        return
    await websocket.accept()
    connection = None
    reader_task: asyncio.Task[Any] | None = None
    terminal_lease = None
    username = "unknown"
    device_name = str(device_id)
    token = str(websocket.session.get("ssh_token") or "")
    send_lock = asyncio.Lock()

    async def send_json(payload: dict[str, Any]) -> None:
        async with send_lock:
            await websocket.send_json(payload)

    async def pump_output() -> None:
        try:
            while True:
                data = await asyncio.to_thread(read_interactive_data, connection)
                if data:
                    await send_json({"type": "data", "data": data})
                await asyncio.sleep(0.035 if data else 0.075)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Interactive terminal output reader failed for device %s", device_id)
            try:
                await send_json({"type": "error", "message": "Terminal output was interrupted unexpectedly. Check the Portivo server log for details."})
            except Exception:
                pass

    try:
        if str(websocket.session.get("auth_type") or "") != "ssh":
            await send_json({"type": "error", "message": "Sign in with a personal SSH account to use the terminal."})
            await websocket.close(code=4403)
            return

        credentials = session_credentials.get_device_credentials(token)
        if not credentials:
            await send_json({"type": "error", "message": "Your SSH session has expired. Sign in again."})
            await websocket.close(code=4401)
            return
        username = credentials["username"]
        ssh_profile = get_ssh_user_profile(username)
        if not ssh_profile or not bool(ssh_profile.get("enabled")):
            await send_json({"type": "error", "message": "Your application access is disabled."})
            await websocket.close(code=4403)
            return
        terminal_access = access_context_for_profile(ssh_profile)
        if not terminal_access.has("terminal.use"):
            await send_json({"type": "error", "message": "Your assigned role does not allow the interactive terminal."})
            await websocket.close(code=4403)
            return

        with db() as conn:
            row = conn.execute(
                "SELECT id, name, host, ssh_port, profile, enabled, site, group_name FROM devices WHERE id = ?",
                (device_id,),
            ).fetchone()
        if not row:
            await send_json({"type": "error", "message": "Switch not found."})
            await websocket.close(code=4404)
            return
        if not bool(row["enabled"]):
            await send_json({"type": "error", "message": "This switch is disabled for operations."})
            await websocket.close(code=4403)
            return
        if not device_in_scope(terminal_access, row):
            await send_json({"type": "error", "message": "This switch is outside your assigned Site/Group scope."})
            await websocket.close(code=4403)
            return

        device = _row_to_dict(row)
        device.update(credentials)
        device_name = str(device["name"] or device_id)
        terminal_lease = await asyncio.to_thread(ssh_coordinator.acquire_terminal, device_id, 0.35)
        await send_json({"type": "status", "state": "connecting", "message": f"Connecting to {device_name}..."})
        connection, prompt = await asyncio.wait_for(
            asyncio.to_thread(open_interactive_connection, device),
            timeout=max(10, settings.ssh_connect_timeout + 5),
        )
        await asyncio.to_thread(resize_interactive_terminal, connection, 160, 40)
        audit(username, "terminal_connected", "device", str(device_id), {"device": device_name, "host": device["host"]})
        await send_json({
            "type": "ready",
            "prompt": prompt,
            "device": device_name,
            "message": f"Interactive SSH session established with {device_name}.",
        })
        reader_task = asyncio.create_task(pump_output())

        while True:
            try:
                payload = await asyncio.wait_for(websocket.receive_json(), timeout=settings.ssh_terminal_idle_minutes * 60)
            except asyncio.TimeoutError:
                await send_json({"type": "error", "message": f"Terminal closed after {settings.ssh_terminal_idle_minutes} minutes of inactivity."})
                await websocket.close(code=4408)
                break

            payload_type = str(payload.get("type") or "")
            if payload_type == "disconnect":
                await websocket.close(code=1000)
                break
            if payload_type == "resize":
                await asyncio.to_thread(
                    resize_interactive_terminal,
                    connection,
                    int(payload.get("columns") or 160),
                    int(payload.get("rows") or 40),
                )
                continue
            if payload_type != "input":
                continue

            if not session_credentials.get_device_credentials(token):
                await send_json({"type": "error", "message": "Your SSH session has expired. Sign in again."})
                await websocket.close(code=4401)
                break

            data = str(payload.get("data") or "").replace("\x00", "")
            if len(data.encode("utf-8", errors="ignore")) > 16_384:
                await send_json({"type": "error", "message": "Terminal input is too large."})
                continue
            await asyncio.to_thread(write_interactive_data, connection, data)
    except WebSocketDisconnect:
        pass
    except SSHDeviceBusyError as exc:
        try:
            await send_json({"type": "error", "message": str(exc)})
            await websocket.close(code=4423)
        except Exception:
            pass
    except Exception:
        logger.exception("Interactive terminal failed for device %s", device_id)
        try:
            await send_json({"type": "error", "message": "The terminal session failed unexpectedly. Check the Portivo server log for details."})
            await websocket.close(code=1011)
        except Exception:
            pass
    finally:
        if reader_task is not None:
            reader_task.cancel()
            try:
                await reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if connection is not None:
            await asyncio.to_thread(close_interactive_connection, connection)
            try:
                audit(username, "terminal_disconnected", "device", str(device_id), {"device": device_name})
            except Exception:
                pass
        if terminal_lease is not None:
            await asyncio.to_thread(terminal_lease.release)


@app.get("/api/profiles")
def profiles(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "command_library.view")
    access = _access(user)
    source = public_profiles()
    allowed = set(action_catalog_for_access(access).keys())
    filtered: dict[str, Any] = {}
    for profile_name, profile in source.items():
        item = dict(profile)
        item["commands"] = {key: value for key, value in (profile.get("commands") or {}).items() if key in allowed}
        item["orchestrated_actions"] = [key for key in (profile.get("orchestrated_actions") or []) if key in allowed]
        item["compatibility"] = {key: value for key, value in (profile.get("compatibility") or {}).items() if key in allowed}
        filtered[profile_name] = item
    return filtered


@app.get("/api/platform/drivers")
def platform_drivers(user: dict[str, Any] = Depends(current_user)) -> list[dict[str, Any]]:
    """Registered OS drivers and normalized capabilities. No credentials are exposed."""
    _require_capability(user, "drivers.view")
    return public_driver_catalog()


@app.get("/api/platform/drivers/power")
def platform_power_drivers(user: dict[str, Any] = Depends(current_user)) -> list[dict[str, Any]]:
    """Built-in UPS driver reference. No UPS inventory or credentials are exposed."""
    _require_capability(user, "drivers.view")
    return power_driver_catalog()


@app.get("/api/catalog")
def action_catalog(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not (_access(user).has("operations.view") or _access(user).has("command_library.view")):
        raise HTTPException(status_code=403, detail="Your assigned role does not allow command access")
    return action_catalog_for_access(_access(user))


def _preview_fix_unp_target(row: Any, credentials: dict[str, str], delay_seconds: int) -> dict[str, Any]:
    device = _row_to_dict(row)
    device.update(credentials)
    result = run_commands(device, ["show unp user"])
    if not result.ok:
        return {
            "device_id": row["id"],
            "device": row["name"],
            "error": result.error or "show unp user failed",
        }
    conflicts = detect_conflicts(result.output)
    limit = max_ports_per_switch()
    if len(conflicts) > limit:
        return {
            "device_id": row["id"],
            "device": row["name"],
            "error": f"Safety limit exceeded: {len(conflicts)} affected ports were detected, while the configured limit is {limit}.",
        }
    summary = format_detection_summary(conflicts, protected=protected_ports())
    if conflicts:
        commands, verification = build_restart_commands(row["profile"], conflicts, delay_seconds)
        command = (
            f"{summary}\n\nPLANNED RESTARTS:\n"
            + "\n".join(commands)
            + "\n\nPERSISTENCE: Not required for transient interface restarts"
        )
    else:
        command = summary
        verification = "show unp user"
    return {
        "device_id": row["id"],
        "device": row["name"],
        "host": row["host"],
        "profile": row["profile"],
        "command": command,
        "verification": verification,
        "detected_ports": [item.port for item in conflicts],
    }


def _preview_vlan_maintenance_target(
    row: Any,
    credentials: dict[str, str],
    target_vlan: int,
    operation: str,
    delay_seconds: int,
) -> dict[str, Any]:
    device = _row_to_dict(row)
    device.update(credentials)
    try:
        with command_session(device, operation="VLAN maintenance preview") as session:
            assessment = inspect_vlan_maintenance_session(
                session, device, target_vlan=target_vlan, operation=operation
            )
    except Exception as exc:
        return {"device_id": row["id"], "device": row["name"], "error": str(exc)}
    return {
        "device_id": row["id"],
        "device": row["name"],
        "host": row["host"],
        "profile": row["profile"],
        "command": format_vlan_maintenance_assessment(assessment, cycle_delay_seconds=delay_seconds),
        "verification": "Safety evidence is re-read immediately before a live operation",
        "support_state": "orchestrated",
        "support_note": "Fail-closed VLAN access-port workflow with mandatory uplink safeguards",
        "matching_ports": assessment.get("matching_count", 0),
        "eligible_ports": assessment.get("eligible_ports", []),
        "protected_ports": assessment.get("protected_ports", []),
    }


@app.post("/api/preview")
def preview(
    payload: PreviewRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_target_scope(user, [target.device_id for target in payload.targets])
    runbook_snapshot: dict[str, Any] | None = None
    if payload.action == "custom_runbook":
        _runbook, runbook_snapshot = _load_runbook_for_execution(user, payload.runbook_id, payload.runbook_variables)
        if len(payload.targets) > int(runbook_snapshot.get("max_targets") or 1):
            raise HTTPException(status_code=400, detail=f"Runbook target limit exceeded: {len(payload.targets)} > {int(runbook_snapshot.get('max_targets') or 1)}")
    else:
        _require_action_permission(user, payload.action)
    items: list[dict[str, Any]] = []

    if payload.action == "custom_runbook":
        plan = format_runbook_plan(runbook_snapshot or {})
        with db() as conn:
            for target in payload.targets:
                row = conn.execute("SELECT id, name, host, profile FROM devices WHERE id = ? AND enabled = 1", (target.device_id,)).fetchone()
                if not row:
                    items.append({"device_id": target.device_id, "error": "Switch not found or disabled"})
                    continue
                items.append({
                    "device_id": row["id"], "device": row["name"], "host": row["host"], "profile": row["profile"],
                    "command": plan, "verification": "", "support_state": "orchestrated",
                    "support_note": f"Runbook #{int((runbook_snapshot or {}).get('id') or 0)} · {str((runbook_snapshot or {}).get('status') or '').title()} · {str((runbook_snapshot or {}).get('risk') or 'read').upper()} risk",
                })
        return {"items": items, "live_scan": False, "runbook": runbook_snapshot}

    if payload.action == "check_unp":
        with db() as conn:
            for target in payload.targets:
                row = conn.execute(
                    "SELECT * FROM devices WHERE id = ? AND enabled = 1",
                    (target.device_id,),
                ).fetchone()
                if not row:
                    items.append({"device_id": target.device_id, "error": "Switch not found or disabled"})
                    continue
                if str(row["profile"] or "").upper() != "AOS8":
                    items.append({
                        "device_id": row["id"], "device": row["name"],
                        "error": "UNP workflows are supported only on the AOS8 ALE profile",
                    })
                    continue
                items.append({
                    "device_id": row["id"],
                    "device": row["name"],
                    "host": row["host"],
                    "profile": row["profile"],
                    "command": "show unp user\n\nANALYZE: detect GUEST with VOIP or IPTV on the same non-protected port",
                    "verification": "",
                    "support_state": "orchestrated",
                    "support_note": "AOS8-only UNP workflow",
                })
        return {"items": items, "live_scan": False}

    if payload.action == "fix_unp":
        credentials = _session_ssh_credentials(request)
        rows: list[Any] = []
        with db() as conn:
            for target in payload.targets:
                row = conn.execute(
                    "SELECT id, name, host, ssh_port, profile FROM devices WHERE id = ? AND enabled = 1",
                    (target.device_id,),
                ).fetchone()
                if not row:
                    items.append({"device_id": target.device_id, "error": "Switch not found or disabled"})
                else:
                    rows.append(row)
        workers = min(6, max(1, len(rows)))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(_preview_fix_unp_target, row, credentials, payload.cycle_delay_seconds): row
                for row in rows
            }
            for future in as_completed(future_map):
                row = future_map[future]
                try:
                    items.append(future.result())
                except Exception as exc:
                    items.append({"device_id": row["id"], "device": row["name"], "error": str(exc)})
        order = {target.device_id: index for index, target in enumerate(payload.targets)}
        items.sort(key=lambda item: order.get(int(item.get("device_id") or 0), 10**9))
        return {"items": items, "live_scan": True}

    if payload.action == "vlan_port_maintenance":
        credentials = _session_ssh_credentials(request)
        rows: list[Any] = []
        with db() as conn:
            for target in payload.targets:
                row = conn.execute(
                    "SELECT id, name, host, ssh_port, profile, model, aos_version FROM devices WHERE id = ? AND enabled = 1",
                    (target.device_id,),
                ).fetchone()
                if not row:
                    items.append({"device_id": target.device_id, "error": "Switch not found or disabled"})
                else:
                    rows.append(row)
        workers = min(6, max(1, len(rows)))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(
                    _preview_vlan_maintenance_target, row, credentials, payload.target_vlan,
                    payload.vlan_maintenance_operation, payload.cycle_delay_seconds
                ): row
                for row in rows
            }
            for future in as_completed(future_map):
                row = future_map[future]
                try:
                    items.append(future.result())
                except Exception as exc:
                    items.append({"device_id": row["id"], "device": row["name"], "error": str(exc)})
        order = {target.device_id: index for index, target in enumerate(payload.targets)}
        items.sort(key=lambda item: order.get(int(item.get("device_id") or 0), 10**9))
        total_eligible = sum(len(item.get("eligible_ports") or []) for item in items if not item.get("error"))
        policy = vlan_maintenance_safeguard_policy()
        total_limit = int(policy["max_total_ports"])
        total_limit_exceeded = total_eligible > total_limit
        if total_limit_exceeded:
            for item in items:
                if not item.get("error"):
                    item["error"] = f"Fleet safety limit exceeded: {total_eligible} eligible ports > {total_limit}. No changes are allowed."
        return {
            "items": items, "live_scan": True, "eligible_total": total_eligible,
            "max_total_ports": total_limit, "safety_limit_exceeded": total_limit_exceeded,
        }

    with db() as conn:
        for target in payload.targets:
            row = conn.execute("SELECT * FROM devices WHERE id = ?", (target.device_id,)).fetchone()
            if not row:
                items.append({"device_id": target.device_id, "error": "Switch not found"})
                continue
            try:
                known_capability = get_action_capability(dict(row), payload.action)
                if known_capability and known_capability.get("state") == "unsupported" and payload.action != "custom_command":
                    raise ValueError(
                        "Not supported by the currently detected switch model/AOS. "
                        "Portivo learned this from an earlier ALE CLI syntax rejection."
                    )
                if payload.action in {"check_unp", "fix_unp"} and str(row["profile"] or "").upper() != "AOS8":
                    raise ValueError("UNP workflows are supported only on the AOS8 ALE profile")
                if payload.action == "poe_status":
                    target_slot = str(target.slot or "").strip()
                    if not target_slot:
                        raise ValueError("A slot is required for PoE slot status")
                    variants = poe_status_commands(row["profile"], target_slot)
                    command = "ALE-aware PoE slot status\n" + "\nOR\n".join(variants)
                    verify = ""
                elif payload.action == "poe_port_status":
                    target_slot = slot_from_port(row["profile"], target.port)
                    variants = poe_status_commands(row["profile"], target_slot)
                    command = "ALE-aware PoE port status\n" + "\nOR\n".join(variants) + f"\nFILTER RESULT: {target.port}"
                    verify = ""
                elif payload.action == "poe_global_status":
                    command = "show interfaces status\nDISCOVER POE SLOTS\nFOR EACH SLOT: ALE family-specific slot-qualified PoE query"
                    verify = ""
                elif payload.action == "custom_command":
                    commands = validate_custom_commands(payload.custom_command)
                    command = "\n".join(commands)
                    verify = ""
                elif payload.action in {"reload_switch", "reload_stack_member"}:
                    command = reload_command(dict(row), payload.action, target.slot)
                    verify = ""
                elif payload.action in {"poe_cycle", "interface_cycle"}:
                    prefix = "poe" if payload.action == "poe_cycle" else "interface"
                    disable, _ = render_command(row["profile"], f"{prefix}_disable", port=target.port, slot=target.slot)
                    enable, _ = render_command(row["profile"], f"{prefix}_enable", port=target.port, slot=target.slot)
                    verify = ""
                    command = f"{disable}\nWAIT {payload.cycle_delay_seconds}s\n{enable}"
                else:
                    command, verify = render_command(
                        row["profile"], payload.action, port=target.port, slot=target.slot,
                        alias=payload.port_alias,
                    )
                if creates_pending_configuration(payload.action):
                    command += "\n\nPERSISTENCE: Pending manual save"
                profile_config = public_profiles().get(str(row["profile"]), {})
                configured_actions = set(profile_config.get("commands", {})) | set(profile_config.get("orchestrated_actions", []))
                support = action_support(str(row["profile"]), payload.action, configured_actions)
                items.append({
                    "device_id": row["id"], "device": row["name"], "host": row["host"],
                    "profile": row["profile"], "command": command, "verification": verify,
                    "support_state": support.state, "support_note": support.note,
                })
            except Exception as exc:
                items.append({"device_id": target.device_id, "device": row["name"], "error": str(exc)})
    return {"items": items}


@app.post("/api/execute", status_code=202)
def execute(
    payload: BulkExecuteRequest,
    background_tasks: BackgroundTasks,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_target_scope(user, [target.device_id for target in payload.targets])
    runbook_snapshot: dict[str, Any] | None = None
    if payload.action == "custom_runbook":
        _runbook, runbook_snapshot = _load_runbook_for_execution(user, payload.runbook_id, payload.runbook_variables)
        if len(payload.targets) > int(runbook_snapshot.get("max_targets") or 1):
            raise HTTPException(status_code=400, detail=f"Runbook target limit exceeded: {len(payload.targets)} > {int(runbook_snapshot.get('max_targets') or 1)}")
        dangerous = str(runbook_snapshot.get("risk") or "change") != "read"
    else:
        _require_action_permission(user, payload.action)
        dangerous = not is_read_only_action(payload.action)
    effective_dry_run = False if payload.action == "check_unp" else bool(payload.dry_run)
    if dangerous and not effective_dry_run and payload.confirmation_text.strip().upper() != "EXECUTE":
        raise HTTPException(status_code=400, detail="Type EXECUTE to confirm this operation")

    credentials = _session_ssh_credentials(request) if (not effective_dry_run or payload.action in {"check_unp", "fix_unp", "vlan_port_maintenance"}) else None
    now = utc_now()
    payload_data = payload.model_dump()
    if runbook_snapshot is not None:
        payload_data["runbook_snapshot"] = runbook_snapshot
    payload_data["dry_run"] = effective_dry_run
    payload_json = json.dumps(payload_data, ensure_ascii=False)
    with db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO jobs(action, status, dry_run, target_count, requested_by, payload_json, created_at)
            VALUES(?, 'queued', ?, ?, ?, ?, ?)
            """,
            (payload.action, int(effective_dry_run), len(payload.targets), user["username"], payload_json, now),
        )
        job_id = int(cursor.lastrowid)
        for target in payload.targets:
            device = conn.execute("SELECT name, host FROM devices WHERE id = ?", (target.device_id,)).fetchone()
            if not device:
                conn.execute(
                    """
                    INSERT INTO job_items(job_id, device_id, device_name, host, port, slot, status, error, finished_at)
                    VALUES(?, ?, '', '', ?, ?, 'failed', 'Switch not found', ?)
                    """,
                    (job_id, target.device_id, target.port, target.slot, now),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO job_items(job_id, device_id, device_name, host, port, slot, status)
                    VALUES(?, ?, ?, ?, ?, ?, 'queued')
                    """,
                    (job_id, target.device_id, device["name"], device["host"], target.port, target.slot),
                )
    audit(user["username"], "execute", "job", str(job_id), {
        "action": payload.action,
        "targets": len(payload.targets),
        "dry_run": effective_dry_run,
        "ports": [target.port for target in payload.targets if target.port][:50],
        "port_alias": payload.port_alias if payload.action == "interface_alias" else "",
    })
    background_tasks.add_task(run_job, job_id, credentials)
    return {"job_id": job_id, "status": "queued"}



def _require_job_management_permission(user: dict[str, Any], job: Any) -> None:
    access = _access(user)
    if access.role_key == "admin":
        return
    if user.get("auth_type") == "ssh" and access.has("activity.jobs") and access.can_action(str(job["action"] or "")):
        return
    raise HTTPException(status_code=403, detail="Your assigned role does not allow lifecycle changes for this Job")


def _job_retry_credentials(job: Any, request: Request) -> dict[str, str] | None:
    try:
        payload = json.loads(str(job["payload_json"] or "{}"))
    except (TypeError, ValueError, json.JSONDecodeError):
        payload = {}
    if bool(payload.get("scheduled")):
        credentials = load_scheduler_credentials()
        if not credentials:
            raise HTTPException(status_code=409, detail="Retry requires a verified Automation SSH credential")
        return credentials
    action = str(job["action"] or "")
    dry_run = bool(job["dry_run"] or 0)
    if not dry_run or action in {"check_unp", "fix_unp", "vlan_port_maintenance"}:
        return _session_ssh_credentials(request)
    return None


def _clone_job_for_retry(conn: sqlite3.Connection, job: Any, actor: str) -> int:
    now = utc_now()
    items = conn.execute(
        "SELECT * FROM job_items WHERE job_id=? AND status <> 'success' ORDER BY id",
        (int(job["id"]),),
    ).fetchall()
    if not items:
        raise HTTPException(status_code=409, detail="This Job has no unfinished or unsuccessful targets to retry")
    cursor = conn.execute(
        """INSERT INTO jobs(action,status,dry_run,target_count,requested_by,payload_json,created_at,retry_of_job_id)
           VALUES(?,'queued',?,?,?,?,?,?)""",
        (str(job["action"]), int(job["dry_run"] or 0), len(items), actor, str(job["payload_json"]), now, int(job["id"])),
    )
    new_id = int(cursor.lastrowid)
    for item in items:
        conn.execute(
            """INSERT INTO job_items(job_id,device_id,device_name,host,port,slot,status)
               VALUES(?,?,?,?,?,?,'queued')""",
            (new_id, int(item["device_id"]), str(item["device_name"]), str(item["host"]), str(item["port"] or ""), str(item["slot"] or "")),
        )
    return new_id

def _history_date_filter(value: str, *, end_of_day: bool = False) -> tuple[str, str]:
    raw = str(value or "").strip()
    if not raw:
        return "", ""
    try:
        if len(raw) == 10:
            parsed = local_date_boundary_utc(raw, end_of_day=end_of_day)
            return ("<", parsed.isoformat()) if end_of_day else (">=", parsed.isoformat())
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return ("<=", parsed.isoformat()) if end_of_day else (">=", parsed.isoformat())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid date filter: {raw}") from exc


def _history_like(value: str) -> str:
    escaped = str(value or "").strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "activity.jobs")
    _require_job_scope(user, job_id)
    now = utc_now()
    with db() as conn:
        job = conn.execute("SELECT * FROM jobs WHERE id=? AND removed_at IS NULL", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        _require_job_management_permission(user, job)
        status = str(job["status"] or "")
        if status in TERMINAL_JOB_STATUSES:
            raise HTTPException(status_code=409, detail=f"Job is already {status}")
        if status == "queued":
            conn.execute("UPDATE job_items SET status='cancelled', error='Cancelled before execution started', finished_at=? WHERE job_id=? AND status='queued'", (now, job_id))
            cancelled = int(conn.execute("SELECT COUNT(*) FROM job_items WHERE job_id=? AND status='cancelled'", (job_id,)).fetchone()[0])
            conn.execute(
                "UPDATE jobs SET status='cancelled', cancel_requested=1, cancel_requested_at=?, cancel_requested_by=?, cancelled_count=?, finished_at=?, heartbeat_at=? WHERE id=?",
                (now, user["username"], cancelled, now, now, job_id),
            )
        else:
            conn.execute(
                "UPDATE jobs SET status='cancelling', cancel_requested=1, cancel_requested_at=?, cancel_requested_by=? WHERE id=?",
                (now, user["username"], job_id),
            )
    audit(user["username"], "cancel_job", "job", str(job_id), {"previous_status": status})
    return {"job_id": job_id, "status": "cancelled" if status == "queued" else "cancelling"}


@app.post("/api/jobs/{job_id}/retry")
def retry_job(job_id: int, request: Request, background_tasks: BackgroundTasks, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "activity.jobs")
    _require_job_scope(user, job_id)
    with db() as conn:
        job = conn.execute("SELECT * FROM jobs WHERE id=? AND removed_at IS NULL", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        _require_job_management_permission(user, job)
        status = str(job["status"] or "")
        if status not in {"failed", "partial", "cancelled", "interrupted"}:
            raise HTTPException(status_code=409, detail="Only Failed, Partial, Cancelled or Interrupted Jobs can be retried")
        if not bool(json.loads(str(job["payload_json"] or "{}" )).get("scheduled")):
            _require_action_permission(user, str(job["action"] or ""))
        credentials = _job_retry_credentials(job, request)
        new_id = _clone_job_for_retry(conn, job, user["username"])
    with db() as conn:
        retry_targets = int(conn.execute("SELECT COUNT(*) FROM job_items WHERE job_id=?", (new_id,)).fetchone()[0])
    audit(user["username"], "retry_job", "job", str(job_id), {"retry_job_id": new_id, "retry_targets": retry_targets})
    background_tasks.add_task(run_job, new_id, credentials)
    return {"job_id": new_id, "status": "queued", "retry_of_job_id": job_id}


@app.delete("/api/jobs/{job_id}")
def remove_job(job_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "activity.jobs")
    _require_job_scope(user, job_id)
    with db() as conn:
        job = conn.execute("SELECT * FROM jobs WHERE id=? AND removed_at IS NULL", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        _require_job_management_permission(user, job)
        status = str(job["status"] or "")
        if status not in TERMINAL_JOB_STATUSES:
            raise HTTPException(status_code=409, detail="Only completed Jobs can be removed from history")
        now = utc_now()
        conn.execute("UPDATE jobs SET removed_at=?, removed_by=? WHERE id=?", (now, user["username"], job_id))
    audit(user["username"], "remove_job_history", "job", str(job_id), {"status": status})
    return {"job_id": job_id, "removed": True}


@app.get("/api/jobs/filter-options")
def job_filter_options(user: dict[str, Any] = Depends(current_user)) -> dict[str, list[str]]:
    _require_capability(user, "activity.jobs")
    with db() as conn:
        scope_clause = _activity_job_scope_clause(conn, user, alias="j")
        actions = conn.execute(
            f"SELECT DISTINCT j.action FROM jobs j WHERE j.removed_at IS NULL AND COALESCE(j.action, '') <> ''{scope_clause} ORDER BY j.action COLLATE NOCASE"
        ).fetchall()
        sources = conn.execute(
            f"SELECT DISTINCT j.requested_by FROM jobs j WHERE j.removed_at IS NULL AND COALESCE(j.requested_by, '') <> ''{scope_clause} ORDER BY j.requested_by COLLATE NOCASE"
        ).fetchall()
        statuses = conn.execute(
            f"SELECT DISTINCT j.status FROM jobs j WHERE j.removed_at IS NULL AND COALESCE(j.status, '') <> ''{scope_clause} ORDER BY j.status COLLATE NOCASE"
        ).fetchall()
    return {
        "actions": [str(row[0]) for row in actions],
        "sources": [str(row[0]) for row in sources],
        "statuses": [str(row[0]) for row in statuses],
    }


@app.get("/api/jobs")
def list_jobs(
    user: dict[str, Any] = Depends(current_user),
    q: str = "",
    status: str = "",
    action: str = "",
    mode: str = "",
    source: str = "",
    date_from: str = "",
    date_to: str = "",
    limit: int = 500,
    page: int = 0,
    page_size: int = 0,
) -> Any:
    _require_capability(user, "activity.jobs")
    safe_limit = max(1, min(int(limit or 500), 1000))
    where: list[str] = ["j.removed_at IS NULL"]
    params: list[Any] = []
    search = str(q or "").strip()
    if search:
        pattern = _history_like(search)
        where.append(
            "("
            "CAST(j.id AS TEXT) LIKE ? ESCAPE '\\' OR "
            "j.action LIKE ? ESCAPE '\\' OR j.status LIKE ? ESCAPE '\\' OR "
            "j.requested_by LIKE ? ESCAPE '\\' OR j.payload_json LIKE ? ESCAPE '\\' OR "
            "EXISTS (SELECT 1 FROM job_items ji WHERE ji.job_id = j.id AND ("
            "ji.device_name LIKE ? ESCAPE '\\' OR ji.host LIKE ? ESCAPE '\\' OR "
            "ji.port LIKE ? ESCAPE '\\' OR ji.command LIKE ? ESCAPE '\\' OR "
            "ji.output LIKE ? ESCAPE '\\' OR ji.verification_output LIKE ? ESCAPE '\\' OR "
            "ji.error LIKE ? ESCAPE '\\'))"
            ")"
        )
        params.extend([pattern] * 12)
    if status:
        where.append("j.status = ?")
        params.append(status.strip())
    if action:
        where.append("j.action = ?")
        params.append(action.strip())
    normalized_mode = str(mode or "").strip().lower()
    if normalized_mode:
        if normalized_mode not in {"live", "simulation"}:
            raise HTTPException(status_code=400, detail="Mode must be live or simulation")
        where.append("j.dry_run = ?")
        params.append(1 if normalized_mode == "simulation" else 0)
    if source:
        where.append("j.requested_by = ?")
        params.append(source.strip())
    from_operator, from_value = _history_date_filter(date_from)
    if from_value:
        where.append(f"j.created_at {from_operator} ?")
        params.append(from_value)
    to_operator, to_value = _history_date_filter(date_to, end_of_day=True)
    if to_value:
        where.append(f"j.created_at {to_operator} ?")
        params.append(to_value)
    clause = f" WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        scope_clause = _activity_job_scope_clause(conn, user, alias="j")
        scoped_clause = f"{clause}{scope_clause}" if clause else (f" WHERE 1=1{scope_clause}" if scope_clause else "")
        if int(page_size or 0) > 0 or int(page or 0) > 0:
            safe_page_size = max(1, min(int(page_size or 25), 100))
            requested_page = max(1, int(page or 1))
            total = int(conn.execute(
                f"SELECT COUNT(*) FROM jobs j{scoped_clause}",
                params,
            ).fetchone()[0])
            pages = max(1, math.ceil(total / safe_page_size))
            safe_page = min(requested_page, pages)
            offset = (safe_page - 1) * safe_page_size
            rows = conn.execute(
                f"SELECT j.* FROM jobs j{scoped_clause} ORDER BY j.id DESC LIMIT ? OFFSET ?",
                [*params, safe_page_size, offset],
            ).fetchall()
            return {
                "items": [_row_to_dict(row) for row in rows],
                "total": total,
                "page": safe_page,
                "page_size": safe_page_size,
                "pages": pages,
            }
        rows = conn.execute(
            f"SELECT j.* FROM jobs j{scoped_clause} ORDER BY j.id DESC LIMIT ?",
            [*params, safe_limit],
        ).fetchall()
    return [_row_to_dict(row) for row in rows]


@app.get("/api/jobs/{job_id}")
def job_detail(job_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    _require_capability(user, "activity.jobs")
    _require_job_scope(user, job_id)
    with db() as conn:
        job = conn.execute("SELECT * FROM jobs WHERE id = ? AND removed_at IS NULL", (job_id,)).fetchone()
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        items = conn.execute("SELECT * FROM job_items WHERE job_id = ? ORDER BY id", (job_id,)).fetchall()
    access = _access(user)
    can_manage = bool(
        access.role_key == "admin"
        or (user.get("auth_type") == "ssh" and access.has("activity.jobs") and access.can_action(str(job["action"] or "")))
    )
    return {
        "job": _row_to_dict(job),
        "items": [_row_to_dict(row) for row in items],
        "lifecycle": {
            "can_manage": can_manage,
            "can_cancel": can_manage and str(job["status"] or "") in {"queued", "running"},
            "can_retry": can_manage and str(job["status"] or "") in {"failed", "partial", "cancelled", "interrupted"},
            "can_remove": can_manage and str(job["status"] or "") in TERMINAL_JOB_STATUSES,
        },
    }


@app.get("/api/jobs/{job_id}/pdf")
def export_job_pdf(
    job_id: int,
    lang: str = "en",
    user: dict[str, Any] = Depends(current_user),
) -> StreamingResponse:
    _require_capability(user, "activity.jobs")
    _require_job_scope(user, job_id)
    language = lang if lang in {"en", "el"} else "en"
    with db() as conn:
        job_row = conn.execute("SELECT * FROM jobs WHERE id = ? AND removed_at IS NULL", (job_id,)).fetchone()
        if not job_row:
            raise HTTPException(status_code=404, detail="Job not found")
        item_rows = conn.execute("SELECT * FROM job_items WHERE job_id = ? ORDER BY id", (job_id,)).fetchall()
    job = _row_to_dict(job_row)
    items = [_row_to_dict(row) for row in item_rows]
    pdf_bytes = build_job_pdf(job, items, language=language, static_dir=STATIC_DIR)
    filename = safe_report_filename(job)
    audit(user["username"], "export_job_pdf", "job", str(job_id), {"language": language, "items": len(items)})
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store, max-age=0",
            "X-Content-Type-Options": "nosniff",
        },
    )


def _validate_inventory_cell(value: Any) -> None:
    if value is not None and len(str(value)) > INVENTORY_IMPORT_MAX_CELL_CHARS:
        raise HTTPException(status_code=413, detail="Inventory contains a cell larger than the supported limit")


def _validate_xlsx_archive(content: bytes) -> None:
    try:
        with ZipFile(io.BytesIO(content)) as archive:
            members = archive.infolist()
            if len(members) > INVENTORY_XLSX_MAX_ZIP_ENTRIES:
                raise HTTPException(status_code=413, detail="XLSX archive contains too many entries")
            total_uncompressed = sum(max(0, int(item.file_size)) for item in members)
            if total_uncompressed > INVENTORY_XLSX_MAX_UNCOMPRESSED_BYTES:
                raise HTTPException(status_code=413, detail="XLSX expanded size exceeds the supported limit")
            for item in members:
                compressed = max(1, int(item.compress_size))
                if item.file_size >= 1024 * 1024 and (item.file_size / compressed) > INVENTORY_XLSX_MAX_COMPRESSION_RATIO:
                    raise HTTPException(status_code=413, detail="XLSX compression ratio is not accepted")
    except BadZipFile as exc:
        raise HTTPException(status_code=400, detail="The XLSX file is not a valid Office archive") from exc


def _parse_inventory_upload(filename: str, content: bytes) -> list[dict[str, Any]]:
    suffix = Path(filename).suffix.lower()
    rows: list[dict[str, Any]] = []
    if suffix == ".csv":
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise HTTPException(status_code=400, detail="CSV must be UTF-8 encoded") from exc
        reader = csv.DictReader(io.StringIO(text))
        if len(reader.fieldnames or []) > INVENTORY_IMPORT_MAX_COLUMNS:
            raise HTTPException(status_code=413, detail="Inventory contains too many columns")
        for row in reader:
            if len(rows) >= INVENTORY_IMPORT_MAX_ROWS:
                raise HTTPException(status_code=413, detail="Inventory contains too many rows")
            for value in row.values():
                _validate_inventory_cell(value)
            rows.append(dict(row))
    elif suffix in {".xlsx", ".xlsm"}:
        _validate_xlsx_archive(content)
        workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        try:
            sheet = workbook.active
            iterator = sheet.iter_rows(values_only=True)
            try:
                first_row = next(iterator)
            except StopIteration as exc:
                raise HTTPException(status_code=400, detail="The workbook is empty") from exc
            if len(first_row) > INVENTORY_IMPORT_MAX_COLUMNS:
                raise HTTPException(status_code=413, detail="Inventory contains too many columns")
            headers = [str(value).strip() if value is not None else "" for value in first_row]
            for values in iterator:
                if not any(value is not None and str(value).strip() for value in values):
                    continue
                if len(rows) >= INVENTORY_IMPORT_MAX_ROWS:
                    raise HTTPException(status_code=413, detail="Inventory contains too many rows")
                if len(values) > INVENTORY_IMPORT_MAX_COLUMNS:
                    raise HTTPException(status_code=413, detail="Inventory contains too many columns")
                for value in values:
                    _validate_inventory_cell(value)
                rows.append({headers[index]: values[index] for index in range(min(len(headers), len(values)))})
        finally:
            workbook.close()
    else:
        raise HTTPException(status_code=400, detail="Only CSV and XLSX files are supported")
    return rows


@app.post("/api/devices/import")
async def import_devices(
    request: Request,
    file: UploadFile = File(...),
    user: dict[str, Any] = Depends(require_inventory_manager),
) -> dict[str, Any]:
    chunks: list[bytes] = []
    total = 0
    try:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > INVENTORY_IMPORT_MAX_BYTES:
                raise HTTPException(status_code=413, detail="Inventory upload exceeds the 20 MiB limit")
            chunks.append(chunk)
    finally:
        await file.close()
    content = b"".join(chunks)
    rows = _parse_inventory_upload(file.filename or "inventory.xlsx", content)
    required = {"name", "host"}
    inserted = 0
    updated = 0
    errors: list[dict[str, Any]] = []
    imported_devices: dict[int, dict[str, Any]] = {}

    for index, raw in enumerate(rows, start=2):
        normalized = {str(key).strip().lower(): value for key, value in raw.items() if key}
        missing = [key for key in required if not str(normalized.get(key, "")).strip()]
        if missing:
            errors.append({"row": index, "error": f"Missing: {', '.join(missing)}"})
            continue
        host = str(normalized["host"]).strip()
        now = utc_now()
        try:
            ssh_port = int(float(normalized.get("ssh_port") or 22))
        except (TypeError, ValueError):
            errors.append({"row": index, "error": "ssh_port must be a number"})
            continue
        if not 1 <= ssh_port <= 65535:
            errors.append({"row": index, "error": "ssh_port must be between 1 and 65535"})
            continue
        values = {
            "name": str(normalized["name"]).strip(), "host": host, "ssh_port": ssh_port,
            "site": str(normalized.get("site") or "").strip(),
            "group_name": str(normalized.get("group_name") or normalized.get("group") or "").strip(),
            "model": str(normalized.get("model") or "").strip(),
            "aos_version": str(normalized.get("aos_version") or "").strip(),
            "profile": str(normalized.get("profile") or "AOS8").strip().upper(),
            "enabled": 1 if str(normalized.get("enabled", "true")).strip().lower() not in {"0", "false", "no"} else 0,
            "notes": str(normalized.get("notes") or "").strip(), "updated_at": now,
        }
        if values["profile"] not in {"AOS6", "AOS8"}:
            errors.append({"row": index, "error": "profile must be AOS6 or AOS8"})
            continue
        try:
            _require_device_scope(user, {"site": values["site"], "group_name": values["group_name"]})
        except HTTPException as exc:
            errors.append({"row": index, "error": str(exc.detail)})
            continue
        try:
            with db() as conn:
                existing = conn.execute("SELECT id FROM devices WHERE host = ?", (host,)).fetchone()
                if existing:
                    device_id = int(existing["id"])
                    assignments = ", ".join(f"{key} = ?" for key in values)
                    conn.execute(f"UPDATE devices SET {assignments} WHERE host = ?", list(values.values()) + [host])
                    updated += 1
                else:
                    insert_values = {**values, "username": "", "password_enc": "", "credential_profile_id": None, "created_at": now}
                    keys = list(insert_values.keys())
                    cursor = conn.execute(
                        f"INSERT INTO devices({','.join(keys)}) VALUES({','.join('?' for _ in keys)})",
                        list(insert_values.values()),
                    )
                    device_id = int(cursor.lastrowid)
                    inserted += 1
            imported_devices[device_id] = {
                "id": device_id, "row": index, "host": host, "ssh_port": ssh_port,
                "profile": values["profile"],
            }
        except Exception as exc:
            errors.append({"row": index, "error": str(exc)})

    verification: dict[str, Any] = {
        "attempted": 0, "successful": 0, "failed": 0, "skipped": 0, "errors": [],
    }
    candidates = list(imported_devices.values())
    if candidates and user.get("auth_type") == "ssh":
        credentials = _session_ssh_credentials(request)
        semaphore = asyncio.Semaphore(6)

        async def detect(candidate: dict[str, Any]) -> dict[str, Any]:
            async with semaphore:
                return await asyncio.to_thread(
                    _detect_imported_device_live,
                    candidate,
                    credentials,
                    actor=str(user["username"]),
                )

        results = await asyncio.gather(*(detect(candidate) for candidate in candidates))
        verification["attempted"] = len(results)
        verification["successful"] = sum(1 for result in results if result["ok"])
        verification["failed"] = len(results) - verification["successful"]
        verification["errors"] = [
            {"row": result["row"], "host": result["host"], "error": result["error"]}
            for result in results if not result["ok"]
        ]
    elif candidates:
        verification["skipped"] = len(candidates)

    audit(user["username"], "import", "device", "bulk", {
        "inserted": inserted,
        "updated": updated,
        "errors": len(errors),
        "auth_type": user.get("auth_type"),
        "live_detection": {
            "attempted": verification["attempted"],
            "successful": verification["successful"],
            "failed": verification["failed"],
            "skipped": verification["skipped"],
        },
    })
    request_health_scan()
    return {"inserted": inserted, "updated": updated, "errors": errors, "verification": verification}


@app.get("/api/devices/template")
def device_template(_: dict[str, Any] = Depends(require_inventory_manager)) -> StreamingResponse:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Devices"
    headers = ["name", "host", "ssh_port", "site", "group_name", "model", "aos_version", "profile", "enabled", "notes"]
    sheet.append(headers)
    sheet.append(["Access Switch 01", "192.0.2.10", 22, "Example Site", "Access Layer", "", "", "AOS8", True, "Documentation example only"])
    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=portivo_devices_template.xlsx"},
    )


def _audit_row_visible(user: dict[str, Any], row: Any) -> bool:
    access = _access(user)
    if access.scope_mode == "all" or access.global_role:
        return True
    object_type = str(row["object_type"] or "")
    object_id = str(row["object_id"] or "")
    actor = str(row["actor"] or "")
    if object_type == "device" and object_id.isdigit():
        with db() as conn:
            device = conn.execute("SELECT id, site, group_name FROM devices WHERE id = ?", (int(object_id),)).fetchone()
        return bool(device and device_in_scope(access, device))
    if object_type == "job" and object_id.isdigit():
        allowed = _accessible_job_ids(user, [int(object_id)])
        return allowed is None or int(object_id) in allowed
    if object_type == "fleet_audit" and object_id.isdigit():
        result = get_audit_run(int(object_id))
        return bool(result and _audit_result_in_scope(user, result))
    # Search requests do not have a durable target table. They are created only
    # after scope enforcement, so expose only the current user's own searches.
    if object_type == "device_finder":
        return actor.casefold() == str(user.get("username") or "").casefold()
    return False


@app.get("/api/audit/filter-options")
def audit_filter_options(user: dict[str, Any] = Depends(current_user)) -> dict[str, list[str]]:
    _require_capability(user, "activity.audit")
    with db() as conn:
        scope_clause, scope_params = _activity_audit_scope_clause(conn, user, alias="a")
        actors = conn.execute(
            f"SELECT DISTINCT a.actor FROM audit_log a WHERE COALESCE(a.actor, '') <> ''{scope_clause} ORDER BY a.actor COLLATE NOCASE",
            scope_params,
        ).fetchall()
        events = conn.execute(
            f"SELECT DISTINCT a.event FROM audit_log a WHERE COALESCE(a.event, '') <> ''{scope_clause} ORDER BY a.event COLLATE NOCASE",
            scope_params,
        ).fetchall()
        object_types = conn.execute(
            f"SELECT DISTINCT a.object_type FROM audit_log a WHERE COALESCE(a.object_type, '') <> ''{scope_clause} ORDER BY a.object_type COLLATE NOCASE",
            scope_params,
        ).fetchall()
    return {
        "actors": [str(row[0]) for row in actors],
        "events": [str(row[0]) for row in events],
        "object_types": [str(row[0]) for row in object_types],
    }


@app.get("/api/audit")
def audit_log(
    user: dict[str, Any] = Depends(current_user),
    q: str = "",
    actor: str = "",
    event: str = "",
    object_type: str = "",
    date_from: str = "",
    date_to: str = "",
    limit: int = 750,
    page: int = 0,
    page_size: int = 0,
) -> Any:
    _require_capability(user, "activity.audit")
    safe_limit = max(1, min(int(limit or 750), 1500))
    where: list[str] = []
    params: list[Any] = []
    search = str(q or "").strip()
    if search:
        pattern = _history_like(search)
        where.append(
            "(CAST(id AS TEXT) LIKE ? ESCAPE '\\' OR actor LIKE ? ESCAPE '\\' OR "
            "event LIKE ? ESCAPE '\\' OR object_type LIKE ? ESCAPE '\\' OR "
            "object_id LIKE ? ESCAPE '\\' OR details_json LIKE ? ESCAPE '\\')"
        )
        params.extend([pattern] * 6)
    if actor:
        where.append("actor = ?")
        params.append(actor.strip())
    if event:
        where.append("event = ?")
        params.append(event.strip())
    if object_type:
        where.append("object_type = ?")
        params.append(object_type.strip())
    from_operator, from_value = _history_date_filter(date_from)
    if from_value:
        where.append(f"created_at {from_operator} ?")
        params.append(from_value)
    to_operator, to_value = _history_date_filter(date_to, end_of_day=True)
    if to_value:
        where.append(f"created_at {to_operator} ?")
        params.append(to_value)
    clause = f" WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        scope_clause, scope_params = _activity_audit_scope_clause(conn, user, alias="a")
        scoped_clause = f"{clause}{scope_clause}" if clause else (f" WHERE 1=1{scope_clause}" if scope_clause else "")
        all_params = [*params, *scope_params]
        if int(page_size or 0) > 0 or int(page or 0) > 0:
            safe_page_size = max(1, min(int(page_size or 25), 100))
            requested_page = max(1, int(page or 1))
            total = int(conn.execute(
                f"SELECT COUNT(*) FROM audit_log a{scoped_clause}",
                all_params,
            ).fetchone()[0])
            pages = max(1, math.ceil(total / safe_page_size))
            safe_page = min(requested_page, pages)
            offset = (safe_page - 1) * safe_page_size
            rows = conn.execute(
                f"SELECT a.* FROM audit_log a{scoped_clause} ORDER BY a.id DESC LIMIT ? OFFSET ?",
                [*all_params, safe_page_size, offset],
            ).fetchall()
            return {
                "items": [_row_to_dict(row) for row in rows],
                "total": total,
                "page": safe_page,
                "page_size": safe_page_size,
                "pages": pages,
            }
        rows = conn.execute(
            f"SELECT a.* FROM audit_log a{scoped_clause} ORDER BY a.id DESC LIMIT ?",
            [*all_params, safe_limit],
        ).fetchall()
    return [_row_to_dict(row) for row in rows]




def _source_archive_bytes() -> bytes:
    """Build a secret-free corresponding-source archive for this exact release."""
    include_files = [
        "VERSION", "run.py", "requirements.txt", "requirements.in", "requirements.lock", ".env.example", "README.md",
        "INSTALLATION.md", "CHANGELOG.md", "LICENSE", "LEGAL.md",
        "THIRD_PARTY_NOTICES.md", "TRADEMARKS.md", "SBOM.spdx.json", "CONTRIBUTING.md",
    ]
    include_dirs = ["app", "scripts", "data", "docs", "examples", "deployment", "THIRD_PARTY_LICENSES"]
    excluded_names = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".venv", "venv", "node_modules"}
    excluded_files = {".env"}
    allowed_data_files = {"action_catalog.json", "command_profiles.json", "ale_cli_validation.json"}
    buffer = io.BytesIO()
    prefix = f"Portivo-Control-Center-v{PORTIVO_BUILD_REVISION}-Source"
    with ZipFile(buffer, "w", ZIP_DEFLATED) as archive:
        for rel in include_files:
            path = PACKAGE_ROOT / rel
            if path.is_file():
                archive.write(path, f"{prefix}/{rel}")
        for dirname in include_dirs:
            base = PACKAGE_ROOT / dirname
            if not base.exists():
                continue
            for path in sorted(base.rglob("*")):
                if not path.is_file():
                    continue
                rel = path.relative_to(PACKAGE_ROOT)
                if any(part in excluded_names for part in rel.parts) or path.name in excluded_files:
                    continue
                if rel.parts and rel.parts[0] == "data" and path.name not in allowed_data_files:
                    continue
                if path.suffix.lower() in {".db", ".sqlite", ".sqlite3", ".log", ".bak", ".pem", ".key", ".pfx", ".p12"}:
                    continue
                archive.write(path, f"{prefix}/{rel.as_posix()}")
    buffer.seek(0)
    return buffer.getvalue()


@app.get("/legal/notice", include_in_schema=False)
def legal_notice() -> FileResponse:
    return FileResponse(PACKAGE_ROOT / "LEGAL.md", media_type="text/markdown; charset=utf-8")


@app.get("/legal/license", include_in_schema=False)
def legal_license() -> FileResponse:
    return FileResponse(PACKAGE_ROOT / "LICENSE", media_type="text/plain; charset=utf-8")


@app.get("/legal/third-party-notices", include_in_schema=False)
def legal_third_party_notices() -> FileResponse:
    return FileResponse(PACKAGE_ROOT / "THIRD_PARTY_NOTICES.md", media_type="text/markdown; charset=utf-8")


@app.get("/legal/trademarks", include_in_schema=False)
def legal_trademarks() -> FileResponse:
    return FileResponse(PACKAGE_ROOT / "TRADEMARKS.md", media_type="text/markdown; charset=utf-8")


@app.get("/legal/source", include_in_schema=False)
def legal_source() -> StreamingResponse:
    filename = f"Portivo-Control-Center-v{PORTIVO_BUILD_REVISION}-Source.zip"
    return StreamingResponse(
        io.BytesIO(_source_archive_bytes()),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store, max-age=0",
        },
    )


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    """Serve the app shell with absolute Open Graph URLs for link previews."""
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    app_url = str(request.url_for("index"))
    og_image_url = str(request.url_for("static", path="assets/og-cover.png"))
    html = html.replace("__APP_URL__", app_url).replace("__OG_IMAGE_URL__", og_image_url)
    return HTMLResponse(
        html,
        headers={
            "Cache-Control": "no-cache",
            "X-Content-Type-Options": "nosniff",
        },
    )


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> FileResponse:
    return FileResponse(STATIC_DIR / "assets" / "favicon.ico", media_type="image/x-icon")


@app.get("/apple-touch-icon.png", include_in_schema=False)
def apple_touch_icon() -> FileResponse:
    return FileResponse(STATIC_DIR / "assets" / "apple-touch-icon.png", media_type="image/png")


@app.get("/manifest.webmanifest", include_in_schema=False)
def web_manifest() -> FileResponse:
    return FileResponse(
        STATIC_DIR / "manifest.webmanifest",
        media_type="application/manifest+json",
        headers={"Cache-Control": "public, max-age=3600"},
    )


@app.exception_handler(Exception)
async def unhandled_error(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled application error", exc_info=exc)
    return JSONResponse(status_code=500, content={"detail": "Unexpected server error. Check the application log."})
