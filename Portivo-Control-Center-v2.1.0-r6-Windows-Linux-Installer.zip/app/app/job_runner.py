# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .config import settings
from .db import db, utc_now
from .device_identity import parse_show_system
from .profiles import render_command, validate_custom_commands, creates_pending_configuration
from .runbooks import format_runbook_plan
from .persistent_save import execute_persistent_save, save_preview_for_profile
from .ssh_runner import command_session, run_commands, run_session_commands
from .pending_config import record_pending_change, clear_pending_changes, pending_count_for_device
from .unp_fix import build_restart_commands, detect_conflicts, format_check_result, format_detection_summary, max_ports_per_switch, protected_ports
from .ale_cli import poe_status_command, poe_status_commands, slot_from_port
from .port_inventory import infer_slots, parse_interface_status, parse_lanpower
from .command_capabilities import get_action_capability, record_action_capability, syntax_rejection
from .job_lifecycle import item_job_cancel_requested, mark_runtime_interrupted
from .reload_actions import reload_command
from .vlan_maintenance import (
    cycle_commands as vlan_cycle_commands,
    format_assessment as format_vlan_assessment,
    inspect_vlan_maintenance_session,
    max_total_ports as vlan_max_total_ports,
    stable_signature as vlan_stable_signature,
)


_executor = ThreadPoolExecutor(max_workers=settings.max_parallel_switches)
_job_lock = threading.Lock()


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {key: row[key] for key in row.keys()}


def _load_device(device_id: int, credentials: dict[str, str] | None) -> dict[str, Any] | None:
    with db() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id = ? AND enabled = 1", (device_id,)).fetchone()
    if not row:
        return None
    device = _row_to_dict(row)
    if credentials:
        device.update(credentials)
    return device


def _update_item(item_id: int, **fields: Any) -> None:
    if not fields:
        return
    assignments = ", ".join(f"{key} = ?" for key in fields)
    values = list(fields.values()) + [item_id]
    with db() as conn:
        conn.execute(f"UPDATE job_items SET {assignments} WHERE id = ?", values)


def _run_persistent_save(device: dict[str, Any], *, runner=run_commands):
    return execute_persistent_save(
        device,
        "save_config",
        runner=runner,
        read_timeout=max(300, settings.ssh_command_timeout),
        force=True,
    )



def _append_output_section(output: str, title: str, content: str) -> str:
    parts = [str(output or "").strip(), title.strip(), str(content or "No output").strip()]
    return "\n\n".join(part for part in parts if part)


def _cycle_commands(device: dict[str, Any], action: str, port: str, slot: str) -> tuple[str, str, str]:
    """Render transient restart commands without persistent-save or post-command verification."""
    prefix = "poe" if action == "poe_cycle" else "interface"
    disable_command, _ = render_command(device["profile"], f"{prefix}_disable", port=port, slot=slot)
    enable_command, _ = render_command(device["profile"], f"{prefix}_enable", port=port, slot=slot)
    return disable_command, enable_command, ""


def _execute_check_unp_item(
    item_id: int,
    device: dict[str, Any],
) -> str:
    """Run a read-only UNP conflict assessment for one switch."""

    if not device.get("username") or not device.get("password_enc"):
        _update_item(
            item_id,
            status="failed",
            command="show unp user",
            error="The personal SSH session expired before the UNP check started",
            finished_at=utc_now(),
        )
        return "failed"

    _update_item(
        item_id,
        status="running",
        command="show unp user",
        started_at=utc_now(),
    )
    scan = run_commands(device, ["show unp user"])
    if not scan.ok:
        if syntax_rejection(scan.output):
            record_action_capability(device, "check_unp", "unsupported", scan.output)
            _update_item(
                item_id,
                status="failed",
                output=(
                    "PORTIVO ALE CAPABILITY RESULT\n"
                    "This AOS8 device rejected the UNP query used by the Check UNP workflow.\n"
                    "Portivo recorded the workflow as unsupported for the current device/model/AOS identity."
                ),
                error="Check UNP is not supported by the detected ALE device/AOS capability set",
                finished_at=utc_now(),
            )
            return "failed"
        _update_item(
            item_id,
            status="failed",
            output=scan.output,
            error=scan.error or "show unp user failed",
            finished_at=utc_now(),
        )
        return "failed"

    conflicts = detect_conflicts(scan.output)
    _update_item(
        item_id,
        status="success",
        command="show unp user",
        output=format_check_result(conflicts, scan.output),
        verification_command="",
        verification_output="",
        finished_at=utc_now(),
    )
    with db() as conn:
        conn.execute(
            "UPDATE devices SET last_seen = ?, last_status = 'online', updated_at = ? WHERE id = ?",
            (utc_now(), utc_now(), device["id"]),
        )
    return "success"


def _execute_fix_unp_item(
    item_id: int,
    device: dict[str, Any],
    *,
    dry_run: bool,
    cycle_delay_seconds: int,
) -> str:
    if not device.get("username") or not device.get("password_enc"):
        _update_item(
            item_id,
            status="failed",
            command="show unp user",
            error="The personal SSH session expired before the UNP scan started",
            finished_at=utc_now(),
        )
        return "failed"

    _update_item(
        item_id,
        status="running",
        command="show unp user",
        verification_command="show unp user",
        started_at=utc_now(),
    )

    def evaluate_scan(scan_result):
        if not scan_result.ok:
            if syntax_rejection(scan_result.output):
                record_action_capability(device, "fix_unp", "unsupported", scan_result.output)
                _update_item(
                    item_id,
                    status="failed",
                    output=(
                        "PORTIVO ALE CAPABILITY RESULT\n"
                        "This AOS8 device rejected the UNP query required by the Fix UNP workflow.\n"
                        "No interfaces were changed and Portivo recorded the workflow as unsupported for the current device/model/AOS identity."
                    ),
                    error="Fix UNP is not supported by the detected ALE device/AOS capability set",
                    finished_at=utc_now(),
                )
                return None
            _update_item(
                item_id,
                status="failed",
                output=scan_result.output,
                error=scan_result.error or "show unp user failed",
                finished_at=utc_now(),
            )
            return None
        conflicts_found = detect_conflicts(scan_result.output)
        summary_text = format_detection_summary(conflicts_found, protected=protected_ports())
        if len(conflicts_found) > max_ports_per_switch():
            _update_item(
                item_id,
                status="failed",
                command="show unp user",
                output=f"{summary_text}\n\nRAW SCAN OUTPUT:\n{scan_result.output}".strip(),
                error=(
                    f"Safety limit exceeded: {len(conflicts_found)} affected ports were detected, "
                    f"while the configured limit is {max_ports_per_switch()}. No interfaces were changed."
                ),
                finished_at=utc_now(),
            )
            return None
        return conflicts_found, summary_text

    if dry_run:
        scan = run_commands(
            device,
            ["show unp user"],
            operation=f"job #{item_id}: check UNP",
            lock_timeout=max(settings.ssh_operation_lock_timeout, 180.0),
        )
        assessed = evaluate_scan(scan)
        if assessed is None:
            return "failed"
        conflicts, summary = assessed
        if not conflicts:
            _update_item(
                item_id,
                status="success",
                command="show unp user",
                output=f"{summary}\n\nRAW SCAN OUTPUT:\n{scan.output}".strip(),
                verification_command="show unp user",
                verification_output=scan.output,
                finished_at=utc_now(),
            )
            return "success"
        planned_commands, verification = build_restart_commands(
            device["profile"], conflicts, cycle_delay_seconds
        )
        command_text = (
            "show unp user\n\n"
            + "\n".join(planned_commands)
            + "\n\nPERSISTENCE: Not required for transient interface restarts"
        )
        _update_item(
            item_id,
            status="success",
            command=command_text,
            output=f"DETECT ONLY. No interfaces were changed.\n\n{summary}\n\nRAW SCAN OUTPUT:\n{scan.output}".strip(),
            verification_command=verification,
            verification_output="Not executed in detect-only mode",
            finished_at=utc_now(),
        )
        return "success"

    try:
        with command_session(
            device,
            operation=f"job #{item_id}: fix UNP",
            lock_timeout=max(settings.ssh_operation_lock_timeout, 180.0),
        ) as session:
            def session_runner(_device, commands, **kwargs):
                return run_session_commands(
                    session,
                    commands,
                    pause_between=float(kwargs.get("pause_between", 0.3)),
                    read_timeout=kwargs.get("read_timeout"),
                )

            scan = session_runner(device, ["show unp user"])
            assessed = evaluate_scan(scan)
            if assessed is None:
                return "failed"
            conflicts, summary = assessed
            if not conflicts:
                _update_item(
                    item_id,
                    status="success",
                    command="show unp user",
                    output=f"{summary}\n\nRAW SCAN OUTPUT:\n{scan.output}".strip(),
                    verification_command="show unp user",
                    verification_output=scan.output,
                    finished_at=utc_now(),
                )
                return "success"

            planned_commands, verification = build_restart_commands(
                device["profile"], conflicts, cycle_delay_seconds
            )
            command_text = (
                "show unp user\n\n"
                + "\n".join(planned_commands)
                + "\n\nPERSISTENCE: Not required for transient interface restarts"
            )
            _update_item(item_id, command=command_text, verification_command=verification)

            action_log: list[str] = [summary, "", "RESTART RESULTS:"]
            restart_failures = 0
            for conflict in conflicts:
                try:
                    disable_command, _ = render_command(
                        device["profile"], "interface_disable", port=conflict.port
                    )
                    enable_command, _ = render_command(
                        device["profile"], "interface_enable", port=conflict.port
                    )
                except Exception as exc:
                    restart_failures += 1
                    action_log.append(f"{conflict.port}: command rendering failed: {exc}")
                    continue

                disable_result = session_runner(device, [disable_command])
                action_log.extend([
                    f"{conflict.port}: {disable_command}",
                    disable_result.output or disable_result.error or "No output",
                ])
                if not disable_result.ok:
                    restart_failures += 1
                    action_log.append(
                        f"{conflict.port}: disable failed. Recovery enable will be attempted immediately."
                    )
                    recovery = session_runner(device, [enable_command])
                    action_log.append(recovery.output or recovery.error or "Recovery enable returned no output")
                    continue

                time.sleep(cycle_delay_seconds)
                enable_result = session_runner(device, [enable_command])
                action_log.extend([
                    f"{conflict.port}: WAIT {cycle_delay_seconds}s",
                    f"{conflict.port}: {enable_command}",
                    enable_result.output or enable_result.error or "No output",
                ])
                if not enable_result.ok:
                    restart_failures += 1
                    action_log.append(
                        f"{conflict.port}: enable failed. Manual inspection is required. Configuration was not saved for safety."
                    )
                else:
                    action_log.append(f"{conflict.port}: interface restart completed")

            time.sleep(2)
            verification_result = session_runner(device, ["show unp user"])
            remaining = detect_conflicts(verification_result.output) if verification_result.ok else conflicts

            # Fix UNP is a transient interface restart workflow. It intentionally does not
            # persist configuration or create an unsaved-configuration marker.
            verification_ok = verification_result.ok and not remaining and restart_failures == 0
            errors: list[str] = []
            if not verification_result.ok:
                errors.append("Interfaces were processed, but the final show unp user verification failed")
            elif remaining:
                errors.append(f"UNP conflicts are still visible on: {', '.join(item.port for item in remaining)}")
            if restart_failures:
                errors.append(f"{restart_failures} interface restart(s) reported an error")
            action_log.extend([
                "",
                "FINAL VERIFICATION:",
                verification_result.output or verification_result.error or "No output",
                "",
                "TRANSACTION STATUS:",
                f"Interface changes: {'Applied' if restart_failures == 0 else 'Partial'}",
                f"Verification: {'Confirmed' if verification_result.ok and not remaining else 'Failed'}",
                "Persistent save: Not required (transient restart)",
            ])
            status = "success" if verification_ok else "partial"
            _update_item(
                item_id,
                status=status,
                command=command_text,
                output="\n".join(action_log).strip(),
                verification_command="show unp user",
                verification_output=verification_result.output or verification_result.error,
                error="; ".join(errors),
                finished_at=utc_now(),
            )
    except Exception as exc:
        _update_item(
            item_id,
            status="failed",
            error=str(exc),
            finished_at=utc_now(),
        )
        return "failed"

    with db() as conn:
        conn.execute(
            "UPDATE devices SET last_seen = ?, last_status = 'online', updated_at = ? WHERE id = ?",
            (utc_now(), utc_now(), device["id"]),
        )
    return "success" if verification_ok else "partial"

def _execute_vlan_maintenance_item(
    item_id: int,
    device: dict[str, Any],
    *,
    dry_run: bool,
    cycle_delay_seconds: int,
    target_vlan: int,
    operation: str,
    expected_signature: Any = None,
) -> str:
    if not device.get("username") or not device.get("password_enc"):
        _update_item(
            item_id, status="failed", error="The SSH session expired before VLAN maintenance started",
            finished_at=utc_now(),
        )
        return "failed"

    _update_item(
        item_id, status="running",
        command=f"VLAN {target_vlan} discovery -> {operation}", started_at=utc_now(),
    )
    try:
        with command_session(device, operation="VLAN port maintenance") as session:
            assessment = inspect_vlan_maintenance_session(
                session, device, target_vlan=target_vlan, operation=operation
            )
            signature = vlan_stable_signature(assessment)
            preview_text = format_vlan_assessment(assessment, cycle_delay_seconds=cycle_delay_seconds)
            if expected_signature is not None and signature != expected_signature:
                _update_item(
                    item_id, status="failed", command=preview_text, output=preview_text,
                    error="VLAN port safety classification changed after the fleet preflight. No changes were made on this switch.",
                    finished_at=utc_now(),
                )
                return "failed"
            if dry_run:
                _update_item(
                    item_id, status="success", command=preview_text, output=preview_text,
                    verification_command="Read-only VLAN/uplink safety inspection", finished_at=utc_now(),
                )
                return "success"
            if assessment.get("safety_limit_exceeded"):
                _update_item(
                    item_id, status="failed", command=preview_text, output=preview_text,
                    error="Per-switch VLAN maintenance safety limit exceeded. No changes were made.",
                    finished_at=utc_now(),
                )
                return "failed"
            eligible = list(assessment.get("eligible_ports") or [])
            if not eligible:
                _update_item(
                    item_id, status="success", command=preview_text, output=preview_text,
                    verification_command="No eligible ports", finished_at=utc_now(),
                )
                return "success"

            # A second read-only assessment immediately before the first change
            # prevents stale target membership or uplink state from being used.
            time.sleep(1)
            confirmation = inspect_vlan_maintenance_session(
                session, device, target_vlan=target_vlan, operation=operation
            )
            if vlan_stable_signature(confirmation) != signature:
                _update_item(
                    item_id, status="failed", command=preview_text,
                    output=format_vlan_assessment(confirmation, cycle_delay_seconds=cycle_delay_seconds),
                    error="VLAN port safety classification changed between validation passes. No changes were made.",
                    finished_at=utc_now(),
                )
                return "failed"

            operation_name = "Restart PoE" if operation == "poe_cycle" else "Restart interface"
            log: list[str] = [preview_text, "", "EXECUTION"]
            failures = 0
            for port in eligible:
                disable, enable = vlan_cycle_commands(str(device.get("profile") or ""), operation, port)
                disable_result = session.execute(disable)
                log.append(f"{port}: {disable}")
                log.append(disable_result.output or disable_result.error or "No output")
                if not disable_result.ok:
                    failures += 1
                    log.append(f"{port}: skipped, disable phase failed")
                    continue
                time.sleep(cycle_delay_seconds)
                enable_result = session.execute(enable)
                log.append(f"{port}: {enable}")
                log.append(enable_result.output or enable_result.error or "No output")
                if not enable_result.ok:
                    # One immediate recovery retry is safer than leaving a port
                    # intentionally disabled after a transient CLI failure.
                    time.sleep(1)
                    recovery = session.execute(enable)
                    log.append(f"{port}: recovery retry -> {enable}")
                    log.append(recovery.output or recovery.error or "No output")
                    if not recovery.ok:
                        failures += 1

            status = "success" if failures == 0 else ("partial" if failures < len(eligible) else "failed")
            log.extend([
                "", "TRANSACTION STATUS",
                f"Operation: {operation_name}",
                f"Eligible ports processed: {len(eligible)}",
                f"Port failures: {failures}",
                "Persistent save: Not required (transient restart)",
            ])
            _update_item(
                item_id, status=status, command=preview_text, output="\n".join(log).strip(),
                verification_command="Dual-pass VLAN/uplink safety validation",
                verification_output="Safety evidence stable before execution",
                error=(f"{failures} port restart(s) failed" if failures else ""),
                finished_at=utc_now(),
            )
    except Exception as exc:
        _update_item(item_id, status="failed", error=str(exc), finished_at=utc_now())
        return "failed"

    with db() as conn:
        conn.execute(
            "UPDATE devices SET last_seen = ?, last_status = 'online', updated_at = ? WHERE id = ?",
            (utc_now(), utc_now(), device["id"]),
        )
    return status


def _preflight_vlan_item(
    item_id: int, credentials: dict[str, str] | None, target_vlan: int, operation: str
) -> tuple[int, Any, int, str]:
    with db() as conn:
        item = conn.execute("SELECT device_id FROM job_items WHERE id = ?", (item_id,)).fetchone()
    if not item:
        return item_id, None, 0, "Job item not found"
    device = _load_device(int(item["device_id"]), credentials)
    if not device:
        return item_id, None, 0, "Switch unavailable or disabled"
    if not device.get("username") or not device.get("password_enc"):
        return item_id, None, 0, "Automation/personal SSH credential unavailable"
    try:
        with command_session(device, operation="VLAN maintenance fleet preflight") as session:
            assessment = inspect_vlan_maintenance_session(
                session, device, target_vlan=target_vlan, operation=operation
            )
        return item_id, vlan_stable_signature(assessment), int(assessment.get("eligible_count") or 0), ""
    except Exception as exc:
        return item_id, None, 0, str(exc)


def _execute_runbook_item(
    item_id: int, device: dict[str, Any], *, dry_run: bool, snapshot: dict[str, Any]
) -> str:
    plan = format_runbook_plan(snapshot)
    _update_item(
        item_id,
        status="running",
        command=plan,
        verification_command="Runbook VERIFY steps",
        started_at=utc_now(),
    )
    if dry_run:
        _update_item(
            item_id,
            status="success",
            output="RUNBOOK DRY RUN\nNo SSH commands were executed.\n\n" + plan,
            finished_at=utc_now(),
        )
        return "success"
    if not device.get("username") or not device.get("password_enc"):
        _update_item(
            item_id,
            status="failed",
            error="The SSH session credential is unavailable",
            finished_at=utc_now(),
        )
        return "failed"

    log: list[str] = [
        f"RUNBOOK EXECUTION: {snapshot.get('name') or 'Custom Runbook'}",
        f"Risk: {str(snapshot.get('risk') or 'read').upper()}",
        "",
    ]
    verification_output: list[str] = []
    try:
        with command_session(
            device,
            operation=f"job #{item_id}: custom runbook",
            lock_timeout=max(settings.ssh_operation_lock_timeout, 180.0),
        ) as session:
            for index, step in enumerate(snapshot.get("steps") or [], start=1):
                step_type = str(step.get("type") or "command")
                if step_type == "wait":
                    seconds = int(step.get("seconds") or 1)
                    log.append(f"{index:02d}. WAIT {seconds}s")
                    time.sleep(seconds)
                    continue
                command = str(step.get("command") or "").strip()
                label = "VERIFY" if step_type == "verify" else "COMMAND"
                log.append(f"{index:02d}. {label} {command}")
                result = session.execute(command)
                text = result.output or result.error or "No output"
                log.append(text)
                if step_type == "verify":
                    verification_output.append(f"{command}\n{text}")
                if not result.ok:
                    message = f"Runbook step {index} failed: {command}"
                    _update_item(
                        item_id,
                        status="failed",
                        output="\n".join(log).strip(),
                        verification_output="\n\n".join(verification_output),
                        error=message,
                        finished_at=utc_now(),
                    )
                    return "failed"
                log.append("")
    except Exception as exc:
        _update_item(
            item_id,
            status="failed",
            output="\n".join(log).strip(),
            verification_output="\n\n".join(verification_output),
            error=str(exc),
            finished_at=utc_now(),
        )
        return "failed"

    log.extend([
        "",
        "RUNBOOK STATUS:",
        "All steps completed successfully.",
        "Persistence: Not inferred automatically for custom runbooks.",
    ])
    _update_item(
        item_id,
        status="success",
        output="\n".join(log).strip(),
        verification_output="\n\n".join(verification_output),
        finished_at=utc_now(),
    )
    with db() as conn:
        conn.execute(
            "UPDATE devices SET last_seen=?, last_status='online', updated_at=? WHERE id=?",
            (utc_now(), utc_now(), device["id"]),
        )
    return "success"

def _execute_item(
    item_id: int,
    action: str,
    dry_run: bool,
    cycle_delay_seconds: int,
    custom_command: str = "",
    port_alias: str = "",
    credentials: dict[str, str] | None = None,
    target_vlan: int = 1,
    vlan_maintenance_operation: str = "poe_cycle",
    vlan_preflight_signature: Any = None,
    runbook_snapshot: dict[str, Any] | None = None,
) -> str:
    if item_job_cancel_requested(item_id):
        _update_item(
            item_id, status="cancelled",
            error="Cancelled before this switch execution started",
            finished_at=utc_now(),
        )
        return "cancelled"
    with db() as conn:
        item = conn.execute("SELECT * FROM job_items WHERE id = ?", (item_id,)).fetchone()
    if not item:
        return "failed"
    item_data = _row_to_dict(item)
    device = _load_device(int(item_data["device_id"]), credentials)
    if not device:
        _update_item(
            item_id,
            status="failed",
            error="The switch is unavailable or disabled",
            finished_at=utc_now(),
        )
        return "failed"

    learned_capability = get_action_capability(device, action)
    if learned_capability and learned_capability.get("state") == "unsupported" and action not in {"custom_command", "custom_runbook"}:
        _update_item(
            item_id, status="failed",
            error=(
                f"This action is not supported by the currently detected device/AOS combination. "
                f"Portivo learned this from an ALE CLI syntax rejection during an earlier attempt. "
                f"Detected profile: {device.get('profile') or 'Unknown'}; model: {device.get('model') or 'Unknown'}; "
                f"AOS: {device.get('aos_version') or 'Unknown'}."
            ),
            finished_at=utc_now(),
        )
        return "failed"

    if action in {"check_unp", "fix_unp"} and str(device.get("profile") or "").upper() != "AOS8":
        _update_item(
            item_id, status="failed",
            error="UNP workflows are supported only on the AOS8 ALE profile",
            finished_at=utc_now(),
        )
        return "failed"

    if action == "check_unp":
        return _execute_check_unp_item(item_id, device)

    if action == "fix_unp":
        return _execute_fix_unp_item(
            item_id,
            device,
            dry_run=dry_run,
            cycle_delay_seconds=cycle_delay_seconds,
        )

    if action == "vlan_port_maintenance":
        return _execute_vlan_maintenance_item(
            item_id, device, dry_run=dry_run, cycle_delay_seconds=cycle_delay_seconds,
            target_vlan=target_vlan, operation=vlan_maintenance_operation,
            expected_signature=vlan_preflight_signature,
        )

    if action == "custom_runbook":
        if not isinstance(runbook_snapshot, dict) or not runbook_snapshot.get("steps"):
            _update_item(item_id, status="failed", error="Runbook snapshot is missing from this job", finished_at=utc_now())
            return "failed"
        return _execute_runbook_item(item_id, device, dry_run=dry_run, snapshot=runbook_snapshot)

    try:
        custom_commands: list[str] = []
        cycle = action in {"poe_cycle", "interface_cycle"}
        if action == "poe_status":
            target_slot = str(item_data.get("slot") or "").strip()
            if not target_slot:
                raise ValueError("A slot is required for PoE slot status")
            primary_command = "ALE-aware PoE slot status: " + " OR ".join(poe_status_commands(device["profile"], target_slot))
            verification = ""
        elif action == "poe_port_status":
            target_slot = slot_from_port(device["profile"], item_data["port"])
            primary_command = "ALE-aware PoE port status: " + " OR ".join(poe_status_commands(device["profile"], target_slot))
            verification = ""
            primary_command += f"\nFILTER RESULT: {item_data['port']}"
        elif action == "poe_global_status":
            primary_command = "show interfaces status\nDISCOVER POE SLOTS\nFOR EACH SLOT: show lanpower (ALE family-specific slot syntax)"
            verification = ""
        elif action == "custom_command":
            custom_commands = validate_custom_commands(custom_command)
            primary_command = "\n".join(custom_commands)
            verification = ""
        elif action in {"reload_switch", "reload_stack_member"}:
            if pending_count_for_device(int(device["id"])) > 0:
                raise ValueError("This switch has unsaved Portivo changes. Save All Changes before reloading it.")
            primary_command = reload_command(device, action, str(item_data.get("slot") or ""))
            verification = ""
        elif cycle:
            disable_command, enable_command, verification = _cycle_commands(
                device, action, item_data["port"], item_data["slot"]
            )
            primary_command = f"{disable_command}\nWAIT {cycle_delay_seconds}s\n{enable_command}"
        else:
            primary_command, verification = render_command(
                device["profile"],
                action,
                port=item_data["port"],
                slot=item_data["slot"],
                alias=port_alias,
            )
            if action in {"poe_enable", "poe_disable"}:
                verify_slot = slot_from_port(device["profile"], item_data["port"])
                verification = "ALE-aware PoE verification: " + " OR ".join(poe_status_commands(device["profile"], verify_slot))
            elif action in {"poe_slot_start", "poe_slot_stop"}:
                verification = "ALE-aware PoE verification: " + " OR ".join(poe_status_commands(device["profile"], item_data["slot"]))
        is_save_action = action == "save_config"
        pending_configuration = creates_pending_configuration(action)
        command_plan = (
            f"SAVE CONFIGURATION:\n{save_preview_for_profile(device['profile'])}"
            if is_save_action
            else primary_command
        )
        if pending_configuration:
            command_plan += "\n\nPERSISTENCE: Pending manual save"
    except Exception as exc:
        _update_item(item_id, status="failed", error=str(exc), finished_at=utc_now())
        return "failed"

    _update_item(
        item_id,
        status="running",
        command=command_plan,
        verification_command=verification,
        started_at=utc_now(),
    )

    if dry_run:
        _update_item(item_id, status="success", output="Dry run only", finished_at=utc_now())
        return "success"

    if not device.get("username") or not device.get("password_enc"):
        _update_item(
            item_id,
            status="failed",
            error="The personal SSH session expired before this job started",
            finished_at=utc_now(),
        )
        return "failed"

    verification_output = ""
    verification_ok = True
    save_ok = True
    pending_recorded = False
    errors: list[str] = []
    result_output = ""

    try:
        with command_session(
            device,
            operation=f"job #{item_id}: {action}",
            lock_timeout=max(settings.ssh_operation_lock_timeout, 180.0),
        ) as session:
            def session_runner(_device, commands, **kwargs):
                return run_session_commands(
                    session,
                    commands,
                    pause_between=float(kwargs.get("pause_between", 0.3)),
                    read_timeout=kwargs.get("read_timeout"),
                )

            if action == "poe_status":
                target_slot = str(item_data.get("slot") or "").strip()
                accepted_command = ""
                accepted_result = None
                failures: list[str] = []
                for candidate in poe_status_commands(device["profile"], target_slot):
                    candidate_result = session.execute(candidate)
                    if candidate_result.ok:
                        accepted_command, accepted_result = candidate, candidate_result
                        break
                    failures.append(f"{candidate}: {candidate_result.error or 'rejected'}")
                if accepted_result is None:
                    record_action_capability(device, action, "unsupported", " | ".join(failures))
                    _update_item(
                        item_id, status="failed", command=" / ".join(poe_status_commands(device["profile"], target_slot)),
                        output="PORTIVO ALE CAPABILITY RESULT\nNo documented PoE slot-status variant was accepted by this switch.",
                        error="PoE slot status is not supported by the detected ALE device/AOS command family",
                        finished_at=utc_now(),
                    )
                    return "failed"
                primary_command = accepted_command
                result_output = accepted_result.output
                record_action_capability(device, action, "supported", accepted_command)
            elif action == "poe_port_status":
                target_port = str(item_data.get("port") or "")
                target_slot = slot_from_port(device["profile"], target_port)
                command = ""
                result = None
                rejected_variants: list[str] = []
                for candidate in poe_status_commands(device["profile"], target_slot):
                    candidate_result = session.execute(candidate)
                    if candidate_result.ok:
                        command, result = candidate, candidate_result
                        break
                    rejected_variants.append(f"{candidate}: {candidate_result.error or 'rejected'}")
                if result is None:
                    evidence_text = " | ".join(rejected_variants)
                    record_action_capability(device, action, "unsupported", evidence_text)
                    _update_item(item_id, status="failed", command=" / ".join(poe_status_commands(device["profile"], target_slot)),
                                 output="", error="PoE status is not supported by the detected ALE device/AOS command family", finished_at=utc_now())
                    return "failed"
                parsed = parse_lanpower(result.output, target_slot, [target_port])
                evidence = parsed.get(target_port) or {}
                if not evidence:
                    verification_ok = False
                    errors.append(
                        f"ALE accepted the slot-qualified PoE query, but port {target_port} was not present in the returned PoE table"
                    )
                summary_lines = [
                    f"Target port: {target_port}",
                    f"ALE status command: {command}",
                    f"PoE state: {evidence.get('poe_state', 'not reported')}",
                    f"Power used: {evidence.get('poe_power_mw', 'not reported')} mW",
                    f"Maximum power: {evidence.get('poe_max_mw', 'not reported')} mW",
                    f"Priority: {evidence.get('poe_priority', 'not reported')}",
                    f"Admin: {evidence.get('poe_admin_state', 'not reported')}",
                ]
                result_output = "PORTIVO PORT FILTER\n" + "\n".join(summary_lines) + "\n\nRAW ALE SLOT OUTPUT\n" + result.output
            elif action == "poe_global_status":
                status_result = session.execute("show interfaces status")
                if not status_result.ok:
                    _update_item(item_id, status="failed", command="show interfaces status",
                                 output=status_result.output, error=status_result.error,
                                 finished_at=utc_now())
                    return "failed"
                ports = parse_interface_status(status_result.output, source="show interfaces status")
                slots = infer_slots(ports.keys(), str(device.get("profile") or "AOS8"))
                if not slots:
                    _update_item(item_id, status="failed", command="show interfaces status",
                                 output=status_result.output,
                                 error="Portivo could not determine a valid PoE slot from the switch interface inventory",
                                 finished_at=utc_now())
                    return "failed"
                sections = []
                slot_failures: list[str] = []
                for target_slot in slots:
                    accepted = False
                    variant_failures: list[str] = []
                    for command in poe_status_commands(device["profile"], target_slot):
                        poe_result = session.execute(command)
                        if poe_result.ok:
                            sections.append(f"### {command}\n{poe_result.output}")
                            accepted = True
                            break
                        variant_failures.append(f"{command}: {poe_result.error or 'rejected'}")
                    if not accepted:
                        slot_failures.append(f"{target_slot}: " + " | ".join(variant_failures))
                if not sections:
                    _update_item(item_id, status="failed", output=status_result.output,
                                 error="No slot-qualified ALE PoE status command succeeded",
                                 finished_at=utc_now())
                    return "failed"
                result_output = "\n\n".join(sections)
                if slot_failures:
                    verification_ok = False
                    errors.append("Some PoE slots could not be read: " + "; ".join(slot_failures))
                    result_output = _append_output_section(
                        result_output, "PARTIAL COLLECTION", "\n".join(slot_failures)
                    )
            elif action == "save_config":
                save_command, save_result = _run_persistent_save(device, runner=session_runner)
                save_output = save_result.output or save_result.error or "No output"
                result_output = _append_output_section("", f"SAVE CONFIGURATION: {save_command}", save_output)
                save_ok = bool(save_result.ok)
                if not save_ok:
                    _update_item(
                        item_id, status="failed", output=result_output,
                        error=save_result.error or "Persistent configuration save failed", finished_at=utc_now(),
                    )
                    return "failed"
                set_cooldown = getattr(session, "set_release_cooldown", None)
                if callable(set_cooldown):
                    set_cooldown(settings.ssh_post_save_cooldown_seconds)
                wait_for_prompt = getattr(session, "wait_for_prompt", None)
                if callable(wait_for_prompt):
                    prompt_ready = wait_for_prompt(timeout=settings.ssh_post_save_prompt_timeout)
                    if not prompt_ready.ok and callable(set_cooldown):
                        set_cooldown(settings.ssh_post_save_fallback_cooldown_seconds)
                cleared = clear_pending_changes(int(device["id"]))
                result_output = _append_output_section(
                    result_output, "PENDING CONFIGURATION",
                    f"Persistent save: Confirmed\nPending changes cleared: {cleared}",
                )
            elif action == "custom_command":
                result = session_runner(device, custom_commands)
                if not result.ok:
                    _update_item(
                        item_id,
                        status="failed",
                        output=result.output,
                        error=result.error,
                        finished_at=utc_now(),
                    )
                    return "failed"
                result_output = result.output
            elif action in {"reload_switch", "reload_stack_member"}:
                reload_result = session.execute_confirmed_reload(primary_command)
                if not reload_result.ok:
                    if syntax_rejection(reload_result.output):
                        record_action_capability(device, action, "unsupported", reload_result.output)
                    _update_item(
                        item_id, status="failed", output=reload_result.output,
                        error=reload_result.error or "Reload request was not accepted", finished_at=utc_now(),
                    )
                    return "failed"
                record_action_capability(device, action, "supported", primary_command)
                target_text = (
                    f"Chassis {item_data.get('slot')}" if action == "reload_stack_member"
                    else "Standalone switch"
                )
                result_output = _append_output_section(
                    reload_result.output,
                    "RELOAD REQUEST ACCEPTED",
                    f"Target: {target_text}\nCommand: {primary_command}\nStatus: Confirmation sent. Connectivity may drop while the target reboots.",
                )
                set_cooldown = getattr(session, "set_release_cooldown", None)
                if callable(set_cooldown):
                    set_cooldown(max(settings.ssh_post_save_cooldown_seconds, 8.0))
            elif action in {"poe_cycle", "interface_cycle"}:
                disable_command, enable_command, verification = _cycle_commands(
                    device, action, item_data["port"], item_data["slot"]
                )
                disable_result = session_runner(device, [disable_command])
                if not disable_result.ok:
                    if syntax_rejection(disable_result.output):
                        record_action_capability(device, action, "unsupported", disable_result.output)
                        _update_item(
                            item_id,
                            status="failed",
                            output=(
                                "PORTIVO ALE CAPABILITY RESULT\n"
                                "The detected device rejected the family-specific restart command before any cycle could complete.\n"
                                "Portivo recorded this workflow as unsupported for the current device/model/AOS identity."
                            ),
                            error="Restart workflow is not supported by the detected ALE device/AOS capability set",
                            finished_at=utc_now(),
                        )
                        return "failed"
                    _update_item(
                        item_id,
                        status="failed",
                        output=disable_result.output,
                        error=disable_result.error,
                        finished_at=utc_now(),
                    )
                    return "failed"
                time.sleep(cycle_delay_seconds)
                enable_result = session_runner(device, [enable_command])
                full_output = (
                    f"{disable_result.output}\n\nWAIT {cycle_delay_seconds}s\n\n{enable_result.output}"
                ).strip()
                if not enable_result.ok:
                    if syntax_rejection(enable_result.output):
                        record_action_capability(device, action, "unsupported", enable_result.output)
                        _update_item(
                            item_id,
                            status="failed",
                            output=(
                                "PORTIVO ALE CAPABILITY RESULT\n"
                                "The disable phase completed, but the detected device rejected the family-specific re-enable syntax.\n"
                                "Manual verification of the port is required. Portivo recorded this workflow as unsupported for the current device/model/AOS identity."
                            ),
                            error="Restart workflow re-enable syntax is not supported by the detected ALE device/AOS capability set",
                            finished_at=utc_now(),
                        )
                        return "failed"
                    _update_item(
                        item_id,
                        status="failed",
                        output=full_output,
                        error=enable_result.error,
                        finished_at=utc_now(),
                    )
                    return "failed"
                operation_name = "Restart PoE" if action == "poe_cycle" else "Restart interface"
                result_output = _append_output_section(
                    full_output,
                    "OPERATION STATUS",
                    f"{operation_name}: Completed\nPort: {item_data['port']}\nCycle delay: {cycle_delay_seconds}s",
                )
            else:
                result = session_runner(device, [primary_command])
                if not result.ok:
                    if syntax_rejection(result.output):
                        record_action_capability(device, action, "unsupported", result.output)
                        capability_output = (
                            "PORTIVO ALE CAPABILITY RESULT\n"
                            "The switch rejected this command syntax for its detected model/AOS combination.\n"
                            "Portivo has recorded the action as unsupported for this device identity and will not keep retrying it.\n"
                            f"Profile: {device.get('profile') or 'Unknown'}\n"
                            f"Model: {device.get('model') or 'Unknown'}\n"
                            f"AOS: {device.get('aos_version') or 'Unknown'}"
                        )
                        _update_item(
                            item_id, status="failed", output=capability_output,
                            error="Action not supported by the detected ALE device/AOS command family",
                            finished_at=utc_now(),
                        )
                        return "failed"
                    _update_item(
                        item_id,
                        status="failed",
                        output=result.output,
                        error=result.error,
                        finished_at=utc_now(),
                    )
                    return "failed"
                record_action_capability(device, action, "supported", primary_command)
                result_output = result.output

            if action in {"poe_enable", "poe_disable", "poe_slot_start", "poe_slot_stop"}:
                verify_slot = (
                    slot_from_port(device["profile"], item_data["port"])
                    if action in {"poe_enable", "poe_disable"}
                    else str(item_data.get("slot") or "").strip()
                )
                verification_ok = False
                verification_failures: list[str] = []
                for candidate in poe_status_commands(device["profile"], verify_slot):
                    verify_result = session.execute(candidate)
                    if verify_result.ok:
                        verification_ok = True
                        verification = candidate
                        verification_output = verify_result.output or ""
                        break
                    verification_failures.append(f"{candidate}: {verify_result.error or 'rejected'}")
                if not verification_ok:
                    verification_output = " | ".join(verification_failures)
                    errors.append("Configuration command completed, but no documented PoE status variant could verify the resulting state")
            elif verification:
                verify_result = session_runner(device, [verification])
                verification_output = verify_result.output or verify_result.error
                verification_ok = verify_result.ok
                if not verification_ok and verify_result.error:
                    errors.append(f"Verification command failed: {verify_result.error}")
                if not verification_ok and not errors:
                    errors.append("Command completed, but verification failed")

            if pending_configuration:
                with db() as conn:
                    job_row = conn.execute(
                        "SELECT j.id AS job_id, j.requested_by FROM jobs j JOIN job_items i ON i.job_id = j.id WHERE i.id = ?",
                        (item_id,),
                    ).fetchone()
                record_pending_change(
                    device_id=int(device["id"]),
                    job_id=int(job_row["job_id"]) if job_row else None,
                    job_item_id=item_id,
                    action=action,
                    port=str(item_data.get("port") or ""),
                    slot=str(item_data.get("slot") or ""),
                    command=primary_command,
                    actor=str(job_row["requested_by"] if job_row else ""),
                    verification_status=("confirmed" if verification_ok else "unconfirmed"),
                )
                pending_recorded = True
                result_output = _append_output_section(
                    result_output,
                    "PERSISTENCE STATUS",
                    "Running configuration changed. Persistent save is pending and can be completed from the Unsaved configuration panel.",
                )
    except Exception as exc:
        _update_item(
            item_id,
            status="failed",
            output=result_output,
            error=str(exc),
            finished_at=utc_now(),
        )
        return "failed"

    completed_ok = verification_ok and save_ok
    if action == "save_config":
        result_output = _append_output_section(
            result_output, "TRANSACTION STATUS",
            "Persistent save: Confirmed\nConfiguration state: Saved",
        )
    elif pending_configuration:
        transaction_status = ["Configuration command: Applied"]
        if verification:
            transaction_status.append(f"Verification: {'Confirmed' if verification_ok else 'Failed'}")
        transaction_status.append(f"Persistent save: {'Pending' if pending_recorded else 'Not recorded'}")
        result_output = _append_output_section(result_output, "TRANSACTION STATUS", "\n".join(transaction_status))
    _update_item(
        item_id,
        status="success" if completed_ok else "partial",
        command=command_plan,
        output=result_output,
        verification_command=verification,
        verification_output=verification_output,
        error="; ".join(errors),
        finished_at=utc_now(),
    )

    device_updates: dict[str, Any] = {
        "last_seen": utc_now(),
        "last_status": "online",
        "updated_at": utc_now(),
    }
    if action == "system_info":
        identity = parse_show_system(result_output, profile_hint=str(device.get("profile") or ""))
        if identity.model:
            device_updates["model"] = identity.model
        if identity.aos_version:
            device_updates["aos_version"] = identity.aos_version
        if identity.detected_profile:
            device_updates["profile"] = identity.detected_profile

    assignments = ", ".join(f"{key} = ?" for key in device_updates)
    with db() as conn:
        conn.execute(
            f"UPDATE devices SET {assignments} WHERE id = ?",
            list(device_updates.values()) + [device["id"]],
        )
    if action not in {"custom_command", "custom_runbook", "check_unp", "fix_unp"}:
        record_action_capability(device, action, "supported", primary_command)
    return "success" if completed_ok else "partial"

def _run_job_impl(job_id: int, credentials: dict[str, str] | None = None) -> None:
    with _job_lock:
        with db() as conn:
            job = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            if not job:
                return
            if str(job["status"] or "") in {"completed", "partial", "failed", "cancelled", "interrupted"}:
                return
            if int(job["cancel_requested"] or 0):
                now = utc_now()
                conn.execute("UPDATE job_items SET status='cancelled', error=CASE WHEN COALESCE(error,'')='' THEN 'Cancelled before execution started' ELSE error END, finished_at=COALESCE(finished_at,?) WHERE job_id=? AND status='queued'", (now, job_id))
                conn.execute("UPDATE jobs SET status='cancelled', finished_at=?, heartbeat_at=? WHERE id=?", (now, now, job_id))
                return
            now = utc_now()
            conn.execute("UPDATE jobs SET status = 'running', started_at = COALESCE(started_at, ?), heartbeat_at = ? WHERE id = ?", (now, now, job_id))
            items = conn.execute("SELECT id FROM job_items WHERE job_id = ? ORDER BY id", (job_id,)).fetchall()
        job_data = _row_to_dict(job)
        payload = json.loads(job_data["payload_json"])
        cycle_delay = int(payload.get("cycle_delay_seconds", 5))
        custom_command = str(payload.get("custom_command", ""))
        port_alias = str(payload.get("port_alias", ""))
        target_vlan = int(payload.get("target_vlan") or 1)
        vlan_operation = str(payload.get("vlan_maintenance_operation") or "poe_cycle")
        runbook_snapshot = payload.get("runbook_snapshot") if isinstance(payload.get("runbook_snapshot"), dict) else None

    preflight_signatures: dict[int, Any] = {}
    if job_data["action"] == "vlan_port_maintenance" and not bool(job_data["dry_run"]):
        workers = min(settings.max_parallel_switches, max(1, len(items)))
        total_eligible = 0
        preflight_errors: dict[int, str] = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [
                pool.submit(_preflight_vlan_item, int(item["id"]), credentials, target_vlan, vlan_operation)
                for item in items
            ]
            for future in as_completed(futures):
                item_id, signature, eligible_count, error = future.result()
                if error:
                    preflight_errors[item_id] = error
                elif signature is not None:
                    preflight_signatures[item_id] = signature
                    total_eligible += eligible_count

        fleet_limit = vlan_max_total_ports()
        if total_eligible > fleet_limit:
            message = (
                f"Fleet VLAN maintenance safety limit exceeded: {total_eligible} eligible ports were discovered, "
                f"while the configured maximum is {fleet_limit}. No changes were made."
            )
            for item in items:
                _update_item(int(item["id"]), status="failed", error=message, finished_at=utc_now())
            with db() as conn:
                conn.execute(
                    "UPDATE jobs SET status = 'failed', success_count = 0, failure_count = ?, finished_at = ? WHERE id = ?",
                    (len(items), utc_now(), job_id),
                )
            return
        for item_id, error in preflight_errors.items():
            _update_item(
                item_id, status="failed",
                error=f"VLAN maintenance safety preflight failed: {error}. No changes were made on this switch.",
                finished_at=utc_now(),
            )

    def submit_args(item_id: int) -> tuple[Any, ...]:
        return (
            item_id, job_data["action"], bool(job_data["dry_run"]), cycle_delay, custom_command,
            port_alias, credentials, target_vlan, vlan_operation, preflight_signatures.get(item_id), runbook_snapshot,
        )

    runnable_ids = [
        int(item["id"]) for item in items
        if job_data["action"] != "vlan_port_maintenance"
        or bool(job_data["dry_run"])
        or int(item["id"]) in preflight_signatures
    ]
    results: list[str] = []
    # Interface restarts are deliberately serialized across switches. PoE
    # restarts keep the normal bounded fleet concurrency.
    if job_data["action"] == "vlan_port_maintenance" and vlan_operation == "interface_cycle":
        for item_id in runnable_ids:
            try:
                results.append(_execute_item(*submit_args(item_id)))
            except Exception:
                results.append("failed")
    elif job_data["action"] == "custom_runbook" and isinstance(runbook_snapshot, dict):
        workers = min(max(1, int(runbook_snapshot.get("concurrency") or 1)), max(1, len(runnable_ids)))
        stop_all = str(runbook_snapshot.get("failure_policy") or "continue") == "stop_all"
        pending = list(runnable_ids)
        running: dict[Any, int] = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            while pending and len(running) < workers:
                item_id = pending.pop(0)
                running[pool.submit(_execute_item, *submit_args(item_id))] = item_id
            stop_requested = False
            while running:
                done = next(as_completed(list(running)))
                item_id = running.pop(done)
                try:
                    result = done.result()
                except Exception:
                    result = "failed"
                results.append(result)
                if stop_all and result not in {"success"}:
                    stop_requested = True
                if not stop_requested and pending:
                    next_id = pending.pop(0)
                    running[pool.submit(_execute_item, *submit_args(next_id))] = next_id
            if stop_requested and pending:
                for item_id in pending:
                    _update_item(
                        item_id, status="failed",
                        error="Runbook stopped before this switch because the failure policy is Stop entire run",
                        finished_at=utc_now(),
                    )
    else:
        futures = [_executor.submit(_execute_item, *submit_args(item_id)) for item_id in runnable_ids]
        for future in as_completed(futures):
            try:
                results.append(future.result())
            except Exception:
                results.append("failed")

    # Include preflight failures already written to the job item table instead
    # of double-executing them.
    with db() as conn:
        item_rows = conn.execute("SELECT status FROM job_items WHERE job_id = ?", (job_id,)).fetchall()
    success = sum(1 for row in item_rows if str(row["status"]) == "success")
    partial = sum(1 for row in item_rows if str(row["status"]) == "partial")
    failure = sum(1 for row in item_rows if str(row["status"]) == "failed")
    interrupted = sum(1 for row in item_rows if str(row["status"]) == "interrupted")
    cancelled = sum(1 for row in item_rows if str(row["status"]) == "cancelled")
    completed_count = success + partial
    with db() as conn:
        job_state = conn.execute("SELECT cancel_requested FROM jobs WHERE id=?", (job_id,)).fetchone()
    cancel_requested = bool(job_state and int(job_state["cancel_requested"] or 0))
    if cancel_requested or cancelled:
        final_status = "cancelled"
    elif interrupted:
        final_status = "interrupted"
    elif failure == 0 and partial == 0:
        final_status = "completed"
    elif completed_count == 0:
        final_status = "failed"
    else:
        final_status = "partial"
    with db() as conn:
        now = utc_now()
        conn.execute(
            """
            UPDATE jobs
            SET status = ?, success_count = ?, failure_count = ?, interrupted_count = ?, cancelled_count = ?,
                finished_at = ?, heartbeat_at = ?
            WHERE id = ?
            """,
            (final_status, completed_count, failure, interrupted, cancelled, now, now, job_id),
        )


def _heartbeat_loop(job_id: int, stop_event: threading.Event) -> None:
    while not stop_event.wait(5.0):
        try:
            with db() as conn:
                conn.execute(
                    "UPDATE jobs SET heartbeat_at=? WHERE id=? AND status IN ('running','cancelling')",
                    (utc_now(), int(job_id)),
                )
        except Exception:
            # Heartbeat evidence is defensive. It must never terminate a live job.
            pass


def run_job(job_id: int, credentials: dict[str, str] | None = None) -> None:
    """Run a Job with lifecycle evidence and fail-safe interruption handling."""
    with db() as conn:
        row = conn.execute("SELECT status FROM jobs WHERE id=?", (int(job_id),)).fetchone()
    if not row or str(row["status"] or "") in {"completed", "partial", "failed", "cancelled", "interrupted"}:
        return
    stop_event = threading.Event()
    heartbeat = threading.Thread(target=_heartbeat_loop, args=(int(job_id), stop_event), name=f"job-{job_id}-heartbeat", daemon=True)
    heartbeat.start()
    try:
        _run_job_impl(int(job_id), credentials)
    except Exception as exc:
        mark_runtime_interrupted(int(job_id), f"Job worker stopped unexpectedly: {type(exc).__name__}: {exc}")
    finally:
        stop_event.set()
        heartbeat.join(timeout=1.0)
