# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
from __future__ import annotations

"""Vendor-neutral switch driver foundation.

The current product surface remains OmniSwitch-only. This module separates
platform identity, SSH transport selection and capability metadata from the
Portivo core so additional network operating systems can be added later as
isolated drivers instead of branching vendor logic through the application.
"""

import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class DriverIdentity:
    vendor: str = ""
    os_family: str = ""
    model: str = ""
    os_version: str = ""
    system_name: str = ""
    description: str = ""
    profile: str = ""
    driver_key: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class DriverDescriptor:
    key: str
    vendor: str
    os_family: str
    profile: str
    netmiko_device_type: str
    system_info_action: str = "system_info"


class SwitchDriver:
    """Contract implemented by every network operating-system driver."""

    descriptor: DriverDescriptor

    def parse_identity(self, output: str, *, allow_family_fallback: bool = False) -> DriverIdentity | None:
        raise NotImplementedError

    def normalize_port(self, value: str) -> str:
        return str(value or "").strip()

    def normalize_slot(self, value: str) -> str:
        return str(value or "").strip()

    def normalize_alias(self, value: str) -> str:
        normalized = " ".join(str(value or "").strip().split())
        if not normalized:
            raise ValueError("A port alias is required")
        if len(normalized) > 64 or _CONTROL_PATTERN.search(normalized) or '"' in normalized or "\\" in normalized:
            raise ValueError("Port alias contains unsupported characters")
        return normalized

    def command_failed(self, output: str) -> bool:
        return False

    def capabilities(self, profile_data: dict[str, Any]) -> set[str]:
        capabilities = {str(item) for item in profile_data.get("commands", {}).keys()}
        capabilities.update(str(item) for item in profile_data.get("orchestrated_actions", []))
        return capabilities


_PORT_PATTERN = re.compile(r"^[0-9]+(?:/[0-9]+){1,2}(?:-[0-9]+(?:/[0-9]+){0,2})?$")
_SLOT_PATTERN = re.compile(r"^[0-9]+(?:/[0-9]+)?$")
_CONTROL_PATTERN = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

_DESCRIPTION_RE = re.compile(r"^\s*Description\s*:\s*(.*?)\s*,?\s*$", re.IGNORECASE | re.MULTILINE)
_NAME_RE = re.compile(r"^\s*Name\s*:\s*(.*?)\s*,?\s*$", re.IGNORECASE | re.MULTILINE)
_MODEL_PATTERNS = (
    re.compile(r"\b(OS\d{4,5}[A-Z]?(?:-[A-Z0-9]+)*)\b", re.IGNORECASE),
    re.compile(r"\bOmniSwitch\s+([0-9]{4,5}[A-Z]?(?:-[A-Z0-9]+)*)\b", re.IGNORECASE),
)
_VERSION_RE = re.compile(r"\b([5-9](?:\.\d+){2,4}\.R\d{1,3})\b", re.IGNORECASE)

_AOS_ERROR_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE | re.MULTILINE)
    for pattern in (
        r"^\s*(?:%\s*)?error\s*(?::|$)",
        r"^\s*(?:%\s*)?unknown command\b",
        r"^\s*(?:%\s*)?invalid (?:command|input|syntax|entry|parameter)\b",
        r"^\s*(?:%\s*)?incomplete command\b",
        r"^\s*(?:%\s*)?syntax error\b",
        r"^\s*(?:%\s*)?authorization (?:failed|denied)\b",
        r"^\s*(?:%\s*)?not authorized\b",
        r"^\s*(?:%\s*)?permission denied\b",
        r"^\s*(?:%\s*)?command not found\b",
    )
)


def _clean(value: str) -> str:
    return str(value or "").strip().rstrip(",").strip()


class AlcatelAOSDriver(SwitchDriver):
    def __init__(self, *, profile: str, major: str) -> None:
        self.major = str(major)
        self.descriptor = DriverDescriptor(
            key=f"ale-aos{self.major}",
            vendor="Alcatel-Lucent Enterprise",
            os_family=f"AOS {self.major}",
            profile=profile,
            netmiko_device_type="alcatel_aos",
        )

    def parse_identity(self, output: str, *, allow_family_fallback: bool = False) -> DriverIdentity | None:
        text = str(output or "")
        description_match = _DESCRIPTION_RE.search(text)
        name_match = _NAME_RE.search(text)
        description = _clean(description_match.group(1)) if description_match else ""
        system_name = _clean(name_match.group(1)) if name_match else ""

        model = ""
        search_text = description or text
        # Some AOS identity views mention both the family (for example OS6360)
        # and the exact chassis SKU (for example OS6360-P10). Prefer the most
        # specific model token so compact/front-panel layouts are not lost just
        # because a generic family token appeared earlier in the output.
        model_candidates: list[str] = []
        for source_text in (search_text, text):
            for pattern in _MODEL_PATTERNS:
                for match in pattern.finditer(source_text):
                    raw = match.group(1).upper()
                    candidate = raw if raw.startswith("OS") else f"OS{raw}"
                    if candidate not in model_candidates:
                        model_candidates.append(candidate)
        if model_candidates:
            model = max(model_candidates, key=lambda value: (value.count("-"), len(value)))

        version_match = _VERSION_RE.search(search_text) or _VERSION_RE.search(text)
        version = version_match.group(1).upper() if version_match else ""
        version_major = version.split(".", 1)[0] if version else ""

        # Without an explicit hint, only claim the output when the AOS major is
        # known. With a profile hint, model evidence is enough to preserve the
        # current inventory verification behavior on releases that omit version.
        if version_major and version_major != self.major:
            return None
        if not version_major and not allow_family_fallback:
            return None
        if not model and "omniswitch" not in text.casefold():
            return None

        return DriverIdentity(
            vendor=self.descriptor.vendor,
            os_family=self.descriptor.os_family,
            model=model,
            os_version=version,
            system_name=system_name,
            description=description,
            profile=self.descriptor.profile,
            driver_key=self.descriptor.key,
        )

    def _normalize_numeric_cli_parameter(self, name: str, value: str) -> str:
        normalized = str(value or "").strip()
        normalized = normalized.translate(str.maketrans({"／": "/", "⁄": "/", "∕": "/"}))
        normalized = re.sub(r"\s*/\s*", "/", normalized)
        pattern = _PORT_PATTERN if name == "port" else _SLOT_PATTERN
        if normalized and not pattern.fullmatch(normalized):
            raise ValueError(
                f"Invalid {name} format: {normalized!r}. Use numeric OmniSwitch notation such as 1/1/2, without extra commands."
            )
        return normalized

    def normalize_port(self, value: str) -> str:
        return self._normalize_numeric_cli_parameter("port", value)

    def normalize_slot(self, value: str) -> str:
        return self._normalize_numeric_cli_parameter("slot", value)

    def command_failed(self, output: str) -> bool:
        return any(pattern.search(str(output or "")) for pattern in _AOS_ERROR_PATTERNS)


class DriverRegistry:
    def __init__(self, drivers: Iterable[SwitchDriver] = ()) -> None:
        self._by_profile: dict[str, SwitchDriver] = {}
        self._by_key: dict[str, SwitchDriver] = {}
        for driver in drivers:
            self.register(driver)

    def register(self, driver: SwitchDriver) -> None:
        descriptor = driver.descriptor
        profile_key = descriptor.profile.strip().upper()
        driver_key = descriptor.key.strip().casefold()
        if not profile_key or not driver_key:
            raise ValueError("Driver profile and key are required")
        if profile_key in self._by_profile:
            raise ValueError(f"A driver is already registered for profile {profile_key}")
        if driver_key in self._by_key:
            raise ValueError(f"Duplicate switch driver key: {descriptor.key}")
        self._by_profile[profile_key] = driver
        self._by_key[driver_key] = driver

    def for_profile(self, profile: str) -> SwitchDriver:
        key = str(profile or "").strip().upper()
        driver = self._by_profile.get(key)
        if driver is None:
            raise KeyError(f"No switch driver is registered for profile {profile!r}")
        return driver

    def maybe_for_profile(self, profile: str) -> SwitchDriver | None:
        return self._by_profile.get(str(profile or "").strip().upper())

    def profiles(self) -> tuple[str, ...]:
        return tuple(self._by_profile.keys())

    def descriptors(self) -> list[DriverDescriptor]:
        return [self._by_profile[key].descriptor for key in sorted(self._by_profile)]

    def detect_identity(self, output: str, *, profile_hint: str = "") -> DriverIdentity | None:
        hinted = self.maybe_for_profile(profile_hint)
        if hinted is not None:
            identity = hinted.parse_identity(output, allow_family_fallback=True)
            if identity is not None:
                return identity
        for driver in self._by_profile.values():
            if driver is hinted:
                continue
            identity = driver.parse_identity(output, allow_family_fallback=False)
            if identity is not None:
                return identity
        return None


registry = DriverRegistry(
    (
        AlcatelAOSDriver(profile="AOS6", major="6"),
        AlcatelAOSDriver(profile="AOS8", major="8"),
    )
)


def driver_for_profile(profile: str) -> SwitchDriver:
    return registry.for_profile(profile)


def netmiko_device_type(profile: str) -> str:
    return driver_for_profile(profile).descriptor.netmiko_device_type


def command_failed(profile: str, output: str) -> bool:
    driver = registry.maybe_for_profile(profile)
    if driver is None:
        # Unknown future profiles fail closed at driver resolution elsewhere;
        # this fallback avoids interpreting arbitrary output as success here.
        return False
    return driver.command_failed(output)


def registered_driver_metadata(profile_data: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    profiles = profile_data or {}
    result: list[dict[str, Any]] = []
    for descriptor in registry.descriptors():
        driver = registry.for_profile(descriptor.profile)
        capabilities = sorted(driver.capabilities(dict(profiles.get(descriptor.profile) or {})))
        result.append(
            {
                "key": descriptor.key,
                "vendor": descriptor.vendor,
                "os_family": descriptor.os_family,
                "profile": descriptor.profile,
                "netmiko_device_type": descriptor.netmiko_device_type,
                "capabilities": capabilities,
            }
        )
    return result
