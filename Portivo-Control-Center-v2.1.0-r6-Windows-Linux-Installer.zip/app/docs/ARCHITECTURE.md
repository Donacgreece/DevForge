# Architecture, v2.1.0-r6

## Components

- **FastAPI backend**: API, authentication, RBAC, Jobs, PDF generation and WebSocket terminal.
- **Static web UI**: English and Greek interface, light and dark themes.
- **SQLite**: inventory, roles, settings, Jobs, Job Items, Audit Log and current device state.
- **Netmiko / Paramiko**: AOS 6 and AOS 8 SSH execution and interactive terminal.
- **Background health monitor**: uses staggered ICMP reachability probes with two bounded retries and optional one-shot SNMPv3 confirmation after ICMP failure. It never opens TCP/22 or performs SSH authentication for health, and it does not retain a sample for every poll.

## Notification engine

Notification delivery is intentionally separated from switch health collection. The background monitor uses one ICMP echo during normal healthy polling. A failed echo receives two bounded retries; only after all three ICMP attempts fail can a configured SNMPv3 `sysUpTime.0` request confirm reachability. There is no TCP/22 or SSH health fallback. The Notification Engine consumes current state and the consecutive-failure counter, then confirms an incident only after the administrator-defined threshold. This keeps alert policy independent from the raw probe result.

Global policy is stored in `notification_policy`. Encrypted receiver endpoints are stored independently in `notification_destinations`, allowing Microsoft Teams / Power Automate, Slack, Discord and Generic JSON webhooks to coexist. Endpoint URLs are encrypted at rest and are never returned in clear text after save.

`notification_incidents` guarantees at most one open notification incident per switch. `notification_outbox` persists a separate delivery row for every destination before network I/O. The background worker records HTTP status and attempts and retries temporary failures with bounded backoff. One destination can fail without blocking other configured destinations. Delivered, failed and cancelled history is bounded to the latest 5,000 records.

Recovery is destination-aware. If a switch recovers before an offline alert is delivered, pending offline rows are cancelled. When at least one destination received the outage, recovery closes the incident and queues recovery only for those destinations that successfully received the corresponding offline event. Optional reminders use the same destination-aware rule.

The neutral event payload is versioned (`schema_version: 1.1`) and contains normalized event, device, health and incident objects. Provider adapters translate this event into a Microsoft Teams Workflow / Power Automate body containing a simple `text` field plus a Teams webhook `type: message` Adaptive Card attachment envelope, Slack Block Kit, Discord embed or unchanged Generic JSON. Microsoft HTTP 2xx responses are treated as workflow acceptance rather than proof that a downstream Teams action completed. Generic endpoints are HTTPS-only and reject localhost, private, link-local and other non-public address targets to reduce SSRF exposure.

## Authentication

1. A local bootstrap administrator is created by the installation script.
2. The administrator adds the first switch without storing switch credentials.
3. Network users authenticate against a configured switch with their personal SSH credentials.
4. The SSH password is encrypted only in server process memory for the active session.
5. Roles are loaded from `ssh_user_profiles` and enforced by backend dependencies.

## Custom Runbooks

Custom Runbooks are reusable CLI workflow definitions stored separately from Jobs. A Runbook contains metadata, a Draft or Approved lifecycle, typed COMMAND/WAIT/VERIFY steps, optional user variables and execution policy. Saving any edit invalidates prior approval by returning the Runbook to Draft. Only an administrator can create, edit, approve, delete or schedule a Runbook. Approved workflows may be executed by Power Users; read-only user access remains constrained by the normal action permissions.

Runbook definitions are never dereferenced dynamically by an already-created Job. Before a manual or scheduled Job is inserted, variables are validated and substituted and the complete rendered workflow is copied into `payload_json` as `runbook_snapshot`. The Job runner executes that snapshot sequentially per target switch within one serialized SSH session. This preserves auditability when a library definition is edited while another Job is queued. Per-Runbook concurrency bounds cross-switch execution, while the existing per-device coordinator continues to serialize all operations that target the same switch.

Scheduled Runbooks use the existing Automation credential and generic Automation Action Registry. A scheduled Runbook must remain Approved and have `allow_scheduled` enabled at the moment the schedule creates its Job. Target limits are re-evaluated at execution creation, preventing a Site or Group scope that has grown beyond the approved Runbook policy from silently expanding the blast radius.

## Platform time model

Portivo stores canonical event, job, audit and operational timestamps in UTC. The administrator-configured `platform_timezone` is an IANA timezone used only when timestamps are presented to users or external notification destinations. Historical database rows are never rewritten when the timezone changes. The same stored UTC instant is converted dynamically in the UI, Notifications and PDF reports, and calendar-day history filters translate local day boundaries back to UTC before querying SQLite. Existing Automation schedules retain their explicit timezone; new schedules default to the current Platform Timezone.

## Automation

Portivo v1.8.0 separates recurring operational work from platform administration. The dedicated Automation workspace owns the reusable service credential, recurring schedules and action-specific safety policies. Manual operations continue to use personal SSH sessions, while scheduled actions use the dedicated encrypted service credential only when a schedule is executed.

`vlan_port_maintenance` is a registry-backed orchestrated action shared by manual Operations and scheduled Automation. Its executor performs read-only VLAN, LAG, LLDP and MAC-table safety inspection, blocks tagged/ambiguous or infrastructure-facing ports, enforces per-switch and fleet-wide impact limits, and revalidates the evidence before any transient PoE/interface restart.

Scheduled actions are stored in `automation_schedules`. The table contains common scheduling and scope fields plus `settings_json` for action-specific options, allowing future automation types to reuse the same scheduler without adding a new database table or page for every feature. The `AUTOMATION_ACTIONS` registry declares each available action, whether it is destructive, whether credentials and Site/Group scope are supported, its optional safeguard profile and any action-specific settings. The initial registry exposes read-only Check UNP and safeguarded Fix UNP.

Existing `unp_schedules` data is migrated once into `automation_schedules` when the new store is empty. The legacy table and v1.6.2 Admin scheduler endpoints are retained for upgrade and cached-client compatibility, but the v1.6.3 UI no longer manages schedules from Admin.

Fix UNP uses one shared safeguard policy regardless of how the action starts. Protected ports, guest-profile keywords, voice/IPTV exclusions and the maximum affected-port limit are therefore identical for manual Fix UNP and scheduled Fix UNP. Administrators can edit the policy from Automation, while signed-in operators can inspect the effective safeguards from the Fix UNP action context before execution.

Scheduled executions still create normal Jobs and Job Items. Automation defines why and when an operation runs; Jobs remains the execution record, result surface and audit trail.

## Global Command Palette

The browser exposes a local `Ctrl+K` / `Cmd+K` command palette over data already loaded into the authenticated session. It indexes primary Portivo workspaces, managed switches and the verified action catalog without creating a separate server-side search index. Page results navigate directly, switch results open the device workspace, command results open Operations with the chosen action selected, and endpoint-shaped queries can hand off to the live Find Device workflow.

The palette applies the current user's permissions before exposing configuration-changing commands. It does not execute a network change directly from the search result; command selections still enter the normal Operations preview and confirmation workflow. This preserves Portivo's existing RBAC, dry-run, Job and Audit controls.

## Vendor driver foundation

Portivo v1.6.0 introduces a vendor-neutral switch driver boundary without changing the current supported device surface. The executable profiles remain AOS 6 and AOS 8, but the core now resolves platform-specific behavior through `SwitchDriver` instances registered by profile.

The driver contract owns SSH transport selection, platform identity parsing, port and slot parameter normalization, alias validation, command rejection detection and capability metadata. The existing ALE AOS 6 and AOS 8 implementations are registered as separate drivers while continuing to use the same validated command profiles and Netmiko transport used by previous releases.

`/api/platform/drivers` exposes non-secret driver and capability metadata to authenticated users. It exists as an integration boundary for future platform work and is not currently surfaced as a vendor selector in the UI. Adding another vendor later requires a driver, command profile and feature-specific parsers before that platform can be presented as supported. v1.6.0 does not include Cisco, HPE, Aruba or other third-party switch compatibility.

## Command execution

1. The user selects an action and targets.
2. The backend renders AOS-specific command templates.
3. The UI shows an exact preview.
4. A Job and per-device Job Items are created.
5. Workers execute targets with bounded parallelism. Operations targeting the same switch enter a strict FIFO queue and share one per-device automation lane; different switches remain independent and can execute in parallel.
6. A live operation owns one SSH connection and one per-device lease for its complete transaction. No second automated Job or interactive terminal can overtake it on the same switch.
7. Read-only actions stop after collection or verification. Configuration changes are applied to running configuration and recorded in `pending_config_changes`; they are not written to flash after every individual action.
8. The Unsaved Configuration workflow groups pending changes by switch. Operators can persist one switch or all pending switches explicitly. AOS 8 uses `write memory flash-synchro`; AOS 6 uses `write memory`.
9. Persistent-save Jobs keep the per-device lane through flash synchronization, stable-prompt detection and the short post-save cooldown so a following SSH operation cannot race the save tail.
10. Before execution, Portivo resolves the action through the detected ALE AOS family and its compatibility metadata. Documentation-backed raw actions, Portivo-orchestrated workflows, model/release-dependent actions and unsupported actions are kept distinct.
11. PoE status is always slot-scoped. Per-port and global PoE views are orchestration workflows that derive the appropriate slot-qualified read-only query and parse the requested scope; the execution engine never emits bare `show lanpower` or AOS 8 `show lanpower port <port>` status syntax.
12. CLI error detection is line-oriented and matches explicit rejection messages. Normal counter labels such as `Error Frames` are not failures. A syntax/capability rejection is stored per device/profile/model/AOS identity so the same unsupported variant is not repeatedly sent until that identity changes.
13. AOS 8-only feature families such as UNP are not exposed as executable AOS 6 actions. Configuration-changing actions are never probed experimentally to discover syntax.
14. An SSH authentication rejection is retried only when the exact same credential fingerprint succeeded on that same switch recently; genuinely unproven credentials still fail immediately to reduce lockout risk.
15. Passwords and terminal content are never written to Job records.

## ALE CLI compatibility and capability learning

The ALE compatibility layer treats AOS 6 and AOS 8 as separate command families. Core commands are resolved through family-specific profiles and the driver registry, while actions that require more than one CLI query are represented as Portivo workflows instead of fake one-to-one command mappings. This is particularly important for PoE, where status collection is slot-qualified and a per-port result is produced by filtering the documented slot output rather than inventing an unsupported per-port status command.

The Command Library exposes a compatibility tier for every action. `documented` is reserved for the family baseline that Portivo maps directly from ALE documentation, `orchestrated` identifies a Portivo workflow composed from safe ALE queries, `model_dependent` means the action may require model/release capability confirmation, and `unsupported` prevents execution for the detected family. The product does not claim that every advanced action is universal across all OmniSwitch models.

`device_action_capabilities` stores runtime evidence for exact device identity. Explicit syntax or capability rejection is learned against device ID, AOS profile, model and AOS version. This suppresses repeated incompatible probes while allowing a software upgrade or hardware replacement to invalidate stale evidence automatically. Learning is used to protect execution and improve previews; Portivo does not probe configuration-changing syntax speculatively.

## Intelligent endpoint locator

Find Device uses live SSH data with identifier-specific command plans. MAC is the primary endpoint identity. IP searches correlate ARP, MAC forwarding and UNP data in a single fleet pass, with a safe active probe and ARP retry when a static IP has no current neighbor entry. MAC and UNP searches use staged enrichment so expensive tables are queried only when they add information. LLDP is collected only on candidate switches to distinguish physical edge ports from learned uplinks.

The resolver never joins endpoint records merely because they share a port. MAC identity is required for cross-source correlation, preventing multi-MAC access ports from mixing IP, username or profile data. UNP Profile ID and VLAN are stored as separate fields. Results are ranked with evidence-based confidence and expose upstream observations without presenting them as the physical endpoint location.

`endpoint_last_seen` stores only the latest verified location for each MAC, not a time-series history. This provides immediate last-known context when a device is currently offline or an IP can no longer be resolved, while keeping database growth bounded.

## Port Troubleshooter

Port Troubleshooter is an on-demand read-only diagnostic path scoped to one switch and one physical port. A diagnosis uses a single serialized SSH session and collects only operational evidence required for that port, including interface state and media, counters, PoE, MAC forwarding, UNP identity and LLDP neighbor data. Existing Live Port Inventory data is used as a fallback for fields not reported by a targeted command.

Diagnostic parsers are conservative. Unknown AOS output remains `Not reported` rather than being inferred. Findings are evidence-based and can highlight conditions such as an enabled port without carrier, CRC/FCS or other interface errors, drops/discards, collisions, PoE faults, zero PoE draw, multiple learned MAC addresses or a live link with no current endpoint evidence. The diagnostic workflow never changes configuration and is available to authenticated SSH users, including read-only roles.

The browser binds each diagnostic request to the exact device, port and Port Details modal session that launched it. If an operator moves to another port while a diagnosis is still completing, the older response cannot overwrite the newer modal state.

## Fleet Audits

Fleet Audits are structured, read-only fleet assessments. Operators explicitly select the target switches and audit type before execution. A run uses bounded cross-device concurrency while the existing per-device SSH coordinator guarantees that each switch still has one serialized automation lane. All commands belonging to one audit/device are executed through one SSH session.

The audit engine stores only normalized findings, evidence summaries, severity, coverage and command-level compatibility errors. Raw SSH credentials are never persisted and raw command output is not retained as audit history. Unsupported commands reduce evidence coverage instead of being interpreted as a device fault.

Thermal audits prefer switch-reported thermal status and thresholds. If a release exposes only numeric temperature without a verified threshold, Portivo reports the observation but does not invent a vendor limit. Full Switch Health combines only the evidence that was actually reported; unavailable metrics do not reduce its health score.

The executable audit catalog intentionally contains only general-purpose operational assessments. Environment-specific VLAN/UNP policy checks and the LAG Health audit introduced in v1.3.3 were retired from new runs in v1.3.4; existing historical audit records remain readable and exportable for backward compatibility.

Completed Fleet Audit runs and their per-switch items are retained in SQLite and participate in database maintenance pruning using the completed-job retention window. Executive PDF reports are generated on demand from the normalized audit record.

## Persistent data

SQLite stores current operational data and audit records. Full time-series interface monitoring remains outside the v1.8.0 database design. SQLite stores only the latest observed admin/link state and transition timestamps in `port_state_cache`, allowing honest Portivo-observed duration without writing every sample. Traffic graphs and historical telemetry should use Prometheus or another time-series database.

## Network exposure

The default bind address is `0.0.0.0:8766`. Production deployments should restrict access to a trusted management network and preferably use an HTTPS reverse proxy. WebSocket forwarding is required for the interactive terminal.


## Per-destination notification routing

The incident detector is global and uses the background TCP health state plus a shared confirmation threshold. Routing is evaluated independently for each enabled webhook destination. Each destination stores its own event subscriptions and Site/Group scope. A confirmed incident therefore exists once, while the outbox fan-out includes only destinations whose current routing policy matches the switch and event. Recovery is constrained to destinations that successfully received the original offline alert and still subscribe to recovery, preventing unmatched recovery messages.
