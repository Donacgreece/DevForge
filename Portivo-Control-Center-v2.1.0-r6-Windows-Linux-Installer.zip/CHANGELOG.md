# Portivo Control Center v2.1.0

### Static revision 2.1.0-r6

- Reworked switch availability for the lowest practical background impact: healthy switches use one ICMP echo per normal poll, while a failed ICMP gets exactly two bounded retries before any fallback is considered.
- Removed TCP/22 from the health engine completely. Auto no longer opens the SSH port for reachability, TCP/22-only mode was removed from the API/UI, and upgrades normalize any legacy `tcp22` health mode to `Auto`.
- Auto now uses at most one lightweight SNMPv3 `sysUpTime.0` request only after all three ICMP attempts fail; without an SNMPv3 monitoring profile, confirmed ICMP failure alone determines the raw reachability result.
- Kept SNMP telemetry independent from ping reachability and added deterministic per-switch polling jitter so large fleets do not probe in lockstep. Existing outage-confirmation thresholds and adaptive offline backoff remain in place.

### Static revision 2.1.0-r5

- Fixed Windows PowerShell/WPF mojibake in the branded uninstall wizard by replacing encoding-sensitive dash punctuation with ASCII-safe text (`Standard uninstall - keep data`).
- Added release validation that requires the Windows uninstaller script to remain ASCII-only, preventing PowerShell 5.1 from mis-decoding UI text on systems that treat BOM-less UTF-8 scripts as legacy ANSI.
- No health-monitoring, SSH-session, application-data or protocol behavior changed from v2.1.0-r4.

### Static revision 2.1.0-r4

- Fixed fresh/recovery Windows installation failing with an invalid `WorkingDirectory` during the private-runtime import probe by running the probe from the existing Portivo application root instead of the service directory that is created later in the workflow.
- Reworked the Windows uninstall layout so the Cancel and **Uninstall Portivo** actions are docked permanently at the bottom of the branded panel and remain visible at normal/high-DPI scaling; long content scrolls independently instead of pushing the action row outside the window.
- Added r4 regression coverage for the fixed uninstall action layout while preserving the safe keep-data default, guarded purge flow, v2.1.0 health architecture and application behavior.

### Static revision 2.1.0-r3

- Rebuilt the Windows uninstaller as a full Portivo-branded WPF experience matching the installer: identical two-panel visual language, logo treatment, typography, action buttons, status/progress presentation and in-window completion state.
- Kept Standard uninstall as the safe default while presenting preserved `.env`, `data/` and `backups/` clearly before removal; Full Removal / Purge remains explicitly destructive and can create a final Desktop backup before deletion.
- Added live uninstall progress for service shutdown/removal, process cleanup, firewall cleanup, Installed Apps deregistration and application/data removal, with failures reported in the same polished workflow instead of a bare script window.
- Enhanced the Linux uninstaller with a branded terminal workflow and explicit step progress while preserving the same keep-data and guarded-purge semantics.
- Preserved all v2.1.0-r2 health-monitoring behavior and the FIXED2 private-Python / WinSW service deployment fixes; this revision changes deployment/uninstall presentation and packaging only.

### Static revision 2.1.0-r2

- Added supported Windows and Linux uninstall workflows instead of relying on manual folder deletion.
- Standard uninstall removes the service, runtime, application files, logs and installer-created firewall exposure while preserving `.env`, `data/` and `backups/` for a future reinstall.
- Added guarded Full Removal / Purge with an explicit destructive confirmation and optional final backup before local credentials, database, configuration and backups are deleted.
- Windows installs now register Portivo in Installed Apps and deploy a self-relocating uninstaller; Linux installs deploy the equivalent uninstaller under the application root and clean systemd/service-account artifacts.

### Static revision 2.1.0-r1

- Replaced periodic switch TCP/SSH-port-only health with an ICMP-first adaptive reachability architecture that never performs background SSH authentication.
- Added optional lightweight SNMPv3 `sysUpTime.0` secondary telemetry with a bounded single-request probe; SNMP telemetry health is stored independently so an SNMP failure cannot mark a ping-reachable switch Offline.
- Added per-switch `Auto`, `Ping`, `SNMPv3` and `TCP/22` health modes. Auto uses Ping → SNMPv3 → TCP/22 fallback while retaining existing consecutive-failure outage confirmation and adaptive offline backoff.
- Added health-monitor profile selection, runtime probe visibility, migration-safe database fields and regression validation for fallback order, no-SSH behavior and independent SNMP telemetry.

# Portivo Control Center v2.0.0

### Static revision 2.0.0-r9

- Updated the validated dependency baseline to cryptography 49.0.0, python-multipart 0.0.32 and ReportLab 4.4.10, and moved the Windows private runtime target to CPython 3.13.15.
- Hardened Windows upstream acquisition with pinned SHA-256 checks for the CPython runtime and WinSW plus fail-closed Authenticode validation before the Python runtime is accepted.
- Removed opportunistic pip self-upgrades from production installers and install the exact lock without dependency re-resolution; Windows additionally requires binary wheels to avoid executing unexpected source builds.
- Strengthened the Linux systemd unit with NoNewPrivileges, ProtectSystem, ProtectHome, PrivateTmp, PrivateDevices, kernel/control-group protections and service-owned write access limited to runtime data directories.

### Static revision 2.0.0-r8

- Added safe web hardening without changing existing LAN exposure or SSH execution: public Swagger/OpenAPI is disabled, public health returns status only, and exact build metadata is available only from loopback for installer verification.
- Hardened browser/network boundaries with explicit terminal WebSocket Origin validation, a broader compatibility-safe Content Security Policy, sanitized unexpected terminal errors, and webhook redirects disabled with destination revalidation immediately before delivery.
- Added bounded switch-inventory imports with a 20 MiB upload cap, 25,000-row/64-column limits, cell-size limits and XLSX expanded-size/compression safeguards, while clearly marking SNMPv3 SHA-1 and DES as legacy and preferring SHA-256 for new profiles.
- Fixed the root Linux installer version mismatch, added dedicated security-hardening regression validation, and preserved the existing HTTPS, SSH trust and service-account behavior for controlled follow-up revisions.

### Static revision 2.0.0-r7

- Made all six Power summary cards keyboard- and mouse-clickable: UPS Assets, Normal, On Battery, Critical, Offline and Protected Switches.
- Aligned summary-card filtering with the metric definitions, including On Battery covering on-battery/low-battery/depleted states and Critical matching critical severity.
- Added a protected-switch metric filter that shows only UPS assets with one or more assigned protected switches while keeping Clear filters predictable.
- Added regression validation for Power summary-card actions, filter semantics, accessibility hooks and the existing six-card responsive layout.

### Static revision 2.0.0-r6

- Fixed sidebar active-state routing so selecting Roadmap highlights only Roadmap and no longer leaves More highlighted at the same time.
- Kept More active for its true child workspaces only: More, Command Library and Drivers.
- Preserved Roadmap in its original persistent sidebar position and preserved the legal notice directly below the More header.
- Added regression validation for mutually exclusive Roadmap/More navigation highlighting without changing permissions or view routing.

### Static revision 2.0.0-r5

- Restored Roadmap to its original persistent sidebar position, exactly as it was before the r4 navigation change.
- Moved the AGPL copyright/legal notice directly below the More header so licensing information appears before the More capability cards.
- Removed the temporary Roadmap card from More while keeping License & legal and Source code in the More workspace.
- Preserved the r4 login cleanup, including the complete removal of the language selector from the login page, with no authentication or operational changes.

### Static revision 2.0.0-r4

- Removed the language selector completely from the login screen while preserving the configured default language and the language controls available after sign-in.
- Moved Roadmap out of the persistent sidebar footer and into the More workspace, positioned directly above Drivers for a cleaner primary navigation hierarchy.
- Kept More available to every authenticated role because it now contains universally available Roadmap and legal/source resources in addition to capability-gated tools.
- Preserved all authentication, theme, localization, permissions and operational behavior; this revision is a focused login/navigation presentation refinement.

### Static revision 2.0.0-r3

- Added SPDX license/copyright headers across Portivo-owned source and installer scripts, and strengthened visible AGPL legal/source access on login and More.
- Added exact runtime dependency pins through `requirements.lock`, with `requirements.in` retained as the dependency-policy input and installers switched to the lockfile.
- Added `SBOM.spdx.json`, expanded third-party component inventory and per-component license material under `THIRD_PARTY_LICENSES/`.
- Added a no-external-code-contributions `CONTRIBUTING.md` policy and formalized matching installer, source and SHA256 release assets.

### Static revision 2.0.0-r2

- Fixed Windows upgrade packaging so `LEGAL.md` and `THIRD_PARTY_NOTICES.md` are copied into the installed application root before licensing validation runs.
- Added an installer-side required-file contract that stops immediately with a clear payload-integrity error if any mandatory licensing artifact is missing after extraction.
- Expanded installation validation to require `LICENSE`, `LEGAL.md`, `THIRD_PARTY_NOTICES.md` and `TRADEMARKS.md`, preventing future source/package drift.
- Preserved the v2.0.0 AGPL-3.0-only licensing boundary and all v1.9.4 functionality; this revision is an installer/update reliability fix only.

### Static revision 2.0.0-r1

- Changed the Portivo-owned source-code license to **GNU Affero General Public License v3.0 only** (`AGPL-3.0-only`) before the first public release.
- Added a dedicated legal notice and clear separation between Portivo licensing, third-party component licenses and trademark rights.
- Added in-app legal access for the AGPL license, third-party notices and a safe exact-version corresponding-source download.
- Established v2.0.0 as the first public licensing boundary while preserving the complete v1.x feature and release history.

# Portivo Control Center v1.9.4

### Static revision 1.9.4-r1

- Refined **Review commands** into a Portivo-native Operations surface with consistent rounded geometry, raised surfaces and balanced spacing instead of a full-card terminal treatment.
- Added a structured per-device header for switch identity, management address, AOS profile and command-support evidence.
- Moved exact CLI into contained inset terminal blocks with clearer separation between support notes and executable text, while preserving wrapping and multi-line verification output.
- Preserved the existing Operations grid, preview API payloads, dry-run behavior and execution workflow; the release is presentation-only for command review.

## v1.9.3 release history

### Static revision 1.9.3-r13

- Power inventory summary now exposes confirmed UPS communication loss as a dedicated neutral **Offline** metric, separate from Normal, On Battery and Critical power health.
- The Health filter includes **Offline**, and the Offline summary card acts as a shortcut that filters and scrolls directly to the affected UPS assets. Communication loss remains informational only and does not raise Dashboard Power attention or notifications.

### Static revision 1.9.3-r12
- Confirmed UPS communication loss now overrides the last-known healthy card accent, so Offline UPS cards render with a neutral status rail while retained telemetry remains visible.

## Static revision 1.9.3-r10

- UPS communication loss is now a debounced informational state in the Power workspace: after the configured consecutive SNMP failure threshold the asset is shown Offline while its last valid battery, runtime, load and power-state telemetry remains visible.
- Added informational `UPS offline` / communication-restored history in Power incidents only; these reachability events never enter Notification Center, webhook routing or delivery history.
- Dashboard Power attention and Infrastructure attention remain driven only by authoritative power conditions such as On Battery, Low Battery, depleted battery, bypass or output-off evidence, so communication loss alone creates no dashboard alert.
- Added regression coverage for transient failure suppression, confirmed UPS Offline visibility, Power-only communication incidents, recovery closure and notification isolation.


## Static revision 1.9.3-r8

- Dashboard switch availability now uses the same configurable consecutive-check outage confirmation threshold as Notifications instead of showing Offline after the first missed probe.
- A switch with previous successful reachability remains Online on Dashboard during the confirmation window; a never-seen switch remains Unknown until enough evidence exists.
- Infrastructure attention, fleet connectivity totals and the Offline metric all use the same confirmed connectivity state while raw probe failures remain available internally for adaptive retries and diagnostics.
- Added a regression validator covering 3-check and 5-check policies so Dashboard and incident confirmation cannot drift apart in future releases.


## Static revision 1.9.3-r7

- Added identity-aware CyberPower / RMCARD and Riello UPS / NetMan power drivers with RFC 1628 telemetry baselines and enterprise/manufacturer detection.
- Expanded Auto detect, Add/Edit UPS, Drivers registry, API schemas and frontend labels for the two new UPS families.
- Renamed the v1.9.3 Roadmap release theme to **UPS Vendor Drivers & Telemetry** and restored the fixed four-bullet Released card.
- Removed reseller-specific branding from product-facing release documentation and validation naming so Portivo tracks manufacturers and protocols consistently.


## Static revision 1.9.3-r6

- Fixed Single Switch Command Center lazy loading so opening a switch loads the same role-filtered verified command profiles used by Operations.
- Added command-profile request de-duplication so direct switch navigation cannot trigger duplicate catalog requests.
- Preserved the v1.9.2 performance model by rendering the full Command Library page only when that page is actually active.
- Refreshing a switch workspace now restores the command catalog if it was not yet cached.

## Static revision 1.9.3-r5

- XPPC alternate runtime/load/output-frequency fallback for cards that return placeholder zeroes.
- Unsupported zero placeholders are no longer shown as real UPS telemetry.
- Healthy partial UPS states no longer create Power attention or Infrastructure attention warnings.
- Windows update health validation now waits for the old listener to exit and reports the actual version/revision response.

## Static revision 1.9.3-r4

- Reworked UPS polling to resolve live SNMP identity before generic telemetry, preventing known XPPC and Vertiv devices from remaining on the Generic UPS-MIB path.
- Added resilient enterprise-MIB reads for Phoenixtec / XPPC and Vertiv / Liebert, including small-batch GET retries and bounded read-only subtree fallback.
- Expanded Socomec coverage to OFYS-RT with NET VISION / RT VISION WEB/SNMP interfaces and RFC 1628 standards telemetry.
- Made the Drivers workspace registry complete and self-healing, with all eight Power drivers plus supported family metadata visible from the backend catalog and frontend fallback catalog.
- Added API no-store behavior and UI/backend build-revision detection so a browser tab can detect that the server was upgraded and reload the correct static bundle.

## v1.9.3 · static revision 1.9.3-r2

- Added native Phoenixtec / XPPC-MIB support for enterprise `1.3.6.1.4.1.935.1`, including automatic driver detection, native model and firmware identity, battery capacity/runtime/voltage/temperature, input voltage/frequency, output voltage/frequency/load and operating state.
- XPPC vendor telemetry now overrides placeholder zero values from partial RFC 1628 implementations while keeping RFC 1628 as a safe fallback for metrics the network card does not expose.
- UPS Details now shows the detected `Phoenixtec / XPPC` driver and native XPPC measurements instead of reporting these cards as Generic UPS-MIB.

- Added UPS vendor-driver coverage for Vertiv, Socomec and AccuLine. Existing APC, Eaton and Generic RFC 1628 support remains unchanged.
- Added a dedicated Vertiv / Liebert driver with Global Products MIB enrichment for system state, output source, battery charge/runtime, load, battery electrical values, input/output measurements, inlet temperature and vendor alarm evidence, with RFC 1628 retained as a standards fallback.
- Added Socomec / NET VISION and AccuLine TNmax driver modes with automatic identity recognition and RFC 1628 normalization for SNMP-enabled models/cards, plus explicit driver selection when a generic network card does not expose a distinctive vendor identity.
- Expanded UPS Auto detect, API validation, Drivers reference metadata, Add/Edit UPS UI and detailed telemetry regression coverage for the new power-driver registry.
- Added a UPS vendor compatibility installation validator including a vendor-only Vertiv telemetry probe so modern Liebert cards remain monitorable even when the standard battery-status scalar is absent.

## v1.9.2 · static revision 1.9.2-r1

- Reduced login critical path to the Dashboard summary and notification badge. Full fleet inventory now warms after first paint rather than blocking sign-in.
- Added a 15-second fleet inventory cache with in-flight request de-duplication and active-view-only rendering for Devices, Operations and Find Device. Hidden workspaces no longer rebuild hundreds of DOM nodes after every inventory request.
- Dashboard refresh no longer reloads `/api/devices` or Pending Configuration every few seconds. `/api/dashboard` now returns a bounded `switch_attention` payload for offline switches and degraded stacks.
- Admin now loads progressively: Overview and Platform settings paint first, while Sessions, Users, Access Control, Monitoring Credentials and verification targets complete independently. Re-entering Admin paints the current authenticated-session cache immediately while fresh data is requested.
- Background refresh is scoped to the active workspace. Full device inventory refresh runs only while a fleet workspace actually needs it.
- Added performance-loading regression validation, including cache isolation across new authentication contexts.

## v1.9.1 · static revision 1.9.1-r20

- Personal access credentials are now single-session per username. A successful new SSH-backed sign-in automatically invalidates older in-memory tokens for the same user, so Admin no longer accumulates stale parallel sessions from repeated logins. The Administration wording now reflects Personal access sessions rather than implying multiple persistent switch SSH connections.
- Removed UPS SNMP reachability as an operator-facing health state. Temporary polling timeouts keep the last valid UPS power snapshot, remain internal telemetry only, and no longer mark a healthy UPS critical or visible as Unreachable anywhere in Power or Dashboard views.
- Removed `UPS unreachable` / `UPS reachable` from incident generation, webhook routing, destination subscriptions, delivery filters and power history. Upgrade startup purges legacy reachability incidents/deliveries, disables the retired destination flag and normalizes stale UPS rows back to their last valid state.
- Power incidents remain evidence-based: confirmed On Battery / Low Battery conditions and confirmed power recovery are still recorded and routed, while transport failures alone can never create operational history.
- Added regression validation for single-session access, silent UPS polling failures, legacy reachability cleanup and operator-facing history suppression.

## v1.9.1 · static revision 1.9.1-r19

- Fixed the remaining compact OS6360 front-panel bug at the model-token boundary. Model strings such as `OS6360-P10 8.10.x` no longer lose the SKU boundary during normalization, so the backend resolves the canonical 8 access + 4 uplink layout correctly.
- Added a frontend fail-safe for recognized OS6360-10/P10 hardware. The Operations workspace now derives the compact layout directly from the recognized model, filters pseudo rows above port 12 before hydration, and therefore cannot render `108`, `111` or `120` as front-panel interfaces even if stale cached/API data contains them.
- Generic OS6360 family fallback now accepts both two-part and three-part interface notation but only infers the compact chassis when ports 1–12 are complete and high-numbered pseudo rows are present, avoiding unsafe inference from a partially parsed larger chassis.
- Extended compact-layout regression validation with numeric AOS suffixes, two-part interface notation, frontend fail-safe presence and phantom-port rejection.

## v1.9.1 · static revision 1.9.1-r18

- Fixed compact OS6360 live-port rendering when AOS reports only the generic `OS6360` family. Portivo now uses unambiguous live interface evidence (physical 1–12 plus high-numbered pseudo rows) to activate the 8 access + 4 uplink layout without persisting a guessed SKU.
- Phantom compact-switch rows such as `108`, `111` and `120` are filtered before PoE discovery, VLAN/interface union, cache persistence and frontend hydration.
- UPS reachability incidents now have a 30-second confirmation window after the existing consecutive-failure threshold, so a delayed SNMP response does not immediately become an operational incident.
- Any valid online UPS poll now closes a stale open `UPS unreachable` incident even when the stored previous state was already online, covering restart/upgrade/reconciliation cases.

# Changelog

## v1.9.1 · static revision 1.9.1-r17

- UPS power incidents now use a 20-second confirmation window before an `On battery` or low-battery observation becomes operational incident history. Short contradictory/transient polls are retained as telemetry only and no longer create 2–20 second outage/recovery noise. Recovery also requires 20 seconds of stable `Normal` power before closing an open incident, while timestamps preserve the first abnormal and first healthy observations.
- Pending UPS webhook alerts are cancelled when the condition recovers before delivery, preventing stale outage notifications from arriving after utility power is already normal. Communication failures remain a separate `UPS Monitoring Unreachable` condition and are never promoted into a power outage merely because an SNMP read is delayed.
- Compact OS6360-10 / OS6360-P10 live identity discovery now checks `show system`, hardware information and chassis information until an exact SKU is found. Identity parsing prefers the most specific model token when both a generic OS6360 family name and OS6360-P10 occur in the same evidence.
- The Operations workspace now immediately hydrates the front panel from the device identity/layout returned by the live inventory refresh instead of continuing to use the stale device object that opened the page. This fixes compact 10-port models remaining under `Additional interfaces` after the backend learned the correct model, and keeps pseudo ports such as 108, 111 and 120 out of the rendered chassis.
- Added regression validation for UPS incident confirmation/recovery, exact compact OS6360 identity selection, live layout hydration and phantom-port rejection.

## v1.9.1 · static revision 1.9.1-r16

- Fixes compact OS6360-10 / OS6360-P10 live port inventory at the authoritative source boundary. When a stored/imported switch model is missing or not parseable, Live Ports now learns the model from `show system` inside the existing serialized SSH session and persists the detected model for future layout rendering.
- Compact OS6360 model matching now tolerates real AOS identity strings that append revision or descriptive text after the SKU instead of requiring the model token to end exactly at `OS6360-10` or `OS6360-P10`.
- Port inventory now removes non-physical compact-model pseudo/summary interfaces such as `1/1/111` and `1/1/120` from interface, VLAN, PoE, cached and final inventory evidence. Only physical front-panel ports 1 through 12 are eligible for OS6360-10/P10.
- Regression validation now covers appended model identity strings and rejects ports 13, 111 and 120 for compact OS6360 hardware.

- Static revision `1.9.1-r15` fixes the Windows upgrade validation bootstrap for the compact OS6360 port-layout regression test. The validator now resolves the Portivo application package correctly when launched by the bundled Windows Python runtime. Installer failure details also prioritize stderr so future validation errors show the real traceback.

## 1.9.1
- Static revision `1.9.1-r14` fixes compact OS6360-10 / OS6360-P10 front-panel inventory. These models are now rendered as 8 access ports plus 4 uplinks, while LANPOWER parsing is fail-closed so numeric summary values can no longer invent phantom interfaces such as `1/1/111` or `1/1/120`.
- Static revision `1.9.1-r13` adds SNMPv3 DES privacy support to Monitoring Credentials for legacy managed devices. DES is accepted by the API and mapped to PySNMP CBC56-DES for verification and monitoring, while AES/AES-128 remain the default modern choices.
- Static revision `1.9.1-r12` fixes Monitoring Credential modal compression at constrained viewport heights and browser zoom. Verification cards now retain their full intrinsic height, helper guidance stays inside the card, and the modal body scrolls instead of allowing content to spill beneath the fixed action footer.


- Static revision `1.9.1-r11` makes the left navigation viewport-safe across desktop resolutions and browser zoom. Desktop labels, Roadmap, account context and session actions are no longer removed by the compact width breakpoint; spacing compresses on short viewports and the sidebar falls back to contained vertical scrolling instead of clipping information. The Monitoring Credential verification panel now grows naturally around its helper text and keeps safe bottom scroll space above the modal footer.

- Static revision `1.9.1-r10` expands Monitoring Credential verification from switch-only targets to managed devices. SSH profiles remain switch-only, while SNMPv3 profiles can now be verified read-only against either enabled switches or managed UPS assets through standard `sysDescr`, with verification target type preserved for later editing.

- Static revision 1.9.1-r9 refines dense UPS inventory cards with a clearer identity header, compact status rail, more breathing room between assets, and a structured metadata band. The redundant full-width battery bar was removed, while secondary actions such as Verify, Edit and Delete moved into a contextual menu so Details and Manage switches remain the primary actions.

- Static revision 1.9.1-r8 improves UPS telemetry quality by reconciling detailed Battery/System cards with the already enriched APC/Eaton snapshot. Vendor-backed battery status now replaces a weaker RFC1628 `Unknown`, vendor-only charge/runtime/load are surfaced in Details when the generic objects are absent, and optional metrics whose only value is `Unknown` are omitted instead of being presented as useful telemetry. No healthy state is invented when the UPS exposes no authoritative status.

- Static revision 1.9.1-r7 refines UPS Details into a deliberately symmetric telemetry workspace: Device Identity and Monitoring use full-width balanced grids, related sections are paired in equal-width rows, odd metrics span cleanly instead of leaving clipped half-cells, and the noisy raw System description field is no longer collected.

- Static revision 1.9.1-r6: fixed Delivery destinations wheel behavior so the inner list scrolls only when it has overflow and naturally hands scrolling back to the page at its boundaries.

- Static revision `1.9.1-r5`: added an on-demand UPS Details workspace that collects the richest read-only telemetry the connected device actually exposes. Detailed collection merges standardized RFC 1628 UPS-MIB identity, battery, input, output, bypass, configuration and diagnostic data with APC PowerNet or Eaton xUPS enrichments, while omitting unsupported OIDs instead of inventing values.
- UPS Details keeps comprehensive polling on demand so the regular background health cycle remains lightweight. Detailed snapshots are cached with their collection timestamp and remain available if a later refresh is temporarily unreachable.
- Added protected-switch context and the ten most recent power incidents inside each UPS details view, plus clearly sourced values and derived Battery/UPS age only when a real replacement/manufacture date exists.
- Added Power Details regression validation for RFC 1628 scaling, APC high-precision battery/diagnostic enrichment, Eaton per-phase telemetry and upgrade-safe detailed telemetry persistence.

- Static revision `1.9.1-r4`: redesigned the logical front panel so every learned stack chassis is rendered as its own clearly numbered member card with its own Access/Uplink modules, and added guarded front-panel reload controls for standalone switches and individual stack members. Reload requires an exact-command preview, an explicit `RELOAD` confirmation and the switch CLI confirmation prompt. AOS8 uses targeted `chassis-id` reload; AOS6 uses learned Primary/Secondary/Idle role-aware mapping and fails closed when the member role is unknown.

- Dashboard Power attention now uses the Portivo purple accent when healthy, escalates to amber only for active UPS attention, and to red for low/depleted battery or output-off states.

- Static revision 1.9.1-r2 removes the redundant Live status only card from Platform settings and uses the freed Administration space for a live Effective Login Path showing the actual SSH authentication source order.
- Dashboard switch attention now labels UPS ownership explicitly, including assigned UPS, UPS battery/runtime telemetry, or No UPS assigned, so power telemetry cannot be mistaken for switch telemetry. Teams/Power Automate switch alerts use the same explicit UPS labels.
- Added a polished Monitoring Mode control to Admin → Platform settings with two explicit operating profiles: Full monitoring and Management only.
- Management only stops background switch availability, Stack Member Health and Power / UPS workers while preserving inventory, monitoring credentials, learned stack baselines, UPS telemetry, protected-switch assignments, notification routing and all existing configuration.
- Added granular Full monitoring service controls for Switch availability, Stack Member Health, Power / UPS and Incident detection. Service choices are retained while Management only is active and resume when Full monitoring is restored.
- On-demand management remains available while monitoring is paused, including Switches, Find Device, Operations, Fleet Audits, Runbooks, Automation, Jobs, Terminal, troubleshooting and administration.
- Automatic switch, stack and UPS incident creation now honors the Incident detection setting independently from background polling.
- Dashboard clearly identifies Management only, suppresses stale live-health metrics and Infrastructure Attention, while Power marks UPS state as Monitoring paused and retains last-known telemetry and last scan timestamps.
- Added monitoring-mode regression validation covering startup behavior, runtime worker state, API persistence, legacy settings compatibility and UI markers.

## 1.9.0

- Static revision `1.9.0-r8`: reordered the Dashboard summary metrics so Power attention appears before Active jobs, keeping infrastructure health ahead of execution activity while preserving all existing behavior.
- Static revision `1.9.0-r7`: refreshed Granular Access Control for the current Portivo module set. Role capabilities are now grouped as Core access, Operations, Observability, Tools, Administration and Advanced access; Devices is renamed to Switches, Drivers has its own read-only capability, and More is shown only when the role can access Command Library or Drivers.
- Split the original coarse Power management right into independent Add UPS, Edit UPS, Delete UPS, Verify UPS telemetry and Assign power sources permissions. Existing Custom Roles saved with the earlier `power.manage` right are expanded automatically in-memory so upgrades do not remove access. Built-in Site Administrator and Power User retain full scoped/global UPS management, while Operator, Helpdesk and Read Only keep power visibility without UPS configuration rights.
- Hardened Power API authorization so each UPS operation is enforced by its exact capability on the server, including Site/Group scope enforcement. The Drivers reference API is now governed by `drivers.view` independently from Switches or Power inventory access.
- Improved power-correlated Microsoft Teams / Power Automate alerts. Switch Offline notifications now explicitly show the assigned UPS, probable root cause and confidence, while correlated Switch Recovered notifications include utility-restoration evidence when the assigned UPS has returned to normal input power.

- Moved More below Admin panel so it remains the final primary navigation entry before the separate Roadmap section.

- Static revision `1.9.0-r5`: Power now has dedicated search and filters for UPS assets plus server-side Power incident search/filtering with a hard 25-row page size and Previous/Next navigation. Power incident content is no longer preloaded through the main Power inventory API, keeping long histories bounded.
- Refined Power panel spacing so filter/content areas sit cleanly below panel dividers instead of touching header lines.
- Simplified global navigation by removing the duplicate Add switch action from the page header, renaming Devices to Switches, and moving Command Library under a new extensible More workspace.
- Added a Drivers reference workspace under More that exposes the registered AOS6/AOS8 switch drivers and Generic RFC 1628, APC PowerNet and Eaton xUPS power drivers with operator-facing descriptions and protocol/capability metadata.
- Static revision `1.9.0-r4`: APC PowerNet monitoring now reads the high-precision battery state-of-charge scalar as a fallback for Easy UPS/NMC combinations that do not expose the classic `upsAdvBatteryCapacity` or RFC1628 charge object. The value is normalized from tenths of a percent and the UI falls back to battery health text only when no numeric charge is available.
- Static revision `1.9.0-r3`: UPS verification timeouts and OS/network SNMP errors are now returned as actionable verification diagnostics instead of a generic server error.
- The Live Verification panel now displays the exact safe SNMP failure reason, and unreachable UPS cards retain their latest monitoring diagnostic so operators can distinguish connectivity/credential failures from missing telemetry.
- Added consistent top spacing inside the UPS assets panel so UPS cards no longer touch the panel-header divider.

- Added Power Infrastructure Monitoring as a first-class subsystem with centralized UPS inventory, Site/Group scope, dedicated Power view/manage capabilities and a polished Power workspace.
- Added read-only SNMPv3 UPS monitoring with a Generic RFC 1628 UPS-MIB driver plus built-in APC PowerNet and Eaton xUPS drivers. Auto detect uses SNMP identity to select APC/Eaton when available and safely falls back to the standard UPS-MIB.
- APC PowerNet enrichment adds vendor model/firmware, battery status, battery capacity, estimated runtime, output state and load telemetry. Eaton xUPS enrichment adds manufacturer/model/software, runtime, battery capacity/ABM state, output source, load and alarm-count telemetry.
- Reused encrypted SNMPv3 Monitoring Credential profiles rather than storing credentials per UPS, with live UPS-MIB verification before or after asset creation.
- Added protected power-source assignment to switch inventory plus a symmetric bulk protected-switch assignment workspace. A UPS can protect multiple switches, and switch/UPS assignments are restricted to compatible Site scope.
- Added UPS On Battery, UPS Power Restored, UPS Low Battery, UPS Unreachable and UPS Reachable event handling with persistent power incidents that are retained even when webhook delivery is disabled, plus Notification Center delivery history when routing is enabled.
- Expanded webhook destination routing with UPS event subscriptions and shared Site/Group scope, including combined switch and UPS coverage counts.
- Added power-aware switch outage correlation. When an assigned UPS is on battery, critically low, depleted, output-off or disappears after low remaining runtime, switch Offline incidents include evidence and a probable/high-confidence power explanation instead of claiming an unverified hardware cause.
- Added Dashboard power attention and power-aware Infrastructure Attention entries while preserving normal switch reachability and stack health semantics.
- Added Power Infrastructure and v1.8.4-to-v1.9.0 migration regression validation to the installation validation chain.

## 1.8.4

- Fixed Windows upgrades from v1.8.3 to v1.8.4 where the database migration attempted to create new Job lifecycle indexes before the corresponding `retry_of_job_id` and `removed_at` columns existed, causing the private Python migration process to exit with code 1.
- Job lifecycle columns are now added before lifecycle indexes are created, and a dedicated legacy-database upgrade regression test validates the exact updater path.
- Improved Windows installer failures so the dialog includes the final Python error details instead of only showing a generic process exit code.

- Added resilient Job lifecycle handling. On every Portivo startup, any orphaned `queued`, `running` or `cancelling` Job from the previous process is automatically reconciled to `interrupted` instead of remaining falsely active.
- Added per-Job heartbeat timestamps and preserved already successful Job items when an execution is interrupted by an application update, service restart or unexpected worker failure.
- Added safe Job cancellation. A cancellation request stops new switch executions at item boundaries, allows any already-running switch action to finish its current safe unit of work, and records the final Job as `cancelled`.
- Added traceable Retry for `failed`, `partial`, `cancelled` and `interrupted` Jobs. Retry creates a new linked Job and re-runs only unfinished or unsuccessful targets, never targets that already completed successfully.
- Added audited Remove from history for terminal Jobs without offering a false manual Mark Completed action. Removed Jobs disappear from normal Activity history while the removal event remains in Audit Log.
- Added lifecycle controls and evidence to Activity → Jobs, including Interrupted/Cancelled/Cancelling states, heartbeat visibility, stopped-target counts, interruption reason, Cancel, Retry and Remove actions.
- Added Job lifecycle regression validation to the standard installation validation chain.

## 1.8.3

- Unified Site/Group selection in Notifications → Delivery Destinations and Automation → Create/Edit schedule with the same custom Portivo scope picker used by Access Assignment.
- Removed browser-native multi-select presentation from those modals, added selected counts, check-mark selection states, internal scrolling and fixed helper footers.
- Aligned Notification routing scope cards to the platform purple design tokens so selected and focus states render consistently instead of falling back to browser-native styling.
- Replaced native browser Sites/Groups multi-select rendering in Access Assignment with custom Portivo scope pickers, eliminating inconsistent Windows selection colors and clipped focus borders.
- Added stable internal scrolling, explicit selected check controls, live selected counts and fixed helper footers so scope guidance remains visible.

## 1.8.2

- Redesigned Notifications → Delivery destinations as a fixed-height two-column card workspace with internal scrolling, compact event/scope/activity summaries and a contextual action menu instead of wide row actions.
- Kept Delivery destinations and Incident detection policy visually balanced on desktop, with Save policy anchored to the lower-right of the policy panel.
- Added server-side pagination to Activity → Jobs and Audit Log with 25 rows by default and selectable 25 / 50 / 100 page sizes. Filtering, searching, counting and Site/Group access scope are applied on the server before LIMIT/OFFSET.
- Reworked Activity filter-option queries to use scoped DISTINCT database queries instead of loading thousands of history rows into the browser.
- Fixed SNMPv3 monitoring verification interoperability by using the OS-selected UDP source path first, simplifying PySNMP USM passphrase handling, and retaining explicit source binding only as a timeout fallback. Added clear in-modal Saving/Verifying feedback and protected stored monitoring secrets from browser autofill overwrites during profile edits.

## 1.8.1

- Refined Notifications routing layout with equal-height Delivery Destinations and Incident Detection panels, a compact two-destination viewport with internal scrolling, endpoint-free destination cards, and a bottom-right anchored Save Policy action.
- Added exact affected-chassis evidence to Stack Degraded incidents and webhook payloads. AOS8 `Config Chas ID` identifies a `Not-Joined` member, while the learned healthy baseline supplies its last-known role and chassis MAC; recovery records preserve which chassis rejoined.
- Fixed AOS8 Virtual Chassis degradation detection for real `Unassigned / Not-Joined` topology rows, using the configured chassis ID as the missing member identity so established stacks can fall from 2/2 to 1/2 (or N/N to N-1/N) and open Stack Degraded incidents after the normal two-check confirmation.
- Aligned the Devices connection pills so Online and Stack health share the exact same vertical baseline and 24 px pill geometry, with latency directly underneath.
- Refined the Monitoring Credential modal into a symmetric two-column layout with consistent field heights, method panels, secret guidance and verification controls.
- Made the Dashboard stack-aware with a dedicated Degraded stacks metric, degraded state in Fleet Connectivity and Infrastructure Attention entries while preserving management-IP Online reachability.
- Aligned device connection health so Online and Stack health appear on the same row with latency directly underneath.
- Hardened SNMPv3 verification and polling with explicit passphrase key handling, route-selected UDP source binding, longer retry windows and a minimum PySNMP 7.1.28 runtime.
- Added selectable Stack Member Health monitoring through dedicated encrypted read-only SSH or SNMPv3 Monitoring Credential profiles, independent from Automation and personal SSH sessions.
- Updated AOS8 SSH stack discovery to prefer the field-validated `show virtual-chassis topology` command, preserving member ID, role, running state and chassis MAC identity.
- Added SNMPv3 authPriv monitoring with SHA/SHA-256 authentication, AES-128 privacy and fail-closed ENTITY-MIB chassis discovery.
- Replaced manual expected-member counts with automatic three-pass baseline learning. Physical chassis remain members of one logical inventory device and are never created as duplicate switch rows.
- Added administrator-controlled baseline relearning plus explicit Credentials Required, Authentication Failed, Command Unsupported and Evidence Unavailable monitoring states.
- Preserved independent Stack Degraded and Stack Recovered incidents with two-pass degradation/recovery confirmation and normal management-IP Online/Offline isolation.
- Added monitoring-profile, topology parser, SNMP ENTITY-MIB, automatic-baseline and incident regression coverage to standard installation validation.

## 1.8.0

- Added granular Access Control with built-in Administrator, Power User, Site Administrator, Operator, Helpdesk and Read Only roles plus administrator-defined Custom Roles.
- Added server-enforced Site/Group scope assignments. Administrator and Power User remain global; every other built-in or Custom Role requires an explicit Selected Sites/Groups or All Sites assignment.
- New SSH identities and migrated legacy standard users fail closed with no scope until an Administrator grants access. Role and scope updates take effect immediately on active SSH sessions.
- Added capability-based module visibility and exact command-action authorization across Operations, live port tools, Find Device, Fleet Audits, Jobs, Audit Log, Runbooks, Command Library, inventory management and direct API execution.
- Helpdesk is limited to scoped diagnostics plus alias, interface restart and PoE restart. Operator adds governed maintenance and approved Runbooks without unrestricted Terminal or Custom CLI. Read Only receives no console or command execution surface.
- Added a dedicated Administration → Access Control experience for user assignments, built-in role inspection and Custom Role authoring, including exact command policies and scope evidence.
- Added static and end-to-end authorization regression validation to the standard installation validation chain.

## 1.7.1

- Added a global IANA Platform Timezone setting while preserving UTC as the canonical database storage format.
- Applied timezone-aware rendering to UI history, Notifications, Jobs, Audit Log, Fleet Audit/Job PDFs and related timestamps, including historical records.
- Made Jobs, Audit and Notification calendar-date filters honor the selected Platform Timezone and DST boundaries.
- Simplified Platform settings by removing the embedded Security Posture block; new Automation schedules default to the Platform Timezone while existing schedule timezones remain unchanged.

## 1.7.0

- Added a governed Custom Runbook Library with reusable COMMAND, WAIT and VERIFY steps, user-defined `{{variables}}`, Draft/Approved lifecycle and administrator approval metadata.
- Added shared Runbook execution for one-time Operations jobs and scheduled Automation jobs, using an immutable rendered snapshot stored with each Job for auditability.
- Added per-Runbook read/change/high risk classification, maximum target limits, bounded concurrency, failure policy and explicit scheduled-execution permission.
- Added Power User execution for approved workflows while keeping Runbook authoring, editing, approval, deletion and scheduling under administrator control.
- Preserved the existing ad-hoc Custom CLI console as a separate one-time tool.
- Added Runbook validation and execution regression tests to standard installation validation.

## 1.6.9

- Unified the Operations and Fleet Audits switch-selection experience around one reusable fleet switch card component.
- Operations now uses the same compact three-column selector, search, Site/Group/Model/Status/AOS filters, selected counter, Select filtered and Clear selection behavior as Fleet Audits.
- Preserved Operations-specific per-switch Port and Slot overrides as compact controls that appear only on selected cards when the chosen action requires them.
- Added shared responsive selector styling so future fleet-selection refinements can be applied consistently across both workflows.

## 1.6.8

- Corrected VLAN Port Maintenance dual-pass stability validation to compare effective Eligible/Protected port classifications instead of volatile descriptive values.
- Learned-MAC count changes on an already protected port no longer trigger false safety aborts.
- Eligibility transitions, newly matching protected ports and removed matching ports still stop execution before any change.
- Added VLAN stability regression validation to the standard installation validation chain.

## 1.6.7

- Replaced invalid Cisco-style `show mac-address-table` variants with the native ALE `show mac-learning` source-learning view for MAC discovery.
- Updated the shared MAC parser to read the real OmniSwitch `Domain / Vlan/SrvcId / Mac Address / Type / Operation / Interface` table format and derive unique learned-MAC counts per port locally.
- Routed VLAN Port Maintenance and Port Troubleshooter through the same profile-based MAC command so uplink safeguards no longer fail on the rejected command.
- Added CLI regression validation that locks the ALE MAC-learning command and parser behavior and rejects reintroduction of `show mac-address-table` in executable paths.

## 1.6.6

- Added **VLAN Port Maintenance** to Operations and Automation with target VLAN, Restart PoE / Restart Interface modes and Site/Group scheduling.
- Added mandatory fail-closed uplink protection using tagged/untagged VLAN evidence, LAG membership, managed-switch LLDP neighbors, multi-VLAN trunk heuristics, learned-MAC thresholds and explicit protected ports.
- Added a fleet-wide impact preflight, per-switch safety limit, second stability scan before live execution and serialization of VLAN-driven interface restart jobs across switches.
- Added a reusable VLAN maintenance safeguard policy and `vlan_port_maintenance` Automation Action Registry entry so the existing scheduler can host future action types.

## 1.6.5

- Combined Platform settings and Security posture into a single Platform & Security card with a compact 2×2 security status area.
- Placed Platform & Security and Authentication Sources in a dedicated desktop grid row that guarantees exactly equal outer card heights.
- Removed the standalone Security model panel from Administration while preserving the same runtime security diagnostics.
- Aligned both top-card action footers at the bottom and kept all settings/authentication persistence APIs unchanged.

## 1.6.4

- Expanded Security posture across the full Administration width and arranged its four indicators horizontally on desktop.
- Removed legacy equal-height stretching from Platform settings so the card uses natural content height.
- Restored the existing Platform settings Save action to a visible compact footer without changing backend persistence.
- Added responsive two-column and single-column Security posture layouts for narrower screens.

## 1.6.3

- Added a dedicated Automation workspace for recurring actions, shared service credentials and action-specific safeguards.
- Moved Fix UNP safeguards out of Admin and made the same policy available from Automation and the Fix UNP operation context.
- Added a generic automation action registry and `automation_schedules` store, with one-time migration from legacy UNP schedules and compatibility endpoints for cached v1.6.2 clients.
- Redesigned Administration around global access control, authentication sources, platform settings, security posture, sessions and data maintenance.

## 1.6.2

- Added configuration-aware reverse-proxy HTTPS mode with Secure cookies, HSTS and explicit trusted-proxy source handling while retaining the v1.6.1 Windows LAN firewall behavior.
- Added progressive login throttling before administrator password verification or SSH/AAA authentication. The limiter tracks source IP plus username and a broader per-IP failure window, returns `429` with `Retry-After`, and does not use hard account lockouts.
- Unified local administrator password creation and password changes on a single 12 to 128 character backend policy while preserving existing password hashes across upgrades.
- Added configuration-aware HTTPS reverse-proxy mode with `PUBLIC_URL_SCHEME=https`, Secure session cookies, HSTS and optional trusted proxy source-header handling restricted to configured proxy IPs.
- Changed database backup downloads to `FileResponse` streaming from a temporary SQLite snapshot with automatic cleanup, avoiding a full backup copy in process RAM.
- Added Admin security diagnostics for transport mode, login throttling and the active local administrator password policy.

## 1.6.1

- Added ordered SSH Authentication Sources. Administrators can select up to five stable enabled switches as Primary, Secondary and fallback sign-in sources, while upgraded installations with no explicit selection automatically prefer up to five recently online devices.
- SSH sign-in now performs parallel TCP availability checks and a single bounded authentication attempt per reachable source. Login uses a dedicated 2.5-second source timeout and a 5-second global window instead of normal operation retries and backoff.
- Removed the extra post-authentication `show system` reconnect from the login request so successful authentication is not delayed by normal SSH operation retry policy. Existing inventory identity remains available and is refreshed by normal operational workflows.
- Separated background health polling from command-execution concurrency. Health checks now use a dedicated 32-worker TCP pool and a 2-second connection timeout while configuration and diagnostic Jobs keep their existing execution limits.
- Added adaptive health scheduling: the first failed probe is retried after 5 seconds, confirmed offline devices are checked every 60 seconds, and devices offline for 15 minutes or longer are checked every 120 seconds. Recovery immediately returns the device to the normal administrator-defined interval.
- Added Admin diagnostics for authentication mode, fast-login timeouts, health worker count and the most recent health-cycle duration and device count.
- Fixed Windows and Linux installer packaging so `data/ale_cli_validation.json` and `INSTALLATION.md` are preserved in the installed application.
- Added `scripts/validate_installation.py`. Both installers now verify required runtime files and run profile, vendor-driver and ALE CLI reliability validation before completing installation.

## 1.6.0

- Added an ALE CLI reliability layer that explicitly separates AOS6 and AOS8 syntax for core switch operations instead of assuming common command forms.
- Replaced raw PoE Global Status and PoE Port Status commands with Portivo-orchestrated, slot-scoped read-only workflows. AOS8 uses documented slot-qualified variants with safe read-only fallback handling; AOS6 uses the legacy slot form.
- Corrected AOS6 family mappings for hardware information, power-supply status, interface administration and PoE operations, and removed AOS8-only UNP actions from the AOS6 executable profile.
- Added per-device action capability learning. ALE syntax rejections are stored against device/profile/model/AOS identity and are not repeatedly sent until the device identity changes.
- Added compatibility metadata to the Command Library: documentation-backed, Portivo-orchestrated, model/release dependent, or unsupported.
- Added CLI reliability validation that rejects known incomplete/invalid PoE patterns and regression-tests AOS6/AOS8 rendering.
- Port inventory, Port Troubleshooter and Fleet Audits now use the centralized ALE command compatibility layer for PoE and family-specific power queries.

## 1.5.2

- Extended the evidence-first Fleet Audit model across all nine active audits. Reports now provide audit-specific operator explanations, richer structured evidence and more actionable recommended checks instead of concentrating deep diagnostics primarily in PoE.
- PoE Capacity Audit now parses both full-interface and slot-local `show lanpower` rows, separates PoE state, priority and admin state, correlates affected ports with Ethernet link/alias data, and includes `show powersupply` context so common PoE/PSE or PSU patterns are visible alongside per-port faults.
- Interface Error Audit now breaks findings down per port into CRC/FCS, other errors, drops/discards and collisions and correlates them with current link/admin state and alias. Port Stability Audit now adds current state/alias to historical flap evidence, while Uplink Health reports include counter breakdown, neighbor and media state.
- Power Supply reports now expose structured PSU ID, reported wattage, AC/DC type, switch-reported state and location when the AOS table provides them. Full Switch Health now includes interface state/detail collection so component findings carry the same richer evidence model.
- PDF export detail is scope-aware: runs up to 25 switches include a full evidence section for every assessed switch; larger fleet runs retain complete fleet tables and add full evidence sections for every Warning, Critical or Unavailable result to keep reports readable at 500+ switch scale.
- All changes remain read-only. No switch configuration, notification routing, SSH operation semantics or vendor-driver support surface changed. No Topology subsystem is included.

## 1.5.1

- Rebuilt Fleet Audit PDF exports around operator-readable diagnostics. Every Warning, Critical and Unavailable result now includes a plain-language interpretation, switch identity, exact read-only collection commands, collection errors where applicable and recommended verification steps.
- Added audit-specific evidence tables for thermal sensors, fans, power supplies, PoE ports, interface error ports, flapping ports, managed uplinks, configuration synchronization evidence and Full Switch Health components.
- Expanded PoE Capacity Audit evidence so affected PoE ports are listed individually with slot/port location, maximum power, actual used power and the exact status reported by the switch. Active powered ports are also listed separately for context.
- Corrected PoE budget accounting so `Total Power Budget Available` is treated as remaining/available power instead of being added again to slot maximum capacity. Explicit total-used values are also recognized when per-port usage is unavailable.
- Audit reports remain read-only and conservative: they explain collected evidence without inventing an unsupported root cause. No switch configuration behavior, notification routing, health checks or vendor-driver behavior changed.
- No Topology subsystem is included in this release.

## 1.5.0

- Added the Global Command Palette with `Ctrl+K` / `Cmd+K` navigation across Portivo pages, managed switches and the verified command catalog. Device results open the switch workspace directly, command results open Operations with the selected action, and endpoint-like queries can launch Find Device.
- Added a vendor-neutral `SwitchDriver` registry. SSH transport selection, platform identity parsing, CLI parameter normalization and command rejection detection are now resolved through registered operating-system drivers instead of being hardcoded in the Portivo core.
- Registered the existing AOS 6 and AOS 8 behavior as isolated Alcatel-Lucent Enterprise drivers and exposed non-secret driver/capability metadata through `/api/platform/drivers` for future platform integrations.
- This release is a foundation only for multi-vendor support. It does not add Cisco, HPE, Aruba or other vendor UI, command profiles or compatibility claims. No Topology subsystem is included.

## 1.4.2

- Restored the compact native Site and Group multi-select controls from v1.4.0 for per-destination notification routing after the searchable checkbox picker introduced in v1.4.1 proved visually heavier than desired.
- Kept the v1.4.1 contained destination modal architecture with fixed header and fixed action footer, so Cancel and Save remain fully visible while only the form body scrolls.
- This release is UI-only. No notification routing semantics, incident detection, webhook payloads, delivery retries, health checks, SSH behavior or switch operations changed.
- No Topology subsystem is included in this release.

## 1.4.1

- Rebuilt the webhook destination modal as a contained three-part layout with fixed header and action footer; only the form body scrolls, so Cancel and Save remain fully visible at every supported viewport height.
- Replaced native Site and Group multi-select boxes with searchable checkbox pickers, selected-count feedback and one-click clear actions.
- Improved routing scope cards, spacing, accessibility states and responsive behavior while preserving the existing per-destination routing semantics.
- This release is UI-only for notification destination editing. No incident detection, webhook payloads, delivery retries, health checks, SSH behavior or switch operations changed.
- No Topology subsystem is included in this release.

## 1.4.0

- Added independent alert routing policy to every webhook destination.
- Each destination can subscribe separately to Switch Offline, Switch Recovered and Still Offline reminder events.
- Each destination can route all enabled switches or its own Site / Group scope; when both Site and Group are selected, intersection logic is used.
- Recovery notifications still close the loop only for destinations that actually received the original offline alert and also allow recovery events.
- The global Health notifications switch now controls the incident engine only. Failure threshold and reminder cadence remain global detection settings.
- Existing v1.3.x global routing settings migrate once to every existing destination, preserving current behavior after upgrade.
- Added per-destination routing summaries and routing coverage to the Notification Center.
- No switch commands, SSH health probe behavior, webhook encryption, provider payload formats or delivery retry semantics changed.

## 1.3.10

- Refined the Health alert policy layout so the form has consistent internal spacing and the Save policy action sits in a dedicated inset footer instead of touching the panel edge.
- Rebalanced Webhook delivery filters into complete symmetrical rows on wide screens, removing the unused grid gap beside Clear filters while preserving responsive layouts.
- This release is UI-only for the Notification Center. No incident logic, webhook payloads, retry behavior, TCP health checks, SSH behavior or switch operations changed.
- No Topology subsystem is included in this release.

## 1.3.9

- Fixed Microsoft Teams / Power Automate webhook compatibility. Microsoft destinations now send both the simple `text` field used by the official Teams workflow templates and the Teams webhook `type: message` Adaptive Card attachment envelope.
- Microsoft HTTP 2xx responses are now presented as **Accepted** rather than implying that the downstream Teams action definitely posted successfully. Test feedback explicitly points operators to the Teams channel or Power Automate run history for final confirmation.
- Redesigned webhook destination cards with a roomier two-section layout, clearer provider/status hierarchy, a dedicated masked-endpoint row and separated Test / Edit / Remove actions.
- Added professional search, filtering and pagination to Network Incidents and Webhook Deliveries. Delivery history can be filtered by event, provider, destination, status and date range, while search includes events, destinations, switches and errors.
- Notification Center now loads up to 500 recent incident/delivery records when opened while retaining bounded database history.
- No switch commands, SSH health checks, alert thresholds or configuration workflows changed in this release.
- No Topology subsystem is included in this release.

## 1.3.8

- Moved health notifications out of the Admin Panel into a dedicated **Notifications** operational workspace with fleet coverage, open incidents and delivery status.
- Replaced the Teams-only integration model with independent encrypted webhook destinations for **Microsoft Teams / Power Automate**, **Slack Incoming Webhooks**, **Discord Webhooks** and **Generic JSON Webhooks**.
- Added provider-aware message adapters so each destination receives a native payload format while Generic JSON endpoints receive the versioned Portivo event schema.
- Added multi-destination fan-out with independent outbox rows, delivery status, retries and backoff per destination. One failed webhook no longer blocks another configured channel.
- Recovery events are destination-aware and are sent only to destinations that successfully received the corresponding offline alert.
- Existing v1.3.7 Microsoft Teams configuration and delivery history are migrated automatically into the generic notification model.
- Webhook URLs remain encrypted at rest, masked after save and excluded from clear-text API or Audit Log output. Generic endpoints are HTTPS-only and protected against localhost/private-address targets.
- Added a compact incidents view that separates actual switch outages from technical webhook delivery failures.
- No Topology subsystem is included in this release.

## 1.3.7

- Added production-grade Microsoft Teams health notifications through Microsoft Power Automate / Teams workflow webhooks.
- Added an Admin Panel integration workspace with encrypted webhook storage, test delivery, enable/disable state, All vs Selected scope, Site and Group filters, outage threshold, recovery alerts and optional still-offline reminders.
- Added a deduplicated incident engine on top of the existing background TCP SSH health monitor. Offline notifications require 2–10 consecutive failed checks, with a default of 3; recovery is emitted only for incidents whose offline alert was actually delivered.
- Added a durable SQLite notification outbox with queued, retrying, delivering, delivered, failed and cancelled states, bounded retention, automatic retry/backoff and recent-delivery visibility.
- Webhook secrets are encrypted with the Portivo application secret, masked after save and never written to Audit Log entries or returned to the browser. Only HTTPS Microsoft Power Automate / Teams webhook hosts are accepted.
- Added structured Portivo notification payloads with switch identity, Site, Group, model, health evidence, incident timing and a ready-to-use Adaptive Card object for Power Automate workflows.
- Notification processing continues without an interactive SSH user because it is driven by the existing background TCP health monitor and Portivo service process.
- No Topology subsystem is included in this release.

## 1.3.6

- Normalized the in-app Roadmap so every stage displays exactly four bullets for consistent card height and visual rhythm.
- Shortened the Released capability summaries so they match the concise density of the In Progress, Next and Planned sections.
- Updated current-version indicators to v1.3.6.
- This release is UI/text-only. No audit commands, SSH behavior, configuration workflows or switch operations changed.
- No Topology subsystem is included in this release.

## 1.3.5

- Added a dedicated semantic icon for each of the nine active Fleet Audits: Thermal Health, Fan & Cooling, Power Supply Health, PoE Capacity, Interface Errors, Port Stability, Uplink Health, Configuration Save and Full Switch Health.
- Fleet Audit cards now use a consistent icon family with restrained per-audit visual tones so audit purpose can be recognized at a glance without changing the existing card hierarchy.
- Fleet Audits and Audit Log now use distinct sidebar icons that clearly separate audit execution from historical traceability.
- This release is UI-only for Fleet Audit iconography. No audit commands, SSH concurrency, assessment policies, PDF logic or switch configuration behavior changed.
- No Topology subsystem is included in this release.

## 1.3.4

- Retired **VLAN / UNP Consistency Audit** from new Fleet Audit runs because its protected-port and service-profile rules are environment-specific rather than general fleet-health checks.
- Retired **LAG Health Audit** from new Fleet Audit runs so the built-in Audit Library exposes only broadly applicable, validated operational assessments.
- The active Fleet Audit Library now contains nine read-only audits: Thermal Health, Fan & Cooling, Power Supply Health, PoE Capacity, Interface Errors, Port Stability, Uplink Health, Configuration Save and Full Switch Health.
- Existing v1.3.3 audit history remains readable and PDF-exportable for backward compatibility; retired audit types cannot be started through the UI or API.
- Updated the in-app Roadmap and current-version indicators to v1.3.4.
- No Topology subsystem is included in this release.

## 1.3.3

- Added **Fleet Audits**, a dedicated read-only diagnostics workspace for structured assessments across selected switches.
- Added eleven audit types: Thermal Health, Fan & Cooling, Power Supply Health, PoE Capacity, Interface Errors, Port Stability, Uplink Health, LAG Health, Configuration Save, VLAN / UNP Consistency and Full Switch Health. Firmware compliance is intentionally not included.
- Audit scope supports fleet filtering and exact device selection before execution. Large-fleet runs use bounded concurrency and one serialized SSH session per switch so same-device automation remains coordinated with existing Portivo operations.
- Thermal assessment uses the switch-reported temperature status and reported Danger / Thresh values when available. Numeric temperatures without verified device thresholds are reported without inventing limits.
- Added evidence-aware severity classification with Healthy, Informational, Warning, Critical and Unavailable outcomes. Unsupported AOS commands reduce coverage instead of creating false failures.
- Added live audit progress, per-switch evidence summaries, reusable audit history and read-only PDF export.
- Added professional executive PDF reports with first-page severity distribution, assessment policy, priority findings and detailed per-switch results. Thermal reports add threshold coverage, above-warning / critical sensor counts and highest observed temperatures.
- Fleet audit history participates in database maintenance retention so repeated large-fleet assessments do not grow the database without bounds.
- Added English and Greek Fleet Audit UI text and localized audit titles/policies in exported reports.
- Updated the in-app Roadmap so v1.3.3 is the Released baseline and Fleet Audits are represented as current product functionality.
- No Topology subsystem is included in this release.

## 1.3.2

- Fixed Live Port Details viewport clipping when Port Troubleshooter results expand beyond the visible screen.
- Port Details now uses a bounded two-row dialog layout with a fixed header and an independently scrollable content area.
- Added stable vertical scrolling, overscroll containment and mobile viewport handling so diagnostics, alias controls and port operations remain reachable at every screen size.
- No switch commands, SSH behavior, diagnostic logic or configuration workflows changed in this release.

## 1.3.1

- Added Port Troubleshooter inside Port Details with a focused, read-only live diagnostic pass for one switch port.
- Diagnostics correlate live interface state and media, error counters, PoE, learned MAC addresses, UNP identity, LLDP neighbors and recent Portivo port activity.
- Added conservative findings for no physical link, CRC/FCS or interface errors, drops/discards, collisions, PoE faults, multiple learned MAC addresses and missing endpoint evidence.
- Each diagnostic request uses one serialized SSH session and is scoped to the exact switch, port and modal session, so stale completions cannot overwrite another port dialog.
- Roadmap Released status now reflects the current v1.3.1 baseline and includes the Port Troubleshooter capability.
- v1.3.1 remains based on the v1.2.9 feature line plus the v1.3.0 race-safe alias fix. No Topology subsystem is included.

## 1.3.0

- Fixed the asynchronous Port Alias race condition in Live Port Details. Each alias save is now scoped to the exact device, port and modal session that initiated it.
- A completed older alias Job can no longer replace `activeWorkspacePort`, alias text, status messages, input state or Saving/Saved state in a newer port dialog.
- Added operation tracking for concurrent alias changes so users can move rapidly between ports without waiting for each alias Job to finish.
- Reworked silent port-inventory synchronization into a coalesced refresh that waits for active alias operations to settle, preventing stale refreshes from overwriting newer local port state.
- Auxiliary Pending Configuration and device-list refresh failures no longer misreport an already successful switch alias operation as failed.
- This release is built directly on the v1.2.9 feature baseline. No Topology subsystem implementation is included.

## 1.2.9

- Rebuilt Find Device as an intelligent endpoint locator with MAC as the primary identity across ARP, UNP, MAC forwarding and LLDP observations.
- Added identifier-specific staged search plans and a dedicated finder concurrency limit for faster large-fleet searches.
- IP searches now support static-IP endpoints, including a safe active probe and ARP retry when no current neighbor entry exists.
- Added topology-aware edge-port ranking. Candidate ports learned through inventory-matched LLDP switch neighbors are marked as upstream observations instead of physical endpoint locations.
- Added evidence-based confidence scoring, Best Match ranking and visible ARP, MAC, UNP and LLDP evidence.
- Added early results while enrichment is still running, so a located port can be used before optional IP enrichment finishes.
- Fixed UNP parsing so Profile ID is never treated as VLAN. VLAN, UNP Profile ID and UNP Profile Name are now separate fields.
- Removed unsafe cross-source correlation by port alone. Endpoint data is correlated by MAC identity, preventing unrelated devices on the same port from being merged.
- Added a bounded `endpoint_last_seen` index that stores only the latest verified location per MAC and exposes last-known location when live resolution fails.
- Split VLAN and UNP Profile into separate explicit search types while keeping Automatic detection for common identifiers.
- Improved Find Device UI with Best Match cards, edge/uplink labels, confidence, evidence, last-known state and active-resolution feedback.

## 1.2.8

- Renamed the grouped persistence action to `Save All Changes` for clearer intent.
- Improved the Save All Changes button contrast and readability in the pending configuration dialog.
- Added an explicit `Saving...` state while the grouped persistent-save Job is running.
- The pending configuration dialog now closes automatically only after the grouped save finishes successfully.
- Failed or partially completed saves keep the dialog open, refresh the remaining pending changes and show a clear error message.
- No icon is shown on the Save All Changes button.

## 1.2.7

- Added grouped configuration persistence. Configuration changes no longer trigger an automatic persistent save after every operation.
- Added per-switch unsaved configuration tracking with change history, timestamps, actor and originating Job references.
- Added a global Unsaved configuration panel with Save per switch and Save all controls.
- Added unsaved indicators in device inventory and switch workspace metadata.
- Save configuration now clears the pending state only after a confirmed persistent save.
- Transient restart workflows do not create pending configuration state or unnecessary write-memory operations.

## 1.2.6

- Fixed Windows update/repair runtime detection by replacing inline `python -c` version probes with `python.exe --version` parsing.
- This prevents valid existing private Python runtimes from failing with `File "<string>", line 1` during an update.
- Reworked the repository README into a concise English product overview and moved deployment details to `INSTALLATION.md`.
- Updated the Windows deployment firewall rule so LAN access on TCP 8766 covers Domain, Private and Public network profiles.
- Existing Portivo firewall rules are updated to the new profile set during install, update or repair.
- Kept the application listener on `0.0.0.0:8766` and added deployment guidance for Public-profile Windows servers.
- Bundled Windows and Linux deployment entry points in the same distribution package with an expanded README.
- No switch-command or SSH execution behavior changed from 1.2.5.

## 1.2.5

- Added an in-app Roadmap entry above the personal SSH profile with Roadmap and Changelog tabs.
- Roadmap stages use Released, In progress, Next, Planned and Exploring instead of fixed delivery dates.
- The embedded changelog highlights the operational changes from the current v1.2.5 line without changing the application version.
- Replaced best-effort per-device locking with a strict FIFO automation queue so separate Jobs targeting the same switch cannot overtake each other.
- Persistent configuration transactions now keep the switch lease through save completion, stable-prompt synchronization, SSH disconnect and a short post-save cooldown.
- Added a longer fallback cooldown when prompt synchronization cannot be confirmed within the configured window, without converting an otherwise successful save into a false failure.
- Added guarded authentication retry for the exact same credential fingerprint only when those credentials succeeded recently on the same switch.
- Bad or unproven credentials still fail immediately, reducing unnecessary authentication attempts and account-lockout risk.
- Different switches remain independent and continue to run concurrently.
- Added regression coverage for FIFO ordering, post-save cooldown, cross-device independence, stable-prompt waiting and guarded SSH authentication recovery.

## 1.2.4

- Restart PoE and Restart Interface are now treated as transient operations: disable, wait, enable, finish.
- Removed post-cycle verification and persistent configuration save from both restart actions.
- Added a concise `OPERATION STATUS` result instead of false verification or save failures.
- Dashboard Connectivity now reports an explicit Unknown count from the backend.
- Connectivity percentage is displayed to one decimal place and is floored rather than rounded, so a degraded fleet can never appear as 100%.
- The connectivity ring still uses the precise online ratio for its visual angle.
- Added regression tests for transient restart workflows and fleet percentage calculation.

## 1.2.3

- Simplified port alias workflow: apply alias, save persistent configuration, finish.
- Removed the unreliable post-command alias verification based on `show interfaces`.
- Added visible Saving and Saved states directly inside the port details dialog.
- Prevented the port details dialog from being closed and reopened after an alias update.
- Updates the switch map and port table immediately, followed by a silent inventory refresh.
- Real CLI or persistent-save failures remain visible, while false verification failures are eliminated.

## 1.2.2

- Fixed false command failures caused by normal counters such as `Error Frames`, `CRC Error Frames` and `Alignment Errors` in `show interfaces` output.
- Configuration jobs now keep one per-switch lock and one SSH connection for the primary command, verification and persistent save.
- Increased the compatibility queue window for configuration jobs so short inventory or health operations are awaited instead of returning `The switch is busy with command execution`.
- Added semantic alias verification that confirms the requested alias value on the target port rather than treating any successful `show interfaces` response as sufficient.
- Persistent save is skipped when verification genuinely fails, preventing an unverified state from being written to flash.
- Added a transaction status section to Job output with separate command, verification and persistent-save results.
- Added regression tests covering one-session configuration transactions and counter text that must not be classified as a CLI error.

## 1.2.1

- Added a compatibility-first per-switch SSH coordinator that serializes automated operations and prevents the interactive terminal from competing for the same switch session.
- Disabled terminal auto-connect. The terminal now connects only after an explicit user action and closes after a configurable idle period.
- Added safe SSH connection retries with progressive backoff and clearer busy, timeout and authentication errors.
- Reworked Live Port Inventory to collect interface, VLAN and PoE data through one SSH connection per refresh.
- Added persistent last-successful inventory snapshots. Temporary SSH failures now keep cached port data visible instead of clearing the workspace.
- Added model-derived front-panel layouts that appear immediately while live data is collected. Known 48-port models render as a symmetric 4 x 12 access-port panel, with uplinks separated. The initial model layout remains static and neutral instead of showing an empty or animated loading state.
- Removed large success and warning banners from the switch workspace and replaced them with a compact status badge.
- Improved workspace symmetry so the switch panel and command widget share the same vertical alignment.
- Added regression tests for SSH coordination, cached inventory fallback and model-based port layouts.

## 1.2.0

- Rebuilt Live Port Inventory around separate authoritative AOS parsers for state/alias, media status, VLAN membership and PoE.
- Fixed false aliases such as `- DIS - en dis` and stopped presenting unreported fields as guessed values.
- Added logical switch front panel with clickable port tiles, state legend, module grouping and PoE indication.
- Added enterprise port table with aliases, Admin State, Physical Link, observed duration, media, VLANs, PoE and detail actions.
- Added verified per-port alias editing through the existing audited job engine.
- Added `port_state_cache` for current-state transition timestamps and Portivo-observed duration.
- Added capability/data-assurance reporting and parser regression tests.

## 1.1.1

* Replaced the repetitive login headline with `Control Without Complexity`.
* Kept the existing login description, security notice, independent-project notice, layout, and functionality unchanged.
* Updated application and static asset version identifiers for the patch release.

## 1.1.0

### Added

* Server-side search and filtering for Jobs.
* Job filters for status, operation, mode, source and date range.
* Search across job item switch names, IP addresses, commands, output, verification output and errors.
* Server-side search and filtering for Audit Log.
* Audit filters for actor, event, object type and date range.
* Dynamic filter options, result counters and one-click filter reset.
* SQLite indexes for common Jobs and Audit filtering fields.

### Changed

* Jobs history result limit increased to 500, with a protected maximum of 1000.
* Audit history result limit increased to 750, with a protected maximum of 1500.
* Static asset cache version updated for the v1.1.0 release.
