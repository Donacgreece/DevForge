# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
# Portivo Control Center branded Windows installer and updater
# Version is read from installer-manifest.json and payload\VERSION.

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$InstallerRoot = Split-Path -Parent $PSCommandPath
$ManifestPath = Join-Path $InstallerRoot 'installer-manifest.json'
if (-not (Test-Path $ManifestPath)) { throw 'installer-manifest.json was not found.' }
$Manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json

$InstallRoot = [string]$Manifest.install_path
$PackageVersion = [string]$Manifest.version
$PackageRevision = [string]$Manifest.revision
$PythonVersion = [string]$Manifest.python_runtime
$PythonUrl = [string]$Manifest.python_url
$ExpectedPythonHash = [string]$Manifest.python_sha256
$PipBootstrapVersion = [string]$Manifest.pip_bootstrap_version
$PipBootstrapUrl = [string]$Manifest.pip_bootstrap_url
$ExpectedPipBootstrapHash = [string]$Manifest.pip_bootstrap_sha256
$WinSWUrl = [string]$Manifest.winsw_url
$ExpectedWinSWHash = [string]$Manifest.winsw_sha256
$ServiceName = [string]$Manifest.service_name
$Port = [int]$Manifest.port
$PayloadZip = Join-Path $InstallerRoot 'payload\portivo-app.zip'
$ExpectedPayloadHash = [string]$Manifest.payload_sha256
$LogoPath = Join-Path $InstallerRoot 'assets\portivo-logo-white.png'
$IconPath = Join-Path $InstallerRoot 'assets\portivo.ico'
$FirewallRuleName = "Portivo Control Center TCP $Port"
$UninstallRegistryKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PortivoControlCenter'
$RuntimeRoot = Join-Path $InstallRoot 'runtime\python'
$RuntimeRollbackRoot = Join-Path $InstallRoot 'runtime\python.installer-backup'
$PythonExe = Join-Path $RuntimeRoot 'python.exe'
$ServiceDir = Join-Path $InstallRoot 'service'
$ServiceExe = Join-Path $ServiceDir 'PortivoService.exe'
$ServiceXml = Join-Path $ServiceDir 'PortivoService.xml'
$DownloadCache = Join-Path $InstallRoot 'runtime\downloads'
$InstallLog = Join-Path $env:TEMP ("Portivo-Installer-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

if (-not (Test-Path $PayloadZip)) { throw 'Portivo application payload is missing.' }
if ($ExpectedPayloadHash) {
    $actualPayloadHash = (Get-FileHash -Path $PayloadZip -Algorithm SHA256).Hash
    if ($actualPayloadHash -ne $ExpectedPayloadHash) { throw 'Portivo application payload integrity check failed.' }
}

function Write-InstallLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -Path $InstallLog -Value $line -Encoding UTF8
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    $args = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args
    exit
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

if (-not [Environment]::Is64BitOperatingSystem) {
    [System.Windows.MessageBox]::Show('Portivo requires 64-bit Windows.', 'Portivo Setup', 'OK', 'Error') | Out-Null
    exit 1
}

function Invoke-ProcessChecked {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$false)][string[]]$ArgumentList = @(),
        [Parameter(Mandatory=$false)][string]$WorkingDirectory = $InstallRoot
    )
    if ([string]::IsNullOrWhiteSpace($WorkingDirectory) -or -not (Test-Path -LiteralPath $WorkingDirectory -PathType Container)) {
        throw "Process working directory does not exist or is not a directory: $WorkingDirectory"
    }
    Write-InstallLog ("RUN: {0} {1}" -f $FilePath, ($ArgumentList -join ' '))
    $stdout = Join-Path $env:TEMP ("portivo-out-{0}.txt" -f [guid]::NewGuid().ToString('N'))
    $stderr = Join-Path $env:TEMP ("portivo-err-{0}.txt" -f [guid]::NewGuid().ToString('N'))
    try {
        $process = Start-Process -FilePath $FilePath -ArgumentList $ArgumentList -WorkingDirectory $WorkingDirectory -Wait -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        $stdoutLines = @()
        $stderrLines = @()
        if (Test-Path $stdout) { $stdoutLines = @(Get-Content $stdout -ErrorAction SilentlyContinue); $stdoutLines | ForEach-Object { Write-InstallLog "OUT: $_" } }
        if (Test-Path $stderr) { $stderrLines = @(Get-Content $stderr -ErrorAction SilentlyContinue); $stderrLines | ForEach-Object { Write-InstallLog "ERR: $_" } }
        if ($process.ExitCode -ne 0) {
            $detailSource = if ($stderrLines.Count -gt 0) { $stderrLines } else { $stdoutLines }
            $detailLines = @($detailSource) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Select-Object -Last 8
            $detail = if ($detailLines.Count -gt 0) { "`n" + ($detailLines -join "`n") } else { '' }
            throw "Process exited with code $($process.ExitCode): $FilePath$detail"
        }
    } finally {
        Remove-Item $stdout,$stderr -Force -ErrorAction SilentlyContinue
    }
}

function Download-File {
    param([string]$Uri, [string]$Destination)
    New-Item -ItemType Directory -Path (Split-Path -Parent $Destination) -Force | Out-Null
    Write-InstallLog "Downloading $Uri"
    if (Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue) {
        try {
            Start-BitsTransfer -Source $Uri -Destination $Destination -ErrorAction Stop
            return
        } catch {
            Write-InstallLog "BITS download failed. Falling back to Invoke-WebRequest: $($_.Exception.Message)"
        }
    }
    Invoke-WebRequest -UseBasicParsing -Uri $Uri -OutFile $Destination
}

function Assert-FileSha256 {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Expected,
        [Parameter(Mandatory=$true)][string]$Label
    )
    if (-not (Test-Path $Path)) { throw "$Label was not found after download." }
    if ([string]::IsNullOrWhiteSpace($Expected)) { throw "$Label does not have a pinned SHA-256 value in installer-manifest.json." }
    $actual = (Get-FileHash -Path $Path -Algorithm SHA256).Hash
    if ($actual -ne $Expected.ToUpperInvariant()) {
        Remove-Item $Path -Force -ErrorAction SilentlyContinue
        throw "$Label SHA-256 integrity check failed."
    }
    Write-InstallLog "$Label SHA-256 verified: $actual"
}

function Assert-AuthenticodeValid {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Label
    )
    $sig = Get-AuthenticodeSignature -FilePath $Path
    if ($sig.Status -ne 'Valid') {
        throw "$Label Authenticode validation failed with status $($sig.Status)."
    }
    Write-InstallLog "$Label Authenticode signature: $($sig.SignerCertificate.Subject)"
}

function Get-InstalledVersion {
    $versionFile = Join-Path $InstallRoot 'VERSION'
    if (Test-Path $versionFile) { return (Get-Content $versionFile -Raw).Trim() }
    return $null
}

function Stop-PortivoService {
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne 'Stopped') {
        Write-InstallLog 'Stopping Portivo Windows Service.'
        Stop-Service -Name $ServiceName -Force -ErrorAction Stop
        $service.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
    }
    for ($i = 0; $i -lt 30; $i++) {
        $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $listener) { return }
        $proc = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
        $path = ''
        try { $path = [string]$proc.Path } catch { }
        if ($path -and $path.StartsWith($InstallRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            Write-InstallLog "Waiting for previous Portivo process PID $($listener.OwningProcess) to release TCP $Port."
            if ($i -ge 20) {
                try { Stop-Process -Id $listener.OwningProcess -Force -ErrorAction Stop; Write-InstallLog "Stopped stale Portivo process PID $($listener.OwningProcess)." } catch { }
            }
        } else {
            throw "TCP port $Port is already used by another process (PID $($listener.OwningProcess)). Stop that process before updating Portivo."
        }
        Start-Sleep -Milliseconds 500
    }
}

function Start-PortivoService {
    Write-InstallLog 'Starting Portivo Windows Service.'
    Start-Service -Name $ServiceName -ErrorAction Stop
    $service = Get-Service -Name $ServiceName
    $service.WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
}

function New-PortivoBackup {
    if (-not (Test-Path $InstallRoot)) { return $null }
    $backupBase = Join-Path $InstallRoot 'backups'
    New-Item -ItemType Directory -Path $backupBase -Force | Out-Null
    $backup = Join-Path $backupBase ("installer-{0}-before-{1}" -f (Get-Date -Format 'yyyyMMdd-HHmmss'), $PackageVersion)
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Write-InstallLog "Creating upgrade backup at $backup"
    $args = @(
        "`"$InstallRoot`"", "`"$backup`"", '/E', '/R:2', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS',
        '/XD', "`"$InstallRoot\backups`"", "`"$InstallRoot\runtime`"", "`"$InstallRoot\logs`"", "`"$InstallRoot\.venv`""
    )
    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($p.ExitCode -gt 7) { throw "Backup failed. Robocopy exit code: $($p.ExitCode)" }
    return $backup
}

function Restore-PortivoBackup {
    param([string]$BackupPath)
    if (-not $BackupPath -or -not (Test-Path $BackupPath)) { return }
    Write-InstallLog "Restoring application from $BackupPath"
    foreach ($dir in @('app','scripts','docs','examples','deployment','THIRD_PARTY_LICENSES')) {
        $target = Join-Path $InstallRoot $dir
        if (Test-Path $target) { Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue }
    }
    $args = @("`"$BackupPath`"", "`"$InstallRoot`"", '/E', '/R:2', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS')
    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($p.ExitCode -gt 7) { Write-InstallLog "Rollback robocopy returned code $($p.ExitCode)." }
    if ((Test-Path $PythonExe) -and (Test-Path (Join-Path $InstallRoot 'requirements.lock'))) {
        try { Invoke-ProcessChecked $PythonExe @('-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--no-deps','-r',(Join-Path $InstallRoot 'requirements.lock')) $InstallRoot } catch { Write-InstallLog "Dependency rollback warning: $($_.Exception.Message)" }
    }
}

function Install-ApplicationPayload {
    if (-not (Test-Path $PayloadZip)) { throw 'Portivo application payload is missing.' }
    $temp = Join-Path $env:TEMP ("PortivoPayload-{0}" -f [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temp -Force | Out-Null
    try {
        Expand-Archive -Path $PayloadZip -DestinationPath $temp -Force
        New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
        foreach ($dir in @('app','scripts','docs','examples','deployment','THIRD_PARTY_LICENSES')) {
            $source = Join-Path $temp $dir
            $target = Join-Path $InstallRoot $dir
            if (Test-Path $target) { Remove-Item $target -Recurse -Force }
            if (Test-Path $source) { Copy-Item $source $target -Recurse -Force }
        }
        $dataTarget = Join-Path $InstallRoot 'data'
        New-Item -ItemType Directory -Path $dataTarget -Force | Out-Null
        foreach ($catalog in @('command_profiles.json','action_catalog.json','ale_cli_validation.json')) {
            Copy-Item (Join-Path $temp "data\$catalog") (Join-Path $dataTarget $catalog) -Force
        }
        foreach ($file in @('run.py','requirements.txt','requirements.in','requirements.lock','VERSION','LICENSE','LEGAL.md','THIRD_PARTY_NOTICES.md','TRADEMARKS.md','SBOM.spdx.json','CONTRIBUTING.md','README.md','CHANGELOG.md','INSTALLATION.md','.env.example')) {
            $source = Join-Path $temp $file
            if (Test-Path $source) { Copy-Item $source (Join-Path $InstallRoot $file) -Force }
        }
        foreach ($requiredFile in @('VERSION','LICENSE','LEGAL.md','THIRD_PARTY_NOTICES.md','TRADEMARKS.md','SBOM.spdx.json','CONTRIBUTING.md','requirements.lock','README.md','INSTALLATION.md')) {
            $installedFile = Join-Path $InstallRoot $requiredFile
            if (-not (Test-Path $installedFile)) {
                throw "Portivo application payload is incomplete after extraction. Missing required file: $requiredFile"
            }
        }
    } finally {
        Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Get-PrivatePythonVersion {
    if (-not (Test-Path $PythonExe)) { return $null }
    try {
        $versionOutput = (& $PythonExe --version 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) { return $null }
        $match = [regex]::Match($versionOutput, 'Python\s+(\d+\.\d+\.\d+)')
        if ($match.Success) { return $match.Groups[1].Value }
        return $null
    } catch {
        return $null
    }
}

function Test-PrivatePythonRuntime {
    $actual = Get-PrivatePythonVersion
    return $actual -eq $PythonVersion
}

function Restore-PrivatePythonRollback {
    if (-not (Test-Path $RuntimeRollbackRoot)) { return }
    Write-InstallLog 'Restoring the previous private Python runtime.'
    if (Test-Path $RuntimeRoot) {
        Remove-Item $RuntimeRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    Move-Item $RuntimeRollbackRoot $RuntimeRoot -Force
}

function Remove-PrivatePythonRollback {
    if (Test-Path $RuntimeRollbackRoot) {
        Remove-Item $RuntimeRollbackRoot -Recurse -Force -ErrorAction SilentlyContinue
        Write-InstallLog 'Removed temporary Python runtime rollback copy after successful validation.'
    }
}

function Configure-EmbeddedPythonPaths {
    # The official CPython embeddable package uses pythonXY._pth isolation.
    # Portivo needs both normal Lib\site-packages discovery and the application
    # root itself on sys.path so the WinSW service can import the `app` package.
    $pth = Get-ChildItem -Path $RuntimeRoot -Filter 'python*._pth' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $pth) { throw 'Embedded CPython path configuration file was not found.' }

    $updated = @()
    foreach ($line in @(Get-Content $pth.FullName -ErrorAction Stop)) {
        $trimmed = $line.Trim()
        if ($trimmed -eq '..\..' -or $trimmed -eq '../..') { continue }
        if ($line -match '^\s*#?\s*import\s+site\s*$') { continue }
        $updated += $line
    }
    # Relative to C:\portivo-control-center\runtime\python, ..\.. is the
    # Portivo application root. _pth paths are resolved relative to python.exe.
    $updated += '..\..'
    $updated += 'import site'
    $updated | Set-Content -Path $pth.FullName -Encoding ASCII
    New-Item -ItemType Directory -Path (Join-Path $RuntimeRoot 'Lib\site-packages') -Force | Out-Null
}

function Test-PortivoRuntimeImports {
    # The service directory is created later by Ensure-PortivoServiceWrapper.
    # On a fresh/recovery install it does not exist yet, so using it as a
    # Start-Process WorkingDirectory causes PowerShell to reject the command.
    # The runtime probe must execute from the application root, which already
    # exists after Install-ApplicationPayload and matches the WinSW service CWD.
    if (-not (Test-Path -LiteralPath $InstallRoot -PathType Container)) {
        throw "Portivo application root does not exist before runtime validation: $InstallRoot"
    }
    $probe = Join-Path $RuntimeRoot 'portivo-import-probe.py'
    try {
        @'
import pathlib
import sys
import app
from app.config import settings
root = pathlib.Path(__file__).resolve().parents[2]
print(f"Portivo import probe OK: root={root}; app={pathlib.Path(app.__file__).resolve()}")
'@ | Set-Content -Path $probe -Encoding UTF8
        Invoke-ProcessChecked $PythonExe @($probe) $InstallRoot
    } finally {
        Remove-Item $probe -Force -ErrorAction SilentlyContinue
    }
}

function Ensure-PipBootstrapWheel {
    if ([string]::IsNullOrWhiteSpace($PipBootstrapVersion) -or [string]::IsNullOrWhiteSpace($PipBootstrapUrl) -or [string]::IsNullOrWhiteSpace($ExpectedPipBootstrapHash)) {
        throw 'Pinned pip bootstrap metadata is missing from installer-manifest.json.'
    }
    New-Item -ItemType Directory -Path $DownloadCache -Force | Out-Null
    $wheel = Join-Path $DownloadCache ("pip-{0}-py3-none-any.whl" -f $PipBootstrapVersion)
    $downloadRequired = $true
    if (Test-Path $wheel) {
        try {
            Assert-FileSha256 $wheel $ExpectedPipBootstrapHash 'pip bootstrap wheel'
            $downloadRequired = $false
        } catch {
            Write-InstallLog "Cached pip bootstrap wheel was rejected: $($_.Exception.Message)"
            Remove-Item $wheel -Force -ErrorAction SilentlyContinue
        }
    }
    if ($downloadRequired) {
        Download-File $PipBootstrapUrl $wheel
        Assert-FileSha256 $wheel $ExpectedPipBootstrapHash 'pip bootstrap wheel'
    }
    return $wheel
}

function Install-PipIntoPrivateRuntime {
    $wheel = Ensure-PipBootstrapWheel
    $bootstrap = Join-Path $DownloadCache 'portivo-pip-bootstrap.py'
    @'
import runpy
import sys

wheel = sys.argv.pop(1)
sys.path.insert(0, wheel)
runpy.run_module("pip", run_name="__main__")
'@ | Set-Content -Path $bootstrap -Encoding UTF8

    Invoke-ProcessChecked $PythonExe @(
        $bootstrap,
        $wheel,
        'install',
        '--disable-pip-version-check',
        '--no-deps',
        '--force-reinstall',
        $wheel
    ) $InstallRoot

    Invoke-ProcessChecked $PythonExe @('-m','pip','--version') $InstallRoot
}

function Ensure-PrivatePython {
    # Use CPython's official embeddable ZIP rather than the registered Windows
    # installer. This is a true application-local runtime: it does not register
    # Python with Windows, does not modify PATH and cannot be redirected into
    # maintenance mode by another Python installation already present on the PC.
    if (Test-PrivatePythonRuntime) {
        Configure-EmbeddedPythonPaths
        Assert-AuthenticodeValid $PythonExe 'Installed CPython runtime'
        $actual = Get-PrivatePythonVersion
        Write-InstallLog "Private Python runtime already present: $actual"
        try {
            & $PythonExe -m pip --version *> $null
            if ($LASTEXITCODE -ne 0) { throw 'pip is missing' }
        } catch {
            Write-InstallLog 'pip is missing from the existing private runtime. Restoring pinned pip bootstrap.'
            Install-PipIntoPrivateRuntime
        }
        return
    }

    # Recover the previous runtime if an earlier installer transaction was
    # interrupted before its rollback/cleanup path completed.
    if ((-not (Test-Path $RuntimeRoot)) -and (Test-Path $RuntimeRollbackRoot)) {
        Write-InstallLog 'Recovering the previous private Python runtime from an interrupted installer transaction.'
        Move-Item $RuntimeRollbackRoot $RuntimeRoot -Force
        if (Test-PrivatePythonRuntime) {
            Configure-EmbeddedPythonPaths
            Assert-AuthenticodeValid $PythonExe 'Recovered CPython runtime'
            Write-InstallLog "Recovered private Python runtime: $(Get-PrivatePythonVersion)"
            try {
                & $PythonExe -m pip --version *> $null
                if ($LASTEXITCODE -ne 0) { throw 'pip is missing' }
            } catch {
                Install-PipIntoPrivateRuntime
            }
            return
        }
    }

    if (Test-Path $RuntimeRollbackRoot) {
        # A previous runtime is already preserved. The primary runtime is an
        # incomplete replacement and must never overwrite the rollback copy.
        if (Test-Path $RuntimeRoot) {
            Write-InstallLog 'Discarding an incomplete replacement Python runtime while preserving the previous rollback copy.'
            Remove-Item $RuntimeRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    } elseif (Test-Path $RuntimeRoot) {
        Write-InstallLog 'Private Python runtime is missing, outdated or incomplete. Preserving it for rollback before extracting the pinned CPython runtime.'
        Move-Item $RuntimeRoot $RuntimeRollbackRoot -Force
    }

    New-Item -ItemType Directory -Path $DownloadCache -Force | Out-Null
    $archive = Join-Path $DownloadCache "python-$PythonVersion-embed-amd64.zip"
    $downloadRequired = $true
    if (Test-Path $archive) {
        try {
            Assert-FileSha256 $archive $ExpectedPythonHash 'CPython embeddable package'
            $downloadRequired = $false
        } catch {
            Write-InstallLog "Cached CPython embeddable package was rejected: $($_.Exception.Message)"
            Remove-Item $archive -Force -ErrorAction SilentlyContinue
        }
    }
    if ($downloadRequired) {
        Download-File $PythonUrl $archive
        Assert-FileSha256 $archive $ExpectedPythonHash 'CPython embeddable package'
    }

    if (Test-Path $RuntimeRoot) {
        Remove-Item $RuntimeRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $RuntimeRoot -Force | Out-Null
    Write-InstallLog "Extracting official CPython $PythonVersion embeddable package into $RuntimeRoot"
    Expand-Archive -Path $archive -DestinationPath $RuntimeRoot -Force

    if (-not (Test-Path $PythonExe)) { throw 'CPython embeddable package did not produce python.exe.' }
    Configure-EmbeddedPythonPaths
    Assert-AuthenticodeValid $PythonExe 'Installed CPython runtime'

    $actual = Get-PrivatePythonVersion
    if ($actual -ne $PythonVersion) { throw "Unexpected private Python version. Expected $PythonVersion, found $actual." }
    Write-InstallLog "Application-local Python runtime ready: $actual"

    Install-PipIntoPrivateRuntime
}

function Install-PythonDependencies {
    $cache = Join-Path $InstallRoot 'runtime\pip-cache'
    New-Item -ItemType Directory -Path $cache -Force | Out-Null
    # The release lock already contains every runtime dependency as an exact pin.
    # Do not self-upgrade pip, do not re-resolve transitive dependencies, and do
    # not execute source distributions on Windows.
    Invoke-ProcessChecked $PythonExe @('-m','pip','install','--disable-pip-version-check','--cache-dir',$cache,'--only-binary=:all:','--no-deps','-r',(Join-Path $InstallRoot 'requirements.lock')) $InstallRoot
    Invoke-ProcessChecked $PythonExe @('-m','pip','check') $InstallRoot
}

function Set-EnvValue {
    param([string]$Path, [string]$Name, [string]$Value)
    $lines = @()
    if (Test-Path $Path) { $lines = @(Get-Content $Path) }
    $found = $false
    $newLines = foreach ($line in $lines) {
        if ($line -match ('^' + [regex]::Escape($Name) + '=')) {
            $found = $true
            "$Name=$Value"
        } else { $line }
    }
    if (-not $found) { $newLines += "$Name=$Value" }
    $newLines | Set-Content -Path $Path -Encoding UTF8
}

function Ensure-PortivoEnvironment {
    $envFile = Join-Path $InstallRoot '.env'
    if (-not (Test-Path $envFile)) {
        $secret = (& $PythonExe (Join-Path $InstallRoot 'scripts\generate_secret.py')).Trim()
        @"
APP_NAME=Portivo Control Center
APP_VERSION=$PackageVersion
APP_HOST=0.0.0.0
APP_PORT=$Port
APP_SECRET_KEY=$secret
APP_ADMIN_USERNAME=admin
PUBLIC_URL_SCHEME=http
TRUST_PROXY_HEADERS=false
TRUSTED_PROXY_IPS=127.0.0.1,::1
LOGIN_RATE_LIMIT_ENABLED=true
LOGIN_RATE_LIMIT_WINDOW_SECONDS=300
LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS=30
SSH_CONNECT_TIMEOUT=12
AUTH_CONNECT_TIMEOUT=2.5
AUTH_GLOBAL_TIMEOUT_SECONDS=5
AUTH_MAX_SOURCES=5
SSH_COMMAND_TIMEOUT=30
SSH_CONNECT_RETRIES=3
SSH_RETRY_BACKOFF_SECONDS=0.75
SSH_OPERATION_LOCK_TIMEOUT=180
SSH_POST_SAVE_PROMPT_TIMEOUT=20
SSH_POST_SAVE_COOLDOWN_SECONDS=2
SSH_POST_SAVE_FALLBACK_COOLDOWN_SECONDS=5
SSH_RECENT_AUTH_SUCCESS_WINDOW_SECONDS=60
SSH_RECENT_AUTH_RETRY_DELAY_SECONDS=2
SSH_TERMINAL_IDLE_MINUTES=15
MAX_PARALLEL_SWITCHES=6
FINDER_MAX_PARALLEL_SWITCHES=12
HEALTH_MONITOR_ENABLED=true
HEALTH_POLL_INTERVAL_SECONDS=30
HEALTH_PING_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_POLL_INTERVAL_SECONDS=120
HEALTH_MAX_PARALLEL_SWITCHES=32
HEALTH_PING_ATTEMPTS=3
HEALTH_PING_RETRY_DELAY_SECONDS=5
HEALTH_POLL_JITTER_SECONDS=10
HEALTH_OFFLINE_POLL_INTERVAL_SECONDS=60
HEALTH_LONG_OFFLINE_AFTER_SECONDS=900
HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS=120
DATABASE_PATH=./data/portivo.db
COMMAND_PROFILES_PATH=./data/command_profiles.json
ACTION_CATALOG_PATH=./data/action_catalog.json
"@ | Set-Content -Path $envFile -Encoding UTF8
    }
    Set-EnvValue $envFile 'APP_VERSION' $PackageVersion
    Set-EnvValue $envFile 'FINDER_MAX_PARALLEL_SWITCHES' '12'
    if (-not (Select-String -Path $envFile -Pattern '^PUBLIC_URL_SCHEME=' -Quiet)) {
        $legacySecure = Select-String -Path $envFile -Pattern '^COOKIE_SECURE=(true|1|yes|on)$' -CaseSensitive:$false -Quiet
        Add-Content -Path $envFile -Value ('PUBLIC_URL_SCHEME=' + $(if ($legacySecure) { 'https' } else { 'http' })) -Encoding UTF8
    }
    foreach ($pair in @(@('TRUST_PROXY_HEADERS','false'),@('TRUSTED_PROXY_IPS','127.0.0.1,::1'),@('LOGIN_RATE_LIMIT_ENABLED','true'),@('LOGIN_RATE_LIMIT_WINDOW_SECONDS','300'),@('LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS','30'),@('AUTH_CONNECT_TIMEOUT','2.5'),@('AUTH_GLOBAL_TIMEOUT_SECONDS','5'),@('AUTH_MAX_SOURCES','5'),@('HEALTH_PING_TIMEOUT_SECONDS','1.5'),@('HEALTH_SNMP_TIMEOUT_SECONDS','1.5'),@('HEALTH_SNMP_POLL_INTERVAL_SECONDS','120'),@('HEALTH_MAX_PARALLEL_SWITCHES','32'),@('HEALTH_PING_ATTEMPTS','3'),@('HEALTH_PING_RETRY_DELAY_SECONDS','5'),@('HEALTH_POLL_JITTER_SECONDS','10'),@('HEALTH_OFFLINE_POLL_INTERVAL_SECONDS','60'),@('HEALTH_LONG_OFFLINE_AFTER_SECONDS','900'),@('HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS','120'))) {
        $name = $pair[0]; $value = $pair[1]
        if (-not (Select-String -Path $envFile -Pattern ('^' + [regex]::Escape($name) + '=') -Quiet)) { Add-Content -Path $envFile -Value ("$name=$value") -Encoding UTF8 }
    }
}

function Initialize-PortivoDatabase {
    param([string]$AdminPassword, [bool]$FreshInstall)
    if ($FreshInstall) {
        if ([string]::IsNullOrWhiteSpace($AdminPassword) -or $AdminPassword.Length -lt 12) { throw 'Administrator password must contain at least 12 characters.' }
        try {
            $env:OSC_ADMIN_PASSWORD = $AdminPassword
            Invoke-ProcessChecked $PythonExe @((Join-Path $InstallRoot 'scripts\set_admin_password.py'),'--username','admin') $InstallRoot
        } finally {
            Remove-Item Env:OSC_ADMIN_PASSWORD -ErrorAction SilentlyContinue
        }
    } else {
        $migrationScript = Join-Path $env:TEMP ("Portivo-Migrate-{0}.py" -f [guid]::NewGuid().ToString('N'))
        try {
            @"
import sys
sys.path.insert(0, r'$InstallRoot')
from app.db import init_db
init_db()
print('Database migrations complete')
"@ | Set-Content -Path $migrationScript -Encoding UTF8
            Invoke-ProcessChecked $PythonExe @($migrationScript) $InstallRoot
        } finally {
            Remove-Item $migrationScript -Force -ErrorAction SilentlyContinue
        }
    }
    Invoke-ProcessChecked $PythonExe @((Join-Path $InstallRoot 'scripts\validate_installation.py')) $InstallRoot
}

function Ensure-PortivoServiceWrapper {
    New-Item -ItemType Directory -Path $ServiceDir -Force | Out-Null
    $needWinSW = $true
    if (Test-Path $ServiceExe) {
        try {
            Assert-FileSha256 $ServiceExe $ExpectedWinSWHash 'WinSW service wrapper'
            $needWinSW = $false
        } catch {
            Write-InstallLog "Existing WinSW wrapper was rejected: $($_.Exception.Message)"
            Remove-Item $ServiceExe -Force -ErrorAction SilentlyContinue
        }
    }
    if ($needWinSW) {
        Download-File $WinSWUrl $ServiceExe
        Assert-FileSha256 $ServiceExe $ExpectedWinSWHash 'WinSW service wrapper'
    }
    $xml = @"
<service>
  <id>$ServiceName</id>
  <name>Portivo Control Center</name>
  <description>Portivo network operations platform.</description>
  <executable>$PythonExe</executable>
  <arguments>run.py</arguments>
  <workingdirectory>$InstallRoot</workingdirectory>
  <startmode>Automatic</startmode>
  <delayedAutoStart>true</delayedAutoStart>
  <depend>Tcpip</depend>
  <hidewindow>true</hidewindow>
  <stoptimeout>20sec</stoptimeout>
  <logpath>$InstallRoot\logs</logpath>
  <log mode="roll-by-size">
    <sizeThreshold>10240</sizeThreshold>
    <keepFiles>8</keepFiles>
  </log>
  <onfailure action="restart" delay="10 sec" />
  <onfailure action="restart" delay="20 sec" />
  <onfailure action="restart" delay="30 sec" />
  <env name="PYTHONUNBUFFERED" value="1" />
</service>
"@
    $xml | Set-Content -Path $ServiceXml -Encoding UTF8
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service) {
        # WinSW 2.12 does not provide a `refresh` command. Recreate the stopped
        # registration so SCM always receives the current XML/service wrapper.
        Write-InstallLog 'Recreating existing Windows Service registration with the current WinSW configuration.'
        try { & sc.exe stop $ServiceName | Out-Null } catch { }
        & sc.exe delete $ServiceName | Out-Null
        for ($i = 0; $i -lt 30; $i++) {
            if (-not (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue)) { break }
            Start-Sleep -Milliseconds 500
        }
        if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
            throw 'Existing Portivo Windows Service registration could not be removed cleanly.'
        }
    }
    Invoke-ProcessChecked $ServiceExe @('install') $ServiceDir
    & sc.exe config $ServiceName start= delayed-auto | Out-Null
}

function Configure-Firewall {
    param([bool]$AllowLan)
    $existing = Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue
    if ($AllowLan) {
        if (-not $existing) {
            New-NetFirewallRule -DisplayName $FirewallRuleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Domain,Private,Public | Out-Null
            Write-InstallLog "Created Windows Firewall rule for TCP $Port on Domain, Private and Public profiles."
        } else {
            Set-NetFirewallRule -DisplayName $FirewallRuleName -Enabled True -Direction Inbound -Action Allow -Profile Domain,Private,Public | Out-Null
            Write-InstallLog "Updated Windows Firewall rule for TCP $Port on Domain, Private and Public profiles."
        }
    } elseif ($existing) {
        Disable-NetFirewallRule -DisplayName $FirewallRuleName | Out-Null
    }
}

function Register-PortivoUninstaller {
    $sourceDir = Join-Path $InstallRoot 'deployment\windows'
    $sourcePs1 = Join-Path $sourceDir 'Uninstall-Portivo.ps1'
    $sourceCmd = Join-Path $sourceDir 'Uninstall Windows.cmd'
    if (-not (Test-Path $sourcePs1) -or -not (Test-Path $sourceCmd)) {
        throw 'Portivo uninstall scripts are missing from the application payload.'
    }
    $uninstallDir = Join-Path $InstallRoot 'uninstall'
    New-Item -ItemType Directory -Path $uninstallDir -Force | Out-Null
    $installedPs1 = Join-Path $uninstallDir 'Uninstall-Portivo.ps1'
    $installedCmd = Join-Path $uninstallDir 'Uninstall Windows.cmd'
    Copy-Item $sourcePs1 $installedPs1 -Force
    Copy-Item $sourceCmd $installedCmd -Force
    $installedIcon = Join-Path $uninstallDir 'portivo.ico'
    $installedLogo = Join-Path $uninstallDir 'portivo-logo-white.png'
    if (Test-Path $IconPath) { Copy-Item $IconPath $installedIcon -Force }
    if (Test-Path $LogoPath) { Copy-Item $LogoPath $installedLogo -Force }

    New-Item -Path $UninstallRegistryKey -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'DisplayName' -Value 'Portivo Control Center' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'DisplayVersion' -Value $PackageVersion -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'Publisher' -Value 'Portivo' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'InstallLocation' -Value $InstallRoot -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'DisplayIcon' -Value $installedIcon -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'URLInfoAbout' -Value 'https://portivo.org' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'Comments' -Value $PackageRevision -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'InstallDate' -Value (Get-Date -Format 'yyyyMMdd') -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'NoModify' -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'NoRepair' -Value 1 -PropertyType DWord -Force | Out-Null
    $uninstallString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$installedPs1`""
    $quietString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$installedPs1`" -Mode KeepData -Quiet"
    New-ItemProperty -Path $UninstallRegistryKey -Name 'UninstallString' -Value $uninstallString -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallRegistryKey -Name 'QuietUninstallString' -Value $quietString -PropertyType String -Force | Out-Null
    Write-InstallLog 'Registered Portivo Control Center in Windows Installed Apps with supported uninstall commands.'
}

function Wait-PortivoHealth {
    $url = "http://127.0.0.1:$Port/api/health/build"
    $lastDetail = 'No HTTP response received.'
    for ($i = 0; $i -lt 60; $i++) {
        try {
            $result = Invoke-RestMethod -Uri $url -Method Get -TimeoutSec 3
            if ($result) {
                $actualVersion = [string]$result.version
                $actualRevision = [string]$result.revision
                $lastDetail = "Health responded version=$actualVersion revision=$actualRevision"
                Write-InstallLog $lastDetail
                if ($actualVersion -eq $PackageVersion -and ((-not $PackageRevision) -or $actualRevision -eq $PackageRevision)) { return @{ Ok=$true; Detail=$lastDetail } }
            }
        } catch {
            $lastDetail = $_.Exception.Message
            Write-InstallLog "Health attempt failed: $lastDetail"
        }
        Start-Sleep -Seconds 1
    }
    return @{ Ok=$false; Detail=$lastDetail }
}

function Copy-InstallerLogToInstall {
    try {
        $logs = Join-Path $InstallRoot 'logs'
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
        Copy-Item $InstallLog (Join-Path $logs (Split-Path -Leaf $InstallLog)) -Force
    } catch { }
}

# WPF user interface
$RawInstalledVersion = Get-InstalledVersion
$DatabaseExists = Test-Path (Join-Path $InstallRoot 'data\portivo.db')
$EnvironmentExists = Test-Path (Join-Path $InstallRoot '.env')
$CoreExists = Test-Path (Join-Path $InstallRoot 'run.py')
$ServiceDetected = [bool](Get-Service -Name $ServiceName -ErrorAction SilentlyContinue)
$HasRecoverableState = $DatabaseExists -or $EnvironmentExists
$FreshInstall = -not $DatabaseExists
$InstalledVersion = if ($HasRecoverableState) { $RawInstalledVersion } else { $null }
$PreservedDataRecovery = $HasRecoverableState -and (-not $RawInstalledVersion)
$RecoveryInstall = $PreservedDataRecovery -or ((-not $HasRecoverableState) -and ($RawInstalledVersion -or $CoreExists -or $ServiceDetected -or (Test-Path $InstallRoot)))
$ModeText = if ($InstalledVersion) { "Existing installation detected: v$InstalledVersion" } elseif ($PreservedDataRecovery) { 'Preserved Portivo data detected: recovery mode' } elseif ($RecoveryInstall) { 'Incomplete installation detected: recovery mode' } else { 'Fresh installation' }
$ActionText = if ($InstalledVersion) { 'Update / Repair' } elseif ($RecoveryInstall) { 'Recover Portivo' } else { 'Install Portivo' }

[xml]$Xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Portivo Control Center Setup" Height="680" Width="980" ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen" Background="#EEF2F8" FontFamily="Segoe UI">
  <Window.Resources>
    <Style x:Key="PrimaryActionButton" TargetType="Button">
      <Setter Property="Background" Value="#6F3FD4"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="BorderBrush" Value="#6F3FD4"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="ButtonChrome"
                    Background="{TemplateBinding Background}"
                    BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}"
                    CornerRadius="7">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" Margin="14,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#5F35C5"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#5F35C5"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#4F2BA8"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#4F2BA8"/>
              </Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#8A63E6"/>
                <Setter TargetName="ButtonChrome" Property="BorderThickness" Value="2"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#D9DDE7"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#D9DDE7"/>
                <Setter Property="Foreground" Value="#8A94A7"/>
                <Setter Property="Cursor" Value="Arrow"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="SecondaryActionButton" TargetType="Button">
      <Setter Property="Background" Value="#EEF2F8"/>
      <Setter Property="Foreground" Value="#172033"/>
      <Setter Property="BorderBrush" Value="#D8DFEA"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="ButtonChrome"
                    Background="{TemplateBinding Background}"
                    BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}"
                    CornerRadius="7">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" Margin="14,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#E3E8F1"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#C7D0DF"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#D7DEE9"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#B9C4D4"/>
              </Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#9A86C8"/>
                <Setter TargetName="ButtonChrome" Property="BorderThickness" Value="2"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter TargetName="ButtonChrome" Property="Background" Value="#F3F5F8"/>
                <Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#E1E5EC"/>
                <Setter Property="Foreground" Value="#9AA3B2"/>
                <Setter Property="Cursor" Value="Arrow"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>
  <Grid>
    <Grid.ColumnDefinitions><ColumnDefinition Width="340"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
    <Border Grid.Column="0" CornerRadius="0" Padding="34">
      <Border.Background>
        <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
          <GradientStop Color="#5C388D" Offset="0"/><GradientStop Color="#302244" Offset="1"/>
        </LinearGradientBrush>
      </Border.Background>
      <Grid>
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <Image x:Name="BrandLogo" Width="260" HorizontalAlignment="Left" Stretch="Uniform"/>
        <StackPanel Grid.Row="1" VerticalAlignment="Center">
          <TextBlock Text="CONTROL WITHOUT" Foreground="#D9D1EA" FontSize="13" FontWeight="SemiBold"/>
          <TextBlock Text="COMPLEXITY" Foreground="White" FontSize="32" FontWeight="Bold" Margin="0,2,0,18"/>
          <TextBlock Text="A guided Windows deployment with a private Python runtime, automatic upgrades and service startup." Foreground="#E9E3F2" FontSize="14" TextWrapping="Wrap" LineHeight="22"/>
        </StackPanel>
        <StackPanel Grid.Row="2">
          <TextBlock Text="PORTIVO WINDOWS DEPLOYMENT" Foreground="#BEB1D1" FontSize="11" FontWeight="SemiBold"/>
          <TextBlock Text="v$PackageVersion" Foreground="White" FontSize="14" FontWeight="Bold" Margin="0,5,0,0"/>
        </StackPanel>
      </Grid>
    </Border>
    <Border Grid.Column="1" Margin="24" Background="White" CornerRadius="18" Padding="34">
      <Grid>
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <StackPanel>
          <TextBlock Text="Portivo Control Center" Foreground="#172033" FontSize="28" FontWeight="Bold"/>
          <TextBlock Text="$ModeText" Foreground="#66758D" FontSize="13" Margin="0,7,0,0"/>
        </StackPanel>
        <Border Grid.Row="1" Margin="0,24,0,0" Background="#F6F3FC" BorderBrush="#E5DCF6" BorderThickness="1" CornerRadius="12" Padding="16">
          <StackPanel>
            <TextBlock Text="INSTALLATION PATH" Foreground="#6F3FD4" FontSize="10" FontWeight="Bold"/>
            <TextBlock Text="$InstallRoot" Foreground="#172033" FontSize="15" FontWeight="SemiBold" Margin="0,4,0,0"/>
            <TextBlock Text="Portivo will use its own private Python runtime and will not modify the Windows PATH." Foreground="#66758D" FontSize="11" Margin="0,5,0,0"/>
          </StackPanel>
        </Border>
        <StackPanel x:Name="PasswordPanel" Grid.Row="2" Margin="0,20,0,0">
          <TextBlock Text="LOCAL ADMINISTRATOR" Foreground="#172033" FontSize="12" FontWeight="Bold"/>
          <TextBlock Text="Choose the bootstrap admin password for this first installation. Minimum 12 characters." Foreground="#66758D" FontSize="11" Margin="0,4,0,8"/>
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="16"/><ColumnDefinition/></Grid.ColumnDefinitions>
            <PasswordBox x:Name="AdminPassword" Grid.Column="0" Height="34" Padding="9" BorderBrush="#D5DBE7"/>
            <PasswordBox x:Name="AdminPassword2" Grid.Column="2" Height="34" Padding="9" BorderBrush="#D5DBE7"/>
          </Grid>
        </StackPanel>
        <CheckBox x:Name="LanAccess" Grid.Row="3" Margin="0,18,0,0" IsChecked="True" Foreground="#172033" FontSize="12" Content="Allow LAN access on TCP port $Port for Domain, Private and Public networks"/>
        <StackPanel Grid.Row="4" Margin="0,24,0,0">
          <TextBlock x:Name="StatusText" Text="Ready to install." Foreground="#172033" FontSize="12" FontWeight="SemiBold"/>
          <ProgressBar x:Name="Progress" Height="8" Margin="0,9,0,0" Minimum="0" Maximum="100" Value="0" Foreground="#6F3FD4" Background="#E8ECF3"/>
          <TextBlock x:Name="DetailText" Text="First installation requires Internet access to obtain the official CPython runtime, Python packages and the Windows service wrapper." Foreground="#66758D" FontSize="10.5" TextWrapping="Wrap" LineHeight="17" MinHeight="44" Margin="0,10,0,0"/>
        </StackPanel>
        <Grid Grid.Row="6" Margin="0,20,0,0">
          <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="10"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
          <Button x:Name="OpenButton" Grid.Column="0" Content="Open Portivo" Width="120" Height="38" HorizontalAlignment="Left" Visibility="Collapsed" Style="{StaticResource SecondaryActionButton}"/>
          <Button x:Name="CloseButton" Grid.Column="1" Content="Close" Width="90" Height="38" Style="{StaticResource SecondaryActionButton}"/>
          <Button x:Name="InstallButton" Grid.Column="3" Content="$ActionText" Width="145" Height="38" Style="{StaticResource PrimaryActionButton}"/>
        </Grid>
      </Grid>
    </Border>
  </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $Xaml
$Window = [Windows.Markup.XamlReader]::Load($reader)
if (Test-Path $IconPath) {
    try { $Window.Icon = [Windows.Media.Imaging.BitmapFrame]::Create([Uri]$IconPath) } catch { }
}
$BrandLogo = $Window.FindName('BrandLogo')
if (Test-Path $LogoPath) {
    $bitmap = New-Object Windows.Media.Imaging.BitmapImage
    $bitmap.BeginInit(); $bitmap.UriSource = [Uri]$LogoPath; $bitmap.CacheOption = 'OnLoad'; $bitmap.EndInit()
    $BrandLogo.Source = $bitmap
}
$PasswordPanel = $Window.FindName('PasswordPanel')
$AdminPassword = $Window.FindName('AdminPassword')
$AdminPassword2 = $Window.FindName('AdminPassword2')
$LanAccess = $Window.FindName('LanAccess')
$StatusText = $Window.FindName('StatusText')
$DetailText = $Window.FindName('DetailText')
$Progress = $Window.FindName('Progress')
$InstallButton = $Window.FindName('InstallButton')
$CloseButton = $Window.FindName('CloseButton')
$OpenButton = $Window.FindName('OpenButton')

if (-not $FreshInstall) { $PasswordPanel.Visibility = 'Collapsed' }

function Set-InstallerStatus {
    param([int]$Percent, [string]$Status, [string]$Detail = '')
    $Progress.Value = $Percent
    $StatusText.Text = $Status
    if ($Detail) { $DetailText.Text = $Detail }
    $Window.Dispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Render)
}

$CloseButton.Add_Click({ $Window.Close() })
$OpenButton.Add_Click({ Start-Process "http://127.0.0.1:$Port" })

$InstallButton.Add_Click({
    if ($FreshInstall) {
        if ($AdminPassword.Password.Length -lt 12) {
            [System.Windows.MessageBox]::Show('Administrator password must contain at least 12 characters.', 'Portivo Setup', 'OK', 'Warning') | Out-Null
            return
        }
        if ($AdminPassword.Password -ne $AdminPassword2.Password) {
            [System.Windows.MessageBox]::Show('Administrator passwords do not match.', 'Portivo Setup', 'OK', 'Warning') | Out-Null
            return
        }
    }

    $InstallButton.IsEnabled = $false
    $CloseButton.IsEnabled = $false
    $backup = $null
    $serviceExisted = [bool](Get-Service -Name $ServiceName -ErrorAction SilentlyContinue)
    Write-InstallLog "Portivo installer started. Package version $PackageVersion. Install root $InstallRoot."
    try {
        Set-InstallerStatus 5 'Preparing installation...' 'Stopping the existing service if one is running.'
        if ($serviceExisted) { Stop-PortivoService }

        if ($HasRecoverableState) {
            $backupLabel = if ($InstalledVersion) { "v$InstalledVersion" } else { 'the recoverable Portivo data' }
            Set-InstallerStatus 12 'Creating safety backup...' "Backing up $backupLabel before continuing."
            $backup = New-PortivoBackup
        } elseif ($RecoveryInstall) {
            Write-InstallLog 'Recovery mode: no database or .env was found, so there is no previous Portivo data to back up.'
        }

        Set-InstallerStatus 22 'Installing Portivo application...' 'Updating application files while preserving the database, environment, logs and backups.'
        Install-ApplicationPayload

        Set-InstallerStatus 35 'Preparing private Python runtime...' "Using Python $PythonVersion inside $RuntimeRoot."
        Ensure-PrivatePython

        Set-InstallerStatus 48 'Installing Python dependencies...' 'Dependencies are installed only into the private Portivo runtime.'
        Install-PythonDependencies

        Set-InstallerStatus 60 'Preparing configuration...' 'Preserving existing secrets and updating the application version.'
        Ensure-PortivoEnvironment

        $dbDetail = if ($FreshInstall) { 'Creating the local administrator and the initial database.' } else { 'Applying safe database migrations to the existing installation.' }
        Set-InstallerStatus 70 'Preparing database...' $dbDetail
        Initialize-PortivoDatabase -AdminPassword $AdminPassword.Password -FreshInstall $FreshInstall

        Set-InstallerStatus 78 'Validating private runtime...' 'Confirming the isolated Python runtime can import the Portivo application package.'
        Test-PortivoRuntimeImports

        Set-InstallerStatus 80 'Installing Windows Service...' 'Configuring Portivo Control Center for Automatic Delayed Start and automatic recovery.'
        New-Item -ItemType Directory -Path (Join-Path $InstallRoot 'logs') -Force | Out-Null
        Ensure-PortivoServiceWrapper

        Set-InstallerStatus 84 'Installing uninstaller...' 'Registering Portivo in Windows Installed Apps and deploying safe keep-data / purge uninstall workflows.'
        Register-PortivoUninstaller

        Set-InstallerStatus 87 'Configuring Windows Firewall...' "Applying the selected LAN access policy for TCP $Port."
        Configure-Firewall -AllowLan ([bool]$LanAccess.IsChecked)

        Set-InstallerStatus 92 'Starting Portivo...' 'Starting the Windows Service and waiting for the API to become healthy.'
        Start-PortivoService

        $health = Wait-PortivoHealth
        if (-not $health.Ok) {
            throw "The Windows Service started, but the v$PackageVersion / $PackageRevision health check did not pass on port $Port. Last result: $($health.Detail)"
        }

        Set-InstallerStatus 100 'Portivo is ready.' "Version $PackageVersion is running as a Windows Service. Open http://127.0.0.1:$Port"
        Write-InstallLog 'Installation completed successfully and health check passed.'
        Copy-InstallerLogToInstall
        Remove-PrivatePythonRollback
        $InstallButton.Visibility = 'Collapsed'
        $OpenButton.Visibility = 'Visible'
        $CloseButton.IsEnabled = $true

        # Clean up obsolete manual-launch artifacts only after successful service deployment.
        $legacyVenv = Join-Path $InstallRoot '.venv'
        if (Test-Path $legacyVenv) {
            try { Remove-Item $legacyVenv -Recurse -Force -ErrorAction Stop; Write-InstallLog 'Removed legacy .venv after successful migration.' } catch { Write-InstallLog "Legacy .venv cleanup skipped: $($_.Exception.Message)" }
        }
    } catch {
        Write-InstallLog "INSTALLATION FAILED: $($_.Exception.ToString())"
        Set-InstallerStatus 100 'Installation did not complete.' $_.Exception.Message
        try {
            if ($backup) {
                Set-InstallerStatus 100 'Restoring previous installation...' 'The installer is rolling back the application and database backup.'
                try { Stop-PortivoService } catch { }
                Restore-PrivatePythonRollback
                Restore-PortivoBackup $backup
                if ($serviceExisted -and (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue)) {
                    try { Start-PortivoService } catch { Write-InstallLog "Rollback service start failed: $($_.Exception.Message)" }
                }
            }
        } catch { Write-InstallLog "ROLLBACK WARNING: $($_.Exception.ToString())" }
        Copy-InstallerLogToInstall
        [System.Windows.MessageBox]::Show("Portivo setup failed.`n`n$($_.Exception.Message)`n`nInstaller log:`n$InstallLog", 'Portivo Setup', 'OK', 'Error') | Out-Null
        $InstallButton.IsEnabled = $true
        $CloseButton.IsEnabled = $true
    }
})

$Window.ShowDialog() | Out-Null
