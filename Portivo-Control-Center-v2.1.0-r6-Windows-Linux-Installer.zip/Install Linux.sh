﻿#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
set -Eeuo pipefail

PRODUCT="Portivo Control Center"
VERSION="2.1.0"
INSTALL_ROOT="/opt/portivo-control-center"
SERVICE_NAME="portivo-control-center"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
SERVICE_USER="portivo"
PORT="8766"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd -P)"
PAYLOAD_ZIP="${SCRIPT_DIR}/payload/portivo-app.zip"
MANIFEST="${SCRIPT_DIR}/installer-manifest.json"
BACKUP_ROOT="/var/backups/portivo-control-center"
TMP_ROOT=""
BACKUP_FILE=""
SERVICE_EXISTED=0
INSTALL_STARTED=0

purple='\033[38;5;99m'
bold='\033[1m'
green='\033[32m'
yellow='\033[33m'
red='\033[31m'
reset='\033[0m'

say() { printf '%b\n' "$*"; }
step() { say "${purple}${bold}==>${reset} $*"; }
warn() { say "${yellow}Warning:${reset} $*"; }
fail() { say "${red}Error:${reset} $*" >&2; exit 1; }

cleanup() {
  if [[ -n "${TMP_ROOT:-}" && -d "$TMP_ROOT" ]]; then
    rm -rf "$TMP_ROOT" || true
  fi
}
trap cleanup EXIT

if [[ "$(uname -s)" != "Linux" ]]; then
  fail "This installer is for Linux only. On Windows use Install Windows.cmd."
fi

if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    say "${purple}${bold}${PRODUCT} v${VERSION}${reset}"
    say "Administrator privileges are required to install the systemd service."
    exec sudo --preserve-env=PATH bash "$0" "$@"
  fi
  fail "Run this installer as root or install sudo first."
fi

[[ -f "$PAYLOAD_ZIP" ]] || fail "Application payload not found: $PAYLOAD_ZIP"
[[ -f "$MANIFEST" ]] || fail "Installer manifest not found: $MANIFEST"
EXPECTED_PAYLOAD_HASH="$(sed -n 's/.*"payload_sha256"[[:space:]]*:[[:space:]]*"\([A-Fa-f0-9]*\)".*/\1/p' "$MANIFEST" | head -n1)"
if [[ -n "$EXPECTED_PAYLOAD_HASH" ]]; then
  ACTUAL_PAYLOAD_HASH="$(sha256sum "$PAYLOAD_ZIP" | awk '{print $1}')"
  if [[ "${ACTUAL_PAYLOAD_HASH,,}" != "${EXPECTED_PAYLOAD_HASH,,}" ]]; then
    fail "Application payload integrity check failed."
  fi
fi

say
say "${purple}${bold}Portivo Control Center${reset}"
say "Control Without Complexity"
say "Linux deployment package v${VERSION}"
say

install_base_packages() {
  local missing=0
  command -v python3 >/dev/null 2>&1 || missing=1
  command -v unzip >/dev/null 2>&1 || missing=1
  command -v curl >/dev/null 2>&1 || missing=1
  command -v ping >/dev/null 2>&1 || missing=1
  if [[ $missing -eq 0 ]] && python3 -m venv --help >/dev/null 2>&1; then
    return
  fi

  step "Installing required Linux packages..."
  if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y python3 python3-venv python3-pip unzip curl ca-certificates iputils-ping
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip unzip curl ca-certificates iputils
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 python3-pip unzip curl ca-certificates iputils
  else
    fail "Supported package manager not found. Install Python 3.11+, python venv, unzip and curl, then run this installer again."
  fi
}

validate_python() {
  python3 - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit(f"Python 3.11 or newer is required. Detected: {sys.version.split()[0]}")
print(sys.version.split()[0])
PY
}

restore_backup() {
  systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
  if [[ -n "${BACKUP_FILE:-}" && -f "$BACKUP_FILE" ]]; then
    warn "Installation failed. Restoring the previous Portivo installation..."
    rm -rf "$INSTALL_ROOT"
    mkdir -p "$INSTALL_ROOT"
    tar -xzf "$BACKUP_FILE" -C / || true
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_ROOT" 2>/dev/null || true
    if [[ $SERVICE_EXISTED -eq 1 ]]; then
      systemctl daemon-reload || true
      systemctl start "$SERVICE_NAME" || true
    fi
  elif [[ -z "${INSTALLED_VERSION:-}" ]]; then
    warn "Removing the incomplete fresh installation..."
    rm -rf "$INSTALL_ROOT"
    rm -f "$SERVICE_FILE"
    systemctl daemon-reload >/dev/null 2>&1 || true
  fi
}

on_error() {
  local rc=$?
  if [[ $INSTALL_STARTED -eq 1 ]]; then restore_backup; fi
  fail "Linux installation did not complete (exit code $rc)."
}
install_base_packages
PYTHON_VERSION="$(validate_python)" || fail "Python 3.11 or newer is required. Debian 12+ or Ubuntu 24.04 LTS+ is recommended."
step "Python ${PYTHON_VERSION} detected."

if id "$SERVICE_USER" >/dev/null 2>&1; then
  :
else
  step "Creating dedicated service account '${SERVICE_USER}'..."
  useradd --system --home-dir "$INSTALL_ROOT" --shell /usr/sbin/nologin "$SERVICE_USER"
fi

INSTALLED_VERSION=""
if [[ -f "$INSTALL_ROOT/VERSION" ]]; then
  INSTALLED_VERSION="$(tr -d '\r\n' < "$INSTALL_ROOT/VERSION")"
fi

if systemctl list-unit-files --type=service 2>/dev/null | grep -q "^${SERVICE_NAME}\.service"; then
  SERVICE_EXISTED=1
fi

HAS_PRESERVED_STATE=0
if [[ -f "$INSTALL_ROOT/data/portivo.db" || -f "$INSTALL_ROOT/.env" ]]; then
  HAS_PRESERVED_STATE=1
fi

if [[ -n "$INSTALLED_VERSION" || $HAS_PRESERVED_STATE -eq 1 ]]; then
  if [[ -n "$INSTALLED_VERSION" ]]; then
    say "Existing installation detected: v${INSTALLED_VERSION}"
    backup_label="${INSTALLED_VERSION}"
  else
    say "Preserved Portivo data detected: recovery mode"
    backup_label="preserved-data"
  fi
  step "Stopping the existing Portivo service..."
  systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
  mkdir -p "$BACKUP_ROOT"
  BACKUP_FILE="${BACKUP_ROOT}/portivo-${backup_label}-before-${VERSION}-$(date +%Y%m%d-%H%M%S).tar.gz"
  step "Creating safety backup: ${BACKUP_FILE}"
  tar --exclude="${INSTALL_ROOT#/}/.venv" --exclude="${INSTALL_ROOT#/}/logs" -czf "$BACKUP_FILE" -C / "${INSTALL_ROOT#/}"
else
  say "Fresh installation"
fi

INSTALL_STARTED=1
trap on_error ERR
TMP_ROOT="$(mktemp -d -t portivo-install-XXXXXX)"
step "Extracting Portivo application payload..."
unzip -q "$PAYLOAD_ZIP" -d "$TMP_ROOT"

mkdir -p "$INSTALL_ROOT"
# Replace application code while preserving runtime data and secrets.
for d in app scripts docs examples deployment THIRD_PARTY_LICENSES; do
  rm -rf "$INSTALL_ROOT/$d"
  [[ -d "$TMP_ROOT/$d" ]] && cp -a "$TMP_ROOT/$d" "$INSTALL_ROOT/$d"
done
mkdir -p "$INSTALL_ROOT/data" "$INSTALL_ROOT/logs" "$INSTALL_ROOT/backups"
for f in command_profiles.json action_catalog.json ale_cli_validation.json; do
  cp -f "$TMP_ROOT/data/$f" "$INSTALL_ROOT/data/$f"
done
for f in run.py requirements.txt requirements.in requirements.lock VERSION LICENSE LEGAL.md THIRD_PARTY_NOTICES.md TRADEMARKS.md SBOM.spdx.json CONTRIBUTING.md README.md CHANGELOG.md INSTALLATION.md .env.example; do
  [[ -f "$TMP_ROOT/$f" ]] && cp -f "$TMP_ROOT/$f" "$INSTALL_ROOT/$f"
done
for f in VERSION LICENSE LEGAL.md THIRD_PARTY_NOTICES.md TRADEMARKS.md SBOM.spdx.json CONTRIBUTING.md requirements.lock README.md INSTALLATION.md; do
  [[ -f "$INSTALL_ROOT/$f" ]] || { echo "Portivo application payload is incomplete after extraction. Missing required file: $f" >&2; exit 1; }
done

step "Deploying Portivo uninstaller..."
mkdir -p "$INSTALL_ROOT/uninstall"
cp -f "$INSTALL_ROOT/deployment/linux/Uninstall Linux.sh" "$INSTALL_ROOT/uninstall/Uninstall Linux.sh"
chmod 700 "$INSTALL_ROOT/uninstall/Uninstall Linux.sh"

step "Preparing isolated Python environment..."
if [[ ! -x "$INSTALL_ROOT/.venv/bin/python" ]]; then
  rm -rf "$INSTALL_ROOT/.venv"
  python3 -m venv "$INSTALL_ROOT/.venv"
fi
"$INSTALL_ROOT/.venv/bin/python" -m pip install --disable-pip-version-check --no-deps -r "$INSTALL_ROOT/requirements.lock"
"$INSTALL_ROOT/.venv/bin/python" -m pip check

ENV_FILE="$INSTALL_ROOT/.env"
if [[ ! -f "$ENV_FILE" ]]; then
  step "Creating secure Portivo environment..."
  SECRET="$(cd "$INSTALL_ROOT" && "$INSTALL_ROOT/.venv/bin/python" scripts/generate_secret.py)"
  cat > "$ENV_FILE" <<ENVEOF
APP_NAME=Portivo Control Center
APP_VERSION=${VERSION}
APP_HOST=0.0.0.0
APP_PORT=${PORT}
APP_SECRET_KEY=${SECRET}
APP_ADMIN_USERNAME=admin
PUBLIC_URL_SCHEME=http
TRUST_PROXY_HEADERS=false
TRUSTED_PROXY_IPS=127.0.0.1,::1
LOGIN_RATE_LIMIT_ENABLED=true
LOGIN_RATE_LIMIT_WINDOW_SECONDS=300
LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS=30
SSH_CONNECT_TIMEOUT=12
AUTH_CONNECT_TIMEOUT=2.5
AUTH_GLOBAL_TIMEOUT_SECONDS=5
AUTH_MAX_SOURCES=5
SSH_COMMAND_TIMEOUT=30
SSH_CONNECT_RETRIES=3
SSH_RETRY_BACKOFF_SECONDS=0.75
SSH_OPERATION_LOCK_TIMEOUT=180
SSH_POST_SAVE_PROMPT_TIMEOUT=20
SSH_POST_SAVE_COOLDOWN_SECONDS=2
SSH_POST_SAVE_FALLBACK_COOLDOWN_SECONDS=5
SSH_RECENT_AUTH_SUCCESS_WINDOW_SECONDS=60
SSH_RECENT_AUTH_RETRY_DELAY_SECONDS=2
SSH_TERMINAL_IDLE_MINUTES=15
MAX_PARALLEL_SWITCHES=6
FINDER_MAX_PARALLEL_SWITCHES=12
HEALTH_MONITOR_ENABLED=true
HEALTH_POLL_INTERVAL_SECONDS=30
HEALTH_PING_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_POLL_INTERVAL_SECONDS=120
HEALTH_MAX_PARALLEL_SWITCHES=32
HEALTH_PING_ATTEMPTS=3
HEALTH_PING_RETRY_DELAY_SECONDS=5
HEALTH_POLL_JITTER_SECONDS=10
HEALTH_OFFLINE_POLL_INTERVAL_SECONDS=60
HEALTH_LONG_OFFLINE_AFTER_SECONDS=900
HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS=120
DATABASE_PATH=./data/portivo.db
COMMAND_PROFILES_PATH=./data/command_profiles.json
ACTION_CATALOG_PATH=./data/action_catalog.json
ENVEOF
  chmod 600 "$ENV_FILE"
else
  # Preserve existing secrets/settings, update only the application version.
  if grep -q '^APP_VERSION=' "$ENV_FILE"; then
    sed -i "s/^APP_VERSION=.*/APP_VERSION=${VERSION}/" "$ENV_FILE"
  else
    printf '\nAPP_VERSION=%s\n' "$VERSION" >> "$ENV_FILE"
  fi
  if ! grep -q '^FINDER_MAX_PARALLEL_SWITCHES=' "$ENV_FILE"; then
    printf 'FINDER_MAX_PARALLEL_SWITCHES=12\n' >> "$ENV_FILE"
  fi
  if ! grep -q '^PUBLIC_URL_SCHEME=' "$ENV_FILE"; then
    if grep -Eqi '^COOKIE_SECURE=(true|1|yes|on)$' "$ENV_FILE"; then
      printf 'PUBLIC_URL_SCHEME=https\n' >> "$ENV_FILE"
    else
      printf 'PUBLIC_URL_SCHEME=http\n' >> "$ENV_FILE"
    fi
  fi
  while IFS='=' read -r key value; do
    if ! grep -q "^${key}=" "$ENV_FILE"; then
      printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
    fi
  done <<'ENVDEFAULTS'
TRUST_PROXY_HEADERS=false
TRUSTED_PROXY_IPS=127.0.0.1,::1
LOGIN_RATE_LIMIT_ENABLED=true
LOGIN_RATE_LIMIT_WINDOW_SECONDS=300
LOGIN_RATE_LIMIT_MAX_DELAY_SECONDS=30
AUTH_CONNECT_TIMEOUT=2.5
AUTH_GLOBAL_TIMEOUT_SECONDS=5
AUTH_MAX_SOURCES=5
HEALTH_PING_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_TIMEOUT_SECONDS=1.5
HEALTH_SNMP_POLL_INTERVAL_SECONDS=120
HEALTH_MAX_PARALLEL_SWITCHES=32
HEALTH_PING_ATTEMPTS=3
HEALTH_PING_RETRY_DELAY_SECONDS=5
HEALTH_POLL_JITTER_SECONDS=10
HEALTH_OFFLINE_POLL_INTERVAL_SECONDS=60
HEALTH_LONG_OFFLINE_AFTER_SECONDS=900
HEALTH_LONG_OFFLINE_POLL_INTERVAL_SECONDS=120
ENVDEFAULTS
fi

if [[ -z "$INSTALLED_VERSION" && ! -f "$INSTALL_ROOT/data/portivo.db" ]]; then
  say
  say "${bold}Create the local Portivo administrator${reset}"
  while true; do
    read -r -s -p "Administrator password (minimum 12 characters): " password1; echo
    read -r -s -p "Confirm administrator password: " password2; echo
    if [[ ${#password1} -lt 12 ]]; then
      warn "The password must contain at least 12 characters."
      continue
    fi
    if [[ "$password1" != "$password2" ]]; then
      warn "Passwords do not match."
      continue
    fi
    break
  done
  step "Creating database and administrator..."
  (cd "$INSTALL_ROOT" && OSC_ADMIN_PASSWORD="$password1" "$INSTALL_ROOT/.venv/bin/python" scripts/set_admin_password.py --username admin)
  unset password1 password2
else
  step "Applying database migrations..."
  (cd "$INSTALL_ROOT" && "$INSTALL_ROOT/.venv/bin/python" - <<'PY'
from app.db import init_db
init_db()
print("Database migrations complete")
PY
  )
fi

step "Validating Portivo installation integrity..."
(cd "$INSTALL_ROOT" && "$INSTALL_ROOT/.venv/bin/python" scripts/validate_installation.py)

step "Installing systemd service..."
cat > "$SERVICE_FILE" <<SERVICEEOF
[Unit]
Description=Portivo Control Center
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_ROOT}
Environment=PYTHONUNBUFFERED=1
ExecStart=${INSTALL_ROOT}/.venv/bin/python ${INSTALL_ROOT}/run.py
Restart=on-failure
RestartSec=10
TimeoutStopSec=20
UMask=0027
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectControlGroups=true
RestrictSUIDSGID=true
ReadWritePaths=${INSTALL_ROOT}/data ${INSTALL_ROOT}/logs ${INSTALL_ROOT}/backups

[Install]
WantedBy=multi-user.target
SERVICEEOF

# Keep application code/runtime root-owned and read-only to the service. Only
# operational state directories remain writable by the dedicated service user.
chown -R root:"$SERVICE_USER" "$INSTALL_ROOT"
chmod -R u=rwX,g=rX,o= "$INSTALL_ROOT"
for writable_dir in data logs backups; do
  mkdir -p "$INSTALL_ROOT/$writable_dir"
  chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_ROOT/$writable_dir"
  chmod -R u=rwX,g=,o= "$INSTALL_ROOT/$writable_dir"
done
chown root:"$SERVICE_USER" "$ENV_FILE"
chmod 640 "$ENV_FILE"
chown -R root:root "$INSTALL_ROOT/uninstall"
chmod 700 "$INSTALL_ROOT/uninstall/Uninstall Linux.sh"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null
systemctl restart "$SERVICE_NAME"

step "Waiting for Portivo health check..."
healthy=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    healthy=1
    break
  fi
  sleep 1
done
[[ $healthy -eq 1 ]] || fail "The service is running but Portivo did not answer on http://127.0.0.1:${PORT}/api/health"

if [[ -t 0 ]]; then
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
    say
    read -r -p "Allow TCP ${PORT} through UFW for LAN access? [Y/n]: " fw_answer
    fw_answer="${fw_answer:-Y}"
    if [[ "$fw_answer" =~ ^[Yy]$ ]]; then
      ufw allow "${PORT}/tcp" >/dev/null
      step "UFW rule added for TCP ${PORT}."
    fi
  elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    say
    read -r -p "Allow TCP ${PORT} through firewalld for LAN access? [Y/n]: " fw_answer
    fw_answer="${fw_answer:-Y}"
    if [[ "$fw_answer" =~ ^[Yy]$ ]]; then
      firewall-cmd --permanent --add-port="${PORT}/tcp" >/dev/null
      firewall-cmd --reload >/dev/null
      step "firewalld rule added for TCP ${PORT}."
    fi
  fi
fi

INSTALL_STARTED=0
trap - ERR
say
say "${green}${bold}Portivo Control Center v${VERSION} is ready.${reset}"
say "Service: ${SERVICE_NAME}.service"
say "Local URL: http://127.0.0.1:${PORT}"
say "LAN URL:   http://SERVER-IP:${PORT}"
say
say "Useful commands:"
say "  systemctl status ${SERVICE_NAME}"
say "  journalctl -u ${SERVICE_NAME} -f"
say "  systemctl restart ${SERVICE_NAME}"
say
