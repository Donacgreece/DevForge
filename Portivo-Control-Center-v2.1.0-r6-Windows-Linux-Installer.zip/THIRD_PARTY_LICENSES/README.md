# Third-Party License Texts

This directory contains license and attribution material for the exact runtime dependency set recorded in `requirements.lock` and `SBOM.spdx.json`, plus the Python runtime and WinSW service wrapper used by the installer.

Portivo-owned source code is licensed separately under `AGPL-3.0-only`. Third-party components retain their own licenses. If a bundled upstream distribution contains additional notices, those notices remain authoritative.
