# Trademarks and independence notice

Portivo Control Center is an independent project. It is not affiliated with, endorsed by, sponsored by, certified by, or supported by ALE International, Alcatel-Lucent Enterprise, or Nokia.

OmniSwitch® and related product names are referenced only to describe technical compatibility. Alcatel-Lucent names and logos are trademarks of their respective owners. No official ALE or Nokia logos are distributed with this project.

All trademarks remain the property of their respective owners.

The GNU AGPL v3.0 license applies to covered Portivo source code and does not grant rights to third-party trademarks, product names or logos. Forks and modified versions must not imply endorsement by ALE International, Alcatel-Lucent Enterprise, Nokia, or any other referenced vendor.
