#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
# Portivo Control Center Linux uninstaller

set -Eeuo pipefail

INSTALL_ROOT="/opt/portivo-control-center"
SERVICE_NAME="portivo-control-center"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
SERVICE_USER="portivo"
PORT="8766"
EXTERNAL_BACKUP_ROOT="/var/backups/portivo-control-center"
MODE="prompt"
TEMP_COPY=0

for arg in "$@"; do
  case "$arg" in
    --keep-data) MODE="keep" ;;
    --purge) MODE="purge" ;;
    --temp-copy) TEMP_COPY=1 ;;
    -h|--help)
      cat <<USAGE
Usage: $0 [--keep-data | --purge]

  --keep-data  Remove Portivo application/service/runtime while preserving
               .env, data/ and backups/ for a future reinstall.
  --purge      Permanently remove Portivo and all local data/config/backups.
USAGE
      exit 0
      ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Root privileges are required. Re-run with sudo." >&2
  exit 1
fi

# If launched from the installed tree, relocate to /tmp before deleting it.
if [[ $TEMP_COPY -eq 0 && "$0" == "$INSTALL_ROOT"/* ]]; then
  tmp_script="$(mktemp -p /tmp portivo-uninstall-XXXXXX.sh)"
  cp "$0" "$tmp_script"
  chmod 700 "$tmp_script"
  args=("--temp-copy")
  [[ "$MODE" == "keep" ]] && args+=("--keep-data")
  [[ "$MODE" == "purge" ]] && args+=("--purge")
  exec "$tmp_script" "${args[@]}"
fi

cleanup_self() {
  if [[ $TEMP_COPY -eq 1 && "$0" == /tmp/portivo-uninstall-* ]]; then
    rm -f "$0" >/dev/null 2>&1 || true
  fi
}
trap cleanup_self EXIT

if [[ -t 1 ]]; then
  C_PURPLE='\033[38;5;99m'; C_BOLD='\033[1m'; C_DIM='\033[2m'; C_RED='\033[31m'; C_GREEN='\033[32m'; C_RESET='\033[0m'
else
  C_PURPLE=''; C_BOLD=''; C_DIM=''; C_RED=''; C_GREEN=''; C_RESET=''
fi
say() { printf '%b\n' "$*"; }
warn() { printf '%bWARNING:%b %s\n' "$C_RED" "$C_RESET" "$*" >&2; }
step() { printf '%b[%s]%b %s\n' "$C_PURPLE$C_BOLD" "$1" "$C_RESET" "$2"; }
brand() {
  say ""
  say "${C_PURPLE}${C_BOLD}PORTIVO CONTROL CENTER${C_RESET}"
  say "${C_BOLD}Clean removal. Your choice of what stays.${C_RESET}"
  say "${C_DIM}────────────────────────────────────────────────────────────${C_RESET}"
}

choose_mode() {
  if [[ "$MODE" != "prompt" ]]; then return; fi
  if [[ ! -t 0 ]]; then MODE="keep"; return; fi
  brand
  say "${C_BOLD}Choose removal mode${C_RESET}"
  say "1) Standard uninstall - keep .env, data and backups"
  say "2) Full removal / purge - permanently delete everything"
  say "3) Cancel"
  read -r -p "Choose [1]: " answer
  answer="${answer:-1}"
  case "$answer" in
    1) MODE="keep" ;;
    2)
      warn "Full removal deletes Portivo credentials, configuration, database and backups."
      read -r -p "Type PURGE to continue: " confirm
      [[ "$confirm" == "PURGE" ]] || { say "Cancelled."; exit 0; }
      MODE="purge"
      ;;
    *) say "Cancelled."; exit 0 ;;
  esac
}

create_final_backup() {
  [[ -d "$INSTALL_ROOT" ]] || return 0
  local backup="/root/Portivo-Final-Backup-$(date +%Y%m%d-%H%M%S).tar.gz"
  local stage
  stage="$(mktemp -d -p /tmp portivo-final-backup-XXXXXX)"
  mkdir -p "$stage/install-root"
  for name in .env data backups; do
    [[ -e "$INSTALL_ROOT/$name" ]] && cp -a "$INSTALL_ROOT/$name" "$stage/install-root/$name"
  done
  if [[ -d "$EXTERNAL_BACKUP_ROOT" ]]; then
    mkdir -p "$stage/external-backups"
    cp -a "$EXTERNAL_BACKUP_ROOT/." "$stage/external-backups/"
  fi
  tar -czf "$backup" -C "$stage" .
  rm -rf "$stage"
  say "Final backup created: $backup"
}

remove_service() {
  if systemctl list-unit-files --type=service 2>/dev/null | grep -q "^${SERVICE_NAME}\.service"; then
    systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true
    systemctl disable "$SERVICE_NAME" >/dev/null 2>&1 || true
  fi
  rm -f "$SERVICE_FILE"
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl reset-failed "$SERVICE_NAME" >/dev/null 2>&1 || true
}

remove_firewall_rules() {
  if command -v ufw >/dev/null 2>&1; then
    ufw delete allow "${PORT}/tcp" >/dev/null 2>&1 || true
  fi
  if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --remove-port="${PORT}/tcp" >/dev/null 2>&1 || true
    firewall-cmd --permanent --remove-port="${PORT}/tcp" >/dev/null 2>&1 || true
    firewall-cmd --reload >/dev/null 2>&1 || true
  fi
}

remove_service_identity() {
  if id "$SERVICE_USER" >/dev/null 2>&1; then
    userdel "$SERVICE_USER" >/dev/null 2>&1 || true
  fi
  if getent group "$SERVICE_USER" >/dev/null 2>&1; then
    groupdel "$SERVICE_USER" >/dev/null 2>&1 || true
  fi
}

remove_keep_data() {
  [[ -d "$INSTALL_ROOT" ]] || return 0
  local preserve
  preserve="$(dirname "$INSTALL_ROOT")/.portivo-preserve-$(date +%s)-$$"
  mkdir -p "$preserve"
  local moved=()
  for name in .env data backups; do
    if [[ -e "$INSTALL_ROOT/$name" ]]; then
      mv "$INSTALL_ROOT/$name" "$preserve/$name"
      moved+=("$name")
    fi
  done
  rm -rf "$INSTALL_ROOT"
  mkdir -p "$INSTALL_ROOT"
  for name in "${moved[@]}"; do mv "$preserve/$name" "$INSTALL_ROOT/$name"; done
  rm -rf "$preserve"
  chown -R root:root "$INSTALL_ROOT"
  cat > "$INSTALL_ROOT/PORTIVO-DATA-PRESERVED.txt" <<NOTICE
Portivo Control Center has been uninstalled.

Preserved for a future reinstall or recovery:
  .env
  data/
  backups/

Reinstall Portivo with the official installer to reuse this preserved state.
NOTICE
}

choose_mode
brand
step "1/5" "Stopping and removing Portivo service"
remove_service
step "2/5" "Removing Portivo firewall rules"
remove_firewall_rules

if [[ "$MODE" == "purge" ]]; then
  if [[ -t 0 ]]; then
    read -r -p "Create a final backup in /root before purge? [y/N]: " backup_answer
    if [[ "$backup_answer" =~ ^[Yy]$ ]]; then create_final_backup; fi
  fi
  step "3/5" "Permanently removing Portivo application and local state"
  rm -rf "$INSTALL_ROOT"
  rm -rf "$EXTERNAL_BACKUP_ROOT"
  result="Portivo application and all local data were permanently removed."
else
  step "3/5" "Removing application while preserving .env, data and backups"
  remove_keep_data
  result="Portivo application removed. Preserved state remains in $INSTALL_ROOT."
fi

step "4/5" "Removing Portivo service identity"
remove_service_identity
step "5/5" "Finalizing uninstall"
say "${C_GREEN}${C_BOLD}Portivo uninstall completed successfully.${C_RESET}"
say "$result"
[[ "$MODE" == "keep" ]] && say "External installer backups remain in $EXTERNAL_BACKUP_ROOT when present."
