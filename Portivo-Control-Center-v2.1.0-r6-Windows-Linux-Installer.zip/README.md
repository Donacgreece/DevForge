<p align="center">
  <img src="docs/assets/README-hero.jpg" alt="Portivo Control Center" width="100%">
</p>

<h1 align="center">Portivo Control Center</h1>

<p align="center">
  <strong>Control Without Complexity</strong>
</p>

<p align="center">
  Centralized network operations, infrastructure visibility and controlled automation for compatible Alcatel-Lucent Enterprise OmniSwitch environments.
</p>

<p align="center">
  <strong>Current release:</strong> v2.1.0 &nbsp;•&nbsp;
  <strong>Build:</strong> r1 &nbsp;•&nbsp;
  <strong>License:</strong> AGPL-3.0-only
</p>

<p align="center">
  <a href="https://portivo.org">Official Website</a> ·
  <a href="https://github.com/Donacgreece/portivo/releases">Releases</a> ·
  <a href="INSTALLATION.md">Installation</a> ·
  <a href="docs/ARCHITECTURE.md">Architecture</a> ·
  <a href="CHANGELOG.md">Changelog</a> ·
  <a href="CONTRIBUTING.md">Contributing</a>
</p>

---

## About Portivo

Portivo Control Center is a self-hosted network operations platform built to simplify the daily management of compatible Alcatel-Lucent Enterprise OmniSwitch environments running AOS 6 and AOS 8.

The official Portivo website is [portivo.org](https://portivo.org).

It brings inventory, switch operations, live port visibility, troubleshooting, fleet auditing, monitoring, power infrastructure, access control, notifications and operational history into one web interface.

Portivo is designed around a simple principle: make repetitive infrastructure work faster without hiding the commands, evidence or operational impact from the engineer.

## Core capabilities

| Area | What Portivo provides |
| --- | --- |
| **Switch inventory** | Centralized device inventory with Site, Group, model, AOS family, management address and availability state. |
| **Operations** | Controlled single-device and bulk workflows with command preview, dry-run support, execution jobs and detailed per-target results. |
| **Live ports** | Port state, administrative state, alias, VLAN, media, PoE information and logical front-panel views for supported hardware. |
| **Port actions** | Interface restart, PoE restart, alias management and controlled maintenance workflows. |
| **Find Device** | Endpoint location using MAC, IP, hostname, UNP identity and network evidence with topology-aware correlation. |
| **Port Troubleshooter** | Read-only correlation of link state, errors, learned MACs, VLAN, UNP, PoE, LLDP and recent activity. |
| **Fleet Audits** | Infrastructure-wide health assessments with detailed evidence, severity and recommended verification steps. |
| **Reporting** | Evidence-rich PDF reports with source commands, diagnostic interpretation and affected components. |
| **Monitoring** | Switch availability, stack member health, incident detection and configurable monitoring modes. |
| **Power infrastructure** | UPS inventory, SNMPv3 monitoring, switch-to-UPS assignments, vendor-aware telemetry and power incident correlation. |
| **Notifications** | Microsoft Teams / Power Automate, Slack, Discord and Generic JSON destinations with scoped routing and retry handling. |
| **Runbooks** | Controlled COMMAND, WAIT and VERIFY automation with variables, approvals and scheduling. |
| **Access control** | Built-in and custom roles with granular capabilities and Site / Group scope. |
| **Auditability** | Searchable Jobs, execution history and Audit Log for operational traceability. |

## Built for safer network operations

Portivo does not treat automation as a black box. Operational workflows are designed to keep the engineer in control.

Key safeguards include:

- Command preview before controlled execution.
- Dry-run and simulation support where applicable.
- Read-only evidence collection for Fleet Audits and troubleshooting.
- Per-device FIFO SSH coordination to prevent overlapping operations against the same switch.
- Granular authorization with role, Site and Group scope.
- Personal SSH sessions instead of shared user SSH passwords.
- Explicit confirmation around high-impact actions.
- Searchable execution history and audit records.
- Encrypted persistent monitoring credentials.
- Secret-safe source and backup handling.

## Fleet Audits

Portivo includes nine general-purpose read-only Fleet Audits designed to provide actionable infrastructure evidence rather than simple pass/fail summaries.

Available audit areas include:

- Thermal health
- Fan health
- Power supply health
- PoE capacity and state
- Interface errors
- Port stability
- Managed uplinks
- Persistent configuration state
- Full switch health

Generated PDF reports can include severity distribution, plain-language interpretation, exact read-only source commands, audit-specific evidence, affected components and recommended checks.

## Find Device and troubleshooting

Portivo helps operators locate endpoints and investigate switch ports without manually repeating the same CLI workflow across the fleet.

Find Device can correlate available evidence such as MAC addresses, IP addresses, hostnames, VLAN information and UNP identity to rank likely endpoint locations.

The Port Troubleshooter collects live read-only evidence for a selected interface and presents related link state, errors, learned MACs, VLAN, UNP, PoE and LLDP information in one workflow.

## Monitoring and incidents

Portivo can operate as a management-only platform or provide continuous infrastructure monitoring.

Monitoring services include:

- Switch availability
- Stack Member Health
- Power / UPS monitoring
- Incident detection

Administrators can control these services independently and can switch between **Full monitoring** and **Management only** without removing monitoring configuration.

## Power infrastructure

UPS devices are treated as first-class infrastructure assets.

Portivo can monitor supported UPS devices over SNMPv3, associate them with the switches they protect and use available power telemetry as additional evidence during network incidents.

The platform includes support for standards-based RFC 1628 telemetry together with vendor-aware driver modes for supported UPS platforms.

Power monitoring can expose information such as:

- Utility / battery state
- Battery condition
- Charge percentage
- Estimated runtime
- Output load
- Available electrical telemetry
- Active power incidents
- Protected switches

Unsupported telemetry is omitted rather than presented as meaningful data.

## Access control

Portivo includes granular role-based access control for environments where different teams require different operational permissions.

Built-in roles include:

- Administrator
- Power User
- Site Administrator
- Operator
- Helpdesk
- Read Only

Administrators can also define Custom Roles and restrict access by Site and Group.

Authorization is enforced by capability rather than by UI visibility alone.

## Architecture

```text
Browser
   |
   v
Portivo Web UI
   |
   v
FastAPI application
   |
   +--> Authentication / RBAC
   +--> Device inventory
   +--> Operations / Jobs
   +--> Fleet Audits / Reports
   +--> Troubleshooting / Find Device
   +--> Monitoring / Incidents
   +--> Notifications
   +--> Power infrastructure
   +--> Runbooks / Scheduler
   +--> Vendor driver registry
   |        |
   |        +--> ALE AOS 6
   |        +--> ALE AOS 8
   |
   +--> Per-device SSH coordinator
   |        |
   |        v
   |   Compatible OmniSwitch devices
   |
   +--> SQLite application database
```

Portivo uses a compatibility-first SSH model. Work targeting the same managed switch is serialized, while operations against different devices can continue independently.

For additional technical information, see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Installation

The recommended deployment method is the packaged installer available from the [GitHub Releases](https://github.com/Donacgreece/portivo/releases) page.

### Windows

Supported baseline:

- 64-bit Windows 10
- 64-bit Windows 11
- Windows Server
- Administrator privileges during installation
- TCP port `8766` available on the host

The Windows package installs Portivo as a managed Windows service and performs installation health checks automatically.

Default installation path:

```text
C:\portivo-control-center
```

Local access:

```text
http://127.0.0.1:8766
```

### Linux

Recommended baseline:

- Debian 12 or newer
- Ubuntu Server 24.04 LTS or newer
- 64-bit Linux with systemd
- Python 3.11 or newer
- root or sudo access

Default installation path:

```text
/opt/portivo-control-center
```

For complete installation, update and troubleshooting instructions, see [INSTALLATION.md](INSTALLATION.md).

The v2.1.0-r5 deployment includes a Portivo-branded Windows uninstall wizard that mirrors the installer experience, plus a guided Linux terminal uninstaller. Standard uninstall removes the application/service/runtime while preserving `.env`, `data/` and `backups/`; Full Purge permanently removes Portivo state only after explicit confirmation.

r4 fixes a Windows fresh/recovery installer WorkingDirectory issue and keeps the Uninstall action permanently visible in the branded wizard at normal and high-DPI scaling.

## Release model

The current public release is:

**Portivo Control Center v2.1.0**

Tested build:

**r6**

Release artifacts are distributed through GitHub Releases and include:

- Windows / Linux installer package
- Exact-version source archive
- SHA-256 checksum file

The Git tag identifies the exact repository state associated with the public release.

Detailed historical revision notes are intentionally kept in [CHANGELOG.md](CHANGELOG.md) instead of this README.

## Security and supply-chain controls

Portivo includes security controls intended for self-hosted infrastructure environments.

The v2.1.0 r6 release includes:

- ICMP-only normal switch reachability with no TCP/22 or background SSH health probe
- Two bounded ICMP retries after a failed normal probe, followed by at most one SNMPv3 `sysUpTime.0` confirmation when configured
- Optional SNMPv3 telemetry stored independently from ping reachability
- Deterministic per-switch polling jitter plus adaptive offline backoff
- Progressive login throttling
- Password policy enforcement
- Granular role-based authorization
- Encrypted monitoring credentials
- Pinned production dependency sets
- Integrity verification for critical Windows runtime components
- Windows Authenticode verification for the Python runtime installer
- Linux service hardening
- Secret-safe source packaging
- Streamed SQLite backup handling

Do not include passwords, SSH credentials, SNMP secrets, private keys, production configuration or sensitive infrastructure data in public GitHub issues.

## Repository documentation

| Document | Description |
| --- | --- |
| [INSTALLATION.md](INSTALLATION.md) | Windows and Linux installation, update and troubleshooting. |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Technical architecture and application structure. |
| [CHANGELOG.md](CHANGELOG.md) | Detailed release and revision history. |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Contribution guidelines. |
| [LEGAL.md](LEGAL.md) | Licensing and corresponding-source information. |
| [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) | Third-party software notices. |
| [SBOM.spdx.json](SBOM.spdx.json) | SPDX Software Bill of Materials. |
| [TRADEMARKS.md](TRADEMARKS.md) | Portivo name, logo and branding terms. |

## Contributing

Contributions, bug reports and focused improvements are welcome.

Before submitting changes, please read [CONTRIBUTING.md](CONTRIBUTING.md). Contributions should remain scoped, testable and consistent with Portivo's operational safety model.

For bugs or feature requests, use the repository's [Issues](https://github.com/Donacgreece/portivo/issues) section.

## License

Portivo-owned source code is licensed under the **GNU Affero General Public License v3.0 only** (`AGPL-3.0-only`).

See:

- [LICENSE](LICENSE)
- [LEGAL.md](LEGAL.md)

Third-party components retain their respective licenses. See:

- [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)
- `THIRD_PARTY_LICENSES/`
- [SBOM.spdx.json](SBOM.spdx.json)

The GNU AGPL does not grant unrestricted rights to the Portivo name, logo or branding. See [TRADEMARKS.md](TRADEMARKS.md).

## Independence notice

Portivo is an independent project.

It is not affiliated with, endorsed by, sponsored by or supported by ALE International, Alcatel-Lucent Enterprise or Nokia. Company and product names are referenced only to describe technical compatibility.

---

<p align="center">
  <strong>Portivo Control Center</strong><br>
  Control Without Complexity
</p>
