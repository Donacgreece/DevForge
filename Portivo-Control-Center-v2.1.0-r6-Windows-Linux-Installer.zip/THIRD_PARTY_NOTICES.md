# Third-Party Notices

Portivo Control Center v2.0.0 uses third-party software. **Portivo-owned source code is licensed under GNU AGPL v3.0 only (`AGPL-3.0-only`)**, while every third-party component remains under its own upstream license. The AGPL does not replace those licenses.

The exact Python runtime dependency set used by this release is recorded in `requirements.lock`. A machine-readable software bill of materials is available in `SBOM.spdx.json`. Full or retained license material is stored under `THIRD_PARTY_LICENSES/`.

## Runtime and packaged components

| Component | Version | License | Copyright / attribution |
|---|---:|---|---|
| Python | 3.13.15 | `PSF-2.0` | Python Software Foundation |
| WinSW | 2.12.0 | `MIT` | WinSW contributors |
| FastAPI | 0.128.2 | `MIT` | Upstream authors and contributors |
| Uvicorn | 0.48.0 | `BSD-3-Clause` | Upstream authors and contributors |
| Netmiko | 4.7.0 | `MIT` | Kirk Byers and contributors |
| Paramiko | 4.0.0 | `LGPL-2.1-only` | Jeff Forcier and contributors |
| scp | 0.16.0 | `LGPL-2.1-or-later` | James Bardin, Remi Rampin and contributors |
| ntc-templates | 9.2.0 | `Apache-2.0` | Network to Code and contributors |
| TextFSM | 2.1.0 | `Apache-2.0` | Google and contributors |
| PySerial | 3.5 | `BSD-3-Clause` | Chris Liechti and contributors |
| Rich | 15.0.0 | `MIT` | Upstream authors and contributors |
| ruamel.yaml | 0.18.17 | `MIT` | Upstream authors and contributors |
| ruamel.yaml.clib | 0.2.15 | `MIT` | Upstream authors and contributors |
| PyYAML | 6.0.3 | `MIT` | Upstream authors and contributors |
| cryptography | 49.0.0 | `Apache-2.0 OR BSD-3-Clause` | Python Cryptographic Authority and contributors |
| cffi | 2.0.0 | `MIT` | Upstream authors and contributors |
| pycparser | 3.0 | `BSD-3-Clause` | Eli Bendersky and contributors |
| bcrypt | 4.3.0 | `Apache-2.0` | Python Cryptographic Authority and contributors |
| PyNaCl | 1.6.2 | `Apache-2.0` | The PyNaCl developers |
| Invoke | 2.2.1 | `BSD-2-Clause` | Jeff Forcier and contributors |
| PySNMP | 7.1.28 | `BSD-2-Clause` | Ilya Etingof, LeXtudio Inc. and contributors |
| pyasn1 | 0.6.4 | `BSD-2-Clause` | Ilya Etingof and contributors |
| python-multipart | 0.0.32 | `Apache-2.0` | Upstream authors and contributors |
| openpyxl | 3.1.5 | `MIT` | Upstream authors and contributors |
| et-xmlfile | 2.0.0 | `MIT` | Upstream authors and contributors |
| itsdangerous | 2.2.0 | `BSD-3-Clause` | Pallets and contributors |
| pydantic | 2.13.4 | `MIT` | Pydantic contributors |
| pydantic-core | 2.46.4 | `MIT` | Pydantic contributors |
| annotated-types | 0.7.0 | `MIT` | Upstream authors and contributors |
| typing-inspection | 0.4.2 | `MIT` | Pydantic contributors |
| typing-extensions | 4.16.0 | `PSF-2.0` | Python Software Foundation and contributors |
| annotated-doc | 0.0.4 | `MIT` | Upstream authors and contributors |
| python-dotenv | 1.2.2 | `BSD-3-Clause` | Upstream authors and contributors |
| ReportLab | 4.4.10 | `BSD-3-Clause` | ReportLab contributors |
| Pillow | 12.3.0 | `MIT-CMU` | Pillow contributors |
| charset-normalizer | 3.4.7 | `MIT` | Upstream authors and contributors |
| HTTPX | 0.28.1 | `BSD-3-Clause` | Encode contributors |
| HTTPCore | 1.0.9 | `BSD-3-Clause` | Encode contributors |
| AnyIO | 4.13.0 | `MIT` | AnyIO contributors |
| Certifi | 2026.5.20 | `MPL-2.0` | Certifi contributors |
| idna | 3.17 | `BSD-3-Clause` | IDNA contributors |
| h11 | 0.16.0 | `MIT` | h11 contributors |
| Starlette | 0.50.0 | `BSD-3-Clause` | Encode contributors |
| Click | 8.1.8 | `BSD-3-Clause` | Pallets and contributors |
| httptools | 0.8.0 | `MIT` | httptools contributors |
| uvloop | 0.22.1 | `MIT OR Apache-2.0` | uvloop contributors |
| watchfiles | 1.2.0 | `MIT` | watchfiles contributors |
| websockets | 16.0 | `BSD-3-Clause` | websockets contributors |
| colorama | 0.4.6 | `BSD-3-Clause` | colorama contributors |
| markdown-it-py | 4.2.0 | `MIT` | markdown-it-py contributors |
| mdurl | 0.1.2 | `MIT` | mdurl contributors |
| Pygments | 2.20.0 | `BSD-2-Clause` | Pygments contributors |
| tzdata | 2026.2 | `Apache-2.0` | Python Packaging Authority / IANA-derived timezone data |

## Important bundled-license notes

Some dependencies, including `cryptography`, `uvloop`, `httptools`, `ReportLab`, `tzdata` and `markdown-it-py`, carry multiple or additional bundled notices. Their component files under `THIRD_PARTY_LICENSES/` preserve the license material exposed by the installed upstream distribution where available.

PySNMP attribution includes Copyright (c) 1999-2020 Ilya Etingof, Copyright (c) 2022-2026 LeXtudio Inc., and other PySNMP contributors. PySNMP is distributed under the BSD 2-Clause license.

## License separation

Third-party notices and licenses apply only to their respective components. Portivo trademarks and branding are governed separately by `TRADEMARKS.md`. Nothing in this file changes the `AGPL-3.0-only` license of Portivo-owned source code.
