# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Dimitris Galatsanos
# Portivo Control Center Windows uninstaller

[CmdletBinding()]
param(
    [ValidateSet('Prompt','KeepData','Purge')][string]$Mode = 'Prompt',
    [switch]$Quiet,
    [switch]$TempCopy,
    [string]$AssetRoot = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$InstallRoot = 'C:\portivo-control-center'
$ServiceName = 'PortivoControlCenter'
$Port = 8766
$FirewallRuleName = "Portivo Control Center TCP $Port"
$UninstallRegistryKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PortivoControlCenter'
$LogPath = Join-Path $env:TEMP ("Portivo-Uninstall-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Write-UninstallLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Resolve branding assets before relocating the executable script to TEMP.
# The installed uninstaller directory is preferred; package assets are a fallback.
if ([string]::IsNullOrWhiteSpace($AssetRoot)) {
    $assetCandidates = @(
        (Join-Path $InstallRoot 'uninstall'),
        (Join-Path $PSScriptRoot 'assets'),
        $PSScriptRoot
    )
    foreach ($candidate in $assetCandidates) {
        if ((Test-Path (Join-Path $candidate 'portivo-logo-white.png')) -or (Test-Path (Join-Path $candidate 'portivo.ico'))) {
            $AssetRoot = $candidate
            break
        }
    }
}
$LogoPath = if ($AssetRoot) { Join-Path $AssetRoot 'portivo-logo-white.png' } else { '' }
$IconPath = if ($AssetRoot) { Join-Path $AssetRoot 'portivo.ico' } else { '' }

function Relaunch-FromTemp {
    $tempScript = Join-Path $env:TEMP ("Portivo-Uninstall-{0}.ps1" -f [guid]::NewGuid().ToString('N'))
    Copy-Item -Path $PSCommandPath -Destination $tempScript -Force
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$tempScript`"",'-Mode',$Mode,'-TempCopy','-AssetRoot',"`"$AssetRoot`"")
    if ($Quiet) { $args += '-Quiet' }
    $start = @{ FilePath='powershell.exe'; ArgumentList=$args; WorkingDirectory=$env:TEMP; Wait=$true }
    if (-not (Test-IsAdministrator)) { $start.Verb = 'RunAs' }
    Start-Process @start | Out-Null
    exit
}

# Always execute the destructive phase from a temporary copy. This allows the
# installed uninstaller directory and the whole application root to be removed.
if (-not $TempCopy) { Relaunch-FromTemp }
if (-not (Test-IsAdministrator)) { throw 'Administrator privileges are required to uninstall Portivo.' }

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

function Stop-And-Remove-Service {
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-UninstallLog "Stopping Windows Service $ServiceName."
        if ($service.Status -ne 'Stopped') {
            try {
                Stop-Service -Name $ServiceName -Force -ErrorAction Stop
                $service.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
            } catch {
                Write-UninstallLog "Service stop warning: $($_.Exception.Message)"
            }
        }
        & sc.exe delete $ServiceName | Out-Null
        for ($i = 0; $i -lt 40; $i++) {
            if (-not (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue)) { break }
            Start-Sleep -Milliseconds 500
        }
        if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
            throw 'The Portivo Windows Service could not be removed from Service Control Manager.'
        }
        Write-UninstallLog 'Windows Service registration removed.'
    }
}

function Stop-Stale-PortivoProcesses {
    foreach ($proc in @(Get-Process -ErrorAction SilentlyContinue)) {
        $path = $null
        try { $path = [string]$proc.Path } catch { }
        if ($path -and $path.StartsWith($InstallRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            try {
                Write-UninstallLog "Stopping stale Portivo process PID $($proc.Id): $path"
                Stop-Process -Id $proc.Id -Force -ErrorAction Stop
            } catch {
                Write-UninstallLog "Process cleanup warning for PID $($proc.Id): $($_.Exception.Message)"
            }
        }
    }
}

function Remove-PortivoFirewallRule {
    try {
        $rules = @(Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue)
        if ($rules.Count -gt 0) {
            $rules | Remove-NetFirewallRule -ErrorAction Stop
            Write-UninstallLog "Removed Windows Firewall rule '$FirewallRuleName'."
        }
    } catch {
        Write-UninstallLog "Firewall cleanup warning: $($_.Exception.Message)"
    }
}

function Remove-UninstallRegistration {
    try {
        if (Test-Path $UninstallRegistryKey) {
            Remove-Item -Path $UninstallRegistryKey -Recurse -Force
            Write-UninstallLog 'Removed Windows Installed Apps registration.'
        }
    } catch {
        Write-UninstallLog "Installed Apps cleanup warning: $($_.Exception.Message)"
    }
}

function New-FinalBackup {
    if (-not (Test-Path $InstallRoot)) { return $null }
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path $desktop)) { $desktop = $env:USERPROFILE }
    $zip = Join-Path $desktop ("Portivo-Final-Backup-{0}.zip" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $stage = Join-Path $env:TEMP ("PortivoFinalBackup-{0}" -f [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    try {
        foreach ($name in @('.env','data','backups')) {
            $source = Join-Path $InstallRoot $name
            if (Test-Path $source) { Copy-Item -Path $source -Destination (Join-Path $stage $name) -Recurse -Force }
        }
        Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal -Force
        Write-UninstallLog "Created final backup: $zip"
        return $zip
    } finally {
        Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Remove-ApplicationKeepData {
    if (-not (Test-Path $InstallRoot)) { return }
    $parent = Split-Path -Parent $InstallRoot
    $preserve = Join-Path $parent (".portivo-preserve-{0}" -f [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $preserve -Force | Out-Null
    $moved = @()
    try {
        foreach ($name in @('.env','data','backups')) {
            $source = Join-Path $InstallRoot $name
            if (Test-Path $source) {
                Move-Item -Path $source -Destination (Join-Path $preserve $name) -Force
                $moved += $name
            }
        }
        Remove-Item -Path $InstallRoot -Recurse -Force -ErrorAction Stop
        New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
        foreach ($name in $moved) {
            Move-Item -Path (Join-Path $preserve $name) -Destination (Join-Path $InstallRoot $name) -Force
        }
        @"
Portivo Control Center has been uninstalled.

Preserved for a future reinstall or recovery:
  .env
  data\
  backups\

Reinstall Portivo with the official installer to reuse this preserved state.
"@ | Set-Content -Path (Join-Path $InstallRoot 'PORTIVO-DATA-PRESERVED.txt') -Encoding UTF8
        Write-UninstallLog 'Application/runtime/logs removed; data, .env and backups preserved.'
    } catch {
        Write-UninstallLog "Keep-data removal failed: $($_.Exception.ToString())"
        if (-not (Test-Path $InstallRoot)) { New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null }
        foreach ($name in $moved) {
            $saved = Join-Path $preserve $name
            $target = Join-Path $InstallRoot $name
            if ((Test-Path $saved) -and -not (Test-Path $target)) {
                Move-Item -Path $saved -Destination $target -Force -ErrorAction SilentlyContinue
            }
        }
        throw
    } finally {
        Remove-Item $preserve -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Remove-ApplicationPurge {
    if (Test-Path $InstallRoot) {
        Remove-Item -Path $InstallRoot -Recurse -Force -ErrorAction Stop
        Write-UninstallLog 'Portivo application root and all local data were permanently removed.'
    }
}


$script:UiWindow = $null
$script:UiProgress = $null
$script:UiStatusText = $null
$script:UiDetailText = $null

function Set-UninstallStatus {
    param([int]$Percent, [string]$Status, [string]$Detail = '')
    if ($script:UiWindow -and $script:UiProgress -and $script:UiStatusText -and $script:UiDetailText) {
        $script:UiProgress.Value = $Percent
        $script:UiStatusText.Text = $Status
        if ($Detail) { $script:UiDetailText.Text = $Detail }
        $script:UiWindow.Dispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Render)
    }
    Write-UninstallLog ("STATUS {0}%: {1} - {2}" -f $Percent,$Status,$Detail)
}

function Invoke-PortivoUninstallCore {
    param(
        [ValidateSet('KeepData','Purge')][string]$SelectedMode,
        [bool]$CreateBackup = $false
    )
    $finalBackup = $null
    Write-UninstallLog "Portivo uninstall started. Mode=$SelectedMode"
    try {
        if ($SelectedMode -eq 'Purge' -and $CreateBackup) {
            Set-UninstallStatus 8 'Creating final backup...' 'Saving .env, data and backups to the Desktop before permanent removal.'
            $finalBackup = New-FinalBackup
        } else {
            Set-UninstallStatus 8 'Preparing removal...' 'Portivo is preparing the installed services and local application state.'
        }

        Set-UninstallStatus 20 'Stopping Portivo...' 'Stopping and removing the Portivo Windows Service registration.'
        Stop-And-Remove-Service

        Set-UninstallStatus 35 'Cleaning running processes...' 'Closing any remaining Portivo processes before files are removed.'
        Stop-Stale-PortivoProcesses

        Set-UninstallStatus 50 'Removing network integration...' 'Removing the Portivo Windows Firewall rule.'
        Remove-PortivoFirewallRule

        Set-UninstallStatus 62 'Removing Windows registration...' 'Removing Portivo Control Center from Windows Installed Apps.'
        Remove-UninstallRegistration

        if ($SelectedMode -eq 'Purge') {
            Set-UninstallStatus 78 'Removing Portivo and local data...' 'Permanently removing the application, configuration, credentials, database, logs and backups.'
            Remove-ApplicationPurge
        } else {
            Set-UninstallStatus 78 'Removing Portivo application...' 'Removing the application, private runtime and logs while preserving .env, data and backups.'
            Remove-ApplicationKeepData
        }

        Set-UninstallStatus 95 'Finalizing uninstall...' 'Verifying the removal workflow and preserved-state boundary.'
        if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
            throw 'The Portivo Windows Service is still registered after uninstall.'
        }
        if (Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue) {
            throw 'The Portivo Windows Firewall rule is still present after uninstall.'
        }
        if (Test-Path $UninstallRegistryKey) {
            throw 'The Portivo Installed Apps registration is still present after uninstall.'
        }
        if ($SelectedMode -eq 'Purge') {
            if (Test-Path $InstallRoot) { throw 'The Portivo installation root still exists after Full Removal.' }
        } else {
            $unexpected = @('run.py','runtime','service','logs','app','scripts','deployment','uninstall') | Where-Object { Test-Path (Join-Path $InstallRoot $_) }
            if ($unexpected.Count -gt 0) { throw "Application files remain after Standard uninstall: $($unexpected -join ', ')" }
        }

        Write-UninstallLog 'Portivo uninstall completed successfully.'
        $detail = if ($SelectedMode -eq 'Purge') {
            'Portivo Control Center and all local Portivo state were removed from this computer.'
        } else {
            "Portivo was removed successfully. Preserved state remains in $InstallRoot (.env, data and backups)."
        }
        if ($finalBackup) { $detail += " Final backup: $finalBackup" }
        Set-UninstallStatus 100 'Portivo was removed successfully.' $detail
        return @{ Ok=$true; Detail=$detail; Backup=$finalBackup }
    } catch {
        Write-UninstallLog "UNINSTALL FAILED: $($_.Exception.ToString())"
        Set-UninstallStatus 100 'Uninstall did not complete.' $_.Exception.Message
        return @{ Ok=$false; Detail=$_.Exception.Message; Backup=$finalBackup }
    }
}

function Get-InstalledPortivoVersion {
    $versionFile = Join-Path $InstallRoot 'VERSION'
    if (Test-Path $versionFile) {
        try { return (Get-Content $versionFile -Raw -ErrorAction Stop).Trim() } catch { }
    }
    return $null
}

function Set-WindowBitmapFromFile {
    param([System.Windows.Window]$Window, [string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path)) { return }
    try {
        $bytes = [IO.File]::ReadAllBytes($Path)
        $stream = New-Object IO.MemoryStream(,$bytes)
        try {
            $decoder = [Windows.Media.Imaging.BitmapDecoder]::Create(
                $stream,
                [Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat,
                [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            )
            if ($decoder.Frames.Count -gt 0) { $Window.Icon = $decoder.Frames[0] }
        } finally { $stream.Dispose() }
    } catch { Write-UninstallLog "Icon load warning: $($_.Exception.Message)" }
}

function Get-MemoryBitmap {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path)) { return $null }
    try {
        $bitmap = New-Object Windows.Media.Imaging.BitmapImage
        $bitmap.BeginInit()
        $bitmap.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bitmap.UriSource = [Uri]$Path
        $bitmap.EndInit()
        $bitmap.Freeze()
        return $bitmap
    } catch {
        Write-UninstallLog "Logo load warning: $($_.Exception.Message)"
        return $null
    }
}

function Show-PortivoUninstallWindow {
    $installedVersion = Get-InstalledPortivoVersion
    $versionLabel = if ($installedVersion) { "v$installedVersion" } else { 'Local installation' }
    $stateParts = @()
    if (Test-Path (Join-Path $InstallRoot '.env')) { $stateParts += '.env' }
    if (Test-Path (Join-Path $InstallRoot 'data')) { $stateParts += 'data' }
    if (Test-Path (Join-Path $InstallRoot 'backups')) { $stateParts += 'backups' }
    $stateLabel = if ($stateParts.Count -gt 0) { $stateParts -join ', ' } else { 'No preserved application state detected' }

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Portivo Control Center Uninstall" Height="680" Width="980" ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen" Background="#EEF2F8" FontFamily="Segoe UI"
        UseLayoutRounding="True" SnapsToDevicePixels="True">
  <Window.Resources>
    <Style x:Key="PrimaryActionButton" TargetType="Button">
      <Setter Property="Background" Value="#6F3FD4"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="BorderBrush" Value="#6F3FD4"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="ButtonChrome" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="7">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" Margin="14,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="ButtonChrome" Property="Background" Value="#5F35C5"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#5F35C5"/></Trigger>
              <Trigger Property="IsPressed" Value="True"><Setter TargetName="ButtonChrome" Property="Background" Value="#4F2BA8"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#4F2BA8"/></Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#8A63E6"/><Setter TargetName="ButtonChrome" Property="BorderThickness" Value="2"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="ButtonChrome" Property="Background" Value="#D9DDE7"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#D9DDE7"/><Setter Property="Foreground" Value="#8A94A7"/><Setter Property="Cursor" Value="Arrow"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="SecondaryActionButton" TargetType="Button">
      <Setter Property="Background" Value="#EEF2F8"/><Setter Property="Foreground" Value="#172033"/><Setter Property="BorderBrush" Value="#D8DFEA"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="ButtonChrome" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="7">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" Margin="14,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="ButtonChrome" Property="Background" Value="#E3E8F1"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#C7D0DF"/></Trigger>
              <Trigger Property="IsPressed" Value="True"><Setter TargetName="ButtonChrome" Property="Background" Value="#D7DEE9"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#B9C4D4"/></Trigger>
              <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#9A86C8"/><Setter TargetName="ButtonChrome" Property="BorderThickness" Value="2"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="ButtonChrome" Property="Background" Value="#F3F5F8"/><Setter TargetName="ButtonChrome" Property="BorderBrush" Value="#E1E5EC"/><Setter Property="Foreground" Value="#9AA3B2"/><Setter Property="Cursor" Value="Arrow"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>
  <Grid>
    <Grid.ColumnDefinitions><ColumnDefinition Width="340"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
    <Border Grid.Column="0" Padding="34">
      <Border.Background><LinearGradientBrush StartPoint="0,0" EndPoint="1,1"><GradientStop Color="#5C388D" Offset="0"/><GradientStop Color="#302244" Offset="1"/></LinearGradientBrush></Border.Background>
      <Grid>
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <Image x:Name="BrandLogo" Width="260" HorizontalAlignment="Left" Stretch="Uniform"/>
        <StackPanel Grid.Row="1" VerticalAlignment="Center">
          <TextBlock Text="REMOVE CLEANLY" Foreground="#D9D1EA" FontSize="13" FontWeight="SemiBold"/>
          <TextBlock Text="STAY IN CONTROL" Foreground="White" FontSize="32" FontWeight="Bold" Margin="0,2,0,18"/>
          <TextBlock Text="A guided Portivo removal with service cleanup, firewall cleanup and a safe choice to preserve or permanently remove local state." Foreground="#E9E3F2" FontSize="14" TextWrapping="Wrap" LineHeight="22"/>
        </StackPanel>
        <StackPanel Grid.Row="2">
          <TextBlock Text="PORTIVO WINDOWS UNINSTALL" Foreground="#BEB1D1" FontSize="11" FontWeight="SemiBold"/>
          <TextBlock Text="$versionLabel" Foreground="White" FontSize="14" FontWeight="Bold" Margin="0,5,0,0"/>
        </StackPanel>
      </Grid>
    </Border>
    <Border Grid.Column="1" Margin="24" Background="White" CornerRadius="18" Padding="30">
      <DockPanel LastChildFill="True">
        <!-- Docked first so the primary action is always visible, even at high DPI. -->
        <Grid DockPanel.Dock="Bottom" Height="42" Margin="0,18,0,0">
          <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="10"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
          <TextBlock x:Name="LogHint" Grid.Column="0" Text="" VerticalAlignment="Center" Foreground="#8A94A7" FontSize="10" TextTrimming="CharacterEllipsis" Margin="0,0,10,0"/>
          <Button x:Name="CloseButton" Grid.Column="1" Content="Cancel" Width="90" Height="38" Style="{StaticResource SecondaryActionButton}"/>
          <Button x:Name="UninstallButton" Grid.Column="3" Content="Uninstall Portivo" Width="145" Height="38" Style="{StaticResource PrimaryActionButton}"/>
        </Grid>

        <StackPanel DockPanel.Dock="Top" Margin="0,0,0,16">
          <TextBlock Text="Portivo Control Center" Foreground="#172033" FontSize="28" FontWeight="Bold"/>
          <TextBlock Text="Choose exactly what should remain on this computer." Foreground="#66758D" FontSize="13" Margin="0,7,0,0"/>
        </StackPanel>

        <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" PanningMode="VerticalOnly">
          <StackPanel Margin="0,0,4,0">
            <Border Background="#F6F3FC" BorderBrush="#E5DCF6" BorderThickness="1" CornerRadius="12" Padding="14">
              <Grid>
                <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                <StackPanel>
                  <TextBlock Text="INSTALLATION PATH" Foreground="#6F3FD4" FontSize="10" FontWeight="Bold"/>
                  <TextBlock Text="$InstallRoot" Foreground="#172033" FontSize="15" FontWeight="SemiBold" Margin="0,4,0,0"/>
                  <TextBlock Text="Detected local state: $stateLabel" Foreground="#66758D" FontSize="11" Margin="0,5,0,0"/>
                </StackPanel>
                <Border Grid.Column="1" Background="#E9E1F8" CornerRadius="9" Padding="11,7" VerticalAlignment="Center"><TextBlock Text="$versionLabel" Foreground="#5F35C5" FontWeight="Bold" FontSize="12"/></Border>
              </Grid>
            </Border>

            <StackPanel x:Name="ModePanel" Margin="0,17,0,0">
              <TextBlock Text="REMOVAL MODE" Foreground="#172033" FontSize="12" FontWeight="Bold" Margin="0,0,0,8"/>
              <Border x:Name="KeepCard" Background="#FAFBFD" BorderBrush="#D9E0EA" BorderThickness="1" CornerRadius="10" Padding="12" Cursor="Hand">
                <Grid><RadioButton x:Name="KeepRadio" IsChecked="True" GroupName="Mode" VerticalAlignment="Top" Margin="0,2,0,0"/><StackPanel Margin="28,0,0,0"><TextBlock Text="Standard uninstall - keep data" Foreground="#172033" FontSize="13" FontWeight="SemiBold"/><TextBlock Text="Removes the application, Windows Service, private Python runtime, firewall rule and logs. Keeps .env, data and backups for a future reinstall." Foreground="#66758D" FontSize="10.5" TextWrapping="Wrap" LineHeight="16" Margin="0,4,0,0"/></StackPanel></Grid>
              </Border>
              <Border x:Name="PurgeCard" Background="#FFF9F8" BorderBrush="#F1D4CF" BorderThickness="1" CornerRadius="10" Padding="12" Margin="0,8,0,0" Cursor="Hand">
                <Grid><RadioButton x:Name="PurgeRadio" GroupName="Mode" VerticalAlignment="Top" Margin="0,2,0,0"/><StackPanel Margin="28,0,0,0"><TextBlock Text="Full removal / purge" Foreground="#8F2D22" FontSize="13" FontWeight="SemiBold"/><TextBlock Text="Permanently removes Portivo plus local credentials, configuration, database and backups. This action cannot be undone." Foreground="#9B4A40" FontSize="10.5" TextWrapping="Wrap" LineHeight="16" Margin="0,4,0,0"/><CheckBox x:Name="BackupCheck" IsEnabled="False" Content="Create a final backup on the Desktop before purge" Foreground="#633A35" Margin="0,6,0,0"/></StackPanel></Grid>
              </Border>
            </StackPanel>

            <StackPanel Margin="0,16,0,0">
              <TextBlock x:Name="StatusText" Text="Ready to uninstall." Foreground="#172033" FontSize="12" FontWeight="SemiBold"/>
              <ProgressBar x:Name="Progress" Height="8" Margin="0,8,0,0" Minimum="0" Maximum="100" Value="0" Foreground="#6F3FD4" Background="#E8ECF3"/>
              <TextBlock x:Name="DetailText" Text="Standard uninstall is selected. Your Portivo configuration and data will be preserved for recovery or a later reinstall." Foreground="#66758D" FontSize="10.5" TextWrapping="Wrap" LineHeight="17" MinHeight="38" Margin="0,8,0,2"/>
            </StackPanel>
          </StackPanel>
        </ScrollViewer>
      </DockPanel>
    </Border>
  </Grid>
</Window>
"@

    $reader = New-Object System.Xml.XmlNodeReader $xaml
    $window = [Windows.Markup.XamlReader]::Load($reader)
    Set-WindowBitmapFromFile -Window $window -Path $IconPath
    $brand = $window.FindName('BrandLogo')
    $logo = Get-MemoryBitmap $LogoPath
    if ($logo) { $brand.Source = $logo }

    $keepRadio = $window.FindName('KeepRadio')
    $purgeRadio = $window.FindName('PurgeRadio')
    $keepCard = $window.FindName('KeepCard')
    $purgeCard = $window.FindName('PurgeCard')
    $backupCheck = $window.FindName('BackupCheck')
    $modePanel = $window.FindName('ModePanel')
    $progress = $window.FindName('Progress')
    $statusText = $window.FindName('StatusText')
    $detailText = $window.FindName('DetailText')
    $closeButton = $window.FindName('CloseButton')
    $uninstallButton = $window.FindName('UninstallButton')
    $logHint = $window.FindName('LogHint')

    $script:UiWindow = $window
    $script:UiProgress = $progress
    $script:UiStatusText = $statusText
    $script:UiDetailText = $detailText

    $keepCard.Add_MouseLeftButtonDown({ $keepRadio.IsChecked = $true })
    $purgeCard.Add_MouseLeftButtonDown({ $purgeRadio.IsChecked = $true })
    $purgeRadio.Add_Checked({
        $backupCheck.IsEnabled = $true
        $detailText.Text = 'Full Removal is selected. Portivo configuration, credentials, database and backups will be permanently deleted after confirmation.'
    })
    $keepRadio.Add_Checked({
        $backupCheck.IsEnabled = $false
        $backupCheck.IsChecked = $false
        $detailText.Text = 'Standard uninstall is selected. Your Portivo configuration and data will be preserved for recovery or a later reinstall.'
    })

    $closeButton.Add_Click({ $window.Close() })
    $uninstallButton.Add_Click({
        $selectedMode = if ($purgeRadio.IsChecked) { 'Purge' } else { 'KeepData' }
        $createBackup = [bool]$backupCheck.IsChecked
        if ($selectedMode -eq 'Purge') {
            $answer = [System.Windows.MessageBox]::Show(
                "Full Removal permanently deletes Portivo credentials, configuration, database and backups.`n`nThis action cannot be undone. Continue?",
                'Confirm Portivo Full Removal', 'YesNo', 'Warning')
            if ($answer -ne 'Yes') { return }
        }

        $modePanel.IsEnabled = $false
        $uninstallButton.IsEnabled = $false
        $closeButton.IsEnabled = $false
        $closeButton.Content = 'Close'
        $logHint.Text = "Log: $LogPath"
        $result = Invoke-PortivoUninstallCore -SelectedMode $selectedMode -CreateBackup $createBackup
        if ($result.Ok) {
            $uninstallButton.Visibility = 'Collapsed'
            $closeButton.IsEnabled = $true
            $modePanel.Opacity = 0.58
        } else {
            $uninstallButton.IsEnabled = $true
            $closeButton.IsEnabled = $true
            $modePanel.IsEnabled = $true
        }
    })

    $window.ShowDialog() | Out-Null
}

function Schedule-TempSelfCleanup {
    if ($TempCopy) {
        $self = $PSCommandPath
        try {
            Start-Process -FilePath 'cmd.exe' -WindowStyle Hidden -ArgumentList '/c',("ping 127.0.0.1 -n 3 >nul & del /f /q `"{0}`"" -f $self) | Out-Null
        } catch { }
    }
}

try {
    if ($Mode -eq 'Prompt' -and -not $Quiet) {
        Show-PortivoUninstallWindow
    } else {
        $selected = if ($Mode -eq 'Purge') { 'Purge' } else { 'KeepData' }
        $result = Invoke-PortivoUninstallCore -SelectedMode $selected -CreateBackup:$false
        if (-not $result.Ok) { exit 1 }
    }
} finally {
    Schedule-TempSelfCleanup
}
