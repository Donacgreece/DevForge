# Contributing to Portivo

Portivo currently does **not** accept external code contributions or pull requests. This keeps copyright ownership and future licensing options clear while the project is in its initial public-release phase.

Bug reports, hardware and firmware compatibility reports, documentation corrections and feature requests are welcome through GitHub Issues once the public repository is available.

Please do not submit code patches or pull requests unless this policy is changed explicitly. If Portivo begins accepting code contributions in the future, an updated contribution and licensing policy will be published first.

Do not publish credentials, private keys, configuration exports, customer data or unpatched security details in a public issue. Use the repository's private security-reporting channel when available.

Portivo-owned source code is licensed under **GNU AGPL v3.0 only** (`AGPL-3.0-only`). See `LICENSE` and `LEGAL.md`.
