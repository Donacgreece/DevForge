# Portivo Control Center Legal Notice

Copyright (C) 2026 Dimitris Galatsanos. All copyright in Portivo-owned source code is retained by the copyright holder.

## License

Portivo-owned source code is licensed under the **GNU Affero General Public License v3.0 only** (`AGPL-3.0-only`). You may copy, modify and redistribute Portivo under the terms of that license. The complete license text is included in `LICENSE`.

This software is provided **without warranty**, to the extent permitted by applicable law. See Sections 15 and 16 of the GNU AGPL v3.0 for the full warranty and liability terms.

## Corresponding source

For installer or binary releases, Portivo publishes an exact-version source archive as a separate release asset alongside the installer. The running web application also exposes **Source code** from the More workspace and login footer, which generates a secret-safe source archive for the exact installed release.

The corresponding-source archive excludes runtime secrets and operational data such as `.env`, databases, logs, backups, private keys and certificates. It includes application source, build/install scripts, dependency policy and lock files, license material, SBOM, documentation and required static/configuration data.

## Third-party software

Third-party components retain their own licenses. See `THIRD_PARTY_NOTICES.md`, `THIRD_PARTY_LICENSES/` and `SBOM.spdx.json`. These licenses are not replaced by the Portivo AGPL license.

## Trademarks

The GNU AGPL applies to copyright permissions for Portivo-owned source code. It does not grant unrestricted rights to the Portivo name, logo or branding. See `TRADEMARKS.md`.
